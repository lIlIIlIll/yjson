# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.601 us | 57.419 us | 3.005 us | 3.478 us | 2.474 us | 0.170 us | 0.066 us | 14.30% |
| address_decode | 0.832 us | 37.188 us | 3.507 us | 3.435 us | 2.045 us | 0.326 us | 0.069 us | 12.81% |
| person_encode | 3.961 us | 95.744 us | 18.064 us | 5.461 us | 10.868 us | 0.570 us | 0.257 us | 15.79% |
| person_decode | 10.322 us | 94.208 us | 29.881 us | 20.118 us | 15.425 us | 1.130 us | 0.429 us | 17.37% |
| large_array_encode | 33.635 us | 496.585 us | 250.688 us | 91.608 us | 75.886 us | 8.952 us | 3.951 us | 10.55% |
| large_array_decode | 52.260 us | 1023.407 us | 406.700 us | 178.300 us | 78.144 us | 18.819 us | 5.049 us | 9.04% |
| large_map_encode | 7.137 us | 284.526 us | 171.994 us | 128.023 us | 131.334 us | 1.839 us | 1.730 us | 5.74% |
| large_map_decode | 28.507 us | 587.331 us | 342.529 us | 223.027 us | 231.305 us | 5.452 us | 4.138 us | 9.84% |
| deep_nested_encode | 42.988 us | 356.786 us | 170.739 us | 85.532 us | 74.208 us | 4.520 us | 2.593 us | 11.05% |
| deep_nested_decode | 66.812 us | 643.928 us | 256.894 us | 142.336 us | 96.199 us | 10.541 us | 3.462 us | 33.99% |
