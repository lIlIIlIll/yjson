# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.611 us | 56.948 us | 3.097 us | 3.471 us | 2.471 us | 0.170 us | 0.067 us | 14.67% |
| address_decode | 0.776 us | 37.205 us | 3.433 us | 3.438 us | 2.041 us | 0.321 us | 0.069 us | 11.48% |
| person_encode | 3.922 us | 95.700 us | 16.788 us | 5.425 us | 10.284 us | 0.566 us | 0.256 us | 16.04% |
| person_decode | 10.167 us | 93.739 us | 29.100 us | 20.003 us | 15.707 us | 1.133 us | 0.430 us | 9.07% |
| large_array_encode | 33.536 us | 552.568 us | 249.626 us | 91.447 us | 75.910 us | 8.921 us | 3.720 us | 7.81% |
| large_array_decode | 50.432 us | 1035.366 us | 415.140 us | 175.467 us | 78.027 us | 18.998 us | 5.053 us | 6.64% |
| large_map_encode | 7.109 us | 304.432 us | 161.078 us | 128.235 us | 131.101 us | 1.752 us | 1.728 us | 10.29% |
| large_map_decode | 28.564 us | 584.020 us | 337.328 us | 222.829 us | 232.171 us | 5.404 us | 4.118 us | 14.44% |
| deep_nested_encode | 46.592 us | 366.702 us | 171.247 us | 84.907 us | 74.496 us | 4.487 us | 2.596 us | 11.64% |
| deep_nested_decode | 81.797 us | 628.928 us | 253.308 us | 142.592 us | 95.616 us | 10.598 us | 3.470 us | 33.04% |
