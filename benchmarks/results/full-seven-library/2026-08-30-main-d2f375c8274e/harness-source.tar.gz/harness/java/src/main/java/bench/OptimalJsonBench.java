package bench;

import com.alibaba.fastjson2.JSONFactory;
import com.alibaba.fastjson2.JSONReader;
import com.alibaba.fastjson2.JSONWriter;
import com.alibaba.fastjson2.TypeReference;
import com.alibaba.fastjson2.annotation.JSONField;
import com.alibaba.fastjson2.reader.ObjectReader;
import com.alibaba.fastjson2.writer.ObjectWriter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.openjdk.jmh.annotations.*;

import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 11, time = 1)
@Fork(value = 1, jvmArgsAppend = {"-Xms128m", "-Xmx128m", "-XX:+AlwaysPreTouch"})
@State(Scope.Thread)
public class OptimalJsonBench {
    private static final long WRITE_FEATURES = JSONWriter.Feature.WriteNulls.mask;
    private static final long READ_FEATURES = 0L;

    private final ObjectMapper jackson = new ObjectMapper();
    private Address address;
    private Person person;
    private List<ProfileRecord> profiles;
    private LinkedHashMap<String, Long> int64Map;
    private List<Map<String, List<ProfileRecord>>> deepNested;

    private String addressText;
    private String personText;
    private String profilesText;
    private String int64MapText;
    private String deepNestedText;

    private com.fasterxml.jackson.databind.ObjectWriter jacksonAddressWriter;
    private com.fasterxml.jackson.databind.ObjectWriter jacksonPersonWriter;
    private com.fasterxml.jackson.databind.ObjectWriter jacksonProfilesWriter;
    private com.fasterxml.jackson.databind.ObjectWriter jacksonMapWriter;
    private com.fasterxml.jackson.databind.ObjectWriter jacksonDeepWriter;
    private com.fasterxml.jackson.databind.ObjectReader jacksonAddressReader;
    private com.fasterxml.jackson.databind.ObjectReader jacksonPersonReader;
    private com.fasterxml.jackson.databind.ObjectReader jacksonProfilesReader;
    private com.fasterxml.jackson.databind.ObjectReader jacksonMapReader;
    private com.fasterxml.jackson.databind.ObjectReader jacksonDeepReader;

    private ObjectWriter fastAddressWriter;
    private ObjectWriter fastPersonWriter;
    private ObjectWriter fastProfilesWriter;
    private ObjectWriter fastMapWriter;
    private ObjectWriter fastDeepWriter;
    private ObjectReader fastAddressReader;
    private ObjectReader fastPersonReader;
    private ObjectReader fastProfilesReader;
    private ObjectReader fastMapReader;
    private ObjectReader fastDeepReader;
    private Type profilesType;
    private Type mapType;
    private Type deepType;

    @Setup(Level.Trial)
    public void setup() throws Exception {
        address = new Address("Nanshan Road", 518000L);
        person = samplePerson();
        profiles = sampleProfiles(64);
        int64Map = sampleInt64Map(64);
        deepNested = sampleDeepNested();

        com.fasterxml.jackson.core.type.TypeReference<List<ProfileRecord>> jacksonProfilesType =
            new com.fasterxml.jackson.core.type.TypeReference<List<ProfileRecord>>() {};
        com.fasterxml.jackson.core.type.TypeReference<LinkedHashMap<String, Long>> jacksonMapType =
            new com.fasterxml.jackson.core.type.TypeReference<LinkedHashMap<String, Long>>() {};
        com.fasterxml.jackson.core.type.TypeReference<List<Map<String, List<ProfileRecord>>>> jacksonDeepType =
            new com.fasterxml.jackson.core.type.TypeReference<List<Map<String, List<ProfileRecord>>>>() {};

        jacksonAddressWriter = jackson.writerFor(Address.class);
        jacksonPersonWriter = jackson.writerFor(Person.class);
        jacksonProfilesWriter = jackson.writerFor(jacksonProfilesType);
        jacksonMapWriter = jackson.writerFor(jacksonMapType);
        jacksonDeepWriter = jackson.writerFor(jacksonDeepType);
        jacksonAddressReader = jackson.readerFor(Address.class);
        jacksonPersonReader = jackson.readerFor(Person.class);
        jacksonProfilesReader = jackson.readerFor(jacksonProfilesType);
        jacksonMapReader = jackson.readerFor(jacksonMapType);
        jacksonDeepReader = jackson.readerFor(jacksonDeepType);

        profilesType = new TypeReference<List<ProfileRecord>>() {}.getType();
        mapType = new TypeReference<LinkedHashMap<String, Long>>() {}.getType();
        deepType = new TypeReference<List<Map<String, List<ProfileRecord>>>>() {}.getType();
        fastAddressWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(Address.class, Address.class, false);
        fastPersonWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(Person.class, Person.class, false);
        fastProfilesWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(profilesType, profiles.getClass(), false);
        fastMapWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(mapType, int64Map.getClass(), false);
        fastDeepWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(deepType, deepNested.getClass(), false);
        fastAddressReader = JSONFactory.getDefaultObjectReaderProvider().getObjectReader(Address.class, false);
        fastPersonReader = JSONFactory.getDefaultObjectReaderProvider().getObjectReader(Person.class, false);
        fastProfilesReader = JSONFactory.getDefaultObjectReaderProvider().getObjectReader(profilesType, false);
        fastMapReader = JSONFactory.getDefaultObjectReaderProvider().getObjectReader(mapType, false);
        fastDeepReader = JSONFactory.getDefaultObjectReaderProvider().getObjectReader(deepType, false);

        addressText = canonicalAddressJsonText();
        personText = canonicalPersonJsonText();
        profilesText = canonicalLargeProfilesJsonText();
        int64MapText = canonicalLargeInt64MapJsonText();
        deepNestedText = canonicalDeepNestedProfilesJsonText();

        require(jacksonAddressReader.<Address>readValue(addressText).zipcode == 518000L, "jackson address");
        require(jacksonPersonReader.<Person>readValue(personText).id == 42L, "jackson person");
        require(jacksonProfilesReader.<List<ProfileRecord>>readValue(profilesText).size() == 64, "jackson array");
        require(jacksonMapReader.<Map<String, Long>>readValue(int64MapText).get("metric_32") == 547L, "jackson map");
        require(jacksonDeepReader.<List<?>>readValue(deepNestedText).size() == 8, "jackson deep");
        require(((Address) readFast(fastAddressReader, Address.class, addressText)).zipcode == 518000L, "fastjson2 address");
        require(((Person) readFast(fastPersonReader, Person.class, personText)).id == 42L, "fastjson2 person");
        require(((List<?>) readFast(fastProfilesReader, profilesType, profilesText)).size() == 64, "fastjson2 array");
        require(((Map<?, ?>) readFast(fastMapReader, mapType, int64MapText)).get("metric_32").equals(547L), "fastjson2 map");
        require(((List<?>) readFast(fastDeepReader, deepType, deepNestedText)).size() == 8, "fastjson2 deep");
    }

    @Benchmark public String jacksonEncodeAddress() throws Exception { return jacksonAddressWriter.writeValueAsString(address); }
    @Benchmark public Object jacksonDecodeAddress() throws Exception { return jacksonAddressReader.readValue(addressText); }
    @Benchmark public String jacksonEncodePerson() throws Exception { return jacksonPersonWriter.writeValueAsString(person); }
    @Benchmark public Object jacksonDecodePerson() throws Exception { return jacksonPersonReader.readValue(personText); }
    @Benchmark public String jacksonEncodeLargeProfileArray() throws Exception { return jacksonProfilesWriter.writeValueAsString(profiles); }
    @Benchmark public Object jacksonDecodeLargeProfileArray() throws Exception { return jacksonProfilesReader.readValue(profilesText); }
    @Benchmark public String jacksonEncodeLargeInt64Map() throws Exception { return jacksonMapWriter.writeValueAsString(int64Map); }
    @Benchmark public Object jacksonDecodeLargeInt64Map() throws Exception { return jacksonMapReader.readValue(int64MapText); }
    @Benchmark public String jacksonEncodeDeepNestedProfiles() throws Exception { return jacksonDeepWriter.writeValueAsString(deepNested); }
    @Benchmark public Object jacksonDecodeDeepNestedProfiles() throws Exception { return jacksonDeepReader.readValue(deepNestedText); }

    @Benchmark public String fastjson2EncodeAddress() { return writeFast(fastAddressWriter, address, Address.class); }
    @Benchmark public Object fastjson2DecodeAddress() { return readFast(fastAddressReader, Address.class, addressText); }
    @Benchmark public String fastjson2EncodePerson() { return writeFast(fastPersonWriter, person, Person.class); }
    @Benchmark public Object fastjson2DecodePerson() { return readFast(fastPersonReader, Person.class, personText); }
    @Benchmark public String fastjson2EncodeLargeProfileArray() { return writeFast(fastProfilesWriter, profiles, profilesType); }
    @Benchmark public Object fastjson2DecodeLargeProfileArray() { return readFast(fastProfilesReader, profilesType, profilesText); }
    @Benchmark public String fastjson2EncodeLargeInt64Map() { return writeFast(fastMapWriter, int64Map, mapType); }
    @Benchmark public Object fastjson2DecodeLargeInt64Map() { return readFast(fastMapReader, mapType, int64MapText); }
    @Benchmark public String fastjson2EncodeDeepNestedProfiles() { return writeFast(fastDeepWriter, deepNested, deepType); }
    @Benchmark public Object fastjson2DecodeDeepNestedProfiles() { return readFast(fastDeepReader, deepType, deepNestedText); }

    private static String writeFast(ObjectWriter objectWriter, Object value, Type type) {
        try (JSONWriter writer = JSONWriter.of()) {
            objectWriter.write(writer, value, null, type, WRITE_FEATURES);
            return writer.toString();
        }
    }

    private static Object readFast(ObjectReader objectReader, Type type, String text) {
        try (JSONReader reader = JSONReader.of(text)) {
            return objectReader.readObject(reader, type, null, READ_FEATURES);
        }
    }

    private static String canonicalAddressJsonText() {
        return "{\"street_name\":\"Nanshan Road\",\"zipcode\":518000}";
    }

    private static String canonicalPersonJsonText() {
        return "{\"user_id\":42,\"name\":\"Lin\",\"age\":28," +
            "\"tags\":[\"cangjie\",\"json\",\"reflect\"]," +
            "\"scores\":{\"math\":95,\"english\":88}," +
            "\"address\":" + canonicalAddressJsonText() + ",\"nick\":null}";
    }

    private static String canonicalLargeProfilesJsonText() {
        StringBuilder text = new StringBuilder("[");
        for (int index = 0; index < 64; index++) {
            if (index > 0) text.append(',');
            text.append("{\"profile_id\":").append(10000 + index)
                .append(",\"alias\":\"alias-").append(index % 16)
                .append("-json-escape\",\"level\":").append(index % 10).append('}');
        }
        return text.append(']').toString();
    }

    private static String canonicalLargeInt64MapJsonText() {
        StringBuilder text = new StringBuilder("{");
        for (int index = 0; index < 64; index++) {
            if (index > 0) text.append(',');
            text.append("\"metric_").append(index).append("\":").append(index * 17L + 3L);
        }
        return text.append('}').toString();
    }

    private static String canonicalDeepNestedProfilesJsonText() {
        StringBuilder text = new StringBuilder("[");
        for (int groupIndex = 0; groupIndex < 8; groupIndex++) {
            if (groupIndex > 0) text.append(',');
            text.append("{\"group_").append(groupIndex).append("\":[");
            for (int recordIndex = 0; recordIndex < 4; recordIndex++) {
                if (recordIndex > 0) text.append(',');
                text.append("{\"profile_id\":").append(groupIndex * 100 + recordIndex)
                    .append(",\"alias\":\"group-").append(groupIndex).append("-profile-")
                    .append(recordIndex).append("\",\"level\":")
                    .append((groupIndex + recordIndex) % 10).append('}');
            }
            text.append("]}");
        }
        return text.append(']').toString();
    }

    private static Person samplePerson() {
        LinkedHashMap<String, Long> scores = new LinkedHashMap<>();
        scores.put("math", 95L);
        scores.put("english", 88L);
        return new Person(42L, "Lin", 28, new ArrayList<>(Arrays.asList("cangjie", "json", "reflect")), scores,
            new Address("Nanshan Road", 518000L), null);
    }

    private static List<ProfileRecord> sampleProfiles(int count) {
        List<ProfileRecord> values = new ArrayList<>(count);
        for (int index = 0; index < count; index++) {
            values.add(new ProfileRecord(10000L + index, "alias-" + (index % 16) + "-json-escape", index % 10));
        }
        return values;
    }

    private static LinkedHashMap<String, Long> sampleInt64Map(int count) {
        LinkedHashMap<String, Long> values = new LinkedHashMap<>(count);
        for (int index = 0; index < count; index++) values.put("metric_" + index, index * 17L + 3L);
        return values;
    }

    private static List<Map<String, List<ProfileRecord>>> sampleDeepNested() {
        List<Map<String, List<ProfileRecord>>> values = new ArrayList<>(8);
        for (int groupIndex = 0; groupIndex < 8; groupIndex++) {
            LinkedHashMap<String, List<ProfileRecord>> group = new LinkedHashMap<>();
            List<ProfileRecord> records = new ArrayList<>(4);
            for (int recordIndex = 0; recordIndex < 4; recordIndex++) {
                records.add(new ProfileRecord(groupIndex * 100L + recordIndex,
                    "group-" + groupIndex + "-profile-" + recordIndex, (groupIndex + recordIndex) % 10));
            }
            group.put("group_" + groupIndex, records);
            values.add(group);
        }
        return values;
    }

    private static void require(boolean condition, String label) {
        if (!condition) throw new IllegalStateException(label);
    }

    public static final class Address {
        @JsonProperty("street_name") @JSONField(name = "street_name") public String street;
        public long zipcode;
        public Address() {}
        public Address(String street, long zipcode) { this.street = street; this.zipcode = zipcode; }
    }

    public static final class Person {
        @JsonProperty("user_id") @JSONField(name = "user_id") public long id;
        public String name;
        public int age;
        public List<String> tags;
        public Map<String, Long> scores;
        public Address address;
        public String nick;
        public Person() {}
        public Person(long id, String name, int age, List<String> tags, Map<String, Long> scores, Address address, String nick) {
            this.id = id; this.name = name; this.age = age; this.tags = tags; this.scores = scores; this.address = address; this.nick = nick;
        }
    }

    public static final class ProfileRecord {
        @JsonProperty("profile_id") @JSONField(name = "profile_id") public long id;
        public String alias;
        public int level;
        public ProfileRecord() {}
        public ProfileRecord(long id, String alias, int level) { this.id = id; this.alias = alias; this.level = level; }
    }
}
