#!/usr/bin/env bash
set -euo pipefail

ROOT=/tmp/yjson-full-benchmark-main-d2f375c8274e-20260830
source "$ROOT/harness/benchmark_env.sh"
mkdir -p "$ROOT/canonical-build-logs"

(
  cd "$ROOT/repo/packages/benchmarks"
  cjpm bench --no-color --filter 'ComprehensiveJsonCompareBenchmarks.yjsonStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/yjson-stdx.log" 2>&1

(
  cd "$ROOT/harness/cjjson"
  cjpm bench --no-color --filter 'CangjieJsonOptimalBenchmarks.cjjsonStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/cangjiejson.log" 2>&1

(
  cd "$ROOT/harness/json4cj"
  cjpm bench --no-color --filter 'Json4CjOptimalBenchmarks.json4cjStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/json4cj.log" 2>&1

(
  cd "$ROOT/cjfast-json"
  cjpm bench --no-color --filter 'CjFastJsonComprehensiveBenchmarks.cjfastStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/cjfast-json.log" 2>&1

(
  cd "$ROOT/harness/java"
  mvn -q package
) >"$ROOT/canonical-build-logs/java.log" 2>&1

printf 'canonical harnesses rebuilt and validated\n'
