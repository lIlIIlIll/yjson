#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/tmp/yjson-full-benchmark-main-d2f375c8274e-20260830")

WORKLOADS = [
    ("address_encode", "Address", "encode", "Address", "EncodeAddress"),
    ("address_decode", "Address", "decode", "Address", "DecodeAddress"),
    ("person_encode", "Person", "encode", "Person", "EncodePerson"),
    ("person_decode", "Person", "decode", "Person", "DecodePerson"),
    ("large_array_encode", "Large Array", "encode", "ArrayList<ProfileRecord>[64]", "EncodeLargeProfileArray"),
    ("large_array_decode", "Large Array", "decode", "ArrayList<ProfileRecord>[64]", "DecodeLargeProfileArray"),
    ("large_map_encode", "Large Map", "encode", "HashMap<String, Int64>[64]", "EncodeLargeInt64Map"),
    ("large_map_decode", "Large Map", "decode", "HashMap<String, Int64>[64]", "DecodeLargeInt64Map"),
    ("deep_nested_encode", "Deep Nested", "encode", "ArrayList<HashMap<String, ArrayList<ProfileRecord>>>", "EncodeDeepNestedProfiles"),
    ("deep_nested_decode", "Deep Nested", "decode", "ArrayList<HashMap<String, ArrayList<ProfileRecord>>>", "DecodeDeepNestedProfiles"),
]

LIBRARIES = [
    "yjson", "stdx_json", "cangjieJSON", "json4cj", "cjfast_json", "jackson", "fastjson2"
]

CANGJIE = {
    "yjson": (ROOT / "repo/packages/benchmarks", "ComprehensiveJsonCompareBenchmarks", "yjsonString"),
    "stdx_json": (ROOT / "repo/packages/benchmarks", "ComprehensiveJsonCompareBenchmarks", "stdxString"),
    "cangjieJSON": (ROOT / "harness/cjjson", "CangjieJsonOptimalBenchmarks", "cjjsonString"),
    "json4cj": (ROOT / "harness/json4cj", "Json4CjOptimalBenchmarks", "json4cjString"),
    "cjfast_json": (ROOT / "cjfast-json", "CjFastJsonComprehensiveBenchmarks", "cjfastString"),
}

JAVA = {
    "jackson": "jackson",
    "fastjson2": "fastjson2",
}


def source_digest(root: Path) -> str:
    digest = hashlib.sha256()
    paths = []
    for current, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", "build-script-cache"}]
        for name in files:
            path = Path(current) / name
            if path.suffix in {".cj", ".toml", ".java", ".xml"}:
                paths.append(path)
    for path in sorted(paths):
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def capture(command: list[str], cwd: Path, env: dict[str, str]) -> str:
    return subprocess.run(command, cwd=cwd, env=env, check=True, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout.strip()


def order(items: list, round_id: int) -> list:
    offset = (round_id - 1) % len(items)
    rotated = items[offset:] + items[:offset]
    return rotated if round_id % 2 else list(reversed(rotated))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--runs", type=int, default=11)
    parser.add_argument("--cpu", type=int, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        parser.error(f"output directory is not empty: {output}")
    raw = output / "raw"
    logs = output / "logs"
    raw.mkdir(parents=True)
    logs.mkdir(parents=True)

    env = os.environ.copy()
    env["cjHeapSize"] = "128MB"
    env["LC_ALL"] = "C"
    cpu_selection = json.loads((ROOT / "cpu-selection.json").read_text())
    if args.cpu != cpu_selection["selected_cpu"] or not cpu_selection["acceptable_both_threads_below_1_percent"]:
        raise SystemExit("selected CPU does not match an acceptable 30-second idle-core sample")

    metadata = {
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "host": platform.node(),
        "platform": platform.platform(),
        "cpu_selection": cpu_selection,
        "heap": "128MB",
        "runs": args.runs,
        "schedule": "workload and seven-library order rotate; even rounds reverse workload order",
        "jmh": "1 fork per outer round, 3x500ms warmup, 1x1s measurement, avgt ns/op",
        "cangjie_bench": "200ms warmup, >=1s duration, >=12 batches, csv-raw",
        "api_policy": "fastest semantically equivalent public typed API; no DOM fallback when a direct typed path exists",
        "canonical_decode_payload_bytes": {
            "Address": 47,
            "Person": 176,
            "ArrayList<ProfileRecord>[64]": 3929,
            "HashMap<String, Int64>[64]": 1013,
            "ArrayList<HashMap<String, ArrayList<ProfileRecord>>>": 1929,
        },
        "versions": {
            "yjson_commit": capture(["git", "rev-parse", "HEAD"], ROOT / "repo", env),
            "cangjieJSON_branch_commit": "910fd9c61858f33b242a0076c22b2e06c8073511",
            "cjfast_json_commit": capture(["git", "rev-parse", "HEAD"], ROOT / "cjfast-json", env),
            "json4cj_source_tree_sha256": source_digest(Path("/tmp/yjson-full-benchmark-main-d2f375c8274e-20260830/json4cj")),
            "cangjieJSON_source_tree_sha256": source_digest(ROOT / "cangjieJSON-upstream"),
            "cjc": capture(["cjc", "-v"], ROOT / "repo", env),
            "cjpm": capture(["cjpm", "--version"], ROOT / "repo", env),
            "java": capture(["java", "-version"], ROOT / "harness/java", env),
            "jmh": "1.37", "jackson": "2.18.2", "fastjson2": "2.0.52",
            "stdx_json_ffi_sha256": file_digest(Path("/home/chenqian/fastjson-bench-sdk-20260803/linux_x86_64_cjnative/static/stdx/libstdx.encoding.jsonFFI.a")),
            "stdx_json_stream_ffi_sha256": file_digest(Path("/home/chenqian/fastjson-bench-sdk-20260803/linux_x86_64_cjnative/static/stdx/libstdx.encoding.json.streamFFI.a")),
        },
        "source_sha256": {
            "yjson": source_digest(ROOT / "repo"),
            "cangjieJSON_harness": source_digest(ROOT / "harness/cjjson"),
            "json4cj_harness": source_digest(ROOT / "harness/json4cj"),
            "cjfast_json": source_digest(ROOT / "cjfast-json"),
            "java_harness": source_digest(ROOT / "harness/java"),
        },
        "lscpu": capture(["lscpu"], ROOT, env),
        "affinity_probe": capture(["taskset", "-c", str(args.cpu), "sh", "-c", "grep Cpus_allowed_list /proc/self/status"], ROOT, env),
        "api_paths": {
            "yjson": "cached typed JsonCodec via YJson.encodeStringWith/decodeStringWith; generated object decoders use cached YJson.fastDecoder",
            "stdx_json": "typed JsonSerializable/JsonDeserializable direct JsonWriter/JsonReader",
            "cangjieJSON": "@JsonAdapter generated toJson/fromJson (only public typed path; DOM-backed internally)",
            "json4cj": "@Codable generated encode/decode via public JsonWriter/JsonReader; public BuiltinEncoders/Decoders for root containers",
            "cjfast_json": "@JsonAdapter generated toJson/fromJson",
            "jackson": "cached concrete/generic ObjectWriter/ObjectReader",
            "fastjson2": "cached concrete/generic ObjectWriter/ObjectReader with per-operation JSONWriter/JSONReader",
        },
    }
    (output / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n")

    fields = ["round", "workload_position", "library_position", "library", "workload_id",
              "scenario", "operation", "payload", "source_case", "elapsed_seconds",
              "load1_before", "load1_after", "report_path", "log_path"]
    with (output / "manifest.csv").open("w", newline="") as stream:
        manifest = csv.DictWriter(stream, fieldnames=fields)
        manifest.writeheader()
        total = args.runs * len(WORKLOADS) * len(LIBRARIES)
        completed_count = 0
        for round_id in range(1, args.runs + 1):
            for workload_position, workload in enumerate(order(WORKLOADS, round_id), 1):
                workload_id, scenario, operation, payload, suffix = workload
                for library_position, library in enumerate(order(LIBRARIES, round_id), 1):
                    report_dir = raw / f"run-{round_id:02d}" / workload_id / library
                    report_dir.mkdir(parents=True)
                    log_path = logs / f"run-{round_id:02d}-{workload_id}-{library}.log"
                    if library in CANGJIE:
                        cwd, suite, prefix = CANGJIE[library]
                        method = prefix + suffix
                        command = ["taskset", "-c", str(args.cpu), "cjpm", "bench", "--skip-build",
                                   "--no-color", "--filter", f"{suite}.{method}*",
                                   "--report-path", str(report_dir), "--report-format", "csv-raw",
                                   "--random-seed", str(round_id)]
                        source_case = method
                    else:
                        cwd = ROOT / "harness/java"
                        method = JAVA[library] + suffix
                        report_file = report_dir / "jmh.json"
                        command = ["taskset", "-c", str(args.cpu), "java", "-jar",
                                   "target/json-optimal-bench-1.0.0-all.jar", f"bench.OptimalJsonBench.{method}",
                                   "-wi", "3", "-w", "500ms", "-i", "1", "-r", "1s", "-f", "1",
                                   "-bm", "avgt", "-tu", "ns", "-rf", "json", "-rff", str(report_file)]
                        source_case = method
                    before = os.getloadavg()[0]
                    started = time.monotonic()
                    command_env = env.copy()
                    if library == "cangjieJSON":
                        command_env["CANGJIE_STDX_PATH"] = "/home/chenqian/fastjson-bench-sdk-20260803"
                    result = subprocess.run(command, cwd=cwd, env=command_env, text=True,
                                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    elapsed = time.monotonic() - started
                    after = os.getloadavg()[0]
                    log_path.write_text(result.stdout)
                    if result.returncode != 0:
                        print(f"FAILED round={round_id} workload={workload_id} library={library} log={log_path}", flush=True)
                        return result.returncode
                    manifest.writerow({
                        "round": round_id, "workload_position": workload_position,
                        "library_position": library_position, "library": library,
                        "workload_id": workload_id, "scenario": scenario, "operation": operation,
                        "payload": payload, "source_case": source_case,
                        "elapsed_seconds": f"{elapsed:.6f}", "load1_before": f"{before:.3f}",
                        "load1_after": f"{after:.3f}", "report_path": report_dir.relative_to(output),
                        "log_path": log_path.relative_to(output),
                    })
                    stream.flush()
                    completed_count += 1
                    print(f"[{completed_count}/{total}] round={round_id} {workload_id} {library} {elapsed:.2f}s", flush=True)
    (output / "COMPLETE").write_text(datetime.now(timezone.utc).isoformat() + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
