#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

LIBRARIES = ["yjson", "stdx_json", "cangjieJSON", "json4cj", "cjfast_json", "jackson", "fastjson2"]
UNITS = {"ns": 1.0, "us": 1_000.0, "ms": 1_000_000.0, "s": 1_000_000_000.0}


def percentile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    if lo == hi:
        return ordered[lo]
    return ordered[lo] * (hi - pos) + ordered[hi] * (pos - lo)


def load_cangjie(path: Path) -> list[float]:
    values = []
    for report in path.rglob("bench-*.csv"):
        with report.open(newline="") as stream:
            for row in csv.DictReader(stream):
                if row.get("Measurement") != "Duration" or int(row["BatchSize"]) <= 0:
                    continue
                values.append(float(row["Duration"]) * UNITS[row["Unit"]] / int(row["BatchSize"]))
    if not values:
        raise ValueError(f"no Cangjie samples in {path}")
    return values


def load_jmh(path: Path) -> list[float]:
    payload = json.loads((path / "jmh.json").read_text())
    if len(payload) != 1:
        raise ValueError(f"expected one JMH result in {path}")
    metric = payload[0]["primaryMetric"]
    if metric["scoreUnit"] != "ns/op":
        raise ValueError(f"unexpected JMH unit in {path}: {metric['scoreUnit']}")
    return [float(metric["score"])]


def summarize(round_values: dict[int, list[float]]) -> dict:
    medians = [statistics.median(round_values[r]) for r in sorted(round_values)]
    median = statistics.median(medians)
    mean = statistics.fmean(medians)
    return {
        "runs": len(medians), "median_ns": median, "p95_ns": percentile(medians, 0.95),
        "cv_percent": statistics.pstdev(medians) / mean * 100.0 if mean else 0.0,
        "mad_percent": statistics.median(abs(v - median) for v in medians) / median * 100.0 if median else 0.0,
        "run_medians_ns": medians,
    }


def paired(yjson_runs: dict[int, list[float]], peer_runs: dict[int, list[float]], rounds: list[int]) -> dict:
    ratios = []
    for round_id in rounds:
        ratios.append(statistics.median(yjson_runs[round_id]) / statistics.median(peer_runs[round_id]))
    return {
        "median_yjson_over_peer": statistics.median(ratios),
        "p95_yjson_over_peer": percentile(ratios, 0.95),
        "yjson_faster_rounds": sum(value < 1.0 for value in ratios),
        "ratios": ratios,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--min-runs", type=int, default=11)
    args = parser.parse_args()
    root = args.root.resolve()
    samples = defaultdict(dict)
    metadata = {}
    with (root / "manifest.csv").open(newline="") as stream:
        for row in csv.DictReader(stream):
            key = (row["workload_id"], row["library"])
            report = root / row["report_path"]
            loader = load_jmh if row["library"] in {"jackson", "fastjson2"} else load_cangjie
            samples[key][int(row["round"])] = loader(report)
            metadata[row["workload_id"]] = {k: row[k] for k in ("scenario", "operation", "payload")}

    rows = []
    for workload_id in metadata:
        lib_runs = {lib: samples[(workload_id, lib)] for lib in LIBRARIES}
        common = sorted(set.intersection(*(set(v) for v in lib_runs.values())))
        if len(common) < args.min_runs:
            raise ValueError(f"{workload_id}: only {len(common)} complete rounds")
        libs = {lib: summarize({r: lib_runs[lib][r] for r in common}) for lib in LIBRARIES}
        ratios = {
            lib: paired(lib_runs["yjson"], lib_runs[lib], common)
            for lib in LIBRARIES if lib != "yjson"
        }
        rows.append({"workload_id": workload_id, **metadata[workload_id], "rounds": len(common),
                     "libraries": libs, "paired": ratios,
                     "stable_cv_le_5_percent": max(v["cv_percent"] for v in libs.values()) <= 5.0})

    (root / "summary.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n")
    headers = ["workload_id", "scenario", "operation", "payload", "rounds"]
    for lib in LIBRARIES:
        headers += [f"{lib}_median_ns", f"{lib}_cv_percent"]
    for lib in LIBRARIES:
        if lib != "yjson":
            headers += [f"paired_yjson_over_{lib}", f"yjson_faster_rounds_vs_{lib}"]
    headers += ["stable_cv_le_5_percent"]
    with (root / "summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            out = {k: row[k] for k in ("workload_id", "scenario", "operation", "payload", "rounds")}
            for lib in LIBRARIES:
                out[f"{lib}_median_ns"] = f"{row['libraries'][lib]['median_ns']:.3f}"
                out[f"{lib}_cv_percent"] = f"{row['libraries'][lib]['cv_percent']:.3f}"
            for lib, comparison in row["paired"].items():
                out[f"paired_yjson_over_{lib}"] = f"{comparison['median_yjson_over_peer']:.6f}"
                out[f"yjson_faster_rounds_vs_{lib}"] = comparison["yjson_faster_rounds"]
            out["stable_cv_le_5_percent"] = row["stable_cv_le_5_percent"]
            writer.writerow(out)

    completed_rounds = min(row["rounds"] for row in rows)
    lines = [
        "# Full optimal-public-API JSON benchmark", "",
        f"Times are median ns/op across {completed_rounds} independent process rounds. Lower is better.", "",
        "| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |",
        "|:--|--:|--:|--:|--:|--:|--:|--:|--:|",
    ]
    for row in rows:
        libs = row["libraries"]
        values = [libs[lib]["median_ns"] for lib in LIBRARIES]
        cvs = [libs[lib]["cv_percent"] for lib in LIBRARIES]
        lines.append("| " + row["workload_id"] + " | " + " | ".join(
            f"{value / 1000.0:.3f} us" for value in values
        ) + f" | {max(cvs):.2f}% |")
    (root / "summary.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
