# json4cj

**Jackson 级别的 JSON 序列化库，为仓颉语言而生。**

json4cj 是一个功能完备的 JSON 编解码库，采用编译期宏代码生成替代运行时反射，提供极致的序列化性能。API 设计对标 Java 生态的 Jackson，但充分利用仓颉语言的宏系统、值类型和扩展机制。

---

## 特性概览

| 优先级 | 特性 | 说明 |
|--------|------|------|
| P0  | `@Codable` + `@CodableKey` + `@CodableSkip` + `@CodableDefault` + `@CodablePolicy` | 基础序列化/反序列化         |
| P0  | 流式 API (`JsonWriter` / `JsonReader`)                                             | 高性能流式读写             |
| P0  | 树模型 API (`JsonValue` / `DefaultJsonTree`)                                        | 树形结构访问               |
| P1  | `@CodableFormat` + `@CodableAlias` + `@CodableEnum` + `@CodableCreator`             | 格式化/别名/枚举/构造器     |
| P1  | `ReadFeature` / `WriteFeature`                                                      | 特性开关                   |
| P2  | `@CodableVariant` + `@CodableVariantCase`                                          | 多态序列化                 |
| P2  | `@CodableUnwrap` + `@CodableRaw` + `@CodableAnyKey/AnyValue` + `@CodableRoot`        | 扁平化/原始值/动态属性/根包装 |
| P3  | `@CodableView` + `@CodableFilter`                                                   | 视图过滤/动态过滤           |
| P3  | `@CodableRef` + `@CodableInject` + `@CodableMerge`                                   | 循环引用/值注入/合并更新     |

---

## 三组件架构

```
json4cj-core         流式引擎 + 树模型 + 异常体系 + 编解码器 + Feature 开关
json4cj-annotations  注解声明 + 宏引擎（编译期代码生成）
json4cj-databind     高级数据绑定（JsonCodec + 模块系统 + 命名策略 + 过滤器）
```

依赖关系：`databind → annotations → core`

---

## 快速开始

### 1. 添加依赖

在 `cjpm.toml` 中添加：

```toml
[dependencies]
json4cj-core = { path = "./json4cj-core" }
json4cj-annotations = { path = "./json4cj-annotations" }
json4cj-databind = { path = "./json4cj-databind" }
```

如果只需基础注解和宏，仅依赖 `json4cj-annotations` 即可。

### 2. 基础用法

```cangjie
import json4cj.annotations.anno.*

@Codable
class User {
    @CodableKey("user_name")
    var name: String = ""

    @CodableKey("age")
    var age: Int64 = 0

    var email: String = ""
}

// 序列化
let user = User()
user.name = "张三"
user.age = 25
user.email = "zhangsan@example.com"
let json = user.toJson()
// {"user_name":"张三","age":25,"email":"zhangsan@example.com"}

// 反序列化
let user2 = User.fromJson(json)
println(user2.name)  // 张三
```

### 3. struct 类型

```cangjie
@Codable
struct Point {
    var x: Float64 = 0.0
    var y: Float64 = 0.0
}

let p = Point(x: 1.5, y: 2.5)
let json = p.toJson()  // {"x":1.5,"y":2.5}
let p2 = Point.fromJson(json)
```

### 4. enum 类型

```cangjie
@Codable
enum Color {
    | Red | Green | Blue
}

// 名称模式（默认）
let json = Color.Red.toJson()  // "Red"
let c = Color.fromJson("\"Green\"")

// 序号模式
@Codable
@CodableEnum[ord]
enum Status {
    | Active | Inactive | Pending
}
let json = Status.Active.toJson()  // 0
```

---

## 注解详解

### P0 — 基础注解

#### @Codable

标记 class/struct/enum 为可序列化类型。

```cangjie
@Codable
class Simple { var name: String = "" }

// 带继承
@Codable(withSuperClass = ParentClass)
class Child extends ParentClass { var extra: String = "" }

// 允许 null 值
@Codable(allowNull = true)
class Nullable { var value: Option<String> = None }
```

#### @CodableKey

自定义 JSON 字段名。

```cangjie
@Codable
class User {
    @CodableKey("user_name")
    var name: String = ""

    @CodableKey("is_active", required: true)
    var active: Bool = false
}
```

#### @CodableSkip

序列化/反序列化时忽略字段。

```cangjie
@Codable
class User {
    var name: String = ""

    @CodableSkip
    var password: String = ""
}
```

#### @CodableDefault

字段缺失时保留默认值（不抛异常）。

```cangjie
@Codable
class Config {
    @CodableDefault
    var timeout: Int64 = 30  // JSON 中缺失时保持 30
}
```

#### @CodablePolicy

控制字段的包含策略。

```cangjie
@Codable
class User {
    var name: String = ""

    @CodablePolicy("NON_NULL")
    var nickname: Option<String> = None  // None 时不输出

    @CodablePolicy("NON_EMPTY")
    var tags: Array<String> = []  // 空数组时不输出
}
```

### P1 — 格式与别名

#### @CodableFormat

指定日期/数字的格式化方式。

```cangjie
@Codable
class Event {
    @CodableFormat("yyyy-MM-dd")
    var date: String = ""

    @CodableFormat("#,##0.00")
    var amount: Float64 = 0.0
}
```

#### @CodableAlias

反序列化时支持多个键名。

```cangjie
@Codable
class User {
    @CodableKey("username")
    @CodableAlias("user_name", "loginName")
    var name: String = ""
}
// JSON 中 "username"、"user_name" 或 "loginName" 都能映射到 name 字段
```

#### @CodableEnum

枚举序列化控制。

```cangjie
// 序号模式（@Codable 外层生成代码，@CodableEnum[ord] 内层配置序号策略）
@Codable
@CodableEnum[ord]
enum Priority { | Low | Medium | High }

// 带默认值（未知枚举值不抛异常）
@Codable
@CodableEnum[default: "Unknown"]
enum Status { | Active | Inactive | Unknown }
```

### P2 — 高级特性

#### @CodableVariant — 多态序列化

```cangjie
// PROPERTY 模式：在对象中添加类型字段
// 注意：@Codable 必须写在外层（最前），@CodableVariant / @CodableVariantCase
// 作为其内层宏（仓颉宏由内向外展开，配置经 setItem/getChildMessages 传递）。
@Codable
@CodableVariant[use: NAME, as: PROPERTY, property: "type", cases: "circle:Circle,rectangle:Rectangle"]
open class Shape {
    var name: String = ""
}

@Codable[withSuperClass = Shape]
@CodableVariantCase["circle"]
class Circle <: Shape {
    var radius: Float64 = 0.0
}

@Codable[withSuperClass = Shape]
@CodableVariantCase["rectangle"]
class Rectangle <: Shape {
    var width: Float64 = 0.0
    var height: Float64 = 0.0
}

// 序列化结果：{"type":"circle","name":"...","radius":5.0}
// 反序列化时根据 type 字段分发到正确的子类
```

```cangjie
// WRAPPER_OBJECT 模式：类型名作为外层键
@Codable
@CodableVariant[use: NAME, as: WRAPPER_OBJECT]
// 序列化结果：{"circle":{"name":"...","radius":5.0}}
```

```cangjie
// WRAPPER_ARRAY 模式：[类型名, 对象]
@Codable
@CodableVariant[use: NAME, as: WRAPPER_ARRAY]
// 序列化结果：["circle",{"name":"...","radius":5.0}]
```

#### @CodableUnwrap — 扁平化内嵌

```cangjie
@Codable
class Address {
    var city: String = ""
    var street: String = ""
}

@Codable
class User {
    var name: String = ""

    @CodableUnwrap
    var address: Address = Address()
}
// 序列化结果：{"name":"张三","city":"北京","street":"长安街"}
// 而非 {"name":"张三","address":{"city":"北京","street":"长安街"}}
```

#### @CodableRaw — 原始 JSON 值

```cangjie
@Codable
class Payload {
    @CodableRaw
    var metadata: String = ""  // 字符串内容作为原始 JSON 写入/读取
}
// metadata = "{\"key\":\"value\"}" → 输出 {"metadata":{"key":"value"}}
```

#### @CodableAnyKey / @CodableAnyValue — 动态属性

```cangjie
@Codable
class Extensible {
    var name: String = ""

    @CodableAnyKey
    var extraKeys: HashMap<String, String> = HashMap<String, String>()

    @CodableAnyValue
    var extraValues: HashMap<String, String> = HashMap<String, String>()
}
// extraKeys 的内容直接展开为 JSON 对象字段
// JSON 中未映射的键值对自动收集到 extraValues
```

#### @CodableRoot — 根名称包装

```cangjie
@Codable
@CodableRoot("user")
class User {
    var name: String = ""
}
// 序列化结果：{"user":{"name":"张三"}}
// 反序列化时自动解包
```

### P3 — 运行时特性

#### @CodableView — 视图过滤

控制哪些字段在不同视图中可见。

```cangjie
@Codable
class User {
    var name: String = ""

    @CodableView("public")
    var email: String = ""

    @CodableView("admin")
    var password: String = ""

    @CodableView("public", "admin")  // 多个视图
    var avatar: String = ""
}

// 设置活跃视图
ViewContext.setActiveViews(["public"])

let json = user.toJson()
// 仅输出 name、email、avatar（password 在 "admin" 视图中，当前未激活）

ViewContext.clear()
```

#### @CodableRef — 循环引用处理

```cangjie
@Codable
class Node {
    var value: String = ""

    @CodableRef
    var next: Option<Node> = None  // 循环引用自动检测

    @CodableRef.Back
    var prev: Option<Node> = None  // 反向引用，序列化时跳过
}

let a = Node(value: "A")
let b = Node(value: "B")
a.next = Some(b)
b.prev = Some(a)  // 循环引用

RefContext.begin()
let json = a.toJson()
// 第二次遇到同一对象时输出 {"$ref": "1"} 而非无限递归
RefContext.end()
```

#### @CodableInject — 值注入

反序列化时从上下文注入值，不从 JSON 读取。

```cangjie
@Codable
class Request {
    var body: String = ""

    @CodableInject("requestId")
    var requestId: String = ""

    @CodableInject("timestamp")
    var timestamp: Int64 = 0
}

// 设置注入值
InjectContext.setValue("requestId", "req-12345")
InjectContext.setValue("timestamp", 1700000000)

let req = Request.fromJson("{\"body\":\"hello\"}")
// req.requestId == "req-12345"（从 InjectContext 注入，非 JSON 读取）
// req.timestamp == 1700000

InjectContext.clear()
```

#### @CodableFilter — 动态过滤

```cangjie
@Codable
@CodableFilter("userFilter")
class User {
    var name: String = ""
    var password: String = ""
    var secretKey: String = ""
}

// 注册过滤器
FilterContext.registerFilter("userFilter", { fieldName, value =>
    fieldName != "password" && fieldName != "secretKey"
})

// 激活过滤器
FilterContext.setActiveFilter("userFilter")

let json = user.toJson()
// 仅输出 name（password 和 secretKey 被过滤掉）

FilterContext.clearActiveFilter()
```

#### @CodableMerge — 合并更新

反序列化时，JSON 缺失的字段保留原值而非覆盖。

```cangjie
@Codable
class Config {
    var host: String = "localhost"
    var port: Int64 = 8080

    @CodableMerge
    var timeout: Int64 = 30
}

let config = Config()
config.timeout = 60  // 修改默认值

// JSON 中缺少 timeout 字段
let updated = Config.fromJson("{\"host\":\"example.com\",\"port\":9090}")
// updated.timeout == 60（保留原值，而非重置为默认值 30）
```

---

## 流式 API

### JsonWriter — 流式写入

```cangjie
import json4cj.core.stream.*

let writer = JsonWriter()
writer.startObject()
writer.field("name", "张三")
writer.field("age", 25)
writer.writeName("tags")
writer.startArray()
writer.value("developer")
writer.value("仓颉")
writer.endArray()
writer.endObject()

let json = writer.toString()
// {"name":"张三","age":25,"tags":["developer","仓颉"]}
```

### JsonReader — 流式读取

```cangjie
import json4cj.core.stream.*

let reader = JsonReader(json)
reader.startObject()
while (let Some(token) <- reader.peek()) {
    if (token == JsonToken.EndObject) { break }
    let name = reader.readName()
    match (name) {
        case "name" => let name = reader.readString()
        case "age" => let age = reader.readInt()
        case _ => reader.skip()
    }
}
reader.endObject()
```

---

## Feature 开关

```cangjie
import json4cj.core.cfg.*

// 写入特性
let writer = JsonWriter()
writer.enableFeature(WriteFeature.PRETTY_PRINT)     // 格式化输出
writer.enableFeature(WriteFeature.QUOTE_FIELD_NAMES) // 字段名加引号

// 读取特性
let reader = JsonReader(json)
reader.enableFeature(ReadFeature.ALLOW_COMMENTS)     // 允许注释
reader.enableFeature(ReadFeature.ALLOW_TRAILING_COMMA) // 允许尾逗号
```

---

## 数据绑定 (databind)

### JsonCodec — 统一入口

```cangjie
import json4cj.databind.bind.*

// 序列化
let json = JsonCodec.stringify(obj)
let writer = JsonCodec.createWriter(prettyPrint: true)
JsonCodec.write(obj, writer)

// 反序列化
let obj = JsonCodec.parse<User>(json)
let reader = JsonCodec.createReader(json)
let obj2 = JsonCodec.read<User>(reader)

// 树模型
let tree = JsonCodec.writeTree(obj)
let obj3 = JsonCodec.readTree<User>(tree)
```

### 模块系统

```cangjie
import json4cj.databind.module.*

let module = SimpleModule("custom")
module.addEncoder(CustomType, CustomEncoder())
module.addDecoder(CustomType, CustomDecoder())

JsonCodec.registerModule(module)
```

### 命名策略

```cangjie
import json4cj.databind.naming.*

// 全局命名策略
JsonCodec.setNamingStrategy(SnakeCase())
// 所有字段名自动转为 snake_case
```

---

## 异常体系

```cangjie
import json4cj.core.exc.*

// JsonException           — 基础异常
//   JsonReadException     — 读取异常
//   JsonWriteException    — 写入异常
//   JsonTypeException     — 类型不匹配
//   JsonMissingField      — 字段缺失
//   JsonOverflowException — 数值溢出

try {
    let user = User.fromJson(invalidJson)
} catch (e: JsonMissingField) {
    println("缺少字段: ${e.message}")
} catch (e: JsonTypeException) {
    println("类型错误: ${e.message}")
}
```

---

## 私有变量支持

仓颉的运行时反射无法访问 `private` 成员。json4cj 通过编译期宏注入代码到类体内部，**天然支持私有字段序列化**，无需任何额外配置。

```cangjie
@Codable
class SecretHolder {
    @CodableKey("secret")
    private var _secret: String = ""

    public prop secret: String {
        get() { _secret }
        set(v) { _secret = v }
    }
}
// 宏生成的 toJsonValue/fromJsonValue 在类内部，可直接访问 _secret
```

---

## 性能

json4cj 的核心优势是**编译期代码生成**：

- **零反射开销**：宏在编译期生成序列化/反序列化代码，运行时无反射调用
- **流式 API**：大 JSON 场景下流式读写远优于树模型全量加载
- **目标**：宏生成路径性能不低于 Jackson 反射路径，宏路径 ≥ 反射路径 3x

---

## 项目结构

```text
json4cj/
├── json4cj-core/              # 流式引擎 + 树模型 + 异常体系
│   └── src/
│       ├── stream/            # JsonWriter, JsonReader, JsonToken
│       ├── tree/              # JsonTree, JsonTreeBuilder
│       ├── extend/            # IJsonAdapter, JsonValue/JsonKind 扩展
│       ├── codec/             # Encoder/Decoder, VariantRegistry
│       ├── cfg/               # CodecConfig, Feature, ViewContext, RefContext...
│       ├── exc/               # 异常体系
│       └── util/              # Base64, JsonPointer, CharEscapes
├── json4cj-annotations/       # 注解 + 宏引擎
│   └── src/
│       ├── anno/              # 23 个注解声明
│       ├── enum/              # PolicyMode, VariantUse, VariantAs 等
│       └── macro/             # CodableMacro, HandleClass/Struct/Enum, MacroInfo
├── json4cj-databind/          # 高级数据绑定
│   └── src/
│       ├── bind/              # JsonCodec, CodecRegistry
│       ├── ser/               # 序列化器
│       ├── deser/             # 反序列化器
│       ├── type/              # TypeSpec, TypeFactory, TypeReference
│       ├── node/              # JsonNode, NodeFactory, NodePatch
│       ├── module/            # 模块系统
│       ├── naming/            # 命名策略
│       ├── filter/            # 过滤器
│       ├── view/              # 视图
│       └── exc/               # 编解码异常
├── execution-plan.md           # 详细执行计划
├── todolist.md                 # 任务清单
└── README.md                   # 本文件
```

---

## 对标 Jackson 映射

| Jackson | json4cj | 说明 |
|---------|---------|------|
| `@JsonProperty` | `@CodableKey` | 字段名映射 |
| `@JsonIgnore` | `@CodableSkip` | 忽略字段 |
| `@JsonInclude` | `@CodablePolicy` | 包含策略 |
| `@JsonAlias` | `@CodableAlias` | 别名 |
| `@JsonFormat` | `@CodableFormat` | 格式化 |
| `@JsonTypeInfo` + `@JsonSubTypes` | `@CodableVariant` + `@CodableVariantCase` | 多态 |
| `@JsonUnwrapped` | `@CodableUnwrap` | 扁平化 |
| `@JsonRawValue` | `@CodableRaw` | 原始值 |
| `@JsonAnyGetter` / `@JsonAnySetter` | `@CodableAnyKey` / `@CodableAnyValue` | 动态属性 |
| `@JsonRootName` | `@CodableRoot` | 根包装 |
| `@JsonView` | `@CodableView` | 视图过滤 |
| `@JsonIdentityInfo` | `@CodableRef` | 循环引用 |
| `@JacksonInject` | `@CodableInject` | 值注入 |
| `@JsonMerge` | `@CodableMerge` | 合并更新 |
| `@JsonFilter` | `@CodableFilter` | 动态过滤 |
| `ObjectMapper` | `JsonCodec` | 数据绑定入口 |
| `JsonGenerator` | `JsonWriter` | 流式写入 |
| `JsonParser` | `JsonReader` | 流式读取 |
| `JsonNode` | `JsonTree` / `JsonNode` | 树模型 |
| `Module` | `CodecModule` | 模块系统 |
| `PropertyNamingStrategy` | `NamingStrategy` | 命名策略 |

---

## License

MIT
