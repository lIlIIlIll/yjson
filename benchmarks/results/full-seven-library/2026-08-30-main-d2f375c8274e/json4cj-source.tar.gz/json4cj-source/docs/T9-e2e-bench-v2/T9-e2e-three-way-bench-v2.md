# T9 端到端三方基准 v2（json4cj vs cangjieJSON vs Jackson）

> 生成日期：2026-08-13；**复测：2026-08-13（commit daf0b6e 后）**
> 环境：Windows 11 / x64；Cangjie 1.0.5（cjpm 1.0.5）；JDK 21.0.11 (Temurin)；Jackson **2.16.1**（上次报告标 2.17.2，本次以 `~/.m2` 实际可用 jar 2.16.1 为准，版本差异对结论无影响）
> 三个被测件：① json4cj（本仓库，宏路径 tree + stream）；② cangjieJSON（`D:\code\jackson\cangjieJSON`，`@JsonAdapter` 宏，tree-only，同样基于 stdx `JsonValue`）；③ Jackson 三组件（`D:\code\jackson`，`writeValueAsString`/`readValue` 字符串端到端）。
> 绝对值运行间波动 ±30%（机器负载），**结论以同环境相对对比为准**。三方均在 2026-08-13 同一会话内跑完；json4cj E2E 跑 3 轮取最干净样本（round 2，round 3 遭遇负载尖峰 +18%~+103% 弃用），PerfLargeList 取 round 1，cangjieJSON 取 round 1，Jackson 1 轮（nanoTime 1s 预热 + 3s 测量均值，本身稳定）。
> 对照基线：[T9-e2e-three-way-bench.md](../T9-e2e-three-way-bench.md)（2026-08-10，v1，2 工作负载）。

---

## 0. 复测更新摘要（2026-08-13，daf0b6e 后）

原 v2 报告（本文件 §1–§7 原始数字标注「v2 原值」）生成于 **daf0b6e 之前**——即 `JsonObjectHelper.entries/keys` 修复（commit 124020f）之后、`HashMap/ArrayList 物化消除`（commit daf0b6e）之前。daf0b6e 针对 tree 反序列化的两处集合适配器：① `HashMap.fromJsonValue` 改直迭代 `getFields()`（bypass entries 物化）；② `ArrayList.fromJsonValue` 改预分配大小构造（对齐 `Array`）。本次复测捕获该修复在三方对比中的效果。

**头条：cangjieJSON-vs-json4cj-tree 反序列化差距显著收窄。**

| 工作负载 | tree deser v2 原值 | 复测 | 变化 | cangjieJSON vs tree（v2→复测） |
|---|---:|---:|---:|---|
| PerfLargeList | 12.36 ms | **10.86 ms** | **−12.1%** | 1.30× → **1.16×** |
| LargeBean | 28.61 μs | **27.18 μs** | **−5.0%** | 1.48× → **1.35×** |
| BigString | 80.84 μs | 84.15 μs | +4.1%（噪声） | 1.05× → 1.08×（噪声） |

- **PerfLargeList 收益最大**（200×40 = 8000 个 HashMap entry，daf0b6e 的直接目标），tree deser −12.1%，cangjieJSON 差距从 1.30× 收窄至 **1.16×**。
- **LargeBean** 含 20-entry `meta` HashMap，tree deser −5.0%，差距 1.48× → **1.35×**。
- **对照组持平**（证 daf0b6e 为定向 tree-deser 修复，非广泛变动）：LargeBean stream deser 26.89→27.79μs、PerfLargeList stream deser 16.19→16.55ms、PerfLargeList stream ser 4.906→5.116ms、LargeBean stream ser 15.69→16.18μs，均在 ±5% 噪声内。
- **BigString deser 高方差**（±8~9% Err），三测样本 80~132μs 浮动；daf0b6e 不触及 BigString（无 HashMap），其浮动为纯噪声，结论「三方贴齐」不变。
- **T9.14 BigString stream ser 修复持续生效**：51.28μs（v2 原值 60.30，v1 95.52），已接近 commit 标注的 52μs 单测目标。

> 对 T9.11/T9.12 影响：**T9.12 子杠杆 1（tree deser codegen 优化）的适配器物化落点已兑现**，cangjieJSON 余量从 1.30~1.48× 收窄至 **1.16~1.35×**，仍存余量但大幅缩小；**子杠杆 2（stream deser 批量退化）未变**（PerfLargeList stream deser 16.55ms 仍 1.52× 慢于 tree）；**T9.11（itoa）维持**，序列化侧无源码落后。

---

## 1. 结论（TL;DR）

**v1 报告指出的两个 json4cj 源码级问题均已修复并经三方复测验证；daf0b6e 进一步收窄 tree 反序列化差距；PerfLargeList 暴露的 stream 反序列化批量级退化（与 v1 BigString stream 序列化退化对称）仍在。**

1. **【T9.14 已验证】BigString stream 序列化退化修复持续生效。** v1 95.52μs → v2 60.30μs → 复测 **51.28μs**（中位，均值 53.59），已接近 commit 标注的 52μs 单测目标。对 Jackson 倍率从 6.1× 降至 **3.1×**。`@Bench` 稳态中位含批量分配压力，高于单次 best-case；中位对中位现为 tree（41.49）的 1.24×，退化已脱离"独立退化"区间。
2. **【entries/keys + daf0b6e 已验证】HashMap 反序列化两轮提速，cangjieJSON 头空间大幅收窄。** LargeBean tree deser 35.36(v1) → 28.61(v2) → **27.18μs**(复测)；cangjieJSON-vs-json4cj-tree 差距 1.73×(v1) → 1.48×(v2) → **1.35×**(复测)。PerfLargeList（8000 HashMap entry）差距 1.30×(v2) → **1.16×**(复测)——集合适配器物化消除收益在 HashMap 密集处集中体现。
3. **【仍存·头条】PerfLargeList stream 反序列化批量退化。** 200×110 字段大对象列表，stream deser **16.55ms**，比 tree（10.86ms）慢 1.52×，比 cangjieJSON（9.355ms）慢 1.77×。与 v1「BigString stream ser 退化」对称：stream 的逐字段 token 分派在单对象上省 DOM 占优，但在批量宽对象上被 stdx 原生批量解析反超。daf0b6e 未触及 stream 路径，此项不变。
4. **序列化侧格局未变：json4cj stream 仍是仓颉最快。** LargeBean ser stream 16.18 < cangjieJSON 25.60 < tree 29.74；PerfLargeList ser stream **5.116ms** < cangjieJSON 8.979 < tree 9.591（stream 1.87× 快于 tree）。序列化对 Jackson 的剩余差距 = itoa 地板（T9.11 范畴），未变。
5. **PerfLargeList 仍是三者中差距最大的工作负载**（ser 4.7–8.9×、deser 5.6–9.9× Jackson），110 字段×200 项放大 itoa + 装箱 + 逐字段分派开销，是后续优化的最高杠杆场景。

> 对 T9.11/T9.12 影响：**T9.12 子杠杆 1（适配器物化消除）已兑现**，cangjieJSON 余量收窄至 1.16~1.35×，残余或含编译/内联差异；**子杠杆 2（stream deser 批量退化）仍未处理**，应立项；**T9.11（itoa）维持**，序列化侧已无源码落后于同侪。

---

## 2. 方法论与工作负载

三方使用**结构一一对应**的工作负载（字段名、类型语义、元素数一致），仅语言语法差异。JSON 是类型擦除的：Int32→Int64、ArrayList→Array/List、?String→String 在字段全填充时产出**逐字节一致**的 JSON（已验证，见 §3.4），故 perf 对比有效。

| 工作负载 | 形状 | 产物大小 | 来源 |
|---|---|---:|---|
| LargeBean | 24 字段混合（5×Int64 + 4×String + 3×Bool + 3×Float64 + Array(20/100) + HashMap(20) + 嵌套 5 字段对象） | 1326 B | T9E2ELargeBean |
| BigString | id/label/checksum + 32KB blob + Array(32×256) | 41125 B | T9E2EBigString |
| **PerfLargeList** | 200 × T9PerfLargeItem（110 字段：61×?String + 30×Int32 + 16×Int64 + Bool + ArrayList(40) + HashMap(40)） | 664816 B | T9BenchLargeList |

| 被测件 | 路径 | 序列化 | 反序列化 | 方法 |
|---|---|---|---|---|
| Jackson | 字符串端到端 | `mapper.writeValueAsString(obj)` | `mapper.readValue(json, Class)` | 手写 `nanoTime()` 循环，预热 1s + 测量 3s |
| json4cj | tree | `obj.toJson()` | `T.fromJson(json)` | `@Bench`，预热 1s + 测量 ~5s，取中位 |
| json4cj | stream | `obj.encode(JsonWriter)` | `T.decode(JsonReader)` | 同上 |
| cangjieJSON | tree | `obj.toJson()` | `T.fromJson(json)` | 同上（仅 tree） |

测试输入数据（类定义 + JSON 串）已单独落盘 `docs/T9-e2e-bench-v2/data/`（见附录 A）。

---

## 3. 实测结果（复测，daf0b6e 后）

> 表中「v2 原值」为 daf0b6e 前的同会话样本（原 v2 报告数字），用于对照 daf0b6e 收益。Jackson 为 nanoTime 均值；json4cj/cangjieJSON 为 `@Bench` 中位。

### 3.1 LargeBean（24 字段含集合，1326 B）

| 实现 | 序列化 (μs) | v2 原值 | 反序列化 (μs) | v2 原值 | ser/Jackson | deser/Jackson |
|---|---:|---:|---:|---:|---:|---:|
| Jackson | 1.693 | 1.707 | 3.457 | 3.433 | 1.0× | 1.0× |
| json4cj tree | 29.74 | 32.32 | **27.18** | 28.61 | 17.6× | 7.9× |
| json4cj stream | 16.18 | 15.69 | 27.79 | 26.89 | 9.6× | 8.0× |
| cangjieJSON | 25.60 | 25.36 | 20.08 | 19.31 | 15.1× | **5.8×** |

> tree deser 27.18（−5.0% vs v2 28.61，Err ±1.5%）；cangjieJSON 20.08（+4.0% vs v2，噪声内）。cangjieJSON-vs-tree 差距 **1.48× → 1.35×**。stream deser 27.79 持平 v2（26.89），证 daf0b6e 未触及 stream。

### 3.2 BigString（41125 B）

| 实现 | 序列化 (μs) | v2 原值 | 反序列化 (μs) | v2 原值 | ser/Jackson | deser/Jackson |
|---|---:|---:|---:|---:|---:|---:|
| Jackson | 16.435 | 15.657 | 32.151 | 32.120 | 1.0× | 1.0× |
| json4cj tree | 41.49 | 46.44 | 84.15 | 80.84 | 2.5× | 2.6× |
| json4cj stream | 51.28 | 60.30 | 64.10 | 72.76 | 3.1× | 2.0× |
| cangjieJSON | 41.19 | 42.73 | 77.71 | 76.66 | 2.5× | 2.4× |

> BigString deser 高方差（±8~9% Err），三测样本 80~132μs 浮动；daf0b6e 不触及 BigString（无 HashMap），浮动为纯噪声。stream ser 51.28（T9.14 修复，vs v1 95.52）。三方 deser 仍在 2.0~2.6× Jackson，相对结构稳定。

### 3.3 PerfLargeList（200×110 字段，664816 B）

| 实现 | 序列化 (ms) | v2 原值 | 反序列化 (ms) | v2 原值 | ser/Jackson | deser/Jackson |
|---|---:|---:|---:|---:|---:|---:|
| Jackson | 1.080 | 1.163 | 1.675 | 1.702 | 1.0× | 1.0× |
| json4cj tree | 9.591 | 10.01 | **10.86** | 12.36 | 8.9× | 6.5× |
| json4cj stream | **5.116** | 4.906 | 16.55 | 16.19 | **4.7×** | 9.9× |
| cangjieJSON | 8.979 | 9.114 | **9.355** | 9.477 | 8.3× | **5.6×** |

> **头条数据**：tree deser 10.86ms（−12.1% vs v2 12.36，Err ±3.5%），cangjieJSON 9.355ms（−1.3% vs v2，噪声内）。cangjieJSON-vs-tree 差距 **1.30× → 1.16×**——daf0b6e 的 HashMap 物化消除（8000 entry）收益在此最集中。stream deser 16.55 持平 v2（16.19），批量退化仍在（1.52× 慢于 tree）。

### 3.4 JSON 一致性验证（输入对等）

三方物化的 JSON 字节数完全一致，证明工作负载结构一一对应、类型擦除未改变产物：

| 工作负载 | json4cj `toJson()` | Jackson `writeValueAsString` | 一致 |
|---|---:|---:|:---:|
| LargeBean | 1326 B | 1326 B | ✓ |
| BigString | 41125 B | 41125 B | ✓ |
| PerfLargeList | 664816 B | 664816 B | ✓ |

---

## 4. 差异分析

### 4.1 BigString stream 序列化：95.52(v1) → 60.30(v2) → 51.28(复测)（T9.14 修复验证）

| 指标 | v1 (08-10) | v2 (08-13) | 复测 | 变化 | 原因 |
|---|---:|---:|---:|---:|---|
| BigString stream ser 中位 | 95.52 μs | 60.30 μs | 51.28 μs | **−46.3%** vs v1 | T9.14（commit fa16955） |
| 对 Jackson 倍率 | 6.1× | 3.9× | 3.1× | 退出最差回归 | |
| 对 tree ser 倍率 | 2.02×（退化） | 1.30× | 1.24× | 退化持续收敛 | |

**差异原因：** v1 发现 `JsonWriter` 写大字符串时 `toString()` 存在双拷贝（先攒 ByteBuffer 再二次拷贝物化 String）。T9.14 消除该冗余拷贝。复测 51.28 已接近 commit 标注的 52μs 单测目标（`@Bench` 稳态中位含批量分配压力，略高于单次 best-case）。退化已从"2× 独立问题"收敛为"24% 残余开销"，优先级降低。

### 4.2 LargeBean tree 反序列化：35.36(v1) → 28.61(v2) → 27.18(复测)（entries + daf0b6e 两轮修复）

| 指标 | v1 (08-10) | v2 (08-13) | 复测 | 变化 | 原因 |
|---|---:|---:|---:|---:|---|
| LargeBean tree deser 中位 | 35.36 μs | 28.61 μs | 27.18 μs | **−23.1%** vs v1 | entries 修复(124020f) + daf0b6e |
| cangjieJSON vs tree 差距 | 1.73× | 1.48× | **1.35×** | 持续收窄 | |
| cangjieJSON deser 中位 | 20.50 μs | 19.31 μs | 20.08 μs | 噪声内 | |

**差异原因：** v1 后两轮修复——① entries/keys 改 stdx `getFields` 原生迭代（commit 124020f）；② daf0b6e 消除 HashMap/ArrayList 物化（直迭代 getFields + ArrayList 预分配）。LargeBean 含 20-entry `meta` HashMap，两轮修复累计降 23.1%。cangjieJSON 同期噪声内持平，故差距从 1.73× 收窄至 1.35×。

### 4.3 PerfLargeList tree 反序列化：12.36(v2) → 10.86(复测)（daf0b6e 主收益点）

| 指标 | v2 (08-13) | 复测 | 变化 | 原因 |
|---|---:|---:|---:|---|
| PerfLargeList tree deser 中位 | 12.36 ms | 10.86 ms | **−12.1%** | daf0b6e（commit daf0b6e） |
| cangjieJSON vs tree 差距 | 1.30× | **1.16×** | 收窄最显著 | |
| cangjieJSON deser 中位 | 9.477 ms | 9.355 ms | −1.3%（噪声内） | |

**差异原因：** PerfLargeList 含 200×40 = 8000 个 HashMap entry，daf0b6e 的 HashMap 直迭代 getFields（bypass `JsonObjectHelper.entries` 的 `ArrayList<(String,JsonValue)>`→`toArray()` 物化）+ ArrayList 预分配在此收益最大化。tree deser −12.1%，cangjieJSON 持平，差距 1.30× → 1.16×。**这是三个工作负载中 cangjieJSON-vs-json4cj-tree 差距最小的**，既验证 daf0b6e 生效，又证明残余 1.16× 余量已接近 cangjieJSON 同地板水平。

### 4.4 对照组持平（证 daf0b6e 定向 tree-deser 修复）

daf0b6e 仅改 `IJsonAdapter.cj` 的 HashMap/ArrayList `fromJsonValue`（tree 路径），未触及 stream 路径。复测对照组（stream ser/deser）均持平 v2：

| 对照场景 | v2 | 复测 | 变化 | 判定 |
|---|---:|---:|---:|---|
| LargeBean stream ser | 15.69 | 16.18 | +3.1% | 噪声 |
| LargeBean stream deser | 26.89 | 27.79 | +3.3% | 噪声 |
| PerfLargeList stream ser | 4.906 | 5.116 | +4.3% | 噪声 |
| PerfLargeList stream deser | 16.19 | 16.55 | +2.2% | 噪声 |
| Jackson（全部） | — | — | ±5% 内 | 机器噪声 |

### 4.5 其他工作负载（v1→v2→复测噪声内稳定）

| 场景 | v1 | v2 | 复测 | 判定 |
|---|---:|---:|---:|---|
| LargeBean tree ser | 30.60 | 32.32 | 29.74 | 噪声 |
| BigString tree ser | 47.16 | 46.44 | 41.49 | −10.6%，噪声（±11% Err） |
| BigString tree deser | 82.40 | 80.84 | 84.15 | 噪声（±8.5% Err） |
| BigString cangjieJSON ser | 50.37 | 42.73 | 41.19 | 噪声 |
| BigString cangjieJSON deser | 87.25 | 76.66 | 77.71 | 噪声 |

**结论：** 除源码修复点（§4.1/§4.2/§4.3）外，v1→v2→复测无其他系统性变化，相对结构稳定。

---

## 5. PerfLargeList 工作负载分析

### 5.1 序列化：stream 大幅领先（1.87× 快于 tree）

PerfLargeList ser：stream **5.116ms** < cangjieJSON 8.979 < tree 9.591。

200×110 字段对象列表，stream `encode` 直写 buffer 省去整棵 JsonValue DOM 的构建 + 二次遍历，优势随对象数×字段数累积。tree 与 cangjieJSON（同为 tree/DOM 路径）接近（9.591 vs 8.979），印证二者 DOM 序列化 codegen 同量级。**序列化侧 json4cj stream 已是仓颉最优，对 Jackson 4.7× 差距 = itoa 地板（200×(61 字符串 + 30 int + 16 long) 的 itoa/字符串物化主导）。**

### 5.2 反序列化：stream 批量退化（仍存·头条）

PerfLargeList deser：cangjieJSON **9.355ms** < tree 10.86 < **stream 16.55**。

| 路径 | deser (ms) | v2 原值 | 相对 cangjieJSON |
|---|---:|---:|---:|
| cangjieJSON (tree) | 9.355 | 9.477 | 1.00× |
| json4cj tree | 10.86 | 12.36 | 1.16×（v2: 1.30×） |
| json4cj stream | 16.55 | 16.19 | 1.77×（v2: 1.71×） |

**stream 反序列化在批量宽对象上仍为最慢**，与 LargeBean（单对象 24 字段）上 stream 略快于 tree（27.79 vs 27.18，噪声内持平）相反。daf0b6e 未触及 stream，tree deser 已降至 10.86，使 tree-vs-stream 差距从 v2 的 1.31× 扩大至 1.52×——**tree 反序列化在批量场景更优于 stream**。

**差异原因（stream 批量退化的机理）：**
- **tree 路径**：一次 `JsonValue.fromStr`（stdx 原生单遍解析器，C/native 级批量 token 化）+ DOM→对象映射。解析成本摊薄到一次原生调用。
- **stream 路径**：逐字段 `JsonReader` token 分派——每个字段 = `next()` + 字段名字符串匹配 + 值解码。200×110 = 22000 次字段分派，每次走 json4cj 自身的 token 循环 + 字段名查找，常数开销高。
- **结论**：单对象时 stream 省 DOM 占优；批量宽对象时 stdx 原生批量解析反超 stream 的逐字段分派。与 v1「BigString stream ser 逐字符 ByteBuffer 写退化」对称——**stream 的粒度优势在单对象、劣势在批量**。

**对 T9.12 的直接证据：** tree deser（10.86）< stream deser（16.55）——tree 反序列化在批量场景已优于 stream，stream 的 token 地板不再是 json4cj 反序列化的下限，子杠杆 1（tree codegen）的收益不依赖 stream 路径。

### 5.3 cangjieJSON 反序列化仍最快（1.16× 残余余量）

PerfLargeList tree deser：json4cj 10.86 vs cangjieJSON 9.355 = **1.16×**（v2: 1.30×）。这是三个工作负载中 cangjieJSON-vs-json4cj-tree 差距最小的（LargeBean 1.35×、BigString 1.08× 噪声）。PerfLargeList 含 8000 HashMap entry，daf0b6e 收益在此最集中，故差距收窄最显著——**既验证修复生效，又证明 DOM→对象映射 codegen 仍有 1.16× 残余余量**（cangjieJSON 同 stdx 解析地板、同 DOM 映射范式，更快即 codegen 更精简；残余或含 Int32 range check、编译/内联差异）。

---

## 6. 仓颉实现互比（复测全景）

| 场景 | json4cj tree | json4cj stream | cangjieJSON | 仓颉最快 | 最慢/最快 |
|---|---:|---:|---:|---|---:|
| LargeBean ser | 29.74 | **16.18** | 25.60 | stream | 1.84× |
| LargeBean deser | 27.18 | 27.79 | **20.08** | cangjieJSON | 1.38× |
| BigString ser | 41.49 | 51.28 | **41.19** | cangjieJSON | 1.24× |
| BigString deser | 84.15 | **64.10** | 77.71 | stream | 1.31× |
| PerfLargeList ser | 9.591 | **5.116** | 8.979 | stream | 1.87× |
| PerfLargeList deser | 10.86 | 16.55 | **9.355** | cangjieJSON | 1.77× |

- **序列化：** stream 在对象列表/单对象上领先（LargeBean 1.84×、PerfLargeList 1.87× 快于 tree）；BigString 上 tree/cangjieJSON 略胜（stream 残余 24% 开销，§4.1）。
- **反序列化：** cangjieJSON 在对象上持续胜出（LargeBean 1.38×、PerfLargeList 1.16×——后者较 v2 1.30× 收窄）；BigString 三方贴齐（噪声内）。**stream deser 在 PerfLargeList 仍为最慢**（§5.2）。

---

## 7. 对 T9.11 / T9.12 的影响更新

### T9.11 — itoa 乘法强度削减（序列化杠杆）
- **结论不变。** 序列化侧 json4cj stream 仍是仓颉最快，无源码级落后于同侪；对 Jackson 的 4.7×（PerfLargeList stream ser）差距 = itoa 地板。PerfLargeList（200×46 个数值字段的 itoa）是 T9.11 收益最高的场景。
- **作用面仅对象/数组序列化。** BigString ser 2.5–3.1× Jackson（字符串拷贝主导），T9.11 对大字符串无收益。

### T9.12 — 反序列化优化
- **子杠杆 1（适配器物化消除）已兑现。** daf0b6e 收回 PerfLargeList 1.30×→1.16×、LargeBean 1.48×→1.35×。**cangjieJSON 仍证明同地板上还有 1.16~1.35× 余量**——残余或含 Int32 range check（cangjieJSON 直接 `Int32(n)`）、编译/内联差异、`Option`/missing/alias/default 分流开销。可继续 profile json4cj `fromJsonValue` 每字段冗余，目标 tree deser 追平 cangjieJSON。
- **子杠杆 2（stream deser 批量退化，仍未处理）。** PerfLargeList stream deser 16.55ms（1.52× 慢于 tree、1.77× 慢于 cangjieJSON）。逐字段 `JsonReader` 分派在批量宽对象上被 stdx 原生批量解析反超。应评估 stream deser 是否对宽对象走"批量取 token 块"或退化到 tree 路径。**与 T9.14 对称的源码级修复项**，收益确定、风险中。
- **tree deser 已可反超 stream deser**（PerfLargeList 实证 10.86 < 16.55）——stream 路线的 token 地板不再是 json4cj 反序列化下限，子杠杆 1 的收益不依赖 stream 路径。

### T9.14 — BigString stream ser 退化（已闭环）
- 95.52(v1)→60.30(v2)→51.28(复测)，最差回归消除，已接近 52μs 单测目标。残余 24% 中位对 tree 的开销优先级降低，可后续随 stream deser 批量修复一并处理（同属 `JsonWriter`/`JsonReader` 流式路径的粒度调优）。

---

## 8. 建议与后续

1. **T9.12 子杠杆 2 立项：stream deser 批量退化修复。** 复刻 T9.14 的闭环模式：profile `JsonReader` 逐字段分派在 200×110 场景的热点，评估"宽对象批量 token 读取"或"大列表 deser 走 tree 快路径"。预期 PerfLargeList stream deser 16.55 → ≤11（追平 tree）。
2. **T9.12 子杠杆 1 续推：fromJsonValue codegen 精简。** daf0b6e 已收回适配器物化大头，残余 1.16× 余量定位：读 cangjieJSON `@JsonAdapter` 的 `fromJsonValue` codegen，与 json4cj `HandleClass.cj` 逐字段对比（Int32 range check、Option/missing/alias/default 分流、集合元素 unboxing），PerfLargeList 8000 HashMap entry 放大易定位。
3. **T9.11 维持待拍板。** 序列化侧无源码落后，itoa 是唯一杠杆但高风险；PerfLargeList 是其最高收益场景，可作决策时的量化锚点。
4. **数据落盘已完成**：`docs/T9-e2e-bench-v2/data/` 含 3 工作负载的类定义（.cj/.java）+ JSON 串（.json），三方反序列化均消费同一份 JSON。

---

## 附录 A：测试输入数据落盘

`docs/T9-e2e-bench-v2/data/`（用户要求"测试用输入数据单独文件存放，包含类和 json 串"）：

| 文件 | 内容 | 大小 |
|---|---|---:|
| LargeBean.cj | json4cj `@Codable` 类（T9E2EDetail + T9E2ELargeBean） | 1733 B |
| LargeBean.java | Jackson POJO（NestedDetail + LargeBean） | 1883 B |
| LargeBean.json | LargeBean 序列化样本（json4cj `toJson()` 产出） | 1326 B |
| BigString.cj | json4cj `@Codable` 类（T9E2EBigString） | 815 B |
| BigString.java | Jackson POJO（BigStringBean） | 725 B |
| BigString.json | BigString 序列化样本 | 41125 B |
| PerfLargeItem.cj | json4cj `@Codable`（T9PerfLargeItem 110 字段 + T9PerfLargeList） | 4870 B |
| PerfLargeItem.java | Jackson POJO（61 String + 30 int + 16 long + bool + List + Map + PerfLargeList） | 3994 B |
| PerfLargeList.json | 200 项完整 JSON（真实 bench 输入） | 664816 B |

JSON 样本由 json4cj 侧 `toJson()` 物化（`T9DumpBenchData` @TestCase），三方反序列化均消费同一份 JSON，保证输入对等。

## 附录 B：基准源与复现

| 产物 | 路径 |
|---|---|
| Jackson E2E | [docs/jackson-bench/JacksonBenchE2E.java](../jackson-bench/JacksonBenchE2E.java)（6 bench：LargeBean/BigString/PerfLargeList × ser/deser） |
| json4cj E2E | [T9BenchE2E_test.cj](../../json4cj-databind/src/macros_test/T9BenchE2E_test.cj) `T9E2EBench`（8 @Bench）+ [T9BenchLargeList_test.cj](../../json4cj-databind/src/macros_test/T9BenchLargeList_test.cj) `T9PerfLargeListBench`（4 @Bench） |
| cangjieJSON E2E | `d:\tmp\cjjson-bench\src\Bench_test.cj`（独立包，6 @Bench） |
| JSON 落盘 | [T9DumpBenchData_test.cj](../../json4cj-databind/src/macros_test/T9DumpBenchData_test.cj) `T9DumpBenchData` @TestCase |

复现命令（每个包目录内，环境变量不跨调用持久）：
```bash
# Jackson（docs/jackson-bench 目录）
M2="C:/Users/flp_0/.m2/repository/com/fasterxml/jackson/core"
JARS="$M2/jackson-annotations/2.16.1/jackson-annotations-2.16.1.jar;$M2/jackson-core/2.16.1/jackson-core-2.16.1.jar;$M2/jackson-databind/2.16.1/jackson-databind-2.16.1.jar"
javac -cp "$JARS" JacksonBenchE2E.java && java -cp ".;$JARS" JacksonBenchE2E

# json4cj（json4cj-databind 目录）
export CANGJIE_HOME="/d/Program Files (x86)/Cangjie"; export PATH="$CANGJIE_HOME/bin:$PATH"
cjpm bench --filter "T9E2EBench"
cjpm bench --filter "T9PerfLargeListBench"
cjpm test  --filter "T9DumpBenchData"   # 落盘 JSON 到 CWD

# cangjieJSON（独立包 d:\tmp\cjjson-bench；需显式 import stdx，临时 cangjieJSON output-type=static）
export CANGJIE_HOME="/d/Program Files (x86)/Cangjie"; export PATH="$CANGJIE_HOME/bin:$PATH"
export CANGJIE_STDX_PATH="D:/Program Files (x86)/Cangjie/stdx"
cjpm bench --filter "CjJsonE2EBench"
```

## 附录 C：原始中位（复测）

```
Jackson:        LargeBean ser 1.693 / deser 3.457 ; BigString ser 16.435 / deser 32.151 ; PerfLargeList ser 1.080ms / deser 1.675ms
json4cj tree:   LargeBean ser 29.74 / deser 27.18 ; BigString ser 41.49 / deser 84.15 ; PerfLargeList ser 9.591ms / deser 10.86ms
json4cj stream: LargeBean ser 16.18 / deser 27.79 ; BigString ser 51.28 / deser 64.10 ; PerfLargeList ser 5.116ms / deser 16.55ms
cangjieJSON:    LargeBean ser 25.60 / deser 20.08 ; BigString ser 41.19 / deser 77.71 ; PerfLargeList ser 8.979ms / deser 9.355ms
JSON sizes:     LargeBean 1326 B ; BigString 41125 B ; PerfLargeList 664816 B（三方一致）

v2 原值（daf0b6e 前，对照）：
Jackson:        LargeBean ser 1.707 / deser 3.433 ; BigString ser 15.657 / deser 32.120 ; PerfLargeList ser 1.163ms / deser 1.702ms
json4cj tree:   LargeBean ser 32.32 / deser 28.61 ; BigString ser 46.44 / deser 80.84 ; PerfLargeList ser 10.01ms / deser 12.36ms
json4cj stream: LargeBean ser 15.69 / deser 26.89 ; BigString ser 60.30 / deser 72.76 ; PerfLargeList ser 4.906ms / deser 16.19ms
cangjieJSON:    LargeBean ser 25.36 / deser 19.31 ; BigString ser 42.73 / deser 76.66 ; PerfLargeList ser 9.114ms / deser 9.477ms
```
