/**
 * 基准输入数据 —— BigString（Jackson POJO，对应 BigString.cj 的 T9E2EBigString）。
 *
 * 字段名/类型/默认值与 Cangjie 侧一一对应。JSON 产物与 json4cj/cangjieJSON 逐字节一致。
 *
 * 实际基准源：docs/jackson-bench/JacksonBenchE2E.java（BigStringBean）。
 * 本文件为独立落盘的输入数据参考。
 */

public class BigString {

    // ---- 较大字符串：单大字符串 + 字符串数组 ----
    static class BigStringPOJO {
        public long id = 1;
        public String label = "payload";
        public String blob;                  // ~32KB
        public String[] chunks;              // 32 × 256
        public long checksum = 1234567890L;
    }
}
