/**
 * 基准输入数据 —— LargeBean（Jackson POJO，对应 LargeBean.cj 的 T9E2ELargeBean）。
 *
 * 字段名/类型语义/默认值与 Cangjie 侧一一对应（long↔Int64、double↔Float64、
 * boolean↔Bool、String[]↔Array<String>、long[]↔Array<Int64>、Map↔HashMap、
 * NestedDetail↔T9E2EDetail）。JSON 产物与 json4cj/cangjieJSON 逐字节一致。
 *
 * 实际基准源：docs/jackson-bench/JacksonBenchE2E.java（LargeBean + NestedDetail）。
 * 本文件为独立落盘的输入数据参考。
 */

public class LargeBean {

    // ---- 对应 LargeBean.detail ----
    static class NestedDetail {
        public String sku = "SKU-9999-MX";
        public long price = 129900;
        public long stock = 2048;
        public double weight = 0.375;
        public String warehouse = "WH-BJ-007";
    }

    // ---- 较大类：24 字段混合 ----
    static class LargeBeanPOJO {
        public long id = 1000001;
        public long seq = 42;
        public long version = 3;
        public long timestamp = 1700000000000L;
        public long flags = 7;
        public String name = "order-2026-08-10-0001";
        public String code = "ORD-AABBCCDD-1234";
        public String category = "electronics/phones/accessories";
        public String owner = "user.mufengzi@example.com";
        public String description;           // ~200 字符
        public boolean active = true;
        public boolean verified = false;
        public boolean enabled = true;
        public double score = 98.5;
        public double ratio = 0.875;
        public double latitude = 39.9042;
        public double longitude = 116.4074;
        public String[] tags;                // 20
        public long[] scores;                // 100
        public Map<String, String> meta;     // 20
        public NestedDetail detail = new NestedDetail();
    }
}
