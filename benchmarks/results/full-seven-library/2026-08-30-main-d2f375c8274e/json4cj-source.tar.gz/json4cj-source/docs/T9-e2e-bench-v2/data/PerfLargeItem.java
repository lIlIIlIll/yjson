/**
 * 基准输入数据 —— PerfLargeItem（110 字段大对象）+ PerfLargeList（200 项包装）。
 *
 * Jackson POJO，对应 PerfLargeItem.cj 的 T9PerfLargeItem/T9PerfLargeList。
 * 字段名/类型语义一一对应：String↔?String（全填充无 null）、int↔Int32、
 * long↔Int64、boolean↔Bool、List<String>↔ArrayList<String>、Map↔HashMap。
 * JSON 产物与 json4cj/cangjieJSON 逐字节一致。
 *
 * 实际基准源：docs/jackson-bench/JacksonBenchE2E.java（内嵌 PerfLargeItem + buildLargeItem）。
 * 本文件为独立落盘的输入数据参考。
 */

import java.util.*;

public class PerfLargeItem {
    // ===== 61 个 String 字段（对应 Cangjie ?String，buildLargeItem 全赋值） =====
    public String optStr01;
    public String optStr02;
    public String optStr03;
    public String optStr04;
    public String optStr05;
    public String optStr06;
    public String optStr07;
    public String optStr08;
    public String optStr09;
    public String optStr10;
    public String optStr11;
    public String optStr12;
    public String optStr13;
    public String optStr14;
    public String optStr15;
    public String optStr16;
    public String optStr17;
    public String optStr18;
    public String optStr19;
    public String optStr20;
    public String optStr21;
    public String optStr22;
    public String optStr23;
    public String optStr24;
    public String optStr25;
    public String optStr26;
    public String optStr27;
    public String optStr28;
    public String optStr29;
    public String optStr30;
    public String optStr31;
    public String optStr32;
    public String optStr33;
    public String optStr34;
    public String optStr35;
    public String optStr36;
    public String optStr37;
    public String optStr38;
    public String optStr39;
    public String optStr40;
    public String optStr41;
    public String optStr42;
    public String optStr43;
    public String optStr44;
    public String optStr45;
    public String optStr46;
    public String optStr47;
    public String optStr48;
    public String optStr49;
    public String optStr50;
    public String optStr51;
    public String optStr52;
    public String optStr53;
    public String optStr54;
    public String optStr55;
    public String optStr56;
    public String optStr57;
    public String optStr58;
    public String optStr59;
    public String optStr60;
    public String optStr61;

    // ===== 30 个 int 字段（对应 Int32） =====
    public int intVal01;
    public int intVal02;
    public int intVal03;
    public int intVal04;
    public int intVal05;
    public int intVal06;
    public int intVal07;
    public int intVal08;
    public int intVal09;
    public int intVal10;
    public int intVal11;
    public int intVal12;
    public int intVal13;
    public int intVal14;
    public int intVal15;
    public int intVal16;
    public int intVal17;
    public int intVal18;
    public int intVal19;
    public int intVal20;
    public int intVal21;
    public int intVal22;
    public int intVal23;
    public int intVal24;
    public int intVal25;
    public int intVal26;
    public int intVal27;
    public int intVal28;
    public int intVal29;
    public int intVal30;

    // ===== 16 个 long 字段（对应 Int64） =====
    public long longVal01;
    public long longVal02;
    public long longVal03;
    public long longVal04;
    public long longVal05;
    public long longVal06;
    public long longVal07;
    public long longVal08;
    public long longVal09;
    public long longVal10;
    public long longVal11;
    public long longVal12;
    public long longVal13;
    public long longVal14;
    public long longVal15;
    public long longVal16;

    // ===== 1 个 boolean + 集合字段 =====
    public boolean boolVal;
    public List<String> tags;          // 40 元素
    public Map<String, String> attrs;  // 40 entry
}

class PerfLargeList {
    public List<PerfLargeItem> items;
}
