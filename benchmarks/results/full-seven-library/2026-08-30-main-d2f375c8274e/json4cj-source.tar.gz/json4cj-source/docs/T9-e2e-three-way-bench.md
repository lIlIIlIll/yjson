# T9 端到端三方基准（json4cj vs cangjieJSON vs Jackson）

> 生成日期：2026-08-10
> 环境：Windows 11 / x64；Cangjie 1.0.5（cjpm 1.0.5）；JDK 21.0.11 (Temurin)；Jackson 2.17.2
> 三个被测件：① json4cj（本仓库，宏路径 tree + stream）；② cangjieJSON（`D:\code\jackson\cangjieJSON`，`@JsonAdapter` 宏，tree-only，同样基于 stdx `JsonValue`）；③ Jackson 三组件（`D:\code\jackson`，`writeValueAsString`/`readValue` 字符串端到端）。
> 绝对值运行间波动 ±30%（机器负载），**结论以同环境相对对比为准**（同 [T9-performance-baseline.md](T9-performance-baseline.md) §1）。三方均在 2026-08-10 同一会话内跑完，跨实现相对结构可靠。

---

## 1. 结论（TL;DR）

**三方端到端（字符串路径）对比后，先前的"json4cj 反序列化无源码级优化空间、地板在仓颉运行时"结论被部分推翻：反序列化存在源码级头空间，序列化则仍受 itoa 地板制约。**

1. **对象路径（LargeBean，24 字段含集合，~1.3KB）差距最大：7.6× ~ 17.1×。** 与基线 §2 一致——集合/双精度密集对象 itoa + 装箱分配主导。
2. **大字符串路径（BigString，~41KB）差距收窄至 2.2× ~ 6.1×。** 单对象开销被大负载摊薄，原始字符串 I/O 主导，仓颉 stdx 在此接近 Jackson。
3. **【新发现·头条】cangjieJSON 在对象反序列化上快于 json4cj。** cangjieJSON 同为仓颉程序、同样基于 stdx `JsonValue.fromStr` 解析（[IJsonAdapter.cj:6](../D:/code/jackson/cangjieJSON/src/IJsonAdapter.cj) `internal import stdx.encoding.json.*`，`fromJson` = `fromJsonValue(JsonValue.fromStr(str))`），**解析步骤与 json4cj 完全相同**，却在 LargeBean 反序列化上比 json4cj 快 1.41×（stream）/ 1.73×（tree）。解析地板相同 → 差距在 **DOM→对象映射 codegen（`fromJsonValue`）**，即 **json4cj 源码侧有可优化头空间**。
4. **序列化 json4cj stream 已是仓颉实现中最快。** LargeBean ser json4cj stream 16.76μs < cangjieJSON 27.13μs（1.62× 快）< json4cj tree 30.60μs。序列化侧 json4cj 已触及仓颉前沿，剩余对 Jackson 的 9.4× 差距 = itoa 地板（T9.11 范畴）。
5. **stream vs tree 随负载形状翻转**：对象两者皆 stream 胜；大字符串序列化 tree 胜（stream 逐字符 ByteBuffer 写入退化 2×）、反序列化 stream 胜。其中 **BigString stream 序列化退化（95.52μs，2× 慢于 tree）是 json4cj 源码可修的独立问题**，非运行时地板。

> 对 T9.11/T9.12 的直接影响：**T9.12（反序列化优化）应升档推进**——cangjieJSON 证明 stdx 地板之上仍有 1.4-1.7× 头空间；**T9.11（itoa 乘法强度削减）仍是序列化唯一杠杆**，但仅作用于对象/数组序列化路径，大字符串序列化无收益。另起一项修复 BigString stream 序列化退化。

---

## 2. 方法论与工作负载

三方使用**结构一一对应**的工作负载（字段名、类型、元素数一致），仅语言语法差异：

- **LargeBean**（较大类，~1.3KB）：24 字段混合——5×Int64 + 4×String + 3×Bool + 3×Float64 + `Array<String>(20)` + `Array<Int64>(100)` + `HashMap<String,String>(20)` + 嵌套 5 字段对象。`description`=200 字符长串。
- **BigString**（较大字符串，~41KB）：`id`/`label`/`checksum`（Int64/String）+ 32KB blob（`'a'`×32768）+ `Array<String>(32×256)`。

| 被测件 | 路径 | 序列化 | 反序列化 | 方法 |
|---|---|---|---|---|
| Jackson | 字符串端到端 | `mapper.writeValueAsString(obj)` | `mapper.readValue(json, Class)` | 手写 `nanoTime()` 循环，预热 1s + 测量 3s |
| json4cj | tree | `obj.toJson()` | `T.fromJson(json)` | `@Bench`，预热 1s + 测量 ~5s，取中位 |
| json4cj | stream | `obj.encode(JsonWriter(ByteBuffer))` | `T.decode(JsonReader)` | 同上 |
| cangjieJSON | tree | `obj.toJson()` | `T.fromJson(json)` | 同上（仅 tree，无 stream 路径） |

基准源文件：
- Jackson：[docs/jackson-bench/JacksonBenchE2E.java](jackson-bench/JacksonBenchE2E.java)
- json4cj：[json4cj-databind/src/macros_test/T9BenchE2E_test.cj](../json4cj-databind/src/macros_test/T9BenchE2E_test.cj)（`@Test class T9E2EBench`，8 个 `@Bench`）
- cangjieJSON：独立基准包 `d:\tmp\cjjson-bench`（依赖 cangjieJSON；cangjieJSON `JsonValue`/`JsonObject` 经 `internal import` 不外导，须在基准文件显式 `import stdx.encoding.json.*`；为避免 stdx 静态重复链接，临时将 cangjieJSON `output-type` 设 `static` 跑完即恢复 `dynamic`）。

---

## 3. 实测结果

### 3.1 LargeBean（24 字段含集合，产物 ~1.3KB）

| 实现 | 序列化 (μs) | 反序列化 (μs) | ser/Jackson | deser/Jackson |
|---|---:|---:|---:|---:|
| Jackson | 1.791 | 3.795 | 1.0× | 1.0× |
| json4cj tree | 30.60 | 35.36 | 17.1× | 9.3× |
| json4cj stream | 16.76 | 28.90 | 9.4× | 7.6× |
| cangjieJSON | 27.13 | 20.50 | 15.1× | **5.4×** |

### 3.2 BigString（~41KB）

| 实现 | 序列化 (μs) | 反序列化 (μs) | ser/Jackson | deser/Jackson |
|---|---:|---:|---:|---:|
| Jackson | 15.603 | 32.708 | 1.0× | 1.0× |
| json4cj tree | 47.16 | 82.40 | 3.0× | 2.5× |
| json4cj stream | 95.52 | 72.96 | 6.1× | 2.2× |
| cangjieJSON | 50.37 | 87.25 | 3.2× | 2.7× |

> json4cj/cangjieJSON 为 `@Bench` 中位（Err% 2.6-11%）；Jackson 为 `nanoTime` 循环均值。跨实现相对结构稳定，绝对值 ±30%。

---

## 4. 分析

### 4.1 对象路径（LargeBean）：差距最大处（7.6× ~ 17.1×）

与 [基线 §2](T9-performance-baseline.md#2-同环境实测对比json4cj-vs-jackson) 一致：含 100 元素 Int64 数组 + 20 entry Map + 3 个 Float64 的对象，序列化受 itoa/Float64 格式化主导（基线 §3/§4：算术占 ~85%），反序列化受逐元素装箱（`Long`/`String`）+ Map 建桶分配放大（基线 §4.3）。LargeBean 的 9.4-17.1× 落在基线"集合类 11-26×"区间内，结构吻合。

### 4.2 大字符串路径（BigString）：差距收窄（2.2× ~ 6.1×）

41KB 负载下单对象开销被摊薄，原始字符串 I/O（UTF-8 拷贝、转义扫描）主导。仓颉 stdx 的字符串处理远比其 itoa 接近 Jackson——三方 BigString 反序列化都在 2.2-2.7×，BigString tree 序列化都在 3.0-3.2×。**大字符串路径不是 itoa 瓶颈所在**，这界定出 T9.11 itoa 优化的有效作用面：仅对象/数组序列化，对大字符串序列化无收益。

### 4.3 仓颉实现互比：序列化 json4cj stream 最快，反序列化 cangjieJSON 最快（头条）

把两个仓颉实现单独拎出比较（同为仓颉、同为 stdx 地板，差异即源码/codegen 差异）：

| 场景 | json4cj tree | json4cj stream | cangjieJSON | 仓颉最快 | 仓颉最慢 / 最快 |
|---|---:|---:|---:|---|---:|
| LargeBean ser | 30.60 | **16.76** | 27.13 | json4cj stream | 1.83× |
| LargeBean deser | 35.36 | 28.90 | **20.50** | cangjieJSON | 1.73× |
| BigString ser | **47.16** | 95.52 | 50.37 | json4cj tree | 2.02× |
| BigString deser | 82.40 | **72.96** | 87.25 | json4cj stream | 1.20× |

**序列化侧（ser）：json4cj 已最优。** LargeBean ser json4cj stream（16.76）比 cangjieJSON（27.13）快 1.62×，比自身 tree 快 1.83×——流式 `encode` 直写 buffer 省去 DOM 构建+二次遍历的优势（基线 §8 已证）。BigString ser 则相反，tree（47.16）≈ cangjieJSON（50.37），stream 退化（95.52，2× 慢）——见 4.4。结论：**序列化 json4cj 无源码级落后于同侪**，对 Jackson 的剩余差距是 itoa 地板。

**反序列化侧（deser）：cangjieJSON 在对象上胜出，这是新发现。**

- **LargeBean deser：cangjieJSON 20.50 < json4cj stream 28.90 < json4cj tree 35.36。** cangjieJSON 比	json4cj tree 快 **1.73×**（稳健高于 ±30% 噪声：json4cj tree 区间 [24.8, 46.0]，cangjieJSON 20.50 落在其下沿之外），比 json4cj stream 快 1.41×（stream 区间 [20.2, 37.6]，cangjieJSON 处于其下沿，**此组对比偏边际、需复跑确认**，但 tree 对比已稳健）。
- **BigString deser：json4cj stream 72.96 < json4cj tree 82.40 < cangjieJSON 87.25。** 大字符串反序列化 json4cj stream 略胜，三方都在 2.2-2.7× Jackson 的窄带内，差异在噪声内。

**为什么 LargeBean deser 的 cangjieJSON 胜出是源码级头空间的证据？**

1. **解析步骤完全相同。** json4cj `fromJson` = `fromJsonValue(JsonValue.fromStr(json))`；cangjieJSON `fromJson` = `fromJsonValue(JsonValue.fromStr(str))`。`JsonValue.fromStr` 是 stdx 原生单遍解析器，二者调用同一份代码——**解析成本地板相同，差异不在解析**。
2. **差异在 DOM→对象映射 codegen。** 二者的 `fromJsonValue` 均由各自宏生成（json4cj `@Codable`、cangjieJSON `@JsonAdapter`），把 `JsonObject` DOM 映射到 bean 字段。cangjieJSON 更快 → 其映射 codegen 更精简。
3. **可能的成本来源（待 profiling 证实，非推测定论）：** json4cj `fromJsonValue` 每字段生成缺失字段逻辑（`JsonMissingField`）、`Option` 解包、`@CodableAlias` 多分支、`@CodableDefault` 判定等（[HandleClass.cj:583](../json4cj-annotations/src/macros/HandleClass.cj) 起 `jsonObj.get(name)` + missing/Option/default 分流）；cangjieJSON 功能子集更小（无 alias/policy/default 语义），每字段开销更低。LargeBean 含 100 元素 Int64 数组，若 json4cj 逐元素 `JsonInt`→`Int64` 转换多一层 `Option`/`match`，100 倍放大即可解释 1.4-1.7×。

> 这推翻了基线 §5/§8"反序列化无源码级优化空间、地板在 stdx `JsonReader`"的结论。该结论针对的是 **stream** 反序列化（stdx `JsonReader` 逐 token 确有固有开销）；但 **tree** 反序列化的瓶颈在 json4cj 自己的 `fromJsonValue` codegen，cangjieJSON 已证明同地板下可更快。

### 4.4 stream vs tree 随负载形状翻转

| 负载形状 | 序列化较快 | 反序列化较快 | 说明 |
|---|---|---|---|
| 对象（LargeBean） | stream（1.83× 快于 tree） | stream（1.22× 快于 tree） | 对象形数据 DOM 构建/解析开销超过流式 token 开销，stream 双向占优 |
| 大字符串（BigString） | **tree**（2.02× 快于 stream） | stream（1.13× 快于 tree） | 序列化：stream 逐字符 `ByteBuffer` 写入退化；反序列化：stream 增量读省去全 DOM |

**BigString stream 序列化退化（95.52μs，比 tree 47.16 慢 2.02×）是独立可修问题**：`JsonWriter` 写大字符串时逐字符（或小批）经 `ByteBuffer` 写入并逐字符查转义，而 tree 路径 `JsonValue.toString()` 是批量序列化器。对长无转义段做批量直写、仅对需转义字符走慢路径，可消除此退化。**这是 json4cj 源码级修复，非运行时地板**，收益直接（大字符串 stream ser 预期回落至 ~50μs 量级，与 tree 持平）。

---

## 5. 对 T9.11 / T9.12 的影响

### T9.11 — 乘法强度削减 itoa（序列化杠杆）

- **结论不变，作用面被精确界定。** 三方对比确认序列化侧 json4cj stream 已是仓颉最快，无源码级落后于同侪；对 Jackson 的 9.4×（LargeBean stream ser）差距 = itoa 地板。T9.11（`n/10` → `n * 倒数 >> shift`）仍是序列化唯一杠杆。
- **作用面仅对象/数组序列化。** BigString tree ser 仅 3.0× Jackson（字符串拷贝主导，非 itoa），T9.11 对大字符串序列化无收益。基线 §5 的风险判断（64 位乘法高字模拟、无 `__int128`、仅整数有效、收益不确定）依然成立。
- **三方对比未改变 T9.11 的风险/收益评估**，仅确认 json4cj 已在仓颉序列化前沿。

### T9.12 — 反序列化优化（应升档）

- **基线"反序列化无源码头空间"结论被推翻。** cangjieJSON（同 stdx 解析地板）在 LargeBean deser 快 json4cj 1.4-1.7×，证明 **DOM→对象映射 codegen 有源码级头空间**。T9.12 应从"待定/重大架构变更"升档为"有数据支撑的推进项"。
- **两档子杠杆，由低风险到高风险：**
  1. **优化 `fromJsonValue` codegen（低风险，先做）。** Profile json4cj vs cangjieJSON 的 DOM→对象映射差异，定位每字段冗余（`Option`/missing/alias 分流、集合元素 unboxing 路径）。目标：tree deser 追平 cangjieJSON（LargeBean 35.36 → ~20.5，潜在 1.7× 收益）。这是纯 codegen 调整，不绕 stdx，回归风险低。
  2. **自写解析器（高风险，后置）。** 绕过 `JsonValue.fromStr` + DOM，直接 `String→对象` 单遍解析，省去 DOM 构建与二次映射。仅在 (1) 触顶后再评估；收益上限更高（消除 DOM 分配），但须自洽处理转义/Unicode/状态机，工作量大。
- **stream 反序列化另论。** 基线 §8 的 stdx `JsonReader` 逐 token 固有开销结论仍成立（stream deser 28.90 仍受 token 层制约）；但 cangjieJSON 的 tree deser（20.50）已**低于** json4cj 的 stream deser（28.90）——意味着优化 tree deser codegen 后，tree 反序列化可反超 stream，stream 路线的 token 地板不再是 json4cj 反序列化的下限。

### 新增项 — BigString stream 序列化退化修复

独立于 T9.11/T9.12，属 json4cj 源码级、低风险、收益确定：`JsonWriter` 大字符串批量直写 + 转义快路径。建议补入 todolist（T9.6 流式子项或新列 T9.13）。

---

## 6. 建议与后续

1. **T9.12 升档，先做 codegen 优化（子杠杆 1）。** 第一步：读 cangjieJSON `@JsonAdapter` 宏的 `fromJsonValue` codegen，与 json4cj `HandleClass.cj` 的 `fromJsonValueFunc` 逐字段对比，定位 json4cj 每字段多出的 `Option`/missing/alias/default 分流与集合元素转换开销；产出差异清单后做针对性精简并 `cjpm test` 回归。
2. **BigString stream ser 退化单独立项修复**（批量字符串写 + 转义快路径），预期大字符串 stream ser 从 95.52 降至 ~50 量级。
3. **T9.11 维持待用户拍板**：序列化侧已无源码头空间，itoa 乘法强度削减是唯一杠杆但高风险；三方对比未提供新证据改变其评估。
4. **复跑确认**：LargeBean deser 的 cangjieJSON-vs-json4cj-stream 对比（1.41×）处于 ±30% 边际，宜在同一会话内交替重跑 json4cj/cangjieJSON 各 2-3 次取中位，固化 1.4× 是否稳健；tree 对比（1.73×）已稳健。

---

## 附录 A：基准产物与复现

| 产物 | 路径 | 说明 |
|---|---|---|
| Jackson E2E | [docs/jackson-bench/JacksonBenchE2E.java](jackson-bench/JacksonBenchE2E.java) | LargeBean/BigString POJO + `bench()` helper |
| json4cj E2E | [json4cj-databind/src/macros_test/T9BenchE2E_test.cj](../json4cj-databind/src/macros_test/T9BenchE2E_test.cj) | `@Test class T9E2EBench`，8 `@Bench`（tree+stream × LargeBean+BigString） |
| cangjieJSON E2E | `d:\tmp\cjjson-bench\src\Bench_test.cj`（独立包，依赖 cangjieJSON） | `@Test class CjJsonE2EBench`，4 `@Bench`（tree-only） |

复现命令（每个包目录内，环境变量不跨调用持久）：
```bash
# Jackson
javac -cp "<jackson jars>" docs/jackson-bench/JacksonBenchE2E.java && java -cp ".:<jackson jars>" JacksonBenchE2E

# json4cj（json4cj-databind 目录）
export CANGJIE_HOME="/d/Program Files (x86)/Cangjie"; export PATH="$CANGJIE_HOME/bin:$PATH"
cjpm bench --filter "T9E2EBench"

# cangjieJSON（独立包 d:\tmp\cjjson-bench；需显式 import stdx，临时 cangjieJSON output-type=static）
export CANGJIE_HOME="/d/Program Files (x86)/Cangjie"; export PATH="$CANGJIE_HOME/bin:$PATH"
export CANGJIE_STDX_PATH="D:/Program Files (x86)/Cangjie/stdx"
cjpm bench --filter "CjJsonE2EBench"
```

## 附录 B：原始中位（μs）

```
Jackson:        LargeBean ser 1.791 / deser 3.795 ; BigString ser 15.603 / deser 32.708
json4cj tree:   LargeBean ser 30.60 / deser 35.36 ; BigString ser 47.16 / deser 82.40
json4cj stream: LargeBean ser 16.76 / deser 28.90 ; BigString ser 95.52 / deser 72.96
cangjieJSON:    LargeBean ser 27.13 / deser 20.50 ; BigString ser 50.37 / deser 87.25
```
