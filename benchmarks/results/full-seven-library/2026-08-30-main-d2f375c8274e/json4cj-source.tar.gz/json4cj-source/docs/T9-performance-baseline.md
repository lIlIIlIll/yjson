# T9 性能基线报告（对标 Jackson，同环境实测）

> 生成日期：2026-08-09  
> 环境：Windows 11 / x64；Cangjie 1.0.5（cjpm 1.0.5）；JDK 21.0.11 (Temurin)；Jackson 2.17.2  
> 机器负载波动导致绝对数值运行间 ±30%，**结论以同环境相对对比为准**（execution-plan §9.9 L882/L896）。

---

## 1. 结论（TL;DR）

**json4cj 当前无法达到 Jackson 的性能水平，根因是仓颉运行时（Cangjie runtime）的数字→字符串转换，而非 json4cj 源码。**

- 同环境对比：json4cj 在全部场景下比 Jackson 慢 **5× ~ 26×**。
- 诊断证明：底层 stdx 引擎（json4cj 的地基）已是性能地板；json4cj 封装仅 +5%~10%，宏路径 +0%（codegen 已最优）。
- **进一步隔离（算术 vs 分配，已定论）：~85% 的逐元素成本是整数除法算术（`n%10`/`n/10`），String 分配几乎无成本。** 纯 div/mod 循环（零分配）51.9μs ≈ `toString`（含分配）60.7μs 的 86%；零堆分配 itoa（62.6μs）并不比 `toString`（60.7μs）快——消除分配没带来任何加速。根因是仓颉 1.0.5 的编译器/JIT **未做除法强度削减**（`x/10` 未改写为乘法+位移），每个数字位走慢 `idiv`（~18ns vs JVM 乘法 ~1ns）。
- 达标项：**宏路径 ≥ 反射路径 3× 已满足**（20 字段时 4.01×）；宏 codegen ≈ 手写（−0.3%）；流式序列化 ≥ 树式 1.5×（1.71×）；注解开销 5/7 达标（<5%，unwrap/raw 为 DOM 构建+重序列化固有开销，T3 流式 bug 已修复）。
- 受限项：流式**反序列化**慢于树式 1.86×（stdx `JsonReader` 逐 token 开销 + 流式固有顺序匹配，非 json4cj codegen 可优化，见 §8）；大 JSON 绝对吞吐受 itoa 瓶颈制约远低于乐观目标；反射反序列化不可测（`BeanDecoder` stub）。

---

## 2. 同环境实测对比（json4cj vs Jackson）

json4cj：`cjpm bench`（@Bench，预热 1s + 测量 5s，取中位 μs）；Jackson：手写 `nanoTime()` 循环（预热 1s + 测量 3s）。

| 场景 | json4cj (μs) | Jackson (μs) | 倍率(json4cj/Jackson) |
|---|---:|---:|---:|
| T9.1.1 primitiveSerialize | 1.343 | 0.217 | 6.2× |
| T9.1.2 primitiveDeserialize | 2.195 | 0.291 | 7.5× |
| T9.3.2 largeArraySerialize (1000×Int64) | 94.73 | 3.660 | **25.9×** |
| T9.3.3 largeArrayDeserialize | 131.2 | 11.509 | 11.4× |
| T9.3.5 largeMapSerialize (100 entry) | 30.31 | 1.893 | 16.0× |
| T9.3.6 largeMapDeserialize | 70.80 | 2.789 | 25.4× |
| T9.4.1 deepNestedSerialize | 1.187 | 0.208 | 5.7× |
| T9.4.2 deepNestedDeserialize | 2.256 | 0.333 | 6.8× |
| T9.4.3 wideSerialize (20 字段) | 2.876 | 0.440 | 6.5× |
| T9.4.5 ultraWideSerialize (50 字段) | 3.495 | 0.841 | 4.2× |
| T9.4.6 ultraWideDeserialize | 16.76 | 1.714 | 9.8× |

> 集合类（大数组/大 Map）差距最大（11×~26×）；标量/窄对象差距相对小（4×~8×），因数字格式化成本被分摊。

---

## 3. 根因隔离诊断（T9ArrayDiag）

对 1000 个 Int64 写入做七路拆解，定位成本归属（算术 vs 分配）：

| 诊断方法 | 中位 (μs) | 含义 |
|---|---:|---|
| `pureArithmeticNoAlloc` | 51.92 | 纯 `n%10`/`n/10` 循环，**零分配**、无数组/buffer/String |
| `directBufferWrite` | 45.86 | 1000× `buf.write(预计算字节)` + 5KB readToEnd/fromUtf8 |
| `int64ToStringOnly` | 60.72 | 纯 `Int64.toString()`×1000，**无 buffer**（含 String 分配） |
| `rawStdxArray` | 62.25 | stdx 原生 `writeValue(Int64)`×1000 + flush + 物化 |
| `itoaToVArray` | 62.55 | 零堆分配 itoa（div/mod + 写栈上 VArray + 逆序） |
| `macroArray` | 67.06 | `CollectionBean.encode(writer)` 宏全路径 |
| `json4cjArray` | 66.08 | json4cj `JsonWriter.writeValue(Int64)` 封装 |

**关键读数（算术 vs 分配，已定论）：**
- `pureArithmeticNoAlloc`(51.9μs，零分配、只做除法) 占 `toString`(60.7μs) 的 **86%** → **成本在算术（整数除法），不在分配**。1000 个数（0-999）约 2889 次 div/mod，每次 ~18ns，正是 x86 `idiv` 代价。
- `itoaToVArray`(62.6μs，**零堆分配**) ≈ `int64ToStringOnly`(60.7μs，**有 String 分配**) → **消除 String 分配几乎零收益**（零分配版甚至略慢，因多了逆序/写入）。先前"分配是元凶、零分配快速路径可大幅加速"的假设被**证伪**。
- `macroArray`(67.1) ≈ `json4cjArray`(66.1) ≈ `rawStdx`(62.3) + 封装开销 → **宏 codegen 零额外开销**（与手写一致，已验证 handWideSerialize 1.23μs ≈ macroWideSerialize 1.27μs）。
- json4cj 封装层 `writeValue(Int64)` 源码（`JsonWriter.cj:67-70`）是纯透传 `inner.writeValue(v)`，无逐调用检查；Float64/String 的逐调用检查（NaN/Infinity/escape）系正确性必需，非冗余。

> 绝对值运行间波动 ±30%（机器负载），但**相对结构稳定**：算术占比始终 ≥85%，json4cj 开销占比始终 ≤10%。

---

## 4. 为什么仓颉运行时慢于 JVM（机制分析）

逐数成本：仓颉 `Int64.toString()` ≈ 61ns；Jackson 整条流水线 ≈ 3.5ns。差距 ~17×，来自：

1. **整数除法算术（主因，~85%）。** itoa 的核心是 `n%10`（取最低位）+ `n/10`（右移一位）循环。诊断 `pureArithmeticNoAlloc`（51.9μs，**零分配**、只做 div/mod）占 `toString`（60.7μs）的 86%——成本在**算术**而非分配。根因：**仓颉 1.0.5 的编译器/JIT 未做除法强度削减**，`x/10` 原样编译为硬件 `idiv`（x64 上 ~20-40 周期，约 18ns/次）；而 JVM 的 Hotspot 把 `x/10` 重写为 `x * 0xCCCCCCCCCCCCCCCD >> 3`（乘法 ~3 周期，约 1ns），再叠加分支 itoa/查表，单数成本低一个数量级。1000 个数（0-999）约 2889 次 div/mod，18ns × 2889 ≈ 52μs，与实测 51.9μs 吻合。
2. **分配并非元凶（已证伪）。** 先前推测 String 堆分配是主因，但 `itoaToVArray`（零堆分配，写栈上 VArray）62.6μs ≈ `int64ToStringOnly`（每次 new String）60.7μs——**消除分配几乎零收益**（零分配版因多一次逆序甚至略慢）。JIT 成熟度（逃逸分析/栈上分配）虽是 JVM 优势，但对 itoa 这类短命数字的贡献远不如除法优化。
3. **反序列化分配放大。** 大数组反序列化 11.4×、大 Map 反序列化 25.4×——逐元素需装箱（`Long`/`String`）、建 Map 桶，仓颉分配 + GC 单对象成本高于 JVM 分代 GC 对短命对象近零成本的处理。此处分配确有影响（区别于序列化的 itoa 路径）。
4. **buffer 物化。** json4cj 末尾 `String.fromUtf8(readToEnd(buf))` 需 UTF-8 解码为 String；Jackson 直接返回 `byte[]`，少一次解码。此项占比小（见 directBufferWrite 45.9μs），非主因。

**结构性证据（非推测）：** 即使假设 json4cj 零开销，`pureArithmeticNoAlloc` 仍是 51.9μs，`rawStdx` 仍是 62μs，比 Jackson 的 3.5μs 慢 15-18×。地板在仓颉运行时的整数除法，不在 json4cj 侧。

---

## 5. 可行性与建议

**json4cj 源码层面无可优化项**（已验证：封装透传、宏 codegen 与手写等价、反射路径 by-design 仅 public）。曾设想绕过 stdx + `Int64.toString()` 缩小差距，实验后结论如下：

- **零分配快速路径——已证不可行。** 自写"div/mod + 写栈上 VArray/直写 ByteBuffer、不创建 String"的 itoa（`itoaToVArray` 62.6μs）并不比 `Int64.toString()`（60.7μs）快——因为成本在**整数除法算术**而非 String 分配。只要仍用 `n/10`、`n%10`，无论是否分配 String，都付同样的 `idiv` 代价。
- **唯一可能有效的方向——用乘法替代除法的 itoa。** 把 `n/10` 替换为 `n * 倒数 >> shift`（除法强度削减，即 JVM 的做法），理论上可将算术成本从 ~18ns/位降到 ~1-3ns/位。但：① 需手写 64 位乘法的高 64 位取值（Cangjie 无 `__int128`，需拆高低位模拟，易错）；② 仅对整数序列化有效，Float64/Unicode String 等瓶颈另在别处；③ 即便算术提速 ~10×，buffer 物化、反序列化分配等仍存，整体仍未必追平 Jackson；④ 仓颉 1.0.5 是否对 `Int64.toString()` 内部已有同样优化未知（实测 60.7μs 表明它没有，或做得不如 JVM）。
- **代价与风险**：① 架构变更（绕过 execution-plan 既定的 stdx 引擎）；② 工作量大（需覆盖 Int64/UInt64 等数值写出路径，且要与 stdx 的状态机/pretty/转义对齐）；③ 收益不确定；④ 需大量正确性测试。

**建议**：此为重大架构决策，需用户拍板。当前阶段先以本报告记录基线与根因，T9.5~T9.9 继续推进 json4cj 内部可达标的子项（注解开销、流式 vs 树式、宏 vs 反射等），宏-vs-反射 3× 已达标。

---

## 6. 已达标 / 受限项速查

| 指标 | 目标 | 实测 | 状态 |
|---|---|---|---|
| 宏路径 ≥ 反射 3×（T9.7.5） | ≥3× | 4.01×（20 字段） | ✅ 达标 |
| 宏 codegen 最优 | ≈手写 | handWide 1.903 ≈ macroWide 1.898 | ✅ 达标 |
| 流式序列化 ≥ 树式 1.5×（T9.6.1） | ≥1.5× | 1.71× | ✅ 达标 |
| 注解开销 <5%（T9.5） | <5% | 5/7 达标（unwrap/raw 为固有开销 3.13×/6.64×，非 bug） | ⚠ 部分达标 |
| 流式反序列化 ≥ 树式 1.5×（T9.6.2） | ≥1.5× | 1.86× 慢（反方向） | ❌ stdx+流式固有 |
| 大 JSON 吞吐（T9.6.3-6） | ≥10/5/5/3 ops/ms | 1.08/0.61/0.62/0.86 | ❌ itoa 瓶颈 |
| 不慢于 Jackson（T9.1 等） | ≤Jackson | 慢 5×~26× | ❌ 受仓颉运行时限制 |
| T9.7.4 反射反序列化 | 可测 | BeanDecoder 为 stub（仓颉反射无法调构造器） | ⏸ 不可测 |

---

## 7. T9.5 注解开销（7 例）

验证各注解相比无注解基线不引入显著序列化/反序列化开销。设计：每例一对 `@Bench`（baseline 无注解 vs annotated 带注解，同结构同字段数），由两次中位之比计算开销。取两次独立运行的稳定值（绝对值运行间 ±30%，以**比率为准**）。

| 用例 | base (μs) | annotated (μs) | 开销 | 目标 | 状态 |
|---|---:|---:|---:|---|---|
| T9.5.1 @CodableKey | 1.386 | 1.383 | −0.2% | <5% | ✅ |
| T9.5.2 @CodableSkip | 1.347 | 0.971 | holder 快 28% | 更快 | ✅ |
| T9.5.3 @CodablePolicy[NON_NULL] | 0.953 | 0.928 | −2.6% | <5% | ✅ |
| T9.5.4 @CodableAlias | 0.939 | 0.940 | +0.1% | <10% | ✅ |
| T9.5.5 @CodableFormat | 1.003 | 1.004 | +0.1% | 允许慢 | ✅（no-op stub） |
| T9.5.6 @CodableUnwrap | 0.732 | 2.287 | 3.13× | <5% | ❌ 固有 |
| T9.5.7 @CodableRaw | 0.869 | 5.766 | 6.64× | 更快 | ❌ 固有 |

**结论：5/7 达标。** @CodableKey/Skip/Policy/Alias/Format 序列化开销均在噪声内（<5%，alias <10%），注解本身不引入显著开销：

- @CodableKey 仅替换**等长**键名（`"aaa"`→`"u01"`），写出字节数一致，开销 −0.2%（曾出现 +14.8% 的单次异常运行，重跑证实为机器负载噪声）。
- @CodableSkip 少写 2/6 字段，holder 快 28%，符合预期。
- @CodablePolicy[NON_NULL] 仅内联 `Option.isNone` 判断，−2.6%。
- @CodableAlias 多生成 2 个 `match` 分支，反序列化 +0.1%（可忽略）。
- @CodableFormat 当前为 **no-op stub**：`format` 已收集（`formatMsgs`）但 codegen 未调用 `getFormat()`，待 T5.3/T7 格式化器落地后需重测。

**T9.5.6/T9.5.7 未达标（T3 流式 bug 已修复，开销为 unwrap/raw 语义固有）：** 此前两者流式 `encode()` 存在两处源码 bug（unwrap 缺 `writeName`、raw `rawField` 绕过 stdx 状态机），仅能退至树路径度量。本轮已修复（见下），改回流路径重测，两者仍超目标——证实开销非 bug 所致，而是 unwrap/raw 的 DOM 构建+重序列化固有成本：

- @CodableUnwrap 流式 encode 现镜像树路径：`toJsonValue()` 构建内嵌 `JsonObject` → `entries()` 逐条 `writeName`+`writeJsonValue` 扁平写入父对象（不嵌套 startObject/endObject）。3.13× 开销与树路径 2.93× 同量级，瓶颈在 `toJsonValue()` 的 DOM 构建。
- @CodableRaw 流式 encode：`rawField` 改为 `JsonValue.fromStr` 解析 + `writeJsonValue` 逐字段重序列化（stdx 无原生 raw-value API，直写 ByteBuffer 会破坏状态机）。6.64× 开销**高于**树路径 3.59×——因 `writeJsonValue` 逐字段走状态机，而树路径 `JsonValue.toString()` 为直接序列化器。raw "更快" 的免转义收益在 stdx 上不可达（须先解析校验合法 JSON）。

**修复细节：** `JsonWriter.writeJsonValue(JsonValue)` 公共方法（自 PrettyPrinter 私有函数上提）递归写入任意 JsonValue 并正确推进 stdx 状态机；`rawField` 改调之；`HandleClass`/`HandleStruct` unwrap 流式 codegen 改用 `toJsonValue`+`entries`+`writeJsonValue`。新增 t5_8_4/t5_9_3 流式 encode 测试，全套 232/232 通过。注：unwrap 流式 **decode** 仍有独立 bug（endObject 后 `decode(reader)` 无法重读已消费的扁平字段），不在本次 encode 修复范围。

---

## 8. T9.6 流式 vs 树模型（6 例）

`@Codable` 生成两条路径：**流式** `encode(writer)`/`decode(reader)`（直接读写 buffer，无中间对象）与**树模型** `toJson()`=`toJsonValue().toString()`/`fromJson()`=`fromJsonValue(JsonValue.fromStr(json))`（先建/解析 DOM 再映射）。

| 用例 | stream | tree | 倍率 | 目标 | 状态 |
|---|---:|---:|---:|---|---|
| T9.6.1 流式写入 vs 树式写入（窄 20 字段） | 2.871μs | 4.912μs | stream **1.71× 快** | ≥1.5× | ✅ |
| T9.6.2 流式读取 vs 树式读取（窄 20 字段） | 6.881μs | 3.704μs | stream **1.86× 慢** | ≥1.5× | ❌ |
| T9.6.3 大 JSON 流式写入（1000 元素） | 0.929ms (1.08 ops/ms) | — | — | ≥10 ops/ms | ❌ itoa-bound |
| T9.6.4 大 JSON 流式读取 | 1.642ms (0.61 ops/ms) | — | — | ≥5 ops/ms | ❌ itoa-bound |
| T9.6.5 大 JSON 树式写入 | — | 1.619ms (0.62 ops/ms) | — | ≥5 ops/ms | ❌ itoa-bound |
| T9.6.6 大 JSON 树式读取 | — | 1.167ms (0.86 ops/ms) | — | ≥3 ops/ms | ❌ itoa-bound |

**结论：序列化流式达标（1.71× 快），反序列化流式未达标（1.86× 慢，与目标相反）；大 JSON 绝对吞吐受 itoa 瓶颈制约，远低于乐观目标。**

**流式序列化更快（✓）：** 树式 `toJson()` 须先构建 `JsonObject` DOM（每字段 `puts` 一次，含键值对的 `JsonString`/`JsonInt` 装箱分配），再 `toString()` 二次遍历序列化；流式 `encode(writer)` 直接 `writeName`+`writeValue` 写 buffer，省去 DOM 构建与二次遍历。窄对象 1.71×、大对象 1.74×（0.929ms vs 1.619ms），优势在尺度间稳定。

**流式反序列化更慢（✗，与目标相反）——根因在 stdx，非 json4cj codegen：**

1. **stdx `JsonReader` 逐 token 开销高于 `JsonValue.fromStr`。** 树式 `fromJson()`=`fromJsonValue(JsonValue.fromStr(json))`：`fromStr` 是 stdx 单遍优化的原生解析器，一次性建 HashMap DOM；流式 `decode(reader)` 经 `JsonReader` 的 `peek()`+`readName()`+`readXxx()` 逐 token 状态机，每字段多次 API 调用 + `Option<CjJsonToken>` 枚举往返，开销超过建 DOM 的成本。
2. **流式须顺序匹配字段名，树式 O(1) 查表。** 树式 `fromJsonValue` codegen 用 `jsonObj.get(name)`（HashMap O(1)，`HandleClass.cj:583`）；流式 `decode` codegen 用 `match (reader.readName())` 顺序串比较（流式无法对未缓冲 token 流随机访问，**这是流式 vs 树式的固有权衡，非缺陷**）。
3. **json4cj decode codegen 已最优。** 审查 `decodeFunc`（`HandleClass.cj:967-1200`）：`startObject` → `while(peek){ if(EndObject) break; match(readName){...; case _=>reader.skip()} }` → `endObject`，是规范的流式反序列化模式，无冗余检查、直接赋值、未知字段 `reader.skip()`。大对象（5 字段/项）仍 1.41× 慢于树式（1.642ms vs 1.167ms），证明成本在 stdx token 层而非字段名匹配（5 路串比较很廉价）。

**结论：T9.6 反序列化 "≥1.5×" 目标在 json4cj 层面不可达**——需 stdx 优化 `JsonReader` 或 json4cj 绕过 `JsonReader` 自写解析（同 §5 itoa 快速路径，属重大架构变更，待用户决策）。序列化目标已达标。

**大 JSON 绝对吞吐（T9.6.3-6）远低于目标：** 1000 元素×5 字段容器序列化 0.929ms→1.08 ops/ms（目标 ≥10）。根因同 §3/§4：每元素含 Int64/Float64 itoa（~62ns/数），1000 元素×~3 数 ≈ 186μs 仅算术，叠加 Float64/String/对象框架达 ~929μs。目标按 Jackson 级吞吐（~3.5ns/数）设定，受仓颉 itoa 瓶颈制约不可达，与 §5 结论一致。

---

## 9. T9.7 宏路径 vs 反射路径（5 例）

同路径对比：宏生成 `encode(writer)` vs `BeanEncoder.encode(writer)`（运行时反射读 public 字段）。反射 bean 字段须 `public var`（仓颉反射仅可见 public 成员，见 [[json4cj-beanencoder-public-only]]）。

| 用例 | macro (μs) | reflection/hand (μs) | 倍率 | 状态 |
|---|---:|---:|---:|---|
| T9.7.1 宏序列化（4 字段） | 1.207 | 2.809（reflect） | macro 2.33× 快 | — |
| T9.7.2 宏反序列化 | 2.281 | — | — | — |
| T9.7.3 反射序列化（4 字段） | — | 2.809 | — | — |
| T9.7.4 反射反序列化 | — | — | — | ⏸ BeanDecoder stub |
| T9.7.5 宏 vs 反射（20 字段） | 1.898 | 7.603（reflect） | macro **4.01× 快** | ✅ ≥3× |
| codegen 最优（20 字段） | 1.898 | 1.903（hand） | −0.3% | ✅ ≈手写 |

**结论：宏路径 ≥ 反射路径 3× **已达标**（20 字段 4.01×）。**

- **倍率随字段数增长：** 4 字段 2.33×、20 字段 4.01×。宏优势在每字段的直接访问（编译期生成 `writer.field("f0", b.f0)`），反射每字段须经 `instanceVariables` 迭代 + `v.getValue(obj)` + 类型 `match`；字段越多，反射的每字段开销（~300ns/字段）相对宏（~43ns/字段，边际）放大越明显，固定开销（`ByteBuffer`+`JsonWriter`+`ClassTypeInfo.of`+`toString`）被摊薄。4 字段时固定开销占比大，倍率仅 2.33×。
- **宏 codegen 已最优：** `macroWideSerialize` 1.898μs ≈ `handWideSerialize` 1.903μs（−0.3%，噪声内），与手写 `startObject`+20×`field`+`endObject` 等价，无额外开销。
- **T9.7.4 反射反序列化不可测：** `BeanDecoder` 为 stub——仓颉反射无法调用构造器/设置字段（无 `Constructor.newInstance` 等价物），故反射反序列化路径无法实现，倍率不可测。宏反序列化 `decode(reader)` 单独可测（2.281μs，7 字段）。

> 三项达标项汇总：宏-vs-反射 ≥3×（4.01×）✅、宏 codegen ≈手写 ✅、流式序列化 ≥树式 1.5×（1.71×）✅。受限项：不慢于 Jackson（受仓颉 itoa 限制 ❌）、流式反序列化 ≥树式（stdx+流式固有，反方向 ❌）、反射反序列化（BeanDecoder stub ⏸）、@CodableUnwrap/Raw 流式路径（bug 待 T3 ⚠）。
