# json4cj 功能测试用例总结（T1–T8）

> 分支：`feat/phase1-core`　|　测试命令：`cjpm test`　|　结果：**databind 全量 229/229 通过**
>
> 本文档汇总 T1–T8 基本功能测试用例，每条含「输入 / 期望输出 / 结果」。
> 仓颉 class 默认非 Equatable（`@Derive[Equatable]` 在含非 Equatable 嵌套类型/Option 时不可用），
> 故等值断言普遍采用字段逐项比对；高精度 Float64 受仓颉 `toString` ~7 位有效数字截断（语言级限制），用容差断言。

## 概览

| 组 | 文件 | 用例数 | 结果 |
|----|------|--------|------|
| T1 基础类型 | T1BasicTypes_test.cj | 30 | 全通过 |
| T2 自定义类型 | T2CustomTypes_test.cj | 11 | 全通过 |
| T3 用户类型 | T3UserTypes_test.cj | 39 | 全通过 |
| T4 集合类型 | T4CollectionTypes_test.cj | 27 | 全通过 |
| T5 注解功能 | T5AnnotationFeatures_test.cj | 22 | 全通过 |
| T6 边界异常 | T6BoundaryException_test.cj | 27 | 全通过 |
| T7 高级场景 | T7AdvancedScene_test.cj | 19 | 全通过 |
| T8 往返一致性 | T8RoundTrip_test.cj | 8 | 全通过 |
| **合计** | | **183** | **全通过** |

### 推迟项（非本轮同步修复范围，均已在测试文件头/行内标注）

- T2.3 元组（仓颉禁止扩展元组，需宏层数组式编解码）
- T3.4 泛型类型（宏未在生成方法施加 `where T <: IJsonAdapter<T>` 约束，泛型字段无默认值）→ 影响 T8.7
- T4.6 VArray（元素类型误解析为 `Int64,3`）、T4.7 Range（无自然 JSON 形态）
- T5.3 NON_EMPTY/NON_DEFAULT（仅设置 ignoreNull，写入门控未实现）、T5.6 @CodableFormat（format 收集但未调用）
- T6.3 $ref 反序列化还原（仅序列化侧去重实现）
- T7.5.2 模块覆盖默认编解码器（registerEncoder/setupModule 空占位，类型擦除未解决）、命名策略端到端、CodecFeature 行为级生效（均依赖宏查阅运行时配置）
- T8.7 泛型往返（依赖 T3.4）

### 本轮同步修复的源码缺陷

- @CodableOrder 静默空操作 → utils.cj 新增 `applyFieldOrder`，HandleClass/HandleStruct 的 collectFields 读取并重排
- struct 流式编码递归、@CodableUnwrap/@CodableAlias 缺陷
- 新增 ArrayList/HashSet 的 IJsonAdapter 扩展
- @CodableRef 编译缺陷：宏由 `field.hashValue()`（不存在）改为 `field.hashCode()`，RefContext 追踪键 UInt64→Int64，流式 @CodableRef 分支改用 buildStreamFieldWrite
- setNamingStrategy 静默丢弃策略 → 改为保留并新增 getNamingStrategy

---

## T1 基础类型（30 项）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t1_1_1 | 各整型正常值（i8=1…uNative=10） | 序列化含对应数值；反序列化字段全等 | PASS |
| t1_1_2 | 各整型上界/下界（含 UInt64 2^64-1） | 边界值无损往返；超大 UInt64 树路径以字符串出现 | PASS |
| t1_1_3 | 全默认 0 | JSON 含 `"i8":0`/`"u64":0`；往返为 0 | PASS |
| t1_1_4 | 有符号负值（i8=-1…iNative=-5） | 负值无损往返 | PASS |
| t1_1_5 | Int8 适配器入参 200 / UInt8 入参 300 | 抛 JsonOverflowException | PASS |
| t1_1_6 | `{"i8":1.5}` | 抛 JsonTypeException | PASS |
| t1_1_7 | UInt8 适配器入参 -5 | 抛 JsonOverflowException | PASS |
| t1_2_1 | f16=1.5,f32=3.14,f64=2.718281828 | 低精度精确往返；f64 容差 <1e-6 | PASS |
| t1_2_2 | f64=0.0 | JSON 含 `"f64":0`；往返为 0.0 | PASS |
| t1_2_3 | f64=2.718281828459045 | 受 toString 截断，容差 <1e-6 | PASS |
| t1_2_5 | Float64 适配器入参 JsonInt(1) | == 1.0 | PASS |
| t1_2_6 | `1.23e10` | Float64 解析 == 1.23e10 | PASS |
| t1_3_1 | flag=true | `{"flag":true}` | PASS |
| t1_3_2 | flag=false / 反序列化 true | `{"flag":false}`；反序列化得 true | PASS |
| t1_4_1 | text="hello" | 往返得 "hello" | PASS |
| t1_4_2 | text="" | `{"text":""}`；往返为空串 | PASS |
| t1_4_3 | text 含 `\n\t"` | 转义写出；往返还原原串 | PASS |
| t1_4_4 | text="中文🎉A" | Unicode 往返一致 | PASS |
| t1_4_5 | text=10000 个 'x' | 往返长度 == 10000 | PASS |
| t1_4_6 | text="a<b>c&d\"e" | HTML/特殊字符往返一致 | PASS |
| t1_5_1 | ch='A' | 往返得 'A' | PASS |
| t1_5_2 | ch='中' | 往返得 '中' | PASS |
| t1_5_3 | ch=U+1F389 | 往返得 U+1F389 | PASS |
| t1_5_4 | `{"ch":"AB"}` | 抛 JsonTypeException | PASS |
| t1_6_1 | bigInt=10^26-1 | 往返等值 | PASS |
| t1_6_2 | decimal=高精度 π | 往返等值 | PASS |
| t1_6_3 | bigInt 负超大 / decimal 极小 | 往返等值 | PASS |
| t1_7_1 | created=2026-07-30T12:00:00Z | toString 往返一致 | PASS |
| t1_7_4 | `{"created":"2026-13-45"}` | 抛 Exception | PASS |
| t1_stream | i8=-128,i64=MAX,u64=2^64-1（流路径） | u64 以数字无损写出；decode 字段全等 | PASS |

## T2 自定义类型（11 项）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t2_1_1 | Unit 字段 | 序列化为 null；适配器层 JsonNull | PASS |
| t2_1_2 | `{"nothing":null}` / `{}` | null→()；缺失非 Option 字段抛 JsonMissingField | PASS |
| t2_2_1 | Some(42)/Some("hello")/Some(inner) | JSON 含值；往返 Some 还原 | PASS |
| t2_2_2 | 全 None | 各字段 `null` | PASS |
| t2_2_3 | 显式 null 各字段 | 反序列化为 None | PASS |
| t2_2_4 | `{}` 缺失字段 | 反序列化为 None | PASS |
| t2_2_5 | Option<Option<Int64>> | Some(Some(1))↔1；None↔null；Some(None)↔null | PASS |
| t2_2_6 | [Some(1),None,Some(3)] | 数组 size=3；元素还原 | PASS |
| t2_2_7 | `{"maybeInt":"not a number"}` | 抛 JsonTypeException | PASS |
| t2_4_8 | color=Green | `"color":"Green"`；往返 `"Green"` | PASS |
| t2_4_9 | [Red,Green,Blue] | JSON 含三名称；往返 size=3 还原 | PASS |

## T3 用户类型（39 项）

### T3.1 普通 class（6）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t3_1_1 | name=张三,age=25,email=Some | JSON 含三字段 | PASS |
| t3_1_2 | email=None | `"email":null` | PASS |
| t3_1_3 | 完整 JSON 反序列化 | 字段全等（email 用 match） | PASS |
| t3_1_4 | 含 extra/unknown 字段 | 额外字段被忽略 | PASS |
| t3_1_5 | `{"age":25}` 缺 name | 抛 JsonMissingField | PASS |
| t3_1_6 | `{}` @CodableDefault | id=0,name=""，tag=None | PASS |

### T3.2 struct（4）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t3_2_1 | Point x=1.5,y=2.5 | JSON 含对应值 | PASS |
| t3_2_2 | `{"x":1.5,"y":2.5}` | 字段全等 | PASS |
| t3_2_3 | 嵌套 Rectangle | 含 topLeft/bottomRight；往返坐标全等 | PASS |
| t3_2_4 | PointBag 含 struct 数组 | 往返 label/points 还原 | PASS |

### T3.3 继承（5）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t3_3_1 | T3Animal 序列化 | 含 name/age | PASS |
| t3_3_2 | T3Dog 序列化 | 含父类+子类字段 | PASS |
| t3_3_3 | T3Dog 反序列化 | 父子字段全等 | PASS |
| t3_3_4 | PolyDog 多态 | 父类fromJson 分发为 PolyDog，字段全等 | PASS |
| t3_3_5 | 三级继承 A←B←C | a/b/c 全往返 | PASS |

### T3.5 混合类型（8）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t3_5_1 | Company 序列化 | 含 name/founded/active | PASS |
| t3_5_2 | employee.department=None | `"department":null` | PASS |
| t3_5_3 | 空 skills | `"skills":[]` | PASS |
| t3_5_4 | headquarters 嵌套 | 含 city/zipCode | PASS |
| t3_5_5 | employees 数组 | 含 张三/李四 | PASS |
| t3_5_6 | metadata Map | 含 level/region | PASS |
| t3_5_7 | 完整反序列化 | 各字段全等（含 None/空数组） | PASS |
| t3_5_8 | 往返一致性 | name/founded/employees/metadata 一致 | PASS |

### T3.6 sealed/多态（3）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t3_6_1 | T3Success/T3Failure | 含 type 鉴别字段+子类字段 | PASS |
| t3_6_2 | 父类静态类型多态序列化 | 写出子类字段 | PASS |
| t3_6_3 | variant 反序列化分发 | r is T3Success，字段全等 | PASS |

### T3.7 私有变量（13）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t3_7_1 | 私有字段反序列化后序列化 | 写出 password/age | PASS |
| t3_7_2 | 私有字段往返 | 再序列化含原值 | PASS |
| t3_7_3 | @CodableKey 私有字段 | 键为 pwd，不含 password | PASS |
| t3_7_4 | @CodableSkip 私有字段 | 不含 internalId，含 score | PASS |
| t3_7_5 | 私有 Option | null / "tok" 正确写出 | PASS |
| t3_7_6 | struct 私有字段 | x/y 往返 | PASS |
| t3_7_7 | 继承私有字段 | 父子私有字段均写出 | PASS |
| t3_7_8 | 私有 @CodablePolicy | None 省略；Some 写出 | PASS |
| t3_7_9 | 私有 @CodableAlias | 主键/两别名均回退 | PASS |
| t3_7_10 | 私有 @CodableUnwrap | 展开到顶层，不含 location | PASS |
| t3_7_11 | 私有 @CodableRaw | 内联原始 JSON | PASS |
| t3_7_12 | 全私有字段 | a/b/c 全写出 | PASS |
| t3_7_14 | 私有字段往返 | json2 == json1 | PASS |

## T4 集合类型（27 项）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t4_1_1 | nums=[1,2,3] | `"nums":[1,2,3]` | PASS |
| t4_1_2 | 反序列化数组 | 元素全等 | PASS |
| t4_1_3 | 空数组往返 | size=0 | PASS |
| t4_1_4 | 字符串数组 | 往返元素全等 | PASS |
| t4_1_5 | 布尔数组 | 往返元素全等 | PASS |
| t4_1_6 | 流路径数组往返 | nums 元素全等 | PASS |
| t4_2_1 | ArrayList 树往返 | size=2，元素全等 | PASS |
| t4_2_2 | ArrayList 流往返 | 元素全等 | PASS |
| t4_3_1 | Map 序列化 | 含各键值 | PASS |
| t4_3_2 | Map 反序列化 | get 返回 Some | PASS |
| t4_3_3 | 空 Map 往返 | size=0 | PASS |
| t4_3_4 | 字符串 Map 往返 | get 返回 Some | PASS |
| t4_3_5 | Map 流往返 | get 返回 Some | PASS |
| t4_3_6 | 多 entry Map | size=3，各键还原 | PASS |
| t4_4_1 | HashSet 树往返 | size=2，contains 成立 | PASS |
| t4_4_2 | HashSet 流往返 | contains 成立 | PASS |
| t4_4_3 | 空 HashSet 往返 | size=0 | PASS |
| t4_5_1 | 数组套数组 | 元素全等 | PASS |
| t4_5_2 | 数组套 Map | 各 Map 元素还原 | PASS |
| t4_5_3 | Map 套数组 | 数组元素全等 | PASS |
| t4_5_4 | Map 套 Map | 嵌套值还原 | PASS |
| t4_5_5 | 三层数组 | grid[0][0][0]=1 等 | PASS |
| t4_5_6 | Option 数组 | Some/None 还原 | PASS |
| t4_5_7 | Option 数组字段 | Some([7,8]) 还原 | PASS |
| t4_5_8 | Map 套字符串数组 | size=3，元素全等 | PASS |
| t4_5_9 | ArrayList 套数组 | 元素全等 | PASS |
| t4_5_10 | 对象数组 | id/name 全等 | PASS |

## T5 注解功能（22 项）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t5_1_1 | @CodableKey 字段 | 键为 user_name/user_age，不含原名 | PASS |
| t5_1_2 | 映射键反序列化 | 字段全等 | PASS |
| t5_1_3 | @CodableKey 往返 | 字段全等 | PASS |
| t5_1_4 | @CodableKey 流往返 | 流路径同样映射；字段全等 | PASS |
| t5_2_1 | @CodableSkip 序列化 | 不含 secret/值 | PASS |
| t5_2_2 | JSON 含 secret 反序列化 | secret 保持默认 | PASS |
| t5_2_3 | @CodableSkip 往返 | secret 丢失→"" | PASS |
| t5_3_1 | NON_NULL None | 字段省略 | PASS |
| t5_3_2 | NON_NULL Some | 字段写出 | PASS |
| t5_3_3 | 缺失 NON_NULL 字段 | 得 None | PASS |
| t5_3_4 | NON_NULL 混合往返 | Some 保留，None 保留 | PASS |
| t5_4_1 | @CodableOrder class | z<a<m 顺序 | PASS |
| t5_4_2 | @CodableOrder struct | z<a<m 顺序 | PASS |
| t5_5_1 | @CodableAlias 序列化 | 用主键，不用别名 | PASS |
| t5_5_2 | 主键反序列化 | 字段全等 | PASS |
| t5_5_3 | 第一别名回退 | userName 还原 | PASS |
| t5_5_4 | 第二别名回退 | userName 还原 | PASS |
| t5_8_1 | @CodableUnwrap 序列化 | 内层展开，不含 inner | PASS |
| t5_8_2 | @CodableUnwrap 反序列化 | 内层字段还原 | PASS |
| t5_8_3 | @CodableUnwrap 往返 | 内层字段全等 | PASS |
| t5_9_1 | @CodableRaw 序列化 | 字符串解析为内联 JSON | PASS |
| t5_9_2 | @CodableRaw 往返 | 还原为紧凑 JSON 字符串 | PASS |

## T6 边界与异常（27 项）

### T6.1 null 处理（5）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t6_1_1 | Option None | `"nick":null` | PASS |
| t6_1_2 | `{"nick":null}` | 得 None | PASS |
| t6_1_3 | 缺失 nick | 得 None | PASS |
| t6_1_4 | Some 往返 | Some("v") 还原 | PASS |
| t6_1_5 | 对象 Option None/Some 往返 | None/Some 还原（match 判定） | PASS |

### T6.2 空/缺失（5）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t6_2_1 | 空串往返 | `"name":""` | PASS |
| t6_2_2 | @CodableDefault 缺失 | 保留默认 0 | PASS |
| t6_2_3 | 必需字段缺失 | 抛 JsonMissingField | PASS |
| t6_2_4 | @CodableDefault 显式 null | 保留默认 0 | PASS |
| t6_2_5 | 空数组/空 Map 往返 | `[]` / `{}` | PASS |

### T6.3 循环引用（3）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t6_3_1 | 钻石 DAG + RefContext | 第二次写 $ref 标记 | PASS |
| t6_3_2 | @CodableRefBack | 跳过 parent，无 $ref | PASS |
| t6_3_3 | 未启用 RefContext | 共享对象完整写出两次 | PASS |

### T6.4 类型不匹配/异常（7）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t6_4_1 | name 给 123 | 抛 JsonTypeException | PASS |
| t6_4_2 | count 给 "abc" | 抛 JsonTypeException | PASS |
| t6_4_3 | active 给 "yes" | 抛 JsonTypeException | PASS |
| t6_4_4 | items 给 {} | 抛 JsonTypeException | PASS |
| t6_4_5 | addr 给 [1] | 抛 JsonTypeException | PASS |
| t6_4_6 | 缺必需 name | 抛 JsonMissingField | PASS |
| t6_4_7 | 畸形 JSON | 抛 Exception | PASS |

### T6.5 特殊字符串（7）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t6_5_1 | `a"b` | 转义 `\"`，往返还原 | PASS |
| t6_5_2 | `a\b` | 往返还原 | PASS |
| t6_5_3 | `a\nb\tc` | 往返还原 | PASS |
| t6_5_4 | 你好世界 | 往返还原 | PASS |
| t6_5_5 | 😀🚀 | 往返还原 | PASS |
| t6_5_6 | 空串 | `"s":""` | PASS |
| t6_5_7 | `{[}]` | 往返还原 | PASS |

## T7 高级场景（19 项）

### T7.1 自定义 Encoder/Decoder（3）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t7_1_1 | Encoder.encode("hi") | 含 `"tag":"hi"` | PASS |
| t7_1_2 | Decoder.decode(`{"tag":"hi"}`) | 得 "hi" | PASS |
| t7_1_3 | SimpleModule 注册编解码器 | 模块名/注册链 OK（占位） | PASS |

### T7.2 命名策略（4）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t7_2_1 | SnakeCase + setNamingStrategy | translate→user_name；策略保留可取 | PASS |
| t7_2_2 | CamelCase | identity（默认行为） | PASS |
| t7_2_3 | PascalCase | userName→UserName | PASS |
| t7_2_4 | KebabCase | userName→user-name | PASS |

### T7.3 树模型（5）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t7_3_1 | JSON→树 | isObject,size=2,has | PASS |
| t7_3_2 | 树→串 | 紧凑含字段；pretty≠紧凑 | PASS |
| t7_3_3 | users/0/name 路径查询 | 得 "Alice" | PASS |
| t7_3_4 | JsonObject 增改 | 含 age:31/active:true | PASS |
| t7_3_5 | JsonPointer /a/b/1,空,/a~1b | 各返回 2/根/9 | PASS |

### T7.4 CodecFeature 开关（5）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t7_4_1 | FAIL_ON_UNKNOWN_PROPERTIES | 开关可存取（行为待宏集成） | PASS |
| t7_4_2 | ACCEPT_SINGLE_VALUE_AS_ARRAY | 开关可存取 | PASS |
| t7_4_3 | WRITE_NULLS | 开关可存取 | PASS |
| t7_4_4 | PRETTY_PRINT 端到端 | 树紧凑无 \n；流式 pretty 含 \n | PASS |
| t7_4_5 | FAIL_ON_NULL_FOR_PRIMITIVES | 开关可存取 | PASS |

### T7.5 模块系统（2 + T7.5.2 推迟）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t7_5_1 | registerModule | 模块名 OK | PASS |
| t7_5_3 | 多模块共存 | 两模块名各自 OK | PASS |

## T8 往返一致性（8 项，T8.7 推迟）

| 用例 | 输入 | 期望输出 | 结果 |
|------|------|----------|------|
| t8_1 | 基础类型聚合对象（含 BigInt/Decimal/DateTime/Rune/UInt64 上界） | obj→JSON→obj2 各字段全等（f64 容差） | PASS |
| t8_2 | Option/枚举/Unit/嵌套用户类型 | Some 还原；color="Green"；unit=() | PASS |
| t8_3 | Array/ArrayList/HashMap/HashSet/嵌套集合/对象数组 | 各集合 size 与元素全等 | PASS |
| t8_4 | @CodableKey/Skip/Default/Alias/Unwrap 聚合 | 映射名写出；skip 重置默认；别名回退；展开还原 | PASS |
| t8_5 | None/空串/空数组/空 Map + Some 往返 | null→None；Some/非空集合还原 | PASS |
| t8_6 | 三层嵌套 + 嵌套数组 + Option 嵌套对象 | 各层字段全等 | PASS |
| t8_8 | VariantDog/Cat 多态 | fromJson 还原子类型，字段全等 | PASS |
| t8_stream | T8Basic 流路径 encode→decode | 各字段全等（f64 容差） | PASS |
| t8_7 | 泛型往返 | **推迟**（@Codable 跳过泛型类，T3.4） | 推迟 |

---

## 同步修复清单（源码改动）

| 缺陷 | 位置 | 修复 |
|------|------|------|
| @CodableOrder 静默空操作 | utils.cj / HandleClass / HandleStruct | 新增 applyFieldOrder，collectFields 读取并重排 |
| struct 流式编码递归缺失 | 宏生成代码 | 修复递归 |
| @CodableUnwrap / @CodableAlias 行为缺陷 | 宏生成代码 | 修复 |
| ArrayList/HashSet 无 IJsonAdapter | ext 适配器 | 新增扩展 |
| @CodableRef 编译失败（hashValue 不存在） | 宏生成代码 | 改用 hashCode；追踪键 UInt64→Int64；流式分支改用 buildStreamFieldWrite |
| setNamingStrategy 静默丢弃策略 | JsonCodec.cj | 保留策略 + 新增 getNamingStrategy |

## 提交记录

- a1223bb fix: setNamingStrategy 保留策略 + getNamingStrategy
- e6b4ae3 test: T7 高级场景测试（19 项）
- b120948 test: 新增 T8 往返一致性测试（8 项）
