import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;

/**
 * 同环境 Jackson 基线基准：与 json4cj T9.1-T9.4 场景一一对应。
 *
 * 方法论（对齐 @Bench）：预热 1s → 测量 3s → μs/op = elapsed_ns / reps。
 * 序列化用 writeValueAsBytes（物化输出，与 json4cj encode+toString 对等）。
 * 反序列化用 mapper.readValue(bytes, Class)。
 */
public class JacksonBench {

    // ---- 对应 json4cj PrimitiveBean ----
    static class PrimitiveBean {
        public byte i8;
        public short i16;
        public int i32;
        public long i64;
        public double f64;
        public boolean flag;
        public String text;
    }

    // ---- 对应 json4cj CollectionBean ----
    static class CollectionBean {
        public long[] intArray;
        public String[] strArray;
        public Map<String, Long> intMap;
        public Map<String, String> strMap;
    }

    // ---- 对应 json4cj DeepNested (4 层) ----
    static class Level3 { public String value; public long count; }
    static class Level2 { public String value; public Level3 level3; }
    static class Level1 { public String value; public Level2 level2; }
    static class DeepNested { public Level1 level1; }

    // ---- 对应 json4cj WideNested (20 字段混合) ----
    static class WideNested {
        public long f1; public String f2; public double f3; public boolean f4; public String f5;
        public long f6; public String f7; public double f8; public boolean f9; public String f10;
        public long f11; public String f12; public double f13; public boolean f14; public String f15;
        public long f16; public String f17; public double f18; public boolean f19; public String f20;
    }

    // ---- 对应 json4cj UltraWide (50 long 字段) ----
    static class UltraWide {
        public long f0,f1,f2,f3,f4,f5,f6,f7,f8,f9;
        public long f10,f11,f12,f13,f14,f15,f16,f17,f18,f19;
        public long f20,f21,f22,f23,f24,f25,f26,f27,f28,f29;
        public long f30,f31,f32,f33,f34,f35,f36,f37,f38,f39;
        public long f40,f41,f42,f43,f44,f45,f46,f47,f48,f49;
    }

    static long sink = 0;

    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // ---- 构造数据 ----
        PrimitiveBean prim = new PrimitiveBean();
        prim.i8 = 1; prim.i16 = 2; prim.i32 = 3; prim.i64 = 4;
        prim.f64 = 3.14; prim.flag = true; prim.text = "hello";
        byte[] primBytes = mapper.writeValueAsBytes(prim);

        long[] rawArr = new long[1000];
        for (int i = 0; i < 1000; i++) rawArr[i] = i;
        byte[] rawArrBytes = mapper.writeValueAsBytes(rawArr);

        CollectionBean collLargeArr = new CollectionBean();
        collLargeArr.intArray = rawArr;
        byte[] collLargeArrBytes = mapper.writeValueAsBytes(collLargeArr);

        Map<String, Long> largeMap = new LinkedHashMap<>();
        for (int i = 0; i < 100; i++) largeMap.put("key" + i, (long) i);
        byte[] largeMapBytes = mapper.writeValueAsBytes(largeMap);

        DeepNested deep = new DeepNested();
        deep.level1 = new Level1(); deep.level1.value = "L1";
        deep.level1.level2 = new Level2(); deep.level1.level2.value = "L2";
        deep.level1.level2.level3 = new Level3(); deep.level1.level2.level3.value = "L3";
        deep.level1.level2.level3.count = 99;
        byte[] deepBytes = mapper.writeValueAsBytes(deep);

        WideNested wide = new WideNested();
        wide.f1 = 1; wide.f3 = 3.14; wide.f4 = true; wide.f6 = 6; wide.f20 = "wide";
        byte[] wideBytes = mapper.writeValueAsBytes(wide);

        UltraWide ultra = new UltraWide();
        byte[] ultraBytes = mapper.writeValueAsBytes(ultra);

        System.out.println("=== Jackson 同环境基线 (JDK21, Jackson 2.17.2) ===");
        System.out.printf("%-34s %10s %12s%n", "case", "median", "ops/ms");
        System.out.println("-".repeat(60));

        // T9.1
        bench("t9_1_1_primitiveSerialize",   () -> { try { sink = mapper.writeValueAsBytes(prim).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_1_2_primitiveDeserialize", () -> { try { sink = mapper.readValue(primBytes, PrimitiveBean.class).i64; } catch (Exception e) { throw new RuntimeException(e); } });

        // raw long[1000] — 对应 T9ArrayDiag rawStdxArray
        bench("t9_diag_rawArraySerialize",   () -> { try { sink = mapper.writeValueAsBytes(rawArr).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_diag_rawArrayDeserialize", () -> { try { sink = mapper.readValue(rawArrBytes, long[].class).length; } catch (Exception e) { throw new RuntimeException(e); } });

        // T9.3
        bench("t9_3_2_largeArraySerialize",   () -> { try { sink = mapper.writeValueAsBytes(collLargeArr).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_3_3_largeArrayDeserialize", () -> { try { sink = mapper.readValue(collLargeArrBytes, CollectionBean.class).intArray.length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_3_5_largeMapSerialize",     () -> { try { sink = mapper.writeValueAsBytes(largeMap).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_3_6_largeMapDeserialize",   () -> { try { sink = mapper.readValue(largeMapBytes, LinkedHashMap.class).size(); } catch (Exception e) { throw new RuntimeException(e); } });

        // T9.4
        bench("t9_4_1_deepNestedSerialize",   () -> { try { sink = mapper.writeValueAsBytes(deep).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_4_2_deepNestedDeserialize", () -> { try { sink = mapper.readValue(deepBytes, DeepNested.class).level1.level2.level3.count; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_4_3_wideSerialize",         () -> { try { sink = mapper.writeValueAsBytes(wide).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_4_5_ultraWideSerialize",    () -> { try { sink = mapper.writeValueAsBytes(ultra).length; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("t9_4_6_ultraWideDeserialize",  () -> { try { sink = mapper.readValue(ultraBytes, UltraWide.class).f49; } catch (Exception e) { throw new RuntimeException(e); } });

        System.out.println("-".repeat(60));
        System.out.println("(sink=" + sink + " 防 DCE)");
    }

    /** 预热 1s + 测量 3s，输出中位 μs/op（取 reps 平均，等价于 mean）。 */
    static void bench(String name, Runnable op) {
        // warmup 1s
        long warmEnd = System.nanoTime() + 1_000_000_000L;
        while (System.nanoTime() < warmEnd) { op.run(); }
        // measure 3s
        long reps = 0;
        long start = System.nanoTime();
        long measureEnd = start + 3_000_000_000L;
        while (System.nanoTime() < measureEnd) { op.run(); reps++; }
        long elapsed = System.nanoTime() - start;
        double usPerOp = elapsed / 1000.0 / reps;
        double opsPerMs = 1000.0 / usPerOp;
        System.out.printf("%-34s %8.3f us  %10.1f%n", name, usPerOp, opsPerMs);
    }
}
