import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;

/**
 * 端到端（字符串路径）Jackson 基线：较大类 + 较大字符串 + 大对象列表。
 *
 * 方法论（对齐 @Bench / JacksonBench）：预热 1s → 测量 3s → μs/op = elapsed_ns / reps。
 * 序列化用 mapper.writeValueAsString（物化 String，与 json4cj/cjjson toJson() 对等）。
 * 反序列化用 mapper.readValue(jsonString, Class)（字符串端到端，消费与 json4cj/cjjson 同一份 JSON）。
 *
 * 场景与 json4cj T9BenchE2E_test.cj + T9BenchLargeList_test.cj、cangjieJSON Bench_test.cj 一一对应：
 *   LargeBean      — 24 字段混合（int/string/bool/double + Array + Map + 嵌套对象），产物 ~3KB
 *   BigString      — 单大字符串 ~32KB + 32×256 字符串数组，产物 ~41KB
 *   PerfLargeList  — 200 × PerfLargeItem（110 字段：61×String + 30×int + 16×long + bool + List + Map），产物 ~600KB+
 *
 * Jackson 版本：本次可用 jar 为 ~/.m2 的 2.16.1（上次报告标 2.17.2，本次以实际 2.16.1 为准）。
 */
public class JacksonBenchE2E {

    // ---- 对应 LargeBean.detail ----
    static class NestedDetail {
        public String sku = "SKU-9999-MX";
        public long price = 129900;
        public long stock = 2048;
        public double weight = 0.375;
        public String warehouse = "WH-BJ-007";
    }

    // ---- 较大类：24 字段混合 ----
    static class LargeBean {
        public long id = 1000001;
        public long seq = 42;
        public long version = 3;
        public long timestamp = 1700000000000L;
        public long flags = 7;
        public String name = "order-2026-08-10-0001";
        public String code = "ORD-AABBCCDD-1234";
        public String category = "electronics/phones/accessories";
        public String owner = "user.mufengzi@example.com";
        public String description;           // ~200 字符
        public boolean active = true;
        public boolean verified = false;
        public boolean enabled = true;
        public double score = 98.5;
        public double ratio = 0.875;
        public double latitude = 39.9042;
        public double longitude = 116.4074;
        public String[] tags;                // 20
        public long[] scores;                // 100
        public Map<String, String> meta;     // 20
        public NestedDetail detail = new NestedDetail();
    }

    // ---- 较大字符串：单大字符串 + 字符串数组 ----
    static class BigStringBean {
        public long id = 1;
        public String label = "payload";
        public String blob;                  // ~32KB
        public String[] chunks;              // 32 × 256
        public long checksum = 1234567890L;
    }

    // ---- 200×110 字段大对象（对应 T9PerfLargeItem/T9PerfLargeList） ----
    static class PerfLargeItem {
        public String optStr01;
        public String optStr02;
        public String optStr03;
        public String optStr04;
        public String optStr05;
        public String optStr06;
        public String optStr07;
        public String optStr08;
        public String optStr09;
        public String optStr10;
        public String optStr11;
        public String optStr12;
        public String optStr13;
        public String optStr14;
        public String optStr15;
        public String optStr16;
        public String optStr17;
        public String optStr18;
        public String optStr19;
        public String optStr20;
        public String optStr21;
        public String optStr22;
        public String optStr23;
        public String optStr24;
        public String optStr25;
        public String optStr26;
        public String optStr27;
        public String optStr28;
        public String optStr29;
        public String optStr30;
        public String optStr31;
        public String optStr32;
        public String optStr33;
        public String optStr34;
        public String optStr35;
        public String optStr36;
        public String optStr37;
        public String optStr38;
        public String optStr39;
        public String optStr40;
        public String optStr41;
        public String optStr42;
        public String optStr43;
        public String optStr44;
        public String optStr45;
        public String optStr46;
        public String optStr47;
        public String optStr48;
        public String optStr49;
        public String optStr50;
        public String optStr51;
        public String optStr52;
        public String optStr53;
        public String optStr54;
        public String optStr55;
        public String optStr56;
        public String optStr57;
        public String optStr58;
        public String optStr59;
        public String optStr60;
        public String optStr61;
        public int intVal01;
        public int intVal02;
        public int intVal03;
        public int intVal04;
        public int intVal05;
        public int intVal06;
        public int intVal07;
        public int intVal08;
        public int intVal09;
        public int intVal10;
        public int intVal11;
        public int intVal12;
        public int intVal13;
        public int intVal14;
        public int intVal15;
        public int intVal16;
        public int intVal17;
        public int intVal18;
        public int intVal19;
        public int intVal20;
        public int intVal21;
        public int intVal22;
        public int intVal23;
        public int intVal24;
        public int intVal25;
        public int intVal26;
        public int intVal27;
        public int intVal28;
        public int intVal29;
        public int intVal30;
        public long longVal01;
        public long longVal02;
        public long longVal03;
        public long longVal04;
        public long longVal05;
        public long longVal06;
        public long longVal07;
        public long longVal08;
        public long longVal09;
        public long longVal10;
        public long longVal11;
        public long longVal12;
        public long longVal13;
        public long longVal14;
        public long longVal15;
        public long longVal16;
        public boolean boolVal = false;
        public List<String> tags = new ArrayList<>();
        public Map<String, String> attrs = new LinkedHashMap<>();
    }

    static class PerfLargeList {
        public List<PerfLargeItem> items = new ArrayList<>();
    }

    static long sink = 0;

    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // ---- 构造 LargeBean ----
        String descBase = "The quick brown fox jumps over the lazy dog. ";
        StringBuilder db = new StringBuilder();
        while (db.length() < 200) db.append(descBase);
        LargeBean large = new LargeBean();
        large.description = db.substring(0, 200);
        large.tags = new String[20];
        for (int i = 0; i < 20; i++) large.tags[i] = "tag" + i;
        large.scores = new long[100];
        for (int i = 0; i < 100; i++) large.scores[i] = i;
        large.meta = new LinkedHashMap<>();
        for (int i = 0; i < 20; i++) large.meta.put("k" + i, "v" + i);
        String largeJson = mapper.writeValueAsString(large);

        // ---- 构造 BigStringBean ----
        String line = "0123456789ABCDEF".repeat(4);   // 64 字符
        BigStringBean big = new BigStringBean();
        big.blob = line.repeat(512);                   // 512 × 64 = 32768 字符
        String chunk = "c".repeat(256);
        big.chunks = new String[32];
        for (int i = 0; i < 32; i++) big.chunks[i] = chunk;
        String bigJson = mapper.writeValueAsString(big);

        // ---- 构造 PerfLargeList（200 × 110 字段大对象）----
        PerfLargeList perfList = new PerfLargeList();
        for (int i = 0; i < 200; i++) perfList.items.add(buildLargeItem(i));
        String perfLargeJson = mapper.writeValueAsString(perfList);

        System.out.println("=== Jackson E2E 字符串路径 (JDK21, Jackson 2.16.1) ===");
        System.out.printf("largeJson=%d  bigJson=%d  perfLargeJson=%d bytes%n",
                largeJson.length(), bigJson.length(), perfLargeJson.length());
        System.out.printf("%-30s %10s %12s%n", "case", "us/op", "ops/ms");
        System.out.println("-".repeat(56));

        bench("largeBean_serialize",        () -> { try { sink = mapper.writeValueAsString(large).length(); } catch (Exception e) { throw new RuntimeException(e); } });
        bench("largeBean_deserialize",      () -> { try { sink = mapper.readValue(largeJson, LargeBean.class).id; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("bigString_serialize",        () -> { try { sink = mapper.writeValueAsString(big).length(); } catch (Exception e) { throw new RuntimeException(e); } });
        bench("bigString_deserialize",      () -> { try { sink = mapper.readValue(bigJson, BigStringBean.class).id; } catch (Exception e) { throw new RuntimeException(e); } });
        bench("perfLargeList_serialize",    () -> { try { sink = mapper.writeValueAsString(perfList).length(); } catch (Exception e) { throw new RuntimeException(e); } });
        bench("perfLargeList_deserialize",  () -> { try { sink = mapper.readValue(perfLargeJson, PerfLargeList.class).items.size(); } catch (Exception e) { throw new RuntimeException(e); } });

        System.out.println("-".repeat(56));
        System.out.println("(sink=" + sink + " 防 DCE)");
    }

    /** 构造 200 项大对象（对应 Cangjie buildLargeItem，字段全填充，JSON 与 json4cj/cjjson 一致）。 */
    static PerfLargeItem buildLargeItem(int index) {
        PerfLargeItem item = new PerfLargeItem();
        item.optStr01 = "os01_" + index;
        item.optStr02 = "os02_" + index;
        item.optStr03 = "os03_" + index;
        item.optStr04 = "os04_" + index;
        item.optStr05 = "os05_" + index;
        item.optStr06 = "os06_" + index;
        item.optStr07 = "os07_" + index;
        item.optStr08 = "os08_" + index;
        item.optStr09 = "os09_" + index;
        item.optStr10 = "os10_" + index;
        item.optStr11 = "os11_" + index;
        item.optStr12 = "os12_" + index;
        item.optStr13 = "os13_" + index;
        item.optStr14 = "os14_" + index;
        item.optStr15 = "os15_" + index;
        item.optStr16 = "os16_" + index;
        item.optStr17 = "os17_" + index;
        item.optStr18 = "os18_" + index;
        item.optStr19 = "os19_" + index;
        item.optStr20 = "os20_" + index;
        item.optStr21 = "os21_" + index;
        item.optStr22 = "os22_" + index;
        item.optStr23 = "os23_" + index;
        item.optStr24 = "os24_" + index;
        item.optStr25 = "os25_" + index;
        item.optStr26 = "os26_" + index;
        item.optStr27 = "os27_" + index;
        item.optStr28 = "os28_" + index;
        item.optStr29 = "os29_" + index;
        item.optStr30 = "os30_" + index;
        item.optStr31 = "os31_" + index;
        item.optStr32 = "os32_" + index;
        item.optStr33 = "os33_" + index;
        item.optStr34 = "os34_" + index;
        item.optStr35 = "os35_" + index;
        item.optStr36 = "os36_" + index;
        item.optStr37 = "os37_" + index;
        item.optStr38 = "os38_" + index;
        item.optStr39 = "os39_" + index;
        item.optStr40 = "os40_" + index;
        item.optStr41 = "os41_" + index;
        item.optStr42 = "os42_" + index;
        item.optStr43 = "os43_" + index;
        item.optStr44 = "os44_" + index;
        item.optStr45 = "os45_" + index;
        item.optStr46 = "os46_" + index;
        item.optStr47 = "os47_" + index;
        item.optStr48 = "os48_" + index;
        item.optStr49 = "os49_" + index;
        item.optStr50 = "os50_" + index;
        item.optStr51 = "os51_" + index;
        item.optStr52 = "os52_" + index;
        item.optStr53 = "os53_" + index;
        item.optStr54 = "os54_" + index;
        item.optStr55 = "os55_" + index;
        item.optStr56 = "os56_" + index;
        item.optStr57 = "os57_" + index;
        item.optStr58 = "os58_" + index;
        item.optStr59 = "os59_" + index;
        item.optStr60 = "os60_" + index;
        item.optStr61 = "os61_" + index;
        item.intVal01 = index % 100;
        item.intVal02 = index % 200;
        item.intVal03 = index % 50;
        item.intVal04 = index % 75;
        item.intVal05 = index % 30;
        item.intVal06 = index % 60;
        item.intVal07 = index % 90;
        item.intVal08 = index % 40;
        item.intVal09 = index % 80;
        item.intVal10 = index % 25;
        item.intVal11 = index % 100;
        item.intVal12 = index % 200;
        item.intVal13 = index % 50;
        item.intVal14 = index % 75;
        item.intVal15 = index % 30;
        item.intVal16 = index % 60;
        item.intVal17 = index % 90;
        item.intVal18 = index % 40;
        item.intVal19 = index % 80;
        item.intVal20 = index % 25;
        item.intVal21 = index % 100;
        item.intVal22 = index % 200;
        item.intVal23 = index % 50;
        item.intVal24 = index % 75;
        item.intVal25 = index % 30;
        item.intVal26 = index % 60;
        item.intVal27 = index % 90;
        item.intVal28 = index % 40;
        item.intVal29 = index % 80;
        item.intVal30 = index % 25;
        item.longVal01 = (long) index * 1;
        item.longVal02 = (long) index * 2;
        item.longVal03 = (long) index * 3;
        item.longVal04 = (long) index * 4;
        item.longVal05 = (long) index * 5;
        item.longVal06 = (long) index * 6;
        item.longVal07 = (long) index * 7;
        item.longVal08 = (long) index * 8;
        item.longVal09 = (long) index * 9;
        item.longVal10 = (long) index * 10;
        item.longVal11 = (long) index * 11;
        item.longVal12 = (long) index * 12;
        item.longVal13 = (long) index * 13;
        item.longVal14 = (long) index * 14;
        item.longVal15 = (long) index * 15;
        item.longVal16 = (long) index * 16;
        item.boolVal = (index % 2 == 0);
        for (int j = 0; j < 40; j++) item.tags.add("tag_" + index + "_" + j);
        for (int j = 0; j < 40; j++) item.attrs.put("k_" + index + "_" + j, "v_" + index + "_" + j);
        return item;
    }

    /** 预热 1s + 测量 3s，输出 μs/op（= elapsed_ns / 1000 / reps）。 */
    static void bench(String name, Runnable op) {
        long warmEnd = System.nanoTime() + 1_000_000_000L;
        while (System.nanoTime() < warmEnd) { op.run(); }
        long reps = 0;
        long start = System.nanoTime();
        long measureEnd = start + 3_000_000_000L;
        while (System.nanoTime() < measureEnd) { op.run(); reps++; }
        long elapsed = System.nanoTime() - start;
        double usPerOp = elapsed / 1000.0 / reps;
        double opsPerMs = 1000.0 / usPerOp;
        System.out.printf("%-30s %8.3f us  %10.1f%n", name, usPerOp, opsPerMs);
    }
}
