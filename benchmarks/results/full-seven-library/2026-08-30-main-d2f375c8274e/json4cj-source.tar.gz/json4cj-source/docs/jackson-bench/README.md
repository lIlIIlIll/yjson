# Jackson 同环境基线对照基准

用于在**同一台机器**上实测 Jackson 性能，作为 json4cj T9 的对照基线（见 [../T9-performance-baseline.md](../T9-performance-baseline.md)）。

## 运行方法

需要 JDK 17+ 与网络（首次下载 3 个 Jackson jar）。在任意空目录执行：

```bash
# 1. 下载 Jackson 2.17.2 三件套
curl -sSL -o jackson-core.jar        "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-core/2.17.2/jackson-core-2.17.2.jar"
curl -sSL -o jackson-databind.jar    "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-databind/2.17.2/jackson-databind-2.17.2.jar"
curl -sSL -o jackson-annotations.jar "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-annotations/2.17.2/jackson-annotations-2.17.2.jar"

# 2. 复制本目录的 JacksonBench.java 到当前目录并编译运行
cp <repo>/docs/jackson-bench/JacksonBench.java .
javac -cp "jackson-core.jar;jackson-databind.jar;jackson-annotations.jar" JacksonBench.java
java  -cp ".;jackson-core.jar;jackson-databind.jar;jackson-annotations.jar" JacksonBench
```

## 方法论

- 预热 1s（触发 JIT）→ 测量 3s，`μs/op = elapsed_ns / reps`，对齐仓颉 `@Bench` 的预热-测量范式。
- 序列化用 `mapper.writeValueAsBytes`（物化输出，与 json4cj `encode + toString` 对等）。
- 反序列化用 `mapper.readValue(bytes, Class)`。
- 场景与 json4cj `T9BenchThroughput_test.cj` 一一对应（PrimitiveBean / 1000×Int64 数组 / 100 entry Map / 4 层嵌套 / 20 字段 / 50 字段）。
- 结果写入 `sink` 防死代码消除。

> 注：json4cj 侧末尾多一次 `String.fromUtf8(readToEnd(buf))` 的 UTF-8 解码，Jackson 直接返回 `byte[]`。此项占比小（见诊断 directBufferWrite），非主要差距来源。
