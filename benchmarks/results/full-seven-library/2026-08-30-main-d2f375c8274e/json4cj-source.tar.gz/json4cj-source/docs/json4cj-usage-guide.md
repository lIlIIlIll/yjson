# json4cj 使用指南

> 写给从 **Java + Jackson** 迁移到 **仓颉 + json4cj** 的业务代码。只讲怎么用。
> 更完整的能力（多态、视图、循环引用等）见根目录 [README.md](../README.md)。

---

## 一、依赖与导入

`cjpm.toml` 加依赖（基础序列化/反序列化只需 `annotations`，它会自动带入 `core`）：

```toml
[dependencies]
json4cj-annotations = { path = "../json4cj-annotations" }
```

用到 `@Codable` 的 `.cj` 文件加两行导入：

```cangjie
import json4cj_annotations.macros.*   // @Codable 及全部注解（触发宏展开）
import json4cj_core.*                  // 核心类型（JsonValue / JsonWriter / JsonReader）
```

> 工程还需配置仓颉扩展标准库 **stdx** 的二进制依赖路径，与 json4cj 各模块 `cjpm.toml` 里的 `[target...bin-dependencies]` 配置一致，否则链接不到 stdx。

---

## 二、业务类怎么适配

在 `class`（或 `struct` / `enum`）上加 `@Codable`，给一个无参 `init`，字段用仓颉原生类型即可：

```cangjie
@Codable
class User {
    var name: String = ""
    var age: Int64 = 0
    var nick: Option<String> = None                              // 可空 → Option<T>
    var scores: Array<Int64> = Array<Int64>()                    // 数组
    var tags: HashMap<String, String> = HashMap<String, String>() // Map
    public init() {}
}
```

要点：

- **必须有无参 `public init() {}`** —— 反序列化靠它先构造空对象，再逐字段填值。
- **字段要有默认值** —— JSON 里缺这个字段时用默认值兜底。
- 可空字段用 `Option<T>`（对应 Java 的 `null` / Jackson 的 `Optional`）。
- 嵌套对象：把被嵌套的类也标 `@Codable` 就行，不用额外配置。
- 私有字段也能序列化（宏在类内部生成代码，天然可访问 `private`）。

---

## 三、序列化 / 反序列化调什么接口

最常用的两个，记住这俩就够了：

| 操作 | 接口 | 返回 |
|------|------|------|
| 序列化 | `obj.toJson()` | `String` |
| 反序列化 | `T.fromJson(jsonString)` | `T` |

```cangjie
let u = User()
u.name = "张三"
u.age = 25

let json = u.toJson()          // {"name":"张三","age":25,...}
let u2 = User.fromJson(json)   // 反序列化回 User 对象
```

不再需要 Jackson 的 `ObjectMapper` —— 类型自己就能转。

**高性能场景（大 JSON）** 用流式接口，不构建中间树、边读边写：

| 操作 | 接口 |
|------|------|
| 流式序列化 | `obj.encode(writer)` |
| 流式反序列化 | `T.decode(reader)` |

```cangjie
import std.io.ByteBuffer

// 序列化
let buf = ByteBuffer()
let w = JsonWriter(buf)
u.encode(w)
let json = w.toString()

// 反序列化
let buf2 = ByteBuffer()
unsafe { buf2.write(json.rawData()) }
let r = JsonReader(buf2)
let u3 = User.decode(r)
```

---

## 四、Jackson 注解对照表

业务最常用的几个，照着换：

| Jackson（Java） | json4cj（仓颉） | 说明 |
|-----------------|------------------|------|
| `@JsonProperty("user_name")` | `@CodableKey["user_name"]` | 字段重命名 |
| `@JsonIgnore` | `@CodableSkip` | 忽略字段（不读不写） |
| `@JsonAlias({"nick","nickname"})` | `@CodableAlias["nick", "nickname"]` | 反序列化时接受多个键名 |
| `@JsonFormat(pattern="yyyy-MM-dd")` | `@CodableFormat["yyyy-MM-dd"]` | 日期格式化 |
| `@JsonInclude(NON_NULL)` | `@CodablePolicy[NON_NULL]` | 输出策略（NON_NULL / NON_EMPTY / NON_DEFAULT） |
| （字段缺失用默认值） | `@CodableDefault` | JSON 缺该字段时不报错，保留默认值 |
| `@JsonRootName("user")` | `@CodableRoot["user"]` | 根包装 `{ "user": {...} }` |
| `@JsonIgnoreType` | `@CodableSkipType` | 整个类型忽略 |

**语法差异**：Jackson 用圆括号 `@JsonProperty("x")`，json4cj 用**方括号** `@CodableKey["x"]`；多个参数逗号分隔，字符串要带引号，枚举值不带引号（如 `NON_NULL`）。

---

## 五、完整示例：Java+Jackson → 仓颉+json4cj

**原来的 Java + Jackson 代码：**

```java
class User {
    @JsonProperty("user_name")  private String name;
    @JsonProperty("user_age")   private int age;
    @JsonIgnore                 private String password;
    @JsonAlias({"nick","nickname"}) private String nick;
    @JsonFormat(pattern="yyyy-MM-dd") private Date birthday;
    @JsonInclude(NON_NULL)      private String email;
    // getters / setters ...
}
// ObjectMapper mapper = new ObjectMapper();
// String json = mapper.writeValueAsString(user);
// User u = mapper.readValue(json, User.class);
```

**改成仓颉 + json4cj：**

```cangjie
import json4cj_annotations.macros.*
import json4cj_core.*
import std.time.DateTime

@Codable
class User {
    @CodableKey["user_name"]
    var name: String = ""

    @CodableKey["user_age"]
    var age: Int64 = 0

    @CodableSkip
    var password: String = ""

    @CodableAlias["nick", "nickname"]
    var nick: String = ""

    @CodableFormat["yyyy-MM-dd"]
    var birthday: DateTime = DateTime.now()

    @CodablePolicy[NON_NULL]
    var email: Option<String> = None    // None 时不输出该字段

    public init() {}
}

// 直接调用，无需 ObjectMapper
let u = User()
u.name = "张三"
u.age = 25
u.email = Some("z@x.com")

let json = u.toJson()        // 序列化
let u2 = User.fromJson(json) // 反序列化
```

---

## 六、错误处理

反序列化出错会抛异常，按需 `catch`：

```cangjie
import json4cj_core.exc.*

try {
    let u = User.fromJson(badJson)
} catch (e: JsonMissingField) {
    // JSON 缺少必填字段
} catch (e: JsonTypeException) {
    // 字段类型不匹配（如期望 String 却收到数字）
} catch (e: Exception) {
    // 畸形 JSON 等其他错误
}
```

常用异常：`JsonMissingField`（缺字段）、`JsonTypeException`（类型错）、`JsonReadException`（读异常）、`JsonOverflowException`（数值溢出），基类为 `JsonException`。

---

## 七、支持的字段类型

`@Codable` 类的字段可以直接用这些类型，无需手写转换：

- **基础类型**：`Int64` / `Int32` / `Int16` / `Int8` / `UInt64` … / `Float64` / `Float32` / `String` / `Bool` / `Rune` / `DateTime` / `BigInt` / `Decimal`
- **可空**：`Option<T>`（即 `?T`）
- **集合**：`Array<T>` / `ArrayList<T>` / `HashMap<String, T>` / `HashSet<T>`
- **嵌套对象**：另一个 `@Codable` class / struct
- **枚举**：`@Codable enum`（默认按名称序列化）

> 更高级的能力（多态 `@CodableVariant`、视图 `@CodableView`、循环引用 `@CodableRef`、值注入 `@CodableInject`、合并更新 `@CodableMerge`、动态过滤 `@CodableFilter` 等）见 [README.md](../README.md)。
