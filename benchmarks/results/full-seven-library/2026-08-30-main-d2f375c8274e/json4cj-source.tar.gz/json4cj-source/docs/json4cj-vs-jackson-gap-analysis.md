# json4cj 能力 GAP 分析（对标 Jackson）

> 生成日期：2026-08-14
> 基线：Java 生态 **Jackson**（jackson-core + jackson-databind + jackson-annotations）的完整能力。
> 维度：**功能 GAP** + **性能 GAP**。每项给出：Jackson 原能力是干什么用的 → json4cj 现状 → 差异 → 影响 → 补齐方案。
> 性能 GAP 的实测数据见 [T9 三方基准报告](T9-e2e-three-way-bench.md)，本文给出根因级分析。

---

## 一、概述

Jackson 是 Java 生态功能最完备的 JSON 库，能力分五块：

1. **流式 API**：`JsonGenerator`（写）/`JsonParser`（读，含异步 `AsyncJsonParser`）—— token 级流式读写。
2. **树模型**：`JsonNode`（可变）—— 内存树构造、查询、修改、再序列化。
3. **数据绑定**：`ObjectMapper` —— POJO ↔ JSON，运行时按 `JavaType` 查表分发到 `JsonSerializer`/`JsonDeserializer`。
4. **注解体系**：20+ 注解控制字段映射、格式、多态、视图、过滤、循环引用等。
5. **模块系统**：`Module`/`SimpleModule` —— 运行时注册自定义编解码器、命名策略、类型工厂等。

json4cj 是仓颉的 JSON 编解码库，对应有：流式（`JsonWriter`/`JsonReader`）、树（`JsonTree`）、`@Codable` 注解 + 编译期代码生成、`JsonCodec` 入口、`CodecModule` 模块接口。本文逐项对照两者差异。

---

## 二、功能 GAP — 注解（对标 Jackson 注解体系）

### 2.1 注解对照总表

| Jackson 注解 | 作用 | json4cj 对应 | 状态 |
|---|---|---|---|
| `@JsonProperty` | 字段名映射 | `@CodableKey` | ✅ |
| `@JsonIgnore` | 忽略字段 | `@CodableSkip` | ✅ |
| `@JsonIgnoreType` | 整个类型忽略 | `@CodableSkipType` | ✅ |
| `@JsonInclude` | 输出策略（NON_NULL 等） | `@CodablePolicy` | ✅ |
| `@JsonAlias` | 反序列化多键名 | `@CodableAlias` | ✅ |
| `@JsonRootName` | 根包装 | `@CodableRoot` | ✅ |
| `@JsonUnwrapped` | 扁平化内嵌 | `@CodableUnwrap` | ✅ |
| `@JsonRawValue` | 原始 JSON 值 | `@CodableRaw` | ✅ |
| `@JsonAnyGetter`/`@JsonAnySetter` | 动态属性 | `@CodableAnyKey`/`@CodableAnyValue` | ✅ |
| `@JsonView` | 视图过滤 | `@CodableView` | ✅ |
| `@JsonFilter` | 动态过滤 | `@CodableFilter` | ✅ |
| `@JacksonInject` | 值注入 | `@CodableInject` | ✅ |
| `@JsonMerge` | 合并更新 | `@CodableMerge` | ✅ |
| `@JsonTypeInfo`+`@JsonSubTypes`+`@JsonTypeName` | 多态 | `@CodableVariant`+`@CodableVariantCase` | ✅ |
| `@JsonEnumDefaultValue` | 未知枚举默认值 | `@CodableEnum[default:]` | ✅ |
| `@JsonIdentityInfo`/`@JsonIdentityReference` | 循环引用去重 | `@CodableRef` | ◑ 仅序列化侧（见 2.3） |
| `@JsonManagedReference`/`@JsonBackReference` | 父子引用 | `@CodableRef`/`@CodableRef.Back` | ◑ 同上 |
| `@JsonCreator` | 自定义构造器/工厂 | `@CodableCreator` | ◑ v1 限制（见 2.2） |
| `@JsonFormat` | 日期/数字格式 | `@CodableFormat` | ❌ no-op（见 2.2） |
| `@JsonNaming` | 类型级命名策略 | 无（全局策略未接入） | ❌（见 2.4） |
| `@JsonIgnoreProperties` | 类型级多字段忽略 | 无 | ❌（见 2.4） |
| `@JsonIncludeProperties` | 字段白名单 | 无 | ❌（见 2.4） |
| `@JsonAutoDetect` | 字段可见性自动检测配置 | 无 | ❌（见 2.4） |
| `@JsonValue` | 类型整体序列化为单值 | 无（可用 `IJsonAdapter` 替代） | ❌（见 2.4） |
| `@JsonPOJOBuilder` | Builder 模式反序列化 | 无 | ❌（见 2.4） |
| `@JsonAppend` | 运行时虚拟属性 | 无 | ❌（见 2.4） |
| `@JsonSetter`/`@JsonGetter` | 指定 setter/getter | 无 | ❌（见 2.4） |
| `@JsonSerialize`/`@JsonDeserialize` | 指定自定义 (de)serializer 类 | `IJsonAdapter`（编译期） | ◑（见 2.4） |
| `@JsonTypeId` | 自定义类型标识字段 | 无（`@CodableVariant` 内置） | ◑ |
| `@JsonTypeIdResolver` | 自定义类型解析器 | `VariantRegistry` | ◑ |
| mix-in 注解 | 为第三方类型套用注解 | 无 | ❌（见 2.4） |

> 图例：✅ 对齐 ◑ 部分对齐/有限制 ❌ 缺失

### 2.2 已有对应但有限制

#### `@JsonFormat` ↔ `@CodableFormat`（no-op stub）
- **Jackson 作用**：控制日期/数字的序列化格式，如 `@JsonFormat(pattern="yyyy-MM-dd", timezone="GMT+8")` 让 `Date` 输出为 `"2026-08-14"` 而非时间戳；`@JsonFormat(shape=STRING)` 让数字输出为字符串。
- **json4cj 现状**：`@CodableFormat["yyyy-MM-dd"]` 注解存在，但**不生效**——宏未读取 pattern、未接入格式化路径（[T9BenchAnnotation_test.cj:113](../json4cj-databind/src/test/macros_test/T9BenchAnnotation_test.cj#L113) 标注"no-op stub"）。`BasicTypeCodec.formatDateTime` 已实现但宏未调用。
- **差异**：Jackson 的格式化可用；json4cj 的同名注解是空操作，`DateTime` 按默认字符串往返，无法控制格式。
- **影响**：用户照 README 写 `@CodableFormat` 不生效（误导）；日期/数字输出格式不可控。
- **补齐方案**：宏读取 `@CodableFormat` pattern，在 `DateTime`/`Decimal`/`Float64` 字段的 `toJsonValue`/`fromJsonValue` 插入 `formatDateTime(value, pattern)`/`parseDateTime` 调用（基础设施已在）。成本中。**P0。**

#### `@JsonCreator` ↔ `@CodableCreator`（v1 限制）
- **Jackson 作用**：指定反序列化用的构造函数或静态工厂方法（含参数映射），支持不可变对象、多构造器选择、参数名注入。
- **json4cj 现状**：`@CodableCreator` 支持变体+创建器（tree 代码生成，委托 `fromJsonValue`），但 v1 限制：① 仅树路径，流路径不支持；② 值参数（`$N`，如 `VArray<N>` 大小）无法走 `IJsonAdapter` 约束，回退跳过（[utils.cj:475](../json4cj-annotations/src/macros/utils.cj#L475)、[T3UserTypes_test.cj:732](../json4cj-databind/src/test/macros_test/T3UserTypes_test.cj#L732)）。
- **差异**：Jackson 可自由指定任意构造器/工厂、支持不可变对象；json4cj 仅部分自定义构造，带值参数字段无法往返，流路径不可用。
- **影响**：不可变值类、带 `VArray<N>` 字段、需流式反序列化的自定义构造场景受限。
- **补齐方案**：① 值参数——宏为 `$N` 生成字面量注入（不经 `IJsonAdapter`）；② 流路径——为 `@CodableCreator` 生成 `decode` 委托。成本中。P2。

#### `@JsonIdentityInfo` ↔ `@CodableRef`（反序列化侧缺失）
- **Jackson 作用**：处理对象图中的循环引用/共享引用——序列化时给对象分配 id，第二次遇到输出 `{"$ref":"id"}`；反序列化时还原完整对象图。
- **json4cj 现状**：序列化侧去重已实现（输出 `{"$ref":"id"}`）；**反序列化侧 `$ref` 解析未实现**，无法还原循环图（[T6BoundaryException_test.cj:21](../json4cj-databind/src/test/macros_test/T6BoundaryException_test.cj#L21)）。
- **差异**：Jackson 循环引用双向往返完整；json4cj 只能单向（序列化去重），反序列化丢失循环。
- **影响**：双向链表、树结构等带循环/共享引用的对象 round-trip 不完整。
- **补齐方案**：`fromJsonValue` 改为两阶段——第一遍建对象并登记到对象表，遇 `$ref` 查表回填。成本高。P2。

### 2.3 类型级命名策略（`@JsonNaming` / 全局策略未接入）

- **Jackson 作用**：`@JsonNaming` 标在类型上指定命名策略（如 `PropertyNamingStrategies.SNAKE_CASE`），该类型所有字段名自动转 snake_case；或全局 `ObjectMapper.setPropertyNamingStrategy()`。
- **json4cj 现状**：`NamingStrategy` 接口 + Snake/Camel/Pascal/Kebab 四种实现**完整**，但 [JsonCodec.cj:132-134](../json4cj-databind/src/bind/JsonCodec.cj#L132-L134) 注明"当前命名策略仅被保留，尚未接入 `@Codable` 宏生成的序列化/反序列化路径（宏直接使用字段名字面量）"；缺 `LOWER_CASE`/`UPPER_SNAKE_CASE`。
- **差异**：Jackson 命名策略可用（类型级或全局）；json4cj `setNamingStrategy(SnakeCase())` 不生效，必须逐字段 `@CodableKey`。
- **影响**：全局 snake_case 不工作（README 示例误导）；无类型级策略。
- **补齐方案**：新增 `@CodableNaming[SnakeCase]` 类型级注解，宏在编译期生成字段名时应用策略（保零开销）。成本中。**P0。**

### 2.4 json4cj 缺失的 Jackson 注解

#### `@JsonIgnoreProperties`（类型级多字段忽略）
- **Jackson 作用**：标在类型上，序列化/反序列化时忽略指定若干字段（`@JsonIgnoreProperties({"internal","cache"})`），常作 mix-in 套到第三方类型。
- **json4cj 现状**：只有 `@CodableSkip`（字段级单忽略）、`@CodableSkipType`（整类型忽略），无类型级多字段忽略。
- **差异**：不能从类型侧一次性忽略多个字段，必须逐字段标 `@CodableSkip`。
- **补齐方案**：加 `@CodableSkipFields["internal","cache"]` 类型级注解，宏生成时跳过。成本低。P3。

#### `@JsonIncludeProperties`（字段白名单）
- **Jackson 作用**：标在类型上，只序列化指定字段（白名单）。
- **json4cj 现状**：无白名单注解（默认 `@Codable` 类所有字段都序列化，黑名单用 `@CodableSkip`）。
- **补齐方案**：加 `@CodableIncludeFields[...]` 类型级注解。成本低。P3。

#### `@JsonAutoDetect`（字段可见性配置）
- **Jackson 作用**：配置字段/getter/setter 的自动检测规则与可见性，控制哪些成员参与序列化。
- **json4cj 现状**：无；`@Codable` 类的所有字段默认参与（宏直接遍历字段，含私有），无可见性配置开关。
- **差异**：json4cj 模型不同——显式字段集，无"自动检测 + 可见性调节"。
- **补齐方案**：低价值（模型不同），可不补；若需要可加 `@CodableAccess` 控制字段默认参与策略。P3。

#### `@JsonValue`（类型整体序列化为单值）
- **Jackson 作用**：标在方法/字段上，其返回值即为整个类型的 JSON 值（如一个 `toString()` 返回的字符串就是输出），常用于包装类型/枚举单值。
- **json4cj 现状**：无注解；但实现 `IJsonAdapter`（`toJsonValue` 返回标量）可达同样效果。
- **差异**：无声明式标记，但功能可达（`IJsonAdapter`）。
- **补齐方案**：不补注解，文档引导单值类型实现 `IJsonAdapter`。P3（功能等价可达）。

#### `@JsonPOJOBuilder`（Builder 模式反序列化）
- **Jackson 作用**：通过 Builder 反序列化不可变 POJO——先调 builder 的 set 方法，再 `build()` 得对象。
- **json4cj 现状**：无；反序列化要求无参 `init` + 逐字段填值（假设可变字段）。
- **差异**：不可变值类（全 `let` 字段）无法反序列化。
- **补齐方案**：扩展 `@CodableCreator` 支持主构造函数 + 参数映射（宏可生成）；或加 `@CodableBuilder`。成本中。P2。

#### `@JsonAppend`（运行时虚拟属性）
- **Jackson 作用**：序列化时追加不在 POJO 中的虚拟字段（如版本号、计算字段），经 `VirtualBeanProperty`。
- **json4cj 现状**：无；`@CodableAnyKey` 动态属性可部分替代（但需数据载体字段）。
- **补齐方案**：低优先级，用 `@CodableAnyKey` 或包装类替代。P3。

#### `@JsonSetter`/`@JsonGetter`（指定 setter/getter）
- **Jackson 作用**：为字段指定特定的 setter/getter 方法（而非默认命名约定）。
- **json4cj 现状**：无；宏直接访问字段（私有亦可），不经过 getter/setter。
- **差异**：json4cj 不经 getter/setter，故此需求弱化；但无法在序列化时调用计算型 getter。
- **补齐方案**：低价值（宏直接访问字段已覆盖私有）。P3。

#### `@JsonSerialize`/`@JsonDeserialize`（指定自定义 (de)serializer 类）
- **Jackson 作用**：为类型指定自定义 `JsonSerializer`/`JsonDeserializer` 实现类，运行时由 `Module` 注册或注解指定。
- **json4cj 现状**：`IJsonAdapter<T>` 是等价扩展点（`toJsonValue` + `static fromJsonValue`），但需在编译期 `extend Type <: IJsonAdapter`，**无运行时注册**（见 5.1）。
- **差异**：Jackson 可运行时换 serializer；json4cj 的自定义适配器在编译期绑定，不能运行时替换。
- **补齐方案**：见 5.1 模块注册表。P2。

#### mix-in 注解（为第三方类型套用注解）
- **Jackson 作用**：把一套注解配置（字段名/忽略/格式）"套"到一个不可修改的第三方类型上，无需改源码。
- **json4cj 现状**：无；`@Codable` 需标在类型定义本身。
- **差异**：不能为 stdx/第三方库类型定制字段映射（除非该类型实现 `IJsonAdapter` 或包一层 `@Codable` 适配类）。
- **补齐方案**：宏支持"为任意可见类型生成 `extend <: IJsonAdapter`"（技术上可行）；或推广适配器 wrapper 模式。P2。

---

## 三、功能 GAP — 流式 API

### 3.1 `JsonParser`（读）的差异

| Jackson `JsonParser` 能力 | json4cj `JsonReader` | 状态 |
|---|---|---|
| `nextToken()` 拉迭代 + `getCurrentValue()`/`getText()` | `peek()` + typed-read（`readInt`/`readString`...） | ◑ 无统一 pull 模型 |
| 异步非阻塞解析（`AsyncJsonParser` + `ByteArrayFeeder`，分块增量） | 同步 `ByteBuffer` | ❌ 无异步 |
| `NumberType`（INT/LONG/BIG_INTEGER/FLOAT/DOUBLE/BIG_DECIMAL） | 仅 Int64/Float64 | ❌ 无 |
| 精确位置（`getCurrentLocation()` line/column/byteOffset） | `location()` 永远返回 (1,1,0)，字段从不更新 | ❌ stub（[JsonReader.cj:43](../json4cj-core/src/stream/JsonReader.cj#L43)） |
| `skipChildren()` 跳过整个子树 | 仅有 `skip()`（跳单 token） | ❌ |
| `getValueAsXxx()` coercion（字符串→数字等） | 有 `ACCEPT_*` Feature 但**未接入**读路径 | ❌ 声明不生效 |
| `readValueAs(Class)` / `readValueAs(TreeNode)` | `readOptional<T>`（需 `JsonDeserializable`）+ `readJsonValue()` | ◑ |
| `getParsingContext()`（当前对象/数组栈） | `JsonStreamContext` 类存在但**未接入** reader（inert） | ❌ |
| `FAIL_ON_TRAILING_TOKENS` 等 | `ReadFeature` 声明但多数未强制 | ◑ |

- **影响**：① 错误不可定位（无行列）；② 超大 JSON 无法分块流式解析（须全量载入）；③ 大数（BigInt/Decimal）无数值类型，按字符串读；④ 设了 coercion 开关不生效；⑤ 手写逐 token 解析器体验差。
- **补齐方案**：① **位置追踪**——封装层逐 token 计数 line/column，不依赖 stdx 内部（P0，收益高）；② `nextToken()` + `skipChildren()` + `copyCurrentStructure(writer)`（低成本，P1）；③ `readBigInt`/`readDecimal` 流式无损（P1）；④ coercion Feature 接入 typed-read 包装层（P1）；⑤ 异步需 stdx 上游支持（非目标，见 9.1）。

### 3.2 `JsonGenerator`（写）的差异

| Jackson `JsonGenerator` 能力 | json4cj `JsonWriter` | 状态 |
|---|---|---|
| `writeObject(Object)` 多态分发 | 无（宏为每个类型生成 `encode`） | ◑ |
| `copyCurrentEvent`/`copyCurrentStructure`（流→流直通） | 无 | ❌ |
| 自定义缩进（`setPrettyPrinter`/缩进字符） | `PrettyPrinter.withIndent` 是 stub，忽略参数 | ❌（[PrettyPrinter.cj:31](../json4cj-core/src/stream/PrettyPrinter.cj#L31)） |
| `WRITE_NUMBERS_AS_STRINGS` 等 | `WRITE_NAN_AS_STRING`/`WRITE_INFINITY_AS_STRING`/`ESCAPE_NON_ASCII` 已接入 | ✅ 部分 |
| `writeBinary(Base64)` | 无内置（`util/Base64` 可手动用） | ◑ |
| 工厂透传配置 | `JsonStreamFactory` 无 `CodecConfig` 重载 | ❌ |

- **补齐方案**：① `withIndent` 透传 stdx 缩进配置或自实现 pretty（P2）；② `copyCurrentStructure` 基于 `readJsonValue`+`writeJsonValue`（P1）；③ 工厂加 `config` 重载（极低成本，P3）。

---

## 四、功能 GAP — 树模型

| Jackson `JsonNode` 能力 | json4cj `JsonTree`/`DefaultJsonTree` | 状态 |
|---|---|---|
| 可变：`put`/`set`/`add`/`remove`/`replaceAll` | 只读访问 | ❌ |
| `withArray`/`withObject`（链式构造/导航） | 无 | ❌ |
| `at(JsonPointer)`/`path(String)`/`path(int)` | 无（`JsonPointer` 存在但不连树） | ❌ |
| `deepCopy()` | 无 | ❌ |
| `findParent`/`findValue`/`findValues`/`findValueAsText` | 无 | ❌ |
| `fieldNames()`/`elements()` 迭代器 | `keys()`/`elements()` 返回数组 | ◑ |
| `numberType()`/`binaryValue()` | 无 | ❌ |
| `MissingNode`/`NullNode` 单例区分 | 有 `Missing` 枚举标签 | ◑ |
| `JsonNodeFactory` 构造节点 | `NodeFactory` 已实现 | ✅ |

- **`JsonPointer` 不连树**：`util/JsonPointer` 实现 RFC 6901 `query(JsonValue)`，但操作 stdx `JsonValue` 而非 `JsonTree`，`JsonTree` 无 `at(pointer)`（[util/JsonPointer.cj](../json4cj-core/src/util/JsonPointer.cj)）。
- **databind `JsonNode` 不完整**：标注"完整实现将在阶段四完成，当前提供基础功能"（[JsonNode.cj:16](../json4cj-databind/src/node/JsonNode.cj#L16)）；`NodeCursor` 基础（缺 `next`/`skipChildren`）；`NodePatch`（RFC 6902）是 stub（无 `apply`，见 8.1）。
- **影响**：无法在内存里 `readTree` → 改 → `writeTree`（Jackson 典型用法）；无法用指针查树；无法深拷贝子树。
- **补齐方案**：① `JsonTree.at(pointer)` 委托 `JsonPointer.query`（成本低，P1）；② `deepCopy`（成本低，P1）；③ 新建 `MutableJsonTree` 支持变异（成本中，P2）。

---

## 五、功能 GAP — 数据绑定与配置

### 5.1 模块系统 / 运行时注册自定义编解码器（stub）

- **Jackson 作用**：`SimpleModule` + `addSerializer`/`addDeserializer` 运行时注册自定义 `JsonSerializer`/`JsonDeserializer`，`ObjectMapper.registerModule()` 生效；可为任意类型（含第三方）挂自定义编解码逻辑。
- **json4cj 现状**：`CodecModule` 接口 + `ModuleRegistry` 已实现，但 `SimpleModule.addEncoder`/`addDecoder`/`setupModule` 空，`CodecRegistry.registerEncoder`/`registerDecoder` 是 stub（"实际实现中需要处理类型擦除"）；README"模块系统"示例不生效。
- **差异**：Jackson 可运行时注册并立即生效；json4cj 的模块 API 是空壳，自定义编解码器只能在编译期经 `IJsonAdapter` 绑定。
- **影响**：无法运行时为非 `@Codable` 类型挂自定义编解码器；模块系统形同虚设。
- **补齐方案**：实现 `CodecRegistry` 按类型全限定名（`String`）查表，`SimpleModule.addEncoder/addDecoder` 真正存储并在 `setupModule` 注册。成本中。P2。

### 5.2 `TypeReference<T>` 运行时泛型捕获（stub）

- **Jackson 作用**：`TypeReference<HashMap<String, User>>(){}` 在运行时捕获完整泛型类型，用于 `readValue(json, typeRef)` 反序列化泛型容器。
- **json4cj 现状**：`TypeReference<T>.getType()` 返回硬编码 `TypeSpec.of("Object")`（stub）；但编译期宏已处理泛型（`@Codable` 泛型类、`extend<T> where T <: IJsonAdapter<T>`，T3.4 验证）。
- **差异**：Jackson 可运行时反序列化任意泛型容器；json4cj 需类型本身 `@Codable`（编译期已知泛型）。
- **影响**：裸 `JsonCodec.parse<HashMap<String, User>>` 不可用（须给容器类标 `@Codable`）。
- **补齐方案**：用宏为常用泛型容器生成 `TypeSpec`，或弃用 `TypeReference`、文档明确"泛型反序列化走 `@Codable` 宏"。P3。

### 5.3 反射兜底（非 `@Codable` 类型）

- **Jackson 作用**：`ObjectMapper` 默认靠反射处理任意 POJO（读所有字段、调构造），无需注解即可序列化/反序列化。
- **json4cj 现状**：`BeanDecoder.decode` 直接 `throw`（[BeanDecoder.cj:32](../json4cj-databind/src/deser/BeanDecoder.cj#L32)）；`BeanEncoder.encode` 反射 public 标量字段，复杂类型写空串 `""`（[BeanEncoder.cj:41](../json4cj-databind/src/ser/BeanEncoder.cj#L41)）。须类型标 `@Codable` 或实现 `IJsonAdapter`。
- **差异**：Jackson 无注解也能处理任意 POJO；json4cj 必须显式标注或实现适配器。
- **影响**：未标注的第三方类型无法直接反序列化。
- **补齐方案**：仓颉反射不支持构造调用，兜底反序列化不可靠，**不补**；文档明确要求 `@Codable`/`IJsonAdapter`。P3。

### 5.4 全局配置 Feature

| Jackson Feature | json4cj | 状态 |
|---|---|---|
| `SerializationFeature.WRITE_DATES_AS_TIMESTAMPS` + 全局 `DateFormat`/`TimeZone` | 无全局日期配置（`@CodableFormat` 还是 stub） | ❌ |
| `WRAP_ROOT_VALUE`/`UNWRAP_ROOT_VALUE` 运行时开关 | 有 `@CodableRoot`（编译期），无运行时开关 | ◑ |
| `ORDER_MAP_ENTRIES_BY_KEYS` | 无 | ❌ |
| `FAIL_ON_TRAILING_TOKENS`/`UNWRAP_SINGLE_VALUE_ARRAYS` | `ACCEPT_SINGLE_VALUE_AS_ARRAY` 声明未强制 | ❌ |
| `WRITE_BIGDECIMAL_AS_PLAIN` | 无（BigDecimal 字符串往返） | ❌ |
| `CoercionConfig`（强制转换规则） | `ACCEPT_*` Feature 声明未强制 | ❌ |

- **`ReadFeature`/`WriteFeature` 多数未强制**：9 个 `ReadFeature` 仅 `FAIL_ON_UNKNOWN_PROPERTIES` 接入；`ACCEPT_STRING_AS_BOOLEAN`/`ACCEPT_INT_AS_FLOAT`/`ACCEPT_SINGLE_VALUE_AS_ARRAY`/`USE_DEFAULTS_FOR_NULLS`/`FAIL_ON_NULL_FOR_PRIMITIVES`/`ALLOW_COMMENTS` 等均未被读路径查询。`WriteFeature` 中 `PRETTY_PRINT`/`ESCAPE_NON_ASCII`/`WRITE_NAN_AS_STRING`/`WRITE_INFINITY_AS_STRING` 已接入。
- **影响**：声明的开关不生效，用户预期与行为不符；无全局日期格式控制。
- **补齐方案**：① typed-read 包装层按 config 插 coercion 分支（P1）；② 全局 `CodecConfig` 加 `dateFormat`，宏生成 `DateTime` 字段代码时读（P1，与 2.2 `@CodableFormat` 一起）。

### 5.5 树↔POJO 转换

- **Jackson 作用**：`objectMapper.valueToTree(obj)`（POJO→树）、`treeToValue(node, Class)`（树→POJO）。
- **json4cj 现状**：`@Codable` 类型经宏生成 `toJsonValue`/`fromJsonValue`（即 POJO↔`JsonValue`），`JsonCodec.writeTree`/`readTree` 存在。功能等价可达，仅限 `@Codable` 类型。
- **补齐方案**：已基本对齐，文档可补示例。P3。

---

## 六、功能 GAP — 类型与精度

| Jackson 能力 | json4cj | 状态 |
|---|---|---|
| `BigDecimal`/`BigInteger` 作为 JSON number（`WRITE_BIGDECIMAL_AS_PLAIN`） | `BigInt`/`Decimal` 经 `BasicTypeAdapter` **字符串往返**（`JsonString`） | ❌ |
| `JsonParser.NumberType` 区分 int/long/bigint/float/double/bigdecimal | 无 NumberType | ❌ |
| `double` 完整双精度序列化 | `Float64.toString` 约 7 位有效数字（**有损**），无 printf 式格式化 | ❌ |
| `long`/`BigInteger` 任意大整数 | UInt64 > `Int64.MAX` 时树路径退化为字符串；流路径 `readUInt64` 无损 | ◑ |
| `byte[]` 二进制（`@JsonFormat` Base64） | 无注解级二进制；`util/Base64` 可手动用 | ◑ |

- **影响**：① 金融大数在 JSON 里是字符串而非 number，跨语言消费方需按字符串读；② 高精度浮点序列化精度丢失（与 Jackson 双精度不一致），测试需容差断言；③ 大 UInt64 树往返变字符串。
- **补齐方案**：① 流路径加 `readBigInt`/`readDecimal`（基于 `readValue<String>`+parse，无损，P1）；② 树扩展 `JsonBigInt`/`JsonBigDecimal` 节点（成本大，P2）；③ Float64 精度受限于 Cangjie 运行时 `toString`，等语言改进或自实现双精度→字符串（Dragon4/Grisu，P3）；④ 注解级 `byte[]` Base64（低成本，P3）。

---

## 七、功能 GAP — 异常与诊断

| Jackson 异常/诊断 | json4cj | 状态 |
|---|---|---|
| `JsonProcessingException` 携带 line/column 位置 | `JsonException.location: Option<String>` 但**从不填充**（位置 stub） | ❌ |
| `JsonMappingException` + `Reference` path-to-root（反序列化对象路径） | 无 | ❌ |
| `UnrecognizedPropertyException`（专用未知字段） | `FAIL_ON_UNKNOWN_PROPERTIES` 抛通用 `JsonReadException` | ❌ |
| `MismatchedInputException`（类型不匹配，带目标类型） | `JsonTypeException`（有 expectedType/actualType） | ◑ |
| `JsonParseException`（解析错误带位置） | `JsonReadException`（无位置） | ◑ |
| `CoercionException`/`InputCoercionException` | `JsonOverflowException`（有 targetType） | ◑ |
| 流级 `IOException` 与映射错误区分 | 仓颉 `Exception` 一统 | ❌ |

- **影响**：反序列化失败无法定位"第几行第几列"；未知字段错误与一般读错误不可区分；无对象路径回溯。
- **补齐方案**：① 先补位置追踪（3.1，P0）；② reader 抛异常时填 `location`；③ 加 `UnrecognizedPropertyException <: JsonReadException`；④ mapping 异常携带字段路径。P2。

---

## 八、功能 GAP — 标准扩展

### 8.1 RFC 6902 JSON Patch（stub）
- **Jackson（经 jackson-jsonpatch）**：`JsonPatch` 读写 patch 操作（add/remove/replace/move/copy/test），`apply(source)` 产出新树。
- **json4cj**：`NodePatch` 定义 `Operation` 枚举 + 字段，但**无 `apply()`**（[NodePatch.cj:28](../json4cj-databind/src/node/NodePatch.cj#L28) stub）。
- **补齐方案**：实现 `apply(JsonTree)` 基于 `at(JsonPointer)` + 替换（依赖 4 的 `at` + 可变树）。P3。

### 8.2 Base64 变体
- **Jackson**：`Base64Variants` 提供 MIME / MODIFIED_FOR_URL / no-line-feed 多变体。
- **json4cj**：`util/Base64` 仅 RFC 4648 默认 MIME（带 `=` 填充），无 URL-safe 变体。
- **补齐方案**：加 `Base64Variant` 枚举 + URL-safe 编解码。成本低。P3。

### 8.3 `JsonPointer` 组合 API
- **Jackson**：`JsonPointer.compile`/`head`/`tail`/`last`/`appendProperty`/`appendIndex` 组合。
- **json4cj**：`util/JsonPointer` 实现 RFC 6901 `query`，无组合 API、不连树。
- **补齐方案**：补组合 API + `JsonTree.at(pointer)`。P2。

---

## 九、性能 GAP

实测数据见 [T9 三方基准报告](T9-e2e-three-way-bench.md)（json4cj vs cangjieJSON vs Jackson，LargeBean/BigString/PerfLargeList 三工作负载）。本节给根因级分析。

### 9.1 总体格局
- **json4cj 比 Jackson 慢 5-26 倍**（序列化与反序列化均如此，工作负载越大放大越明显）。
- 该差距有两层来源：① **语言运行时差距**（Cangjie vs JVM）—— 数值转字符串、装箱、GC 等，第三方 cangjieJSON 同样受此制约；② **json4cj 自身开销** —— 适配器间接调用、树物化、调度路径。区分二者是优化的前提。

### 9.2 序列化差距（根因：数值转字符串地板）
- **Jackson**：`ToStringGenerator` 用优化过的 itoa + strength-reduction，整数/浮点→字符串极快。
- **json4cj**：依赖 Cangjie 运行时 `Int64.toString`/`Float64.toString`，无 strength-reduction，是序列化热路径地板。`Float64.toString` 还**有损**（约 7 位有效数字，见 6）。
- **现状**：序列化是 json4cj vs Jackson 差距最大的环节，根因在语言运行时而非 json4cj 代码。
- **补齐方案**：① 等待 Cangjie 改进 itoa/提供格式化 API（上游）；② json4cj 自实现优化 itoa（如查表 + 分段），绕过运行时（成本中，**P0**）；③ Float64 自实现双精度→字符串（Dragon4/Grisu，成本高，P3）。

### 9.3 反序列化差距
- **树反序列化**：经 `IJsonAdapter.cj` 修复后，json4cj tree 反序列化相对同语言基准 cangjieJSON 收窄至 **1.16-1.35x**（commit `daf0b6e`）；`JsonObjectHelper.entries/keys` 修复后 LargeList tree 反序列化 **-15.7%**（commit `124020f`）。差距主要在适配器间接调用 + 树物化开销。
- **流反序列化**：≈ stdx `JsonReader` 地板（json4cj 封装其上，无额外大幅开销）。cangjieJSON 同样基于 stdx，故 Cangjie 系库的流式反序列化上限就是 stdx。
- **补齐方案**：① 适配器内联化（宏生成直接字段读写，减少虚调用，**P0**）；② 树反序列化减少中间 `JsonValue` 物化（直构造目标对象，P1）；③ 流路径已近地板，优化空间小。

### 9.4 BigString 流式序列化（已修复）
- 原 95μs，T9.14 修复双拷贝后 **52μs**（commit `cf5e9a4`），追平 tree（47μs）与 cangjieJSON（50μs）。流式序列化的"双拷贝"类开销已消除。

### 9.5 性能约束（项目目标）
- 原则上**不能比 Jackson 性能低**（当前违反，是待闭合的性能 GAP）。
- **宏路径 ≥ 反射路径 3x**（即宏生成代码须比运行时反射快 3 倍以上，这是宏代码生成的存在意义）。

### 9.6 性能 GAP 优先级
| 优先级 | 项 | 理由 |
|---|---|---|
| **P0** | 自实现优化 itoa 绕过运行时 | 序列化差距最大根因，可控（不依赖上游） |
| **P0** | 适配器内联化（宏直读写字段） | 减少虚调用，缩小 tree 反序列化与 cangjieJSON 差距 |
| **P1** | 减少树反序列化中间物化 | 直构造目标对象 |
| **P3** | Float64 双精度→字符串 | 受限于语言，自实现成本高 |

---

## 十、非目标（不在范围）

| Jackson 生态能力 | 不做的原因 |
|---|---|
| 非 JSON 格式（jackson-dataformat-xml/csv/avro/smile/protobuf） | json4cj 是 JSON 专用库 |
| JSON Schema 生成（jackson-jsonschema） | 属独立工具链职责 |
| 异步/反应式流（`AsyncJsonParser`） | 依赖 stdx 上游支持，非 json4cj 单独可成 |
| 树模型全套变异 API（默认） | 树定位"访问视图"，变异走可选 `MutableJsonTree` |

---

## 十一、补齐优先级总览

按"用户感知收益 / 实现成本"排序，结合功能与性能：

| 优先级 | GAP 项 | 维度 |
|---|---|---|
| **P0** | 9.2 自实现优化 itoa | 性能 |
| **P0** | 9.3 适配器内联化 | 性能 |
| **P0** | 2.2 `@CodableFormat` 接入 | 功能 |
| **P0** | 2.3 `@CodableNaming` 类型级命名策略 | 功能 |
| **P0** | 3.1 位置追踪（line/column） | 功能 |
| **P1** | 2.1 `IJsonAdapter` 流式桥接（单适配器覆盖树+流） | 功能 |
| **P1** | 5.4 ReadFeature coercion 接入 | 功能 |
| **P1** | 4 树 `at(pointer)` + `deepCopy` | 功能 |
| **P1** | 6 流路径 `readBigInt`/`readDecimal` | 功能 |
| **P1** | 9.3 减少树反序列化中间物化 | 性能 |
| **P2** | 2.2 `@CodableCreator` v1 补齐（值参数+流） | 功能 |
| **P2** | 2.2 `@CodableRef` 反序列化侧 | 功能 |
| **P2** | 5.1 模块注册表实现 | 功能 |
| **P2** | 2.4 mix-in / `@JsonPOJOBuilder` / `@JsonSerialize` 运行时注册 | 功能 |
| **P2** | 7 异常特化 + location 填充 | 功能 |
| **P2** | 6 树扩展 `JsonBigInt`/`JsonBigDecimal` 节点 | 功能 |
| **P3** | 6 Float64 精度（受限语言） | 功能/性能 |
| **P3** | 8.1 JSON Patch apply / 8.2 Base64 变体 / 8.3 JsonPointer 组合 | 功能 |
| **P3** | 2.4 `@JsonIgnoreProperties`/`@JsonIncludeProperties`/`@JsonAppend`/`@JsonAutoDetect` 等 | 功能 |

---

## 附：调研方法与证据

本 GAP 分析基于对 json4cj 三组件源码的实际审阅：
- **注解层**：`json4cj-annotations/src/anno/`（23 注解）+ `enums/` + `macros/`（HandleClass/HandleStruct/HandleEnum + utils）。
- **core 层**：`stream/`、`tree/`、`codec/`、`ext/`、`cfg/`、`util/`、`exc/`。
- **databind 层**：`bind/`、`ser/`+`deser/`、`naming/`、`node/`、`types/`、`module/`、`view/`+`filter/`、`exc/`。

stub 证据：stub grep 命中 `@CodableFormat` no-op、`@CodableCreator` v1、`@CodableRef` 反序列化未实现；直接读取确认 `BeanDecoder`/`SimpleModule`/`JsonReader.location`/`PrettyPrinter.withIndent`/`TypeReference`/`NodePatch` 等 stub。性能数据引自 T9 三方基准与 commit `daf0b6e`/`124020f`/`cf5e9a4`。
