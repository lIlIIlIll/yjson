# json4cj 详细执行计划

> **目标**：用仓颉语言实现三个组件 `json4cj-core`、`json4cj-annotations`、`json4cj-databind`，功能上完全对标 Java 版 Jackson 的 `jackson-core`、`jackson-annotations`、`jackson-databind`，但拥有独立的代码架构、命名规范和实现逻辑。

---

## 一、背景分析总结

### 1.1 Jackson 三组件职责

| 组件 | 职责 | 核心类型 |
|------|------|----------|
| **jackson-annotations** | 声明式契约注解（~50个注解/枚举/工具类） | `@JsonProperty`, `@JsonIgnore`, `@JsonInclude`, `@JsonTypeInfo`, `@JsonFormat` 等 |
| **jackson-core** | 流式 JSON 读写引擎 | `JsonGenerator`(写), `JsonParser`(读), `JsonFactory`(工厂), `JsonToken`(令牌) |
| **jackson-databind** | 高级数据绑定（ObjectMapper 为入口） | `ObjectMapper`, `JsonSerializer<T>`, `JsonDeserializer<T>`, `JavaType`, `Module` |

### 1.2 仓颉 vs Java 能力差异

| 能力 | Java | 仓颉 | 影响 |
|------|------|------|------|
| 运行时反射 | 完整（含 private/枚举/注解继承） | 有限（仅 public，不支持枚举，注解不继承） | **不能照搬 Jackson 反射路线，私有变量必须靠宏** |
| 编译期宏 | 无（仅 apt） | **属性宏 + 嵌套宏通信** | 宏是核心引擎 |
| 注解参数 | 任意编译期常量 | `const init` 限编译期常量 | 功能等价 |
| 泛型擦除 | 有 | 有 | 类型信息需编译期捕获 |
| 标准库 JSON | 无（需第三方） | `stdx.encoding.json` + `stdx.encoding.json.stream` | 有底层支撑 |

### 1.3 cangjieJSON 现有实现分析

**架构**：单包 `cjjson`，宏驱动，基于 `stdx.encoding.json` 的 `JsonValue` 树模型。

**优点**：
- 用宏（`@JsonAdapter`）在编译期生成序列化/反序列化代码，零反射开销
- 通过嵌套宏通信（`GlobalInfo` 单例）收集字段级注解信息（`@JsonName`, `@JsonIgnore`, `@JsonIgnoreNull`, `@JsonDefault`）
- 支持 class/struct/泛型/继承/open class
- 用 `extend` 为所有基础类型实现了 `IJsonAdapter<T>` 接口

**局限**：
- **无流式 API**：完全基于 `JsonValue` 树模型，大 JSON 性能差
- **注解能力有限**：仅 5 个注解（`@JsonAdapter`, `@JsonName`, `@JsonIgnore`, `@JsonIgnoreNull`, `@JsonDefault`），远不及 Jackson 的 50+
- **无 ObjectMapper**：没有统一的配置/路由/模块化入口
- **无自定义序列化器**：没有 `JsonSerializer<T>`/`JsonDeserializer<T>` 扩展机制
- **无多态支持**：没有 `@JsonTypeInfo`/`@JsonSubTypes`
- **无树模型 API**：没有 `JsonNode` 等价物
- **异常体系简陋**：仅 3 个异常类
- **命名与 Jackson 过于相似**：`@JsonName` ≈ `@JsonProperty`，`@JsonIgnore` 直接同名

---

## 二、设计原则与命名规范

### 2.1 核心设计原则

1. **宏为主，反射为辅**：编译期代码生成是主引擎，运行时有限反射做兜底
2. **流式优先**：核心读写基于流式 API（`JsonWriter`/`JsonReader`），树模型为上层封装
3. **渐进式功能**：注解从少到多，用户不用注解也能工作（反射兜底）
4. **仓颉惯用**：充分利用仓颉的 `extend`、`Option`、`enum class`、`interface`、`prop` 等特性
5. **独立身份**：包名、类名、方法名全部重新设计，不与 Jackson 雷同

### 2.2 命名规范

| 概念 | Jackson 命名 | json4cj 命名 | 理由 |
|------|-------------|-------------|------|
| 项目/包前缀 | `com.fasterxml.jackson` | `json4cj` | 仓颉项目命名习惯 |
| 序列化注解 | `@JsonSerializable` | `@Codable` | 仓颉社区惯用"编码/解码"语义 |
| 属性映射 | `@JsonProperty` | `@CodableKey` | "Key"更贴合 JSON 键值对语义 |
| 忽略 | `@JsonIgnore` | `@CodableSkip` | "Skip"更直观 |
| 包含策略 | `@JsonInclude` | `@CodablePolicy` | "Policy"表示序列化策略 |
| 排序 | `@JsonPropertyOrder` | `@CodableOrder` | 简洁 |
| 格式 | `@JsonFormat` | `@CodableFormat` | 一致 |
| 多态类型 | `@JsonTypeInfo` | `@CodableVariant` | "Variant"体现变体语义 |
| 子类型 | `@JsonSubTypes` | `@CodableVariantCase` | 嵌套命名 |
| 别名 | `@JsonAlias` | `@CodableAlias` | 一致 |
| 流式写入器 | `JsonGenerator` | `JsonWriter` | 仓颉 stdx 已有此命名 |
| 流式读取器 | `JsonParser` | `JsonReader` | 仓颉 stdx 已有此命名 |
| 对象映射器 | `ObjectMapper` | `JsonCodec` | "Codec"=编解码器 |
| 序列化器 | `JsonSerializer<T>` | `Encoder<T>` | 编码器 |
| 反序列化器 | `JsonDeserializer<T>` | `Decoder<T>` | 解码器 |
| 注册表 | — | `CodecRegistry` | 编解码注册表 |
| 树节点 | `JsonNode` | `JsonValue` | 仓颉 stdx 已有此类型，扩展之 |
| 类型信息 | `JavaType` | `TypeSpec` | 类型规格 |
| 配置 | `MapperConfig` | `CodecConfig` | 一致 |
| 特性开关 | `Feature` (enum) | `CodecFeature` (enum) | 一致 |
| 工厂 | `JsonFactory` | `JsonStreamFactory` | 明确流式 |

---

## 三、三组件架构设计

### 3.1 整体依赖关系

```
┌─────────────────────────────────────────────────────┐
│                   用户代码层                          │
│                                                      │
│  @Codable                                            │
│  class User {                                        │
│      @CodableKey["user_name"]                        │
│      var name: String = ""                           │
│      @CodableSkip                                    │
│      var password: String = ""                       │
│      @CodablePolicy[NON_NULL]                        │
│      var email: Option<String> = None                │
│  }                                                   │
└──────────┬──────────────────────┬────────────────────┘
           │                      │
    ┌──────▼──────┐        ┌─────▼──────────┐
    │ json4cj-    │        │ json4cj-        │
    │ annotations │        │ databind        │
    │ (注解+宏)    │        │ (JsonCodec+     │
    │             │        │  Encoder/Decoder│
    └──────┬──────┘        │  CodecRegistry  │
           │               │  TypeSpec       │
           │               └─────┬──────────┘
           │                     │
    ┌──────▼─────────────────────▼──────────┐
    │          json4j-core                   │
    │  (JsonWriter/JsonReader 流式引擎,      │
    │   JsonValue 树模型,                    │
    │   异常体系, 基础类型编解码)             │
    └───────────────────────────────────────┘
```

**依赖方向**：
- `json4cj-annotations` 依赖 `json4cj-core`（宏生成代码使用 core 的类型）
- `json4cj-databind` 依赖 `json4cj-core` + `json4cj-annotations`
- `json4cj-core` 无外部依赖（仅仓颉标准库 + stdx）

---

### 3.2 json4cj-core 架构

#### 职责
对标 `jackson-core`：流式 JSON 读写引擎、令牌体系、异常体系、基础类型编解码

#### 目录结构
```
json4cj-core/
├── cjpm.toml
├── README.md
├── src/
│   ├── stream/                    # 流式读写 API
│   │   ├── JsonWriter.cj          # 流式 JSON 写入器（对标 JsonGenerator）
│   │   ├── JsonReader.cj          # 流式 JSON 读取器（对标 JsonParser）
│   │   ├── JsonToken.cj           # JSON 令牌枚举（对标 JsonToken）
│   │   ├── JsonStreamFactory.cj   # 流式工厂（对标 JsonFactory）
│   │   └── JsonStreamContext.cj   # 读写上下文/位置追踪
│   ├── tree/                      # 树模型 API
│   │   ├── JsonTree.cj            # 树节点统一接口（对标 TreeNode/JsonNode 核心）
│   │   ├── JsonTreeKind.cj        # 树节点类型枚举
│   │   ├── JsonTreeBuilder.cj     # 从流/字符串构建树
│   │   └── JsonTreeWalker.cj      # 树遍历器
│   ├── codec/                     # 基础类型编解码
│   │   ├── Encoder.cj             # 编码器接口 Encoder<T>
│   │   ├── Decoder.cj             # 解码器接口 Decoder<T>
│   │   ├── BuiltinEncoders.cj     # 内置编码器（Int64/Float64/String/Bool/Array/HashMap...）
│   │   └── BuiltinDecoders.cj     # 内置解码器
│   ├── extend/                    # stdx 扩展
│   │   ├── JsonValueExtend.cj     # JsonValue 便捷扩展
│   │   └── JsonKindExtend.cj      # JsonKind 便捷扩展
│   ├── exc/                       # 异常体系
│   │   ├── JsonException.cj       # 基础异常
│   │   ├── JsonReadException.cj   # 读取异常
│   │   ├── JsonWriteException.cj  # 写入异常
│   │   ├── JsonTypeException.cj   # 类型不匹配
│   │   ├── JsonMissingField.cj    # 字段缺失
│   │   └── JsonOverflowException.cj # 数值溢出
│   ├── cfg/                       # 配置体系
│   │   ├── CodecConfig.cj         # 全局编解码配置
│   │   ├── ReadFeature.cj         # 读取特性开关枚举
│   │   ├── WriteFeature.cj        # 写入特性开关枚举
│   │   └── PrettyPrinter.cj       # 格式化输出
│   ├── util/                      # 工具类
│   │   ├── Base64.cj              # Base64 编解码
│   │   ├── JsonPointer.cj         # JSON Pointer (RFC 6901)
│   │   └── CharEscapes.cj         # 字符转义
│   └── package.cj                 # 包声明与导出
└── test/
    ├── stream/                    # 流式 API 测试
    ├── tree/                      # 树模型测试
    ├── codec/                     # 编解码测试
    └── extend/                    # 扩展测试
```

#### 核心类型设计

**1. JsonToken（令牌枚举）**
```cangjie
public enum JsonToken {
    | StartObject
    | EndObject
    | StartArray
    | EndArray
    | FieldName(String)
    | ValueInt(Int64)
    | ValueFloat(Float64)
    | ValueString(String)
    | ValueBool(Bool)
    | ValueNull
    | Eof
}
```

**2. JsonWriter（流式写入器）**

> 基于 `stdx.encoding.json.stream.JsonWriter` 封装，stdx 底层使用 `ByteBuffer` 字节流。
> json4cj 在 stdx 基础上增加链式调用和便捷方法。

```cangjie
public class JsonWriter {
    // 构造
    public init(buf: ByteBuffer)         // 对标 stdx JsonWriter(ByteBuffer)

    // 结构控制（对标 stdx startObject/endObject/startArray/endArray）
    func startObject(): JsonWriter       // 写 {
    func endObject(): JsonWriter         // 写 }
    func startArray(): JsonWriter        // 写 [
    func endArray(): JsonWriter          // 写 ]
    func writeName(fieldName: String): JsonWriter  // 写字段名，对标 stdx writeName()

    // 值写入（对标 stdx writeValue()，json4cj 增加链式返回）
    func writeValue(v: Int64): JsonWriter
    func writeValue(v: Float64): JsonWriter
    func writeValue(v: String): JsonWriter
    func writeValue(v: Bool): JsonWriter
    func writeNull(): JsonWriter

    // 便捷方法（json4cj 扩展：writeName + writeValue 合并调用）
    func field(name: String, v: Int64): JsonWriter    // writeName + writeValue
    func field(name: String, v: String): JsonWriter
    func field(name: String, v: Bool): JsonWriter
    func field(name: String, v: Float64): JsonWriter
    func nullField(name: String): JsonWriter

    // 格式控制（对标 stdx WriteConfig）
    var writeConfig: WriteConfig         // compact / pretty / 自定义

    // 控制
    func flush(): Unit
    func close(): Unit
    func toString(): String
}
```

**3. JsonReader（流式读取器）**

> 基于 `stdx.encoding.json.stream.JsonReader` 封装，stdx 底层使用 `ByteBuffer` 字节流。
> json4cj 在 stdx 基础上增加便捷读取方法和位置追踪。

```cangjie
public class JsonReader {
    // 构造
    public init(buf: ByteBuffer)         // 对标 stdx JsonReader(ByteBuffer)

    // 前进（对标 stdx peek() 返回 Option<JsonToken>）
    func peek(): Option<JsonToken>       // 查看下一个 token，不消耗
    func skip(): Unit                    // 跳过当前值，对标 stdx skip()

    // 结构判断（对标 stdx startObject/endObject/startArray/endArray）
    func startObject(): Unit
    func endObject(): Unit
    func startArray(): Unit
    func endArray(): Unit

    // 读取值（对标 stdx readName()/readValue<T>()）
    func readName(): String              // 读取字段名
    func readValue<T>(): T where T <: JsonDeserializable<T>  // 泛型读值

    // 便捷方法（json4cj 扩展：对基础类型的快捷读取）
    func readInt(): Int64                // 内部调用 readValue<Int64>()
    func readFloat(): Float64            // 内部调用 readValue<Float64>()
    func readString(): String            // 内部调用 readValue<String>()
    func readBool(): Bool                // 内部调用 readValue<Bool>()

    // 位置追踪（json4cj 扩展）
    func location(): JsonLocation
}
```

**4. Encoder<T> / Decoder<T>（编解码器接口）**

> stdx 已提供 `JsonSerializable`（序列化）和 `JsonDeserializable<T>`（反序列化）接口。
> json4cj 的 `Encoder<T>`/`Decoder<T>` 在此基础上抽象，提供更灵活的注册/查找机制。

```cangjie
public interface Encoder<T> {
    func encode(value: T, writer: JsonWriter): Unit
}

public interface Decoder<T> {
    func decode(reader: JsonReader): T
}

// stdx 内置类型已实现 JsonDeserializable<T>，可直接用 readValue<T>() 读取：
// Int8~Int64, UInt8~UInt64, Float16~Float64, Bool, String,
// Array<T>, ArrayList<T>, HashMap<String, T>, Option<T>,
// BigInt, Decimal, DateTime
```

**5. JsonTree（树模型节点接口）**

> stdx 已提供 `JsonValue` 树模型及其子类（`JsonObject`、`JsonArray`、`JsonString`、`JsonInt`、`JsonFloat`、`JsonBool`、`JsonNull`）。
> 解析入口为 `JsonValue.fromStr(str)`，类型判断用 `kind(): JsonKind`（枚举值：`JsObject`/`JsArray`/`JsString`/`JsInt`/`JsFloat`/`JsBool`/`JsNull`）。
> json4cj 的 `JsonTree` 在 stdx `JsonValue` 基础上扩展，提供更友好的操作接口。

```cangjie
public interface JsonTree {
    func kind(): JsonTreeKind
    func isObject(): Bool
    func isArray(): Bool
    func isInt(): Bool
    func isFloat(): Bool
    func isString(): Bool
    func isBool(): Bool
    func isNull(): Bool

    // Object 操作（对标 stdx JsonObject.get()/put()/operator[]）
    func get(key: String): Option<JsonTree>
    func keys(): Array<String>
    func put(key: String, value: JsonTree): JsonTree

    // Array 操作（对标 stdx JsonArray.get()/add()/size()）
    func get(index: Int64): Option<JsonTree>
    func size(): Int64
    func add(value: JsonTree): JsonTree

    // 值提取（对标 stdx asInt()/asFloat()/asString()/asBool() + getValue()）
    func asInt(): Int64
    func asFloat(): Float64
    func asString(): String
    func asBool(): Bool

    // 转换
    func toString(): String           // 紧凑输出，对标 stdx toString()
    func toPrettyString(): String     // 格式化输出，对标 stdx toJsonString()
    func toWriter(writer: JsonWriter): Unit
}
```

---

### 3.3 json4cj-annotations 架构

#### 职责
对标 `jackson-annotations`：定义所有注解、相关枚举、宏代码生成引擎

#### 目录结构
```
json4cj-annotations/
├── cjpm.toml
├── README.md
├── src/
│   ├── anno/                      # 注解定义（纯声明，对标 Jackson 注解类）
│   │   ├── Codable.cj             # @Codable 主注解（触发宏展开）
│   │   ├── CodableKey.cj          # @CodableKey 字段名映射
│   │   ├── CodableSkip.cj         # @CodableSkip 忽略字段
│   │   ├── CodablePolicy.cj       # @CodablePolicy 包含策略
│   │   ├── CodableOrder.cj        # @CodableOrder 字段排序
│   │   ├── CodableFormat.cj       # @CodableFormat 格式化
│   │   ├── CodableAlias.cj        # @CodableAlias 别名
│   │   ├── CodableDefault.cj      # @CodableDefault 默认值
│   │   ├── CodableVariant.cj      # @CodableVariant 多态类型信息
│   │   ├── CodableVariantCase.cj  # @CodableVariantCase 子类型声明
│   │   ├── CodableUnwrap.cj       # @CodableUnwrap 扁平化内嵌
│   │   ├── CodableRaw.cj          # @CodableRaw 原始JSON值
│   │   ├── CodableView.cj         # @CodableView 视图过滤
│   │   ├── CodableRef.cj          # @CodableRef 对象引用（循环引用）
│   │   ├── CodableInject.cj       # @CodableInject 注入值
│   │   ├── CodableCreator.cj      # @CodableCreator 指定构造方法
│   │   ├── CodableAnyKey.cj       # @CodableAnyKey 动态键读取
│   │   ├── CodableAnyValue.cj     # @CodableAnyValue 动态值写入
│   │   ├── CodableEnum.cj         # @CodableEnum 枚举序列化策略
│   │   └── CodableMeta.cj         # 元注解（标记所有 json4cj 注解）
│   ├── enum/                      # 注解相关枚举
│   │   ├── PolicyMode.cj          # 包含策略：ALWAYS / NON_NULL / NON_EMPTY / NON_DEFAULT
│   │   ├── AccessMode.cj          # 访问模式：READ_WRITE / READ_ONLY / WRITE_ONLY
│   │   ├── VariantUse.cj          # 类型信息使用方式：NAME / TYPE / NONE
│   │   ├── VariantAs.cj           # 类型信息包含方式：PROPERTY / WRAPPER / ARRAY
│   │   ├── EnumNaming.cj          # 枚举命名策略
│   │   ├── NullHandling.cj        # null 处理策略
│   │   └── NumberFormat.cj        # 数字格式
│   ├── macro/                     # 宏代码生成引擎
│   │   ├── CodableMacro.cj        # @Codable 主宏入口
│   │   ├── MacroContext.cj        # 宏展开上下文（替代 GlobalInfo）
│   │   ├── FieldMeta.cj           # 字段元数据（收集注解信息后的结构化表示）
│   │   ├── TypeMeta.cj            # 类型元数据（class/struct 级别）
│   │   ├── CodeEmitter.cj         # 代码发射器（生成 Token 流的工具类）
│   │   ├── ClassProcessor.cj      # class 类型处理器
│   │   ├── StructProcessor.cj     # struct 类型处理器
│   │   ├── EnumProcessor.cj       # enum 类型处理器（含 @CodableEnum 策略）
│   │   ├── FieldCollector.cj      # 字段收集与注解解析
│   │   ├── SerializeEmitter.cj    # 序列化代码生成
│   │   ├── DeserializeEmitter.cj  # 反序列化代码生成
│   │   ├── VariantEmitter.cj      # 多态类型代码生成
│   │   ├── RegistryEmitter.cj     # 注册表初始化代码生成
│   │   └── Diagnostic.cj          # 编译期诊断与报错
│   └── package.cj
└── test/
    ├── anno/                      # 各注解功能测试
    ├── macro/                     # 宏展开测试
    └── integration/               # 集成测试
```

#### 核心注解映射表（Jackson → json4cj）

| Jackson 注解 | json4cj 注解 | 功能差异 |
|-------------|-------------|----------|
| `@JsonProperty` | `@CodableKey` | 支持名称映射、required、access 模式 |
| `@JsonIgnore` | `@CodableSkip` | 忽略字段 |
| `@JsonIgnoreProperties` | `@CodableSkip(keys: [...])` | 类级别忽略多个字段 |
| `@JsonIgnoreType` | `@CodableSkipType` | 忽略整个类型 |
| `@JsonInclude` | `@CodablePolicy` | 包含策略 ALWAYS/NON_NULL/NON_EMPTY/NON_DEFAULT |
| `@JsonPropertyOrder` | `@CodableOrder` | 字段排序 |
| `@JsonFormat` | `@CodableFormat` | 日期/数字格式化 |
| `@JsonAlias` | `@CodableAlias` | 反序列化别名 |
| `@JsonCreator` | `@CodableCreator` | 指定构造方法 |
| `@JsonTypeInfo` | `@CodableVariant` | 多态类型鉴别 |
| `@JsonSubTypes` | `@CodableVariantCase` | 子类型声明（嵌套宏） |
| `@JsonTypeName` | `@CodableVariant.Name` | 类型名称 |
| `@JsonUnwrapped` | `@CodableUnwrap` | 扁平化内嵌对象 |
| `@JsonRawValue` | `@CodableRaw` | 原始 JSON 值写入 |
| `@JsonView` | `@CodableView` | 视图过滤 |
| `@JsonIdentityInfo` | `@CodableRef` | 对象引用/循环引用处理 |
| `@JsonAnyGetter` | `@CodableAnyKey` | 动态属性读取 |
| `@JsonAnySetter` | `@CodableAnyValue` | 动态属性写入 |
| `@JsonValue` | `@CodableEnum` | 枚举序列化策略 |
| `@JsonSetter` | `@CodableKey(access: WRITE_ONLY)` | 通过 access 参数合并 |
| `@JsonGetter` | `@CodableKey(access: READ_ONLY)` | 通过 access 参数合并 |
| `@JacksonInject` | `@CodableInject` | 注入值 |
| `@JsonFilter` | `@CodableFilter` | 动态过滤 |
| `@JsonRootName` | `@CodableRoot` | 根名称包装 |
| `@JsonMerge` | `@CodableMerge` | 合并更新 |
| `@JsonAutoDetect` | — | 不适用（仓颉无反射可见性控制） |
| `@JsonBackReference` | `@CodableRef.Back` | 循环引用反向 |
| `@JsonManagedReference` | `@CodableRef.Managed` | 循环引用正向 |

#### 宏代码生成策略（对比 cangjieJSON 的改进）

**cangjieJSON 方式**：
- 用 `GlobalInfo` 单例做宏通信（字段级注解写入全局表，class 级宏读取）
- 生成 `toJson()/fromJson()` 方法直接操作 `JsonValue` 树（注：stdx 实际 API 为 `JsonValue.fromStr()` 而非 `fromJson()`）
- 没有中间表示，直接拼接 Tokens

**json4cj 方式（改进）**：
- 用 `MacroContext` 做宏通信（更结构化，支持嵌套场景）
- 生成 `encode(writer)/decode(reader)` 方法操作流式 API（性能更好）
- 先收集为 `FieldMeta`/`TypeMeta` 中间表示，再由 `CodeEmitter` 统一生成
- 支持注册到 `CodecRegistry`（运行时可查找）
- 支持多态/视图/引用等高级特性

---

### 3.4 json4cj-databind 架构

#### 职责
对标 `jackson-databind`：高级数据绑定、JsonCodec 入口、模块系统、树模型操作

#### 目录结构
```
json4cj-databind/
├── cjpm.toml
├── README.md
├── src/
│   ├── bind/                      # 数据绑定核心
│   │   ├── JsonCodec.cj           # 主入口（对标 ObjectMapper）
│   │   ├── CodecReader.cj         # 读取器（对标 ObjectReader）
│   │   ├── CodecWriter.cj         # 写入器（对标 ObjectWriter）
│   │   ├── CodecRegistry.cj       # 编解码器注册表
│   │   └── CodecConfig.cj         # 编解码配置
│   ├── ser/                       # 序列化体系
│   │   ├── Encoder.cj             # 编码器基接口（重导出 core 的）
│   │   ├── BeanEncoder.cj         # Bean 编码器（运行时反射兜底）
│   │   ├── StdEncoders.cj         # 标准编码器集合
│   │   ├── EncoderFactory.cj      # 编码器工厂
│   │   └── ContextualEncoder.cj   # 上下文感知编码器
│   ├── deser/                     # 反序列化体系
│   │   ├── Decoder.cj             # 解码器基接口（重导出 core 的）
│   │   ├── BeanDecoder.cj         # Bean 解码器（运行时反射兜底）
│   │   ├── StdDecoders.cj         # 标准解码器集合
│   │   ├── DecoderFactory.cj      # 解码器工厂
│   │   └── ContextualDecoder.cj   # 上下文感知解码器
│   ├── type/                      # 类型系统
│   │   ├── TypeSpec.cj            # 类型规格（对标 JavaType）
│   │   ├── TypeFactory.cj         # 类型工厂
│   │   └── TypeReference.cj       # 泛型类型引用
│   ├── node/                      # 树模型高级操作
│   │   ├── JsonNode.cj            # 增强版树节点（基于 core.JsonTree 扩展）
│   │   ├── NodeFactory.cj         # 节点工厂
│   │   ├── NodeCursor.cj          # 节点遍历游标
│   │   └── NodePatch.cj           # JSON Patch (RFC 6902)
│   ├── module/                    # 模块系统
│   │   ├── CodecModule.cj         # 模块接口（对标 Module）
│   │   ├── SimpleModule.cj        # 简单模块实现
│   │   └── ModuleRegistry.cj      # 模块注册表
│   ├── naming/                    # 命名策略
│   │   ├── NamingStrategy.cj      # 命名策略接口
│   │   ├── SnakeCase.cj           # snake_case
│   │   ├── CamelCase.cj           # camelCase
│   │   ├── PascalCase.cj          # PascalCase
│   │   └── KebabCase.cj           # kebab-case
│   ├── filter/                    # 过滤器
│   │   ├── CodecFilter.cj         # 过滤器接口
│   │   └── SimpleFilter.cj        # 简单过滤器
│   ├── view/                      # 视图系统
│   │   └── CodecView.cj           # 视图定义与解析
│   ├── exc/                       # 数据绑定异常
│   │   ├── CodecException.cj      # 编解码基础异常
│   │   ├── BindException.cj       # 绑定异常
│   │   └── InvalidFormat.cj       # 格式无效
│   └── package.cj
└── test/
    ├── bind/                      # 数据绑定测试
    ├── ser/                       # 序列化测试
    ├── deser/                     # 反序列化测试
    ├── node/                      # 树模型测试
    ├── module/                    # 模块测试
    ├── naming/                    # 命名策略测试
    └── integration/               # 集成测试
```

#### 核心类型设计

**1. JsonCodec（主入口，对标 ObjectMapper）**
```cangjie
public class JsonCodec {
    private let config: CodecConfig
    private let registry: CodecRegistry

    // 构造
    public init()
    public init(config: CodecConfig)

    // 序列化
    public func stringify<T>(value: T): String
    public func write<T>(value: T, writer: JsonWriter): Unit
    public func writeTree<T>(value: T): JsonTree

    // 反序列化
    public func parse<T>(json: String): T where T <: Decodable<T>
    public func read<T>(reader: JsonReader): T where T <: Decodable<T>
    public func readTree(json: String): JsonTree

    // 配置
    public func configure(feature: CodecFeature, state: Bool): JsonCodec
    public func registerModule(module: CodecModule): JsonCodec
    public func setNamingStrategy(strategy: NamingStrategy): JsonCodec

    // 视图
    public func viewFor(clazz: ClassTypeInfo): CodecReader
    public func writerWithView(view: ClassTypeInfo): CodecWriter
}
```

**2. CodecRegistry（编解码器注册表）**
```cangjie
public class CodecRegistry {
    // 注册（由宏生成的初始化代码调用）
    public func registerEncoder<T>(typeName: String, encoder: Encoder<T>): Unit
    public func registerDecoder<T>(typeName: String, decoder: Decoder<T>): Unit

    // 查找
    public func getEncoder(typeName: String): Option<Encoder<Object>>
    public func getDecoder(typeName: String): Option<Decoder<Object>>

    // 内置类型自动注册
    public func registerBuiltinTypes(): Unit
}
```

**3. TypeSpec（类型规格，对标 JavaType）**
```cangjie
public class TypeSpec {
    let qualifiedName: String
    let typeArguments: Array<TypeSpec>
    let isOptional: Bool
    let isCollection: Bool
    let isMap: Bool

    static func of(name: String): TypeSpec
    static func of(name: String, args: Array<TypeSpec>): TypeSpec
}
```

---

## 四、Jackson 功能对标清单

### 4.1 jackson-annotations 功能覆盖

| # | Jackson 注解 | json4cj 注解 | 实现方式 | 优先级 |
|---|-------------|-------------|----------|--------|
| 1 | `@JsonProperty` | `@CodableKey` | 宏编译期读取 | P0 |
| 2 | `@JsonIgnore` | `@CodableSkip` | 宏编译期剔除 | P0 |
| 3 | `@JsonInclude` | `@CodablePolicy` | 宏生成条件代码 | P0 |
| 4 | `@JsonPropertyOrder` | `@CodableOrder` | 宏编译期排序 | P0 |
| 5 | `@JsonFormat` | `@CodableFormat` | 宏生成格式化调用 | P1 |
| 6 | `@JsonAlias` | `@CodableAlias` | 宏生成 match 多分支 | P1 |
| 7 | `@JsonCreator` | `@CodableCreator` | 宏生成构造调用 | P1 |
| 8 | `@JsonTypeInfo` | `@CodableVariant` | 宏+注册表 | P2 |
| 9 | `@JsonSubTypes` | `@CodableVariantCase` | 嵌套宏通信 | P2 |
| 10 | `@JsonUnwrapped` | `@CodableUnwrap` | 宏生成扁平化代码 | P2 |
| 11 | `@JsonRawValue` | `@CodableRaw` | 宏生成原始写入 | P2 |
| 12 | `@JsonAnyGetter/Setter` | `@CodableAnyKey/AnyValue` | 运行时反射+宏 | P2 |
| 13 | `@JsonView` | `@CodableView` | 运行时过滤+宏 | P3 |
| 14 | `@JsonIdentityInfo` | `@CodableRef` | 运行时引用追踪+宏 | P3 |
| 15 | `@JsonIgnoreType` | `@CodableSkipType` | 宏编译期跳过整个类型 | P1 |
| 16 | `@JsonIgnoreProperties` | `@CodableSkip(keys: [...])` | 宏编译期跳过多个字段 | P1 |
| 17 | `@JsonSetter/Getter` | `@CodableKey(access: ...)` | 合并到 CodableKey | P0 |
| 18 | `@JsonValue` | `@CodableEnum` | 枚举序列化策略 | P1 |
| 19 | `@JacksonInject` | `@CodableInject` | 运行时注入 | P3 |
| 20 | `@JsonRootName` | `@CodableRoot` | 宏生成包装代码 | P2 |
| 21 | `@JsonFilter` | `@CodableFilter` | 运行时过滤 | P3 |
| 22 | `@JsonMerge` | `@CodableMerge` | 宏生成合并逻辑 | P3 |
| 23 | `@JsonEnumDefaultValue` | `@CodableEnum.Default` | 宏生成默认值逻辑 | P2 |
| 24 | `@JsonClassDescription` | `@CodableDoc` | 文档注解，不影响序列化 | P3 |
| 25 | `@JsonAutoDetect` | — | 不适用（仓颉无反射可见性控制） | N/A |

### 4.2 jackson-core 功能覆盖

| # | 功能 | json4cj 实现 | 优先级 |
|---|------|-------------|--------|
| 1 | `JsonGenerator` 流式写入 | `JsonWriter` | P0 |
| 2 | `JsonParser` 流式读取 | `JsonReader` | P0 |
| 3 | `JsonToken` 令牌类型 | `JsonToken` 枚举 | P0 |
| 4 | `JsonFactory` 工厂 | `JsonStreamFactory` | P0 |
| 5 | `JsonStreamContext` 上下文 | `JsonStreamContext` | P1 |
| 6 | `JsonLocation` 位置 | `JsonLocation` | P1 |
| 7 | `JsonPointer` 指针 | `JsonPointer` | P2 |
| 8 | `TreeNode` 树接口 | `JsonTree` | P1 |
| 9 | `PrettyPrinter` 格式化 | `PrettyPrinter` | P1 |
| 10 | `Base64Variant` 编码 | `Base64` | P2 |
| 11 | `Version` 版本 | `Version` | P2 |
| 12 | 异常体系 | 完整异常层次 | P0 |
| 13 | `StreamReadFeature/WriteFeature` | `ReadFeature/WriteFeature` | P1 |
| 14 | `FilteringGeneratorDelegate` | `FilterWriter` | P3 |
| 15 | 异步解析 | 考虑后续版本 | P3 |

### 4.3 jackson-databind 功能覆盖

| # | 功能 | json4cj 实现 | 优先级 |
|---|------|-------------|--------|
| 1 | `ObjectMapper` 入口 | `JsonCodec` | P0 |
| 2 | `ObjectReader/Writer` | `CodecReader/CodecWriter` | P0 |
| 3 | `JsonSerializer<T>` | `Encoder<T>` | P0 |
| 4 | `JsonDeserializer<T>` | `Decoder<T>` | P0 |
| 5 | `JavaType` 类型系统 | `TypeSpec` | P1 |
| 6 | `Module` 模块系统 | `CodecModule` | P1 |
| 7 | `JsonNode` 树模型 | `JsonNode`（扩展 JsonTree） | P1 |
| 8 | `PropertyNamingStrategy` | `NamingStrategy` | P1 |
| 9 | `AnnotationIntrospector` | 编译期宏替代 | P1 |
| 10 | `BeanDescription` | `TypeMeta`（编译期） | P1 |
| 11 | `BeanSerializer/Deserializer` | `BeanEncoder/BeanDecoder`（运行时反射兜底） | P2 |
| 12 | `SerializerProvider` | `CodecRegistry` | P1 |
| 13 | `DeserializationFeature/SerializationFeature` | `CodecFeature` | P1 |
| 14 | `TypeDeserializer` 多态反序列化 | `VariantDecoder` | P2 |
| 15 | `ObjectWriter/Reader` with views | `CodecWriter/Reader` with views | P3 |
| 16 | `MappingIterator` | `CodecIterator` | P3 |
| 17 | `InjectableValues` | `InjectableValues` | P3 |
| 18 | `JsonSchema` | `SchemaGenerator` | P3 |

---

## 五、实施阶段与任务分解

### 阶段一：基础设施（json4cj-core 核心）— 预计 3 天

| 任务 | 描述 | 产出 |
|------|------|------|
| 1.1 | 创建项目骨架 | `json4cj-core/cjpm.toml` + 目录结构 |
| 1.2 | 实现异常体系 | `exc/` 下 6 个异常类 |
| 1.3 | 实现 `JsonToken` 枚举 | 令牌类型定义 |
| 1.4 | 实现 `JsonWriter` 流式写入 | 基于 `stdx.encoding.json.stream` 封装 |
| 1.5 | 实现 `JsonReader` 流式读取 | 基于 `stdx.encoding.json.stream` 封装 |
| 1.6 | 实现 `JsonStreamFactory` | 工厂方法 |
| 1.7 | 实现 `JsonStreamContext` | 读写位置追踪 |
| 1.8 | 实现 `JsonValue`/`JsonKind` 扩展 | `extend/` 下便捷方法 |
| 1.9 | 实现 `Encoder<T>`/`Decoder<T>` 接口 | 编解码器接口 |
| 1.10 | 实现内置编解码器 | `BuiltinEncoders`/`BuiltinDecoders`（基础类型） |
| 1.11 | 实现 `CodecConfig` + `Feature` 枚举 | 配置体系 |
| 1.12 | 实现 `PrettyPrinter` | 格式化输出 |
| 1.13 | 编写 core 单元测试 | 流式读写、异常、编解码 |

### 阶段二：注解与宏引擎（json4cj-annotations 核心）— 预计 5 天

| 任务 | 描述 | 产出 |
|------|------|------|
| 2.1 | 创建项目骨架 | `json4cj-annotations/cjpm.toml` + 目录结构 |
| 2.2 | 实现枚举类型 | `PolicyMode`, `AccessMode`, `VariantUse`, `VariantAs` 等 |
| 2.3 | 实现 P0 注解 | `@Codable`, `@CodableKey`, `@CodableSkip`, `@CodablePolicy`, `@CodableOrder` |
| 2.4 | 实现 `MacroContext` | 嵌套宏通信（替代 GlobalInfo，支持多场景） |
| 2.5 | 实现 `FieldMeta`/`TypeMeta` | 字段/类型的结构化元数据中间表示 |
| 2.6 | 实现 `FieldCollector` | 从 AST 收集字段 + 解析注解 → FieldMeta |
| 2.7 | 实现 `CodeEmitter` | Token 流生成的工具类 |
| 2.8 | 实现 `ClassProcessor` | 处理 class 类型 |
| 2.9 | 实现 `StructProcessor` | 处理 struct 类型 |
| 2.10 | 实现 `SerializeEmitter` | 生成 `encode(writer)` 方法（流式写入） |
| 2.11 | 实现 `DeserializeEmitter` | 生成 `decode(reader)` 方法（流式读取） |
| 2.12 | 实现 `RegistryEmitter` | 生成注册到 CodecRegistry 的初始化代码 |
| 2.13 | 实现 `@Codable` 主宏入口 | 路由到各处理器 |
| 2.14 | 实现 `Diagnostic` | 编译期错误报告 |
| 2.15 | 编写注解+宏测试 | 各注解功能验证 |

### 阶段三：数据绑定（json4cj-databind 核心）— 预计 4 天

| 任务 | 描述 | 产出 |
|------|------|------|
| 3.1 | 创建项目骨架 | `json4cj-databind/cjpm.toml` + 目录结构 |
| 3.2 | 实现 `CodecRegistry` | 编解码器注册与查找 |
| 3.3 | 实现 `JsonCodec` 主入口 | `stringify/parse/write/read` 方法 |
| 3.4 | 实现 `CodecConfig` | 全局配置 + Feature 开关 |
| 3.5 | 实现 `CodecReader/CodecWriter` | 预配置的读写器 |
| 3.6 | 实现 `TypeSpec` + `TypeFactory` | 类型系统 |
| 3.7 | 实现 `BeanEncoder/BeanDecoder` | 运行时反射兜底（无注解类） |
| 3.8 | 实现 `NamingStrategy` 体系 | 4 种命名策略 + 自定义扩展 |
| 3.9 | 实现 `CodecModule` 模块系统 | 模块注册与发现 |
| 3.10 | 实现树模型高级操作 | `JsonNode` + `NodeFactory` |
| 3.11 | 编写 databind 测试 | JsonCodec 全流程测试 |

### 阶段四：P1 功能补齐 — 预计 3 天

| 任务 | 描述 | 产出 |
|------|------|------|
| 4.1 | 实现枚举序列化 | `@CodableEnum` + `EnumProcessor` |
| 4.2 | 实现 `@CodableFormat` | 日期/数字格式化 |
| 4.3 | 实现 `@CodableAlias` | 反序列化别名 |
| 4.4 | 实现 `@CodableCreator` | 指定构造方法 |
| 4.5 | 实现 `@CodableSkipType` | 忽略整个类型 |
| 4.6 | 实现 `@CodableSkip(keys: [...])` | 类级别忽略多个字段 |
| 4.7 | 实现 `ReadFeature/WriteFeature` | 流式读写特性开关 |
| 4.8 | 实现 `JsonTree` 树模型 | 完整树节点实现 |
| 4.9 | 实现 `JsonPointer` | JSON Pointer 查询 |
| 4.10 | 编写 P1 功能测试 | |

### 阶段五：P2 高级特性 — 预计 4 天

| 任务 | 描述 | 产出 |
|------|------|------|
| 5.1 | 实现多态序列化 | `@CodableVariant` + `VariantEmitter` |
| 5.2 | 实现子类型声明 | `@CodableVariantCase` 嵌套宏 |
| 5.3 | 实现 `@CodableUnwrap` | 扁平化内嵌对象 |
| 5.4 | 实现 `@CodableRaw` | 原始 JSON 写入 |
| 5.5 | 实现 `@CodableAnyKey/AnyValue` | 动态属性（运行时反射） |
| 5.6 | 实现 `@CodableRoot` | 根名称包装 |
| 5.7 | 实现 `@CodableEnum.Default` | 枚举默认值 |
| 5.8 | 编写 P2 功能测试 | |

### 阶段六：P3 特性与完善 — 预计 3 天

| 任务 | 描述 | 产出 |
|------|------|------|
| 6.1 | 实现 `@CodableView` | 视图过滤系统 |
| 6.2 | 实现 `@CodableRef` | 对象引用/循环引用处理 |
| 6.3 | 实现 `@CodableInject` | 值注入 |
| 6.4 | 实现 `@CodableFilter` | 动态过滤器 |
| 6.5 | 实现 `@CodableMerge` | 合并更新 |
| 6.6 | 完善文档与示例 | README + 使用指南 |
| 6.7 | 全面集成测试 | 跨组件集成测试 |

---

## 六、关键技术方案

### 6.1 宏通信机制（改进 cangjieJSON 的 GlobalInfo）

**问题**：cangjieJSON 的 `GlobalInfo` 用全局单例，不支持并发宏展开，不支持嵌套场景。

**改进方案**：`MacroContext` 基于仓颉宏嵌套通信的 `setItem/getItem` 机制：

```cangjie
// 字段级注解宏
public macro CodableKey(attr: Tokens, input: Tokens): Tokens {
    assertParentContext("Codable")
    let fieldName = parseFieldName(input)
    let keyName = parseKeyName(attr)
    setItem("codable.key.${fieldName}", keyName)
    return input
}

// 类级宏
public macro Codable(attr: Tokens, input: Tokens): Tokens {
    let decl = parseDecl(input)
    // ... 解析类结构 ...
    // 通过 getChildMessages 或 getItem 获取字段级注解
    for (field in fields) {
        let key = getItem("codable.key.${field.name}")
        // ... 构建字段元数据 ...
    }
    // 生成代码...
}
```

### 6.2 流式 API 实现（对标 jackson-core 的 JsonGenerator/Parser）

**策略**：基于 `stdx.encoding.json.stream` 做上层封装，提供更友好的 API。

**stdx 实际 API 对照**（经实测验证）：

| 维度 | stdx 实际 API | json4cj 封装 |
|------|-------------|-------------|
| Writer 构造 | `JsonWriter(ByteBuffer)` | 同上，底层基于字节流 |
| 写入对象 | `startObject()` / `endObject()` | 同上 |
| 写入数组 | `startArray()` / `endArray()` | 同上 |
| 写字段名 | `writeName(name)` | 同上 |
| 写值 | `writeValue(v)` | 同上，增加链式返回 |
| 格式控制 | `writeConfig = WriteConfig.pretty/compact` | 同上，增加自定义配置 |
| Reader 构造 | `JsonReader(ByteBuffer)` | 同上 |
| 查看 token | `peek(): Option<JsonToken>` | 同上 |
| 读字段名 | `readName()` | 同上 |
| 泛型读值 | `readValue<T>()` | 同上 |
| 跳过值 | `skip()` | 同上 |
| 自定义序列化 | `JsonSerializable` 接口 | json4cj 的 `Encoder<T>` 在此基础上扩展 |
| 自定义反序列化 | `JsonDeserializable<T>` 接口 | json4cj 的 `Decoder<T>` 在此基础上扩展 |

**stdx 内置类型支持**（`readValue<T>()` / `writeValue(v)` 已原生支持）：
- 整数：`Int8` ~ `Int64`，`UInt8` ~ `UInt64`
- 浮点：`Float16` ~ `Float64`
- 布尔：`Bool`
- 字符串：`String`
- 集合：`Array<T>`、`ArrayList<T>`、`HashMap<String, T>`
- 可选：`Option<T>`
- 其他：`BigInt`、`Decimal`、`DateTime`（RFC 3339）

**json4cj 封装增强点**：
1. `JsonWriter` 增加 `field()` / `nullField()` 便捷方法（writeName + writeValue 合并调用）
2. `JsonWriter` 所有写入方法返回 `this`，支持链式调用
3. `JsonReader` 增加 `readInt()` / `readFloat()` / `readString()` / `readBool()` 便捷方法
4. `JsonReader` 增加 `location()` 位置追踪
5. 对于不支持 `stdx.encoding.json.stream` 的平台，回退到基于 `stdx.encoding.json` 的树模型

### 6.3 私有变量序列化策略（宏 vs 反射的关键差异）

**问题**：仓颉的运行时反射（`ClassTypeInfo`）**不支持访问 `private` 成员变量**，这与 Java 的 `Field.setAccessible(true)` 完全不同。因此，私有变量的序列化/反序列化**只能依赖宏在编译期生成代码**。

**解决方案**：宏生成的 `toJsonValue()`/`fromJsonValue()`/`encode()`/`decode()` 方法被注入到类声明体内部（通过 `cd.body.decls.add()`），作为类的成员方法，自然拥有对 `private` 字段的访问权限。这是 json4cj "宏为主、反射为辅"架构的关键优势：

```cangjie
// 用户代码：含私有变量
@Codable
class SecretUser {
    private var password: String = ""   // 私有字段
    var name: String = ""               // 公有字段
}

// 宏生成代码（注入到类体内部，可访问 private）
class SecretUser {
    private var password: String = ""
    var name: String = ""

    // ✅ 宏生成的方法在类内部，可直接读写 private 字段
    public func toJsonValue(): JsonValue {
        let jsonObj = JsonObject()
        jsonObj.put("password", this.password.toJsonValue())  // 可访问 private
        jsonObj.put("name", this.name.toJsonValue())
        return jsonObj
    }

    public static func fromJsonValue(jsonValue: JsonValue): SecretUser {
        // ...
        obj.password = String.fromJsonValue(...)   // 可赋值 private
        obj.name = String.fromJsonValue(...)
        return obj
    }
}
```

**对比**：

| 方式 | private 字段 | public 字段 | 说明 |
| ------ | ------------ | ----------- | ---- |
| 宏生成代码（类内部） | ✅ 可读写 | ✅ 可读写 | 生成的代码是类成员，天然有访问权限 |
| 运行时反射（ClassTypeInfo） | ❌ 不可访问 | ✅ 可读写 | 仓颉反射仅支持 public 成员 |
| BeanEncoder 反射兜底 | ❌ 跳过 | ✅ 可读写 | 无 @Codable 时仅序列化 public 字段 |

**实现要点**：

1. `HandleClass.collectFields()` 遍历 `cd.body.decls` 时，`VarDecl` 包含所有成员变量（不论 private/public），宏无需做可见性过滤
2. `HandleStruct.collectFields()` 同理，struct 的私有字段也由宏生成代码在内部访问
3. 继承场景：`toJsonValueInherit()`/`fromJsonValueInherit()` 方法生成在子类内部，只能访问子类自身的 private 字段；父类 private 字段需要父类也标注 `@Codable` 并生成对应的 Inherit 方法
4. BeanEncoder/BeanDecoder 反射兜底时，仅处理 `public` 成员变量，私有字段被跳过——这进一步强化了 `@Codable` 宏的必要性

### 6.4 性能优化策略（对标 Jackson 性能基线）

**原则**：json4cj 的序列化/反序列化性能**不得低于 Jackson**。宏编译期代码生成天然具备零反射开销的优势，只要实现中避免常见的性能陷阱，性能应优于 Jackson 的反射路径，与 Jackson 的 Afterburner 模块相当。

**Jackson 性能基线参考**（基于 jackson-databind 2.x，典型硬件）：

| 场景 | Jackson 吞吐量（ops/ms） | json4cj 目标 |
| ------ | ------------------------ | ------------ |
| 简单 POJO 序列化（5 字段） | ~800 | ≥ 800 |
| 简单 POJO 反序列化（5 字段） | ~600 | ≥ 600 |
| 嵌套对象序列化（3 层） | ~400 | ≥ 400 |
| 大数组序列化（1000 元素） | ~50 | ≥ 50 |
| 大数组反序列化（1000 元素） | ~35 | ≥ 35 |
| 流式写入（无绑定） | ~2000 | ≥ 2000 |
| 流式读取（无绑定） | ~1500 | ≥ 1500 |

> 注：绝对数值因硬件/仓颉运行时而异，以同环境对比为准则。核心要求是 json4cj 的**宏生成路径**不能慢于 Jackson 的**反射路径**。

**6.4.1 编译期优化（宏生成代码的零开销设计）**

宏生成代码是 json4cj 的性能基石。以下规则确保生成代码本身不引入额外开销：

| 规则 | 说明 | 反例（禁止） |
| ------ | ------ | ------ |
| 直接字段访问 | 生成 `obj.name` 而非通过 getter/反射 | `ClassTypeInfo.of(obj).instanceVariables` |
| 类型特化读写 | 基础类型生成 `readInt()`/`readString()` 而非泛型 `readValue<T>()` | 统一用 `readValue<T>()` 再转型 |
| 避免 try-catch 热路径 | 正常路径的 fromJsonValue 不用 try-catch 包裹 | 每个字段赋值都 try-catch |
| 编译期常量内联 | JSON 键名在宏中直接拼入 Tokens，运行时不拼接字符串 | 运行时 `name + "Field"` |
| 消除中间对象 | 序列化直接写流/树，不创建中间 DataTransferObject | 先转 DTO 再序列化 |
| 避免不必要的 Option 解包 | 非 Option 字段直接赋值，不生成 `if (let Some(v) <- ...)` | 所有字段都用 Option 模式 |

**6.4.2 运行时优化**

| 优化点 | 策略 | 实现位置 |
| ------ | ------ | ------ |
| ByteBuffer 复用 | JsonWriter/JsonReader 构造时支持传入预分配的 ByteBuffer | `stream/JsonWriter.cj`、`stream/JsonReader.cj` |
| 对象池 | CodecRegistry 缓存 Encoder/Decoder 实例，避免重复创建 | `bind/CodecRegistry.cj` |
| 字符串延迟解码 | JsonReader 读取字段名时仅在 match 命中后才解码值 | `macro/HandleClass.cj` 生成的 decode() |
| 零拷贝流式写入 | `@CodableRaw` 字段直接写入 ByteBuffer，不经过 String 中间表示 | `stream/JsonWriter.cj` 新增 `rawField()` |
| HashMap 预分配 | fromJsonValue 中创建 HashMap 时指定初始容量 | 宏生成代码 |
| 避免 `toString()` 开销 | toJsonValue 直接构建 JsonObject，不经过字符串拼接 | 宏生成代码 |
| TypeSpec 缓存 | TypeFactory 缓存已创建的 TypeSpec 实例 | `type/TypeFactory.cj` |
| 命名策略结果缓存 | NamingStrategy 对已转换的名称做缓存 | `naming/NamingStrategy.cj` |

**6.4.3 宏生成代码的性能对比**

```cangjie
// ❌ 慢：Jackson 反射路径（运行时通过 ClassTypeInfo 读取字段）
let info = ClassTypeInfo.of(obj)
for (v in info.instanceVariables) {
    writer.writeName(v.name)
    writeReflectValue(writer, v.getValue(obj))  // 反射调用 + 类型判断 + 装箱
}

// ✅ 快：json4cj 宏生成路径（编译期生成，零反射零装箱）
writer.startObject()
writer.field("name", obj.name)           // 直接字段访问，类型特化
writer.field("age", obj.age)             // 直接字段访问，Int64 专用 writeValue
writer.field("email", obj.email)         // 直接字段访问
writer.endObject()
```

**6.4.4 性能回归防护**

- 每个 P 阶段完成后运行基准测试，对比前一版本性能，若下降超过 10% 必须修复后再提交
- 关键路径（序列化/反序列化核心循环）禁止引入堆分配（`new`/`Some()`/`ArrayList()` 等）
- 流式 API 路径不得退化为树模型路径（如先构建 JsonValue 再 toString）

### 6.5 运行时反射兜底（对标 jackson-databind 的 BeanSerializer）

**场景**：用户类没有加 `@Codable` 注解，但仍然需要序列化。

**限制**：由于仓颉反射不支持访问 `private` 成员，BeanEncoder **只能序列化 `public` 成员变量**。若需序列化私有字段，必须使用 `@Codable` 注解走宏路线。

**方案**：
```cangjie
// BeanEncoder 通过反射读取 public 成员（仅限 public，private 不可访问）
public class BeanEncoder <: Encoder<Object> {
    public func encode(value: Object, writer: JsonWriter): Unit {
        let info = ClassTypeInfo.of(value)
        writer.startObject()
        for (v in info.instanceVariables) {
            // 仅处理 public 成员，private 成员被跳过
            writer.writeName(v.name)
            writeReflectValue(writer, v.getValue(value))
        }
        writer.endObject()
    }
}
```

### 6.4 多态实现（对标 @JsonTypeInfo）

**方案**：宏编译期注册子类型映射 → 运行时根据类型鉴别字段路由

```cangjie
// 用户代码
// 注意：@Codable 必须写在外层（最前），@CodableVariant / @CodableVariantCase
// 作为其内层宏，通过 setItem/getChildMessages 传递配置（仓颉宏由内向外展开）。
@Codable
@CodableVariant[use: VariantUse.NAME, as: VariantAs.PROPERTY, property: "type", cases: "dog:Dog,cat:Cat"]
open class Animal { var name: String = "" }

@Codable[withSuperClass = Animal]
@CodableVariantCase["dog"]
class Dog <: Animal { var breed: String = "" }

// 宏生成：编译期注册
// AnimalCodecRegistry.registerVariant("dog", Dog.encoder, Dog.decoder)

// 运行时路由
// JsonCodec.parse<Animal>(json) → 读取 "type" 字段 → 查注册表 → 路由到 Dog.decoder
```

### 6.5 枚举序列化（对标 Jackson 的枚举处理）

**方案**：`@CodableEnum` 宏支持多种策略：

```cangjie
// @Codable 为外层代码生成宏，@CodableEnum 为内层配置宏（仓颉宏由内向外展开）。
@Codable
@CodableEnum           // 默认：枚举名作为字符串
enum Color { | Red | Green | Blue }

@Codable
@CodableEnum[ord]      // 用序号
enum Priority { | Low | Medium | High }

@Codable
@CodableEnum[default: "Active"]  // 未知值回退默认值
enum Status {
    | Active
    | Inactive
}
```

---

## 七、与 cangjieJSON 的关键区别

| 维度 | cangjieJSON | json4cj |
|------|------------|---------|
| 架构 | 单包 monolith | 三组件分层（core/annotations/databind） |
| 读写引擎 | 基于 `JsonValue` 树模型 | 基于 `JsonWriter`/`JsonReader` 流式 API |
| 注解数量 | 5 个 | 20+ 个（对标 Jackson 全部注解） |
| 宏通信 | `GlobalInfo` 全局单例 | `MacroContext` + `setItem/getItem`（支持嵌套） |
| 代码生成 | 直接拼接 Tokens | `FieldMeta`/`TypeMeta` 中间表示 → `CodeEmitter` |
| 扩展机制 | 无（仅 `IJsonAdapter` 接口） | `Encoder<T>`/`Decoder<T>` + `CodecModule` 模块系统 |
| 多态 | 不支持 | `@CodableVariant` + 注册表 |
| 视图 | 不支持 | `@CodableView` |
| 循环引用 | 不支持 | `@CodableRef` |
| 命名策略 | 无 | `NamingStrategy` 体系 |
| 配置 | `allowNull` 属性 | 完整的 `CodecConfig` + `Feature` 开关 |
| 异常体系 | 3 个异常 | 6+ 个异常（层次化） |
| 树模型 | 无独立树模型（直接用 stdx.JsonValue） | `JsonTree`/`JsonNode` 统一接口 |
| 枚举支持 | 不支持（`HandleEnum` 为空） | `@CodableEnum` + `EnumProcessor` |

---

## 八、风险与应对

| 风险 | 影响 | 应对 |
| ------ | ------ | ------ |
| `stdx.encoding.json.stream` 平台兼容性 | 部分平台可能不支持流式 API | 提供基于 `stdx.encoding.json` 树模型的回退实现 |
| 仓颉宏的 AST API 稳定性 | 宏接口可能变化 | 隔离宏代码，提供 adapter 层 |
| 仓颉反射对泛型支持有限 | 泛型类型的运行时编解码可能受限 | 编译期通过宏捕获泛型信息，运行时尽量不依赖反射 |
| 仓颉反射不支持私有变量 | `ClassTypeInfo` 无法访问 `private` 成员 | 完全依赖宏在编译期生成代码（宏注入类内部可访问 private），反射兜底仅处理 public 字段 |
| 仓颉运行时性能与 JVM 差异 | 仓颉 M:N 线程模型的运行时性能特征与 JVM 不同，绝对数值可能不可直接对比 | 以同环境自身前后版本对比为主，绝对数值仅作参考；性能目标按同环境 Jackson 的相对比例设定 |
| `@CodableVariant` 多态实现复杂 | 需要宏+注册表+运行时分发 | 分阶段实现，先支持简单场景 |
| 流式 API 封装层性能损耗 | json4cj 在 stdx 之上的封装可能引入额外开销 | 封装层尽量内联，关键路径零封装；基准测试验证封装开销 < 5% |
| 大 JSON 树模型内存峰值 | 树模型需要整棵 JsonValue 驻留内存 | 推荐用户使用流式 API 处理大 JSON；树模型路径加内存限制配置 |
| 循环引用检测性能 | 运行时 IdentityMap 开销 | 仅在配置开启时启用，默认关闭 |
| 枚举反射不支持 | 仓颉 `ClassTypeInfo` 不支持枚举 | 完全依赖宏在编译期生成枚举的编解码代码 |
| 宏生成代码膨胀 | 大量字段的类可能生成大量代码影响编译速度 | 宏仅生成必要方法，不生成冗余代码；编译速度不作为运行时性能约束 |

---

## 九、序列化/反序列化测试用例设计

> 本章基于仓颉类型体系和 Jackson 测试覆盖分析，设计 json4cj 全场景测试用例。每个用例包含类定义和预期 JSON，确保对标 Jackson 能力不丢失。

### 9.1 基础类型测试（T1）

#### T1.1 整数类型

```cangjie
@Codable
class IntTypes {
    var i8: Int8 = 0
    var i16: Int16 = 0
    var i32: Int32 = 0
    var i64: Int64 = 0
    var iNative: IntNative = 0
    var u8: UInt8 = 0
    var u16: UInt16 = 0
    var u32: UInt32 = 0
    var u64: UInt64 = 0
    var uNative: UIntNative = 0
}
```

```json
{"i8":1,"i16":2,"i32":3,"i64":4,"iNative":5,"u8":6,"u16":7,"u32":8,"u64":9,"uNative":10}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.1.1 | 正常值序列化 | 各类型正常值 |
| T1.1.2 | 边界值序列化 | Int8 的 -128/127, Int64 的 min/max, UInt64 的 max 等 |
| T1.1.3 | 零值序列化 | 各类型 0 值 |
| T1.1.4 | 负数序列化（有符号） | Int8/Int16/Int32/Int64/IntNative 负值 |
| T1.1.5 | 反序列化边界值 | 大数反序列化，溢出应抛 JsonOverflowException |
| T1.1.6 | 反序列化类型不匹配 | JSON 中浮点数反序列化到整数字段 |
| T1.1.7 | UInt 类型反序列化负数 | 负数反序列化到 UInt 字段应报错 |

#### T1.2 浮点类型

```cangjie
@Codable
class FloatTypes {
    var f16: Float16 = 0.0
    var f32: Float32 = 0.0
    var f64: Float64 = 0.0
}
```

```json
{"f16":1.5,"f32":3.14,"f64":2.718281828}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.2.1 | 正常值序列化 | 各浮点类型正常值 |
| T1.2.2 | 零值 | 正零和负零 |
| T1.2.3 | 精度边界 | Float16 约 3 位有效数字，Float32 约 6 位，Float64 约 15 位 |
| T1.2.4 | 特殊值处理 | NaN → `"NaN"` 字符串，Infinity → `"Infinity"` 字符串（对标 Jackson） |
| T1.2.5 | 整数反序列化为浮点 | JSON 中 `1` 反序列化为 Float64 应为 `1.0` |
| T1.2.6 | 科学计数法 | `1.23e10` 格式解析 |
| T1.2.7 | 精度丢失检测 | 超出类型精度的值反序列化 |

#### T1.3 布尔类型

```cangjie
@Codable
class BoolType {
    var flag: Bool = false
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.3.1 | true 序列化 | → `{"flag":true}` |
| T1.3.2 | false 序列化 | → `{"flag":false}` |
| T1.3.3 | 字符串转布尔 | `"true"` → `true`（需 CodecFeature 支持） |
| T1.3.4 | 整数转布尔 | `1` → `true`, `0` → `false`（需 CodecFeature 支持） |

#### T1.4 字符串类型

```cangjie
@Codable
class StringType {
    var text: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.4.1 | 普通字符串 | `"hello"` |
| T1.4.2 | 空字符串 | `""` |
| T1.4.3 | 含转义字符 | `"line1\nline2"`, `"tab\there"`, `"quote\"inside"` |
| T1.4.4 | 含 Unicode | `"中文"`, `"🎉"`, `"A"` |
| T1.4.5 | 超长字符串 | 10000+ 字符 |
| T1.4.6 | 含特殊 HTML 字符 | `<>&"` 转义处理 |

#### T1.5 Rune 类型

```cangjie
@Codable
class RuneType {
    var ch: Rune = 'A'
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.5.1 | ASCII 字符 | `'A'` → `"A"` |
| T1.5.2 | 中文字符 | `'中'` → `"中"` |
| T1.5.3 | Emoji | `'🎉'` → `"🎉"` |
| T1.5.4 | 反序列化多字符字符串 | `"AB"` 反序列化为 Rune 应报错 |

#### T1.6 BigInt / Decimal 类型

```cangjie
@Codable
class BigTypes {
    var bigInt: BigInt = BigInt(0)
    var decimal: Decimal = Decimal(0)
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.6.1 | 大整数序列化 | 超出 Int64 范围的整数 |
| T1.6.2 | 高精度小数 | `Decimal("3.141592653589793238")` |
| T1.6.3 | 反序列化超大数 | JSON 中超长数字字符串 |

#### T1.7 DateTime 类型

```cangjie
@Codable
class DateTimeType {
    var created: DateTime = DateTime.now()
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T1.7.1 | 默认格式 | RFC 3339 格式 `"2026-07-30T12:00:00Z"` |
| T1.7.2 | 自定义格式 | `@CodableFormat["yyyy-MM-dd"]` → `"2026-07-30"` |
| T1.7.3 | 时间戳格式 | Unix 时间戳（秒/毫秒） |
| T1.7.4 | 反序列化无效日期 | `"2026-13-45"` 应报错 |

### 9.2 仓颉自定义类型测试（T2）

#### T2.1 Unit 类型

```cangjie
@Codable
class UnitType {
    var nothing: Unit = ()
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T2.1.1 | 序列化 | Unit 值序列化为 `null` |
| T2.1.2 | 反序列化 | `null` 反序列化为 `()` |

#### T2.2 Option 类型

```cangjie
@Codable
class OptionTypes {
    var maybeInt: Option<Int64> = None
    var maybeStr: ?String = None       // ?T 语法糖
    var maybeObj: ?Inner = None
}

@Codable
class Inner {
    var value: Int64 = 0
}
```

```json
{"maybeInt":42,"maybeStr":"hello","maybeObj":{"value":1}}
```

```json
{"maybeInt":null,"maybeStr":null,"maybeObj":null}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T2.2.1 | Some 值序列化 | 各类型 Some 值 |
| T2.2.2 | None 序列化 | → JSON `null` |
| T2.2.3 | JSON null 反序列化 | → `None` |
| T2.2.4 | 缺失字段反序列化 | JSON 中无该字段 → `None` |
| T2.2.5 | 嵌套 Option | `Option<Option<Int64>>` — `Some(Some(1))` / `Some(None)` / `None` |
| T2.2.6 | Option 集合 | `Array<Option<Int64>>` 含 None 元素 |
| T2.2.7 | 非 None 值类型不匹配 | JSON 字符串反序列化到 `Option<Int64>` 字段 |

#### T2.3 元组类型

```cangjie
@Codable
class TupleTypes {
    var pair: (Int64, String) = (0, "")
    var triple: (Int64, String, Bool) = (0, "", false)
    var nested: ((Int64, Int64), String) = ((0, 0), "")
}
```

```json
{"pair":[1,"hello"],"triple":[1,"hello",true],"nested":[[1,2],"world"]}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T2.3.1 | 二元组序列化 | → JSON 数组 |
| T2.3.2 | 多元组序列化 | 三元组、四元组 |
| T2.3.3 | 嵌套元组 | 元组内含元组 |
| T2.3.4 | 含 Option 的元组 | `(Int64, ?String)` |
| T2.3.5 | 反序列化数组长度不匹配 | JSON 数组长度 ≠ 元组元素数应报错 |
| T2.3.6 | 反序列化元素类型不匹配 | JSON 数组元素类型与元组对应位置类型不符 |

#### T2.4 枚举类型

```cangjie
@Codable
@CodableEnum
enum Color {
    | Red
    | Green
    | Blue
}

@Codable
@CodableEnum
enum Priority {
    | Low
    | Medium
    | High
}

// 带关联值的枚举
@Codable
enum Shape {
    | Circle(Float64)
    | Rectangle(Float64, Float64)
    | Triangle(Float64, Float64, Float64)
}

// 递归枚举
@Codable
enum Expr {
    | Num(Int64)
    | Add(Expr, Expr)
    | Neg(Expr)
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T2.4.1 | 简单枚举名称序列化 | `Color.Red` → `"Red"` |
| T2.4.2 | 简单枚举反序列化 | `"Green"` → `Color.Green` |
| T2.4.3 | 枚举序号序列化 | `@CodableEnum[ord]` → `0`/`1`/`2` |
| T2.4.4 | 未知枚举值反序列化 | `"Purple"` → 行为由 CodecFeature 决定（报错/null/默认值） |
| T2.4.5 | 带关联值的枚举序列化 | `Shape.Circle(3.14)` → `{"Circle":[3.14]}` |
| T2.4.6 | 带关联值的枚举反序列化 | 反序列化回枚举 |
| T2.4.7 | 递归枚举 | `Add(Num(1), Num(2))` 序列化和反序列化 |
| T2.4.8 | 枚举作为字段 | class 中包含 enum 字段 |
| T2.4.9 | 枚举集合 | `Array<Color>` 序列化 |
| T2.4.10 | 枚举作为 Map key | `HashMap<Color, String>` 序列化 |
| T2.4.11 | 大小写不敏感反序列化 | `"red"` → `Color.Red`（需 CodecFeature 支持） |

### 9.3 用户自定义类型测试（T3）

#### T3.1 普通 class

```cangjie
@Codable
class User {
    var name: String = ""
    var age: Int64 = 0
    var email: ?String = None
}
```

```json
{"name":"张三","age":25,"email":"zhangsan@example.com"}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.1.1 | 基本序列化 | 全部字段有值 |
| T3.1.2 | 含 Option 字段 | email 为 None 时 → JSON null 或省略（由 @CodablePolicy 决定） |
| T3.1.3 | 基本反序列化 | JSON → 对象 |
| T3.1.4 | 多余字段忽略 | JSON 中含 class 未定义的字段，默认忽略 |
| T3.1.5 | 缺失字段 | JSON 中缺少非 Option 字段 → 使用默认值或报错 |
| T3.1.6 | 空对象 | `{}` 反序列化 → 所有字段为默认值 |

#### T3.2 struct 类型

```cangjie
@Codable
struct Point {
    var x: Float64 = 0.0
    var y: Float64 = 0.0
}

@Codable
struct Rectangle {
    var topLeft: Point = Point()
    var bottomRight: Point = Point()
}
```

```json
{"x":1.5,"y":2.5}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.2.1 | struct 序列化 | 值类型序列化 |
| T3.2.2 | struct 反序列化 | 反序列化为新值副本 |
| T3.2.3 | 嵌套 struct | Rectangle 包含 Point |
| T3.2.4 | struct 含 Array 字段 | struct 内含集合 |

#### T3.3 继承（open class）

```cangjie
@Codable
open class Animal {
    var name: String = ""
    var age: Int64 = 0
}

@Codable
class Dog <: Animal {
    var breed: String = ""
}

@Codable
class Cat <: Animal {
    var indoor: Bool = true
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.3.1 | 父类序列化 | Animal 实例序列化 |
| T3.3.2 | 子类序列化 | Dog 实例序列化，含父类字段 |
| T3.3.3 | 子类反序列化 | JSON → Dog 实例 |
| T3.3.4 | 多态反序列化 | 静态类型为 Animal，实际为 Dog |
| T3.3.5 | 多层继承 | A → B → C 三层继承序列化 |

#### T3.4 泛型类型

```cangjie
@Codable
class Box<T> {
    var value: T = DefaultOf<T>()  // 需默认值
}

@Codable
class Pair<A, B> {
    var first: A = DefaultOf<A>()
    var second: B = DefaultOf<B>()
}

@Codable
class Container<T> {
    var items: Array<T> = []
    var count: Int64 = 0
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.4.1 | 单泛型参数 | `Box<Int64>` 序列化 |
| T3.4.2 | 多泛型参数 | `Pair<Int64, String>` 序列化 |
| T3.4.3 | 泛型含集合字段 | `Container<Int64>` 序列化 |
| T3.4.4 | 嵌套泛型 | `Box<Box<Int64>>` 序列化 |
| T3.4.5 | 泛型与继承结合 | `Container<Dog>` 其中 Dog 继承自 Animal |
| T3.4.6 | 泛型反序列化 | 类型信息正确恢复 |

#### T3.5 混合类型（class 内含基础类型 + 自定义类型 + 集合）

```cangjie
@Codable
class Company {
    var name: String = ""
    var founded: Int64 = 0
    var active: Bool = true
    var headquarters: Address = Address()
    var departments: Array<String> = []
    var employees: Array<Employee> = []
    var metadata: HashMap<String, String> = HashMap<String, String>()
}

@Codable
class Address {
    var city: String = ""
    var street: String = ""
    var zipCode: String = ""
}

@Codable
class Employee {
    var id: Int64 = 0
    var name: String = ""
    var salary: Float64 = 0.0
    var department: ?String = None
    var skills: Array<String> = []
}
```

```json
{
    "name": "示例科技",
    "founded": 2020,
    "active": true,
    "headquarters": {"city": "北京", "street": "中关村大街1号", "zipCode": "100080"},
    "departments": ["研发", "市场", "运营"],
    "employees": [
        {"id": 1, "name": "张三", "salary": 15000.0, "department": "研发", "skills": ["仓颉", "Java"]},
        {"id": 2, "name": "李四", "salary": 12000.0, "department": null, "skills": []}
    ],
    "metadata": {"level": "A", "region": "north"}
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.5.1 | 完整对象序列化 | 所有字段有值 |
| T3.5.2 | 含 null 字段 | department 为 null |
| T3.5.3 | 含空集合 | skills 为空数组 |
| T3.5.4 | 含嵌套对象 | headquarters 为 Address 对象 |
| T3.5.5 | 含对象数组 | employees 数组 |
| T3.5.6 | 含 Map | metadata 字段 |
| T3.5.7 | 完整反序列化 | JSON → Company 对象 |
| T3.5.8 | 往返一致性 | serialize → deserialize → serialize 结果一致 |

#### T3.6 sealed class

```cangjie
@Codable
sealed abstract class Result {
    var code: Int64 = 0
}

@Codable
class Success <: Result {
    var data: String = ""
}

@Codable
class Failure <: Result {
    var message: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.6.1 | 子类序列化 | Success/Failure 各自序列化 |
| T3.6.2 | 多态序列化 | 静态类型为 Result，动态为 Success |
| T3.6.3 | 配合 @CodableVariant | 类型鉴别字段自动写入/读取 |

#### T3.7 私有变量（private var/let）

> **核心背景**：仓颉语言的运行时反射（`ClassTypeInfo`）不支持访问 `private` 成员变量，因此**私有变量的序列化/反序列化必须依赖宏在编译期生成代码**。宏生成的 `toJsonValue()`/`fromJsonValue()`/`encode()`/`decode()` 方法注入到类体内部，作为类的成员方法自然拥有对 `private` 字段的访问权限——这是 json4cj "宏为主、反射为辅"架构的关键优势之一。

```cangjie
// 场景1：class 含私有变量
@Codable
class SecretUser {
    private var password: String = ""
    var name: String = ""
    private var age: Int64 = 0
}

// 场景2：class 含私有变量 + @CodableKey 映射
@Codable
class MappedSecret {
    @CodableKey["pwd"]
    private var password: String = ""
    var username: String = ""
}

// 场景3：class 含私有变量 + @CodableSkip
@Codable
class SkipSecret {
    @CodableSkip
    private var internalId: String = ""
    var name: String = ""
    private var score: Int64 = 0
}

// 场景4：class 含私有 Option 变量
@Codable
class PrivateOption {
    private var maybeToken: ?String = None
    var name: String = ""
}

// 场景5：struct 含私有变量
@Codable
struct SecretPoint {
    private var x: Float64 = 0.0
    private var y: Float64 = 0.0
}

// 场景6：继承 + 私有变量
@Codable
open class BaseSecret {
    private var baseField: String = ""
    var visible: String = ""
}

@Codable[withSuperClass=BaseSecret]
class ChildSecret <: BaseSecret {
    private var childField: Int64 = 0
    var label: String = ""
}

// 场景7：私有变量 + @CodablePolicy
@Codable
class PolicySecret {
    @CodablePolicy[NON_NULL]
    private var email: ?String = None
    var name: String = ""
}

// 场景8：私有变量 + @CodableAlias
@Codable
class AliasSecret {
    @CodableKey["token"]
    @CodableAlias["access_token", "auth_token"]
    private var authToken: String = ""
    var name: String = ""
}

// 场景9：私有变量 + @CodableUnwrap
@Codable
class UnwrapSecret {
    var name: String = ""
    @CodableUnwrap
    private var location: Location = Location()
}

// 场景10：私有变量 + @CodableRaw
@Codable
class RawSecret {
    var name: String = ""
    @CodableRaw
    private var rawJson: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T3.7.1 | 私有变量序列化 | `private var` 能正确序列化到 JSON（宏生成代码在类内部，可访问 private） |
| T3.7.2 | 私有变量反序列化 | JSON 值能正确赋值到 `private var` 字段 |
| T3.7.3 | 私有变量 + @CodableKey | 私有字段的键名映射正常工作 |
| T3.7.4 | 私有变量 + @CodableSkip | 私有字段被正确忽略 |
| T3.7.5 | 私有 Option 变量 | `private var maybeX: ?T = None` 序列化为 null 或省略 |
| T3.7.6 | struct 含私有变量 | struct 的 private 字段同样能正确编解码 |
| T3.7.7 | 继承 + 私有变量 | 父类私有字段通过 `Inherit` 方法正确处理 |
| T3.7.8 | 私有变量 + @CodablePolicy | NON_NULL 策略在私有字段上正常工作 |
| T3.7.9 | 私有变量 + @CodableAlias | 私有字段的别名反序列化正常工作 |
| T3.7.10 | 私有变量 + @CodableUnwrap | 私有内嵌对象的扁平化正常工作 |
| T3.7.11 | 私有变量 + @CodableRaw | 私有字段的原始 JSON 读写正常工作 |
| T3.7.12 | 纯私有变量类 | 所有字段均为 private 的 class/struct 序列化 |
| T3.7.13 | 反射兜底对比 | 未标注 @Codable 的类，BeanEncoder 无法序列化私有字段（验证反射限制） |
| T3.7.14 | 往返一致性 | 私有变量 round-trip 测试：obj → JSON → obj2，所有字段值一致 |

### 9.4 集合类型测试（T4）

#### T4.1 Array 类型

```cangjie
@Codable
class ArrayTypes {
    var ints: Array<Int64> = []
    var strings: Array<String> = []
    var bools: Array<Bool> = []
    var objects: Array<User> = []    // User 见 T3.1
    var empty: Array<Int64> = []
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.1.1 | 整数数组序列化 | `[1, 2, 3]` |
| T4.1.2 | 字符串数组序列化 | `["a", "b", "c"]` |
| T4.1.3 | 对象数组序列化 | User 数组 |
| T4.1.4 | 空数组序列化 | `[]` |
| T4.1.5 | 大数组 | 1000+ 元素 |
| T4.1.6 | 反序列化 | JSON 数组 → Array |
| T4.1.7 | 元素类型不匹配 | `[1, "two", 3]` 反序列化为 `Array<Int64>` 应报错 |

#### T4.2 ArrayList 类型

```cangjie
@Codable
class ArrayListType {
    var items: ArrayList<String> = ArrayList<String>()
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.2.1 | 序列化 | ArrayList 与 Array 输出相同 |
| T4.2.2 | 反序列化 | JSON 数组 → ArrayList |

#### T4.3 HashMap 类型

```cangjie
@Codable
class MapTypes {
    var stringMap: HashMap<String, String> = HashMap<String, String>()
    var intMap: HashMap<String, Int64> = HashMap<String, Int64>()
    var objectMap: HashMap<String, User> = HashMap<String, User>()
    var nestedMap: HashMap<String, HashMap<String, Int64>> = HashMap<String, HashMap<String, Int64>>()
}
```

```json
{
    "stringMap": {"key1": "val1", "key2": "val2"},
    "intMap": {"a": 1, "b": 2},
    "objectMap": {"user1": {"name": "张三", "age": 25, "email": null}},
    "nestedMap": {"group1": {"x": 1, "y": 2}, "group2": {"x": 3, "y": 4}}
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.3.1 | String-String Map | 键值均为字符串 |
| T4.3.2 | String-Int Map | 值为整数 |
| T4.3.3 | String-Object Map | 值为自定义对象 |
| T4.3.4 | 空 Map | `{}` |
| T4.3.5 | 反序列化 | JSON 对象 → HashMap |
| T4.3.6 | 非字符串 key | 需特殊处理（枚举 key 等） |

#### T4.4 HashSet 类型

```cangjie
@Codable
class SetType {
    var tags: HashSet<String> = HashSet<String>()
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.4.1 | 序列化 | → JSON 数组 |
| T4.4.2 | 反序列化 | JSON 数组 → HashSet（自动去重） |
| T4.4.3 | 含重复元素 | JSON `[1,1,2]` → `HashSet<Int64>` 去重为 2 个元素 |

#### T4.5 嵌套集合（重点）

```cangjie
@Codable
class NestedCollections {
    // 二维
    var matrix: Array<Array<Int64>> = []                           // Array<Array<Int64>>
    var mapOfArrays: HashMap<String, Array<Int64>> = HashMap<>()   // Map<String, Array<Int64>>
    var arrayOfMaps: Array<HashMap<String, Int64>> = []            // Array<Map<String, Int64>>

    // 三维
    var cube: Array<Array<Array<Int64>>> = []                      // 三层嵌套
    var mapOfMaps: HashMap<String, HashMap<String, Int64>> = HashMap<>()  // 嵌套 Map
    var mapOfArrayOfMap: HashMap<String, Array<HashMap<String, Int64>>> = HashMap<>()  // 三层混合

    // 含 Option
    var optionalArray: Array<Option<Int64>> = []
    var optionalMap: HashMap<String, ?Int64> = HashMap<String, ?Int64>()
}
```

```json
{
    "matrix": [[1,2,3],[4,5,6]],
    "mapOfArrays": {"row1":[1,2],"row2":[3,4]},
    "arrayOfMaps": [{"a":1},{"b":2}],
    "cube": [[[1,2],[3,4]],[[5,6],[7,8]]],
    "mapOfMaps": {"g1":{"x":1,"y":2},"g2":{"x":3,"y":4}},
    "mapOfArrayOfMap": {"group":[{"x":1},{"y":2}]},
    "optionalArray": [1, null, 3],
    "optionalMap": {"a":1, "b":null}
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.5.1 | 二维数组 | `Array<Array<Int64>>` |
| T4.5.2 | Map of Array | `HashMap<String, Array<Int64>>` |
| T4.5.3 | Array of Map | `Array<HashMap<String, Int64>>` |
| T4.5.4 | 三维数组 | `Array<Array<Array<Int64>>>` |
| T4.5.5 | 嵌套 Map | `HashMap<String, HashMap<String, Int64>>` |
| T4.5.6 | 三层混合嵌套 | Map → Array → Map |
| T4.5.7 | 含 null 的数组 | `Array<Option<Int64>>` 含 None 元素 |
| T4.5.8 | 含 null 的 Map 值 | `HashMap<String, ?Int64>` 含 null 值 |
| T4.5.9 | 深层嵌套反序列化 | 4 层以上嵌套正确反序列化 |
| T4.5.10 | 空嵌套集合 | 外层非空但内层为空 `{"key":[]}` |

#### T4.6 VArray 类型

```cangjie
@Codable
struct VArrayType {
    var fixed: VArray<Int64, $3> = [0, 0, 0]
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.6.1 | 序列化 | → JSON 数组 |
| T4.6.2 | 反序列化 | JSON 数组长度必须匹配 VArray 长度 |

#### T4.7 Range 类型

```cangjie
@Codable
class RangeType {
    var intRange: Range<Int64> = 0..10
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T4.7.1 | 序列化 | Range 序列化为 `{"start":0,"end":10,"step":1}` |
| T4.7.2 | 反序列化 | JSON → Range 对象 |

### 9.5 注解功能测试（T5）

#### T5.1 @CodableKey

```cangjie
@Codable
class KeyMapping {
    @CodableKey["user_name"]
    var name: String = ""
    @CodableKey["user_age"]
    var age: Int64 = 0
}
```

```json
{"user_name":"张三","user_age":25}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.1.1 | 序列化字段名映射 | Java 字段名 → JSON 不同键名 |
| T5.1.2 | 反序列化字段名映射 | JSON 键名 → Java 字段名 |
| T5.1.3 | access 模式 | `@CodableKey[access: AccessMode.WRITE_ONLY]` 序列化时忽略 |
| T5.1.4 | required | `@CodableKey[required: true]` 缺失时报错 |

#### T5.2 @CodableSkip

```cangjie
@Codable
class SkipFields {
    var name: String = ""
    @CodableSkip
    var password: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.2.1 | 序列化跳过 | password 不出现在 JSON 中 |
| T5.2.2 | 反序列化忽略 | JSON 中含 password 字段被忽略 |
| T5.2.3 | 类级别跳过 | `@CodableSkip["password", "secret"]` |

#### T5.3 @CodablePolicy

```cangjie
@Codable
class PolicyFields {
    var name: String = ""
    @CodablePolicy[NON_NULL]
    var email: ?String = None
    @CodablePolicy[NON_EMPTY]
    var tags: Array<String> = []
    @CodablePolicy[NON_DEFAULT]
    var status: Int64 = 0
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.3.1 | ALWAYS | 始终包含（默认） |
| T5.3.2 | NON_NULL | None 时省略 |
| T5.3.3 | NON_EMPTY | 空数组/空字符串时省略 |
| T5.3.4 | NON_DEFAULT | 等于默认值时省略 |

#### T5.4 @CodableOrder

```cangjie
@Codable
@CodableOrder["z", "a", "m"]
class OrderedFields {
    var z: String = ""
    var a: String = ""
    var m: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.4.1 | 指定顺序序列化 | JSON 字段顺序为 z, a, m |
| T5.4.2 | 未列出字段排末尾 | |

#### T5.5 @CodableAlias

```cangjie
@Codable
class AliasFields {
    @CodableKey["username"]
    @CodableAlias["user_name", "loginName"]
    var name: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.5.1 | 主名反序列化 | `"username"` → name |
| T5.5.2 | 别名反序列化 | `"user_name"` → name |
| T5.5.3 | 多别名 | `"loginName"` → name |
| T5.5.4 | 序列化只用主名 | 输出 `"username"` |

#### T5.6 @CodableFormat

```cangjie
@Codable
class FormatFields {
    @CodableFormat["yyyy-MM-dd"]
    var birthDate: DateTime = DateTime.now()
    @CodableFormat["0.00"]
    var price: Float64 = 0.0
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.6.1 | 日期格式化序列化 | → `"2026-07-30"` |
| T5.6.2 | 日期格式化反序列化 | `"2026-07-30"` → DateTime |
| T5.6.3 | 数字格式化 | `1234.5` → `"1234.50"` |
| T5.6.4 | 格式不匹配反序列化 | 报错 |

#### T5.7 @CodableVariant（多态）

```cangjie
@Codable
@CodableVariant[use: VariantUse.NAME, as: VariantAs.PROPERTY, property: "type", cases: "circle:Circle2,rectangle:Rectangle2"]
open class Shape2 {
    var name: String = ""
}

@Codable[withSuperClass = Shape2]
@CodableVariantCase["circle"]
class Circle2 <: Shape2 {
    var radius: Float64 = 0.0
}

@Codable[withSuperClass = Shape2]
@CodableVariantCase["rectangle"]
class Rectangle2 <: Shape2 {
    var width: Float64 = 0.0
    var height: Float64 = 0.0
}
```

```json
{"type":"circle","name":"C1","radius":5.0}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.7.1 | 子类序列化含类型字段 | `"type":"circle"` |
| T5.7.2 | 多态反序列化 | 根据 type 字段路由到 Circle2 |
| T5.7.3 | 未知类型反序列化 | `"type":"triangle"` 不在注册表中应报错 |
| T5.7.4 | 多态集合 | `Array<Shape2>` 含不同子类 |
| T5.7.5 | WRAPPER_ARRAY 模式 | `["circle", {"name":"C1","radius":5.0}]` |
| T5.7.6 | WRAPPER_OBJECT 模式 | `{"circle":{"name":"C1","radius":5.0}}` |

#### T5.8 @CodableUnwrap

```cangjie
@Codable
class Location {
    var city: String = ""
    var zipCode: String = ""
}

@Codable
class PersonWithLocation {
    var name: String = ""
    @CodableUnwrap
    var location: Location = Location()
}
```

```json
{"name":"张三","city":"北京","zipCode":"100080"}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.8.1 | 序列化扁平化 | location 字段展开到上层 |
| T5.8.2 | 反序列化合并 | 上层字段合并回 location |
| T5.8.3 | 字段名冲突 | 扁平化后字段名与上层冲突 |

#### T5.9 @CodableRaw

```cangjie
@Codable
class RawField {
    var name: String = ""
    @CodableRaw
    var extra: String = ""
}
```

```json
{"name":"test","extra":{"any":"json","goes":true}}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T5.9.1 | 原始 JSON 写入 | extra 字段直接写入原始 JSON 字符串 |
| T5.9.2 | 原始 JSON 读取 | extra 字段读取为原始 JSON 字符串 |

### 9.6 边界与异常场景测试（T6）

#### T6.1 null 值处理

```cangjie
@Codable
class NullContainer {
    var str: ?String = None
    var num: ?Int64 = None
    var obj: ?Inner = None
    var arr: ?Array<String> = None
    var map: ?HashMap<String, String> = None
}
```

```json
{"str":null,"num":null,"obj":null,"arr":null,"map":null}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T6.1.1 | 全 null 对象序列化 | 所有字段为 null |
| T6.1.2 | 全 null 对象反序列化 | JSON 全部 null → 所有字段为 None |
| T6.1.3 | null 嵌套在集合中 | `Array<Option<String>>` 含 null |
| T6.1.4 | null 在 Map value 中 | `HashMap<String, ?String>` 含 null value |
| T6.1.5 | 非空字段收到 null | 非 Option 字段反序列化收到 null → 报错或默认值 |

#### T6.2 空/缺失处理

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T6.2.1 | 空对象 `{}` | 反序列化为所有默认值 |
| T6.2.2 | 空数组 `[]` | 反序列化为空集合 |
| T6.2.3 | 空字符串 `""` | 反序列化为空字符串（非 null） |
| T6.2.4 | 字段缺失 | 非 Option 字段缺失 → 默认值或报错 |
| T6.2.5 | 空数组 vs null | `[]` 与 `null` 反序列化行为不同 |

#### T6.3 循环引用

```cangjie
@Codable
class TreeNode {
    var value: String = ""
    @CodableRef
    var children: Array<TreeNode> = []
    @CodableRef.Back
    var parent: ?TreeNode = None
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T6.3.1 | 无循环引用 | 树形结构正常序列化 |
| T6.3.2 | 循环引用检测 | A→B→A 循环引用序列化不无限递归 |
| T6.3.3 | 自引用 | A.children 包含 A 自身 |

#### T6.4 类型不匹配与异常

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T6.4.1 | 字符串反序列化为 Int | `"abc"` → Int64 字段应抛 JsonTypeException |
| T6.4.2 | 对象反序列化为数组 | `[1,2]` → 对象字段应抛 JsonTypeException |
| T6.4.3 | 数组反序列化为对象 | `{}` → 数组字段应抛 JsonTypeException |
| T6.4.4 | 必需字段缺失 | 抛 JsonMissingField |
| T6.4.5 | 数值溢出 | 超出类型范围的数值 → JsonOverflowException |
| T6.4.6 | 无效 JSON | `{invalid` 格式错误 → JsonReadException |
| T6.4.7 | 嵌套层级过深 | 100 层嵌套对象 |

#### T6.5 特殊字符串

```cangjie
@Codable
class SpecialStrings {
    var withNewline: String = ""
    var withTab: String = ""
    var withQuote: String = ""
    var withBackslash: String = ""
    var withUnicode: String = ""
    var withEmoji: String = ""
    var empty: String = ""
    var veryLong: String = ""
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T6.5.1 | 换行符 | `"line1\nline2"` → 正确转义 |
| T6.5.2 | Tab | `"a\tb"` → 正确转义 |
| T6.5.3 | 引号 | `"say \"hello\""` → 正确转义 |
| T6.5.4 | 反斜杠 | `"path\\to\\file"` → 正确转义 |
| T6.5.5 | Unicode | `"中文🎉"` → 正确序列化 |
| T6.5.6 | 空字符串 | `""` → `""` |
| T6.5.7 | 超长字符串 | 10000 字符 |

### 9.7 高级场景测试（T7）

#### T7.1 自定义 Encoder/Decoder

```cangjie
class DateEncoder <: Encoder<DateTime> {
    public func encode(value: DateTime, writer: JsonWriter): Unit {
        writer.value(value.format("yyyy-MM-dd"))
    }
}

class DateDecoder <: Decoder<DateTime> {
    public func decode(reader: JsonReader): DateTime {
        let str = reader.readString()
        return DateTime.parse(str, "yyyy-MM-dd")
    }
}
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T7.1.1 | 自定义编码器 | 注册后使用自定义编码逻辑 |
| T7.1.2 | 自定义解码器 | 注册后使用自定义解码逻辑 |
| T7.1.3 | 模块注册 | 通过 CodecModule 注册自定义编解码器 |

#### T7.2 命名策略

```cangjie
let codec = JsonCodec()
    .setNamingStrategy(SnakeCase())
```

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T7.2.1 | SnakeCase | `userName` → `"user_name"` |
| T7.2.2 | CamelCase | `user_name` → `"userName"` |
| T7.2.3 | PascalCase | `userName` → `"UserName"` |
| T7.2.4 | KebabCase | `userName` → `"user-name"` |

#### T7.3 树模型操作

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T7.3.1 | 字符串 → JsonTree | 构建树 |
| T7.3.2 | JsonTree → 字符串 | 序列化树 |
| T7.3.3 | 按路径查询 | `tree.get("users/0/name")` |
| T7.3.4 | 修改节点 | 树节点增删改 |
| T7.3.5 | JsonPointer 查询 | RFC 6901 路径查询 |

#### T7.4 CodecFeature 开关

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T7.4.1 | FAIL_ON_UNKNOWN_PROPERTIES | 未知字段报错 vs 忽略 |
| T7.4.2 | ACCEPT_SINGLE_VALUE_AS_ARRAY | 单值自动包装为数组 |
| T7.4.3 | WRITE_NULLS | 是否写出 null 值字段 |
| T7.4.4 | PRETTY_PRINT | 格式化输出 |
| T7.4.5 | FAIL_ON_NULL_FOR_PRIMITIVES | 非空字段收到 null 是否报错 |

#### T7.5 模块系统

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T7.5.1 | 注册模块 | `codec.registerModule(myModule)` |
| T7.5.2 | 模块覆盖默认编解码器 | 自定义类型优先使用模块注册的编解码器 |
| T7.5.3 | 多模块共存 | 不同模块注册不同类型 |

### 9.8 往返一致性测试（T8）

> 所有以上类型均需通过往返（round-trip）测试：`obj → JSON → obj2`，断言 `obj == obj2`

| 用例编号 | 场景 | 说明 |
|----------|------|------|
| T8.1 | 基础类型往返 | 所有 T1 类型 |
| T8.2 | 自定义类型往返 | 所有 T2/T3 类型 |
| T8.3 | 集合类型往返 | 所有 T4 类型 |
| T8.4 | 注解类型往返 | 所有 T5 类型 |
| T8.5 | 含 null/空值往返 | null 字段序列化后反序列化仍为 null |
| T8.6 | 嵌套对象往返 | 深层嵌套结构往返一致 |
| T8.7 | 泛型类型往返 | 泛型参数信息不丢失 |
| T8.8 | 多态类型往返 | 类型鉴别信息完整保留 |

### 9.9 性能基准测试（T9）

> **核心目标**：json4cj 的宏生成路径性能不得低于 Jackson 的反射路径。基准测试使用仓颉 `@Bench` 标注 + `cjpm bench` 运行，每个用例记录吞吐量（ops/ms）和 P99 延迟（μs）。
>
> 测试方法：对同一数据结构，分别运行序列化和反序列化各 N 次（N ≥ 10000），取平均值。大对象/大集合场景适当减少次数但不少于 1000 次。

#### T9.1 基础类型吞吐量

```cangjie
@Codable
class PrimitiveBean {
    var i8: Int8 = 0
    var i16: Int16 = 0
    var i32: Int32 = 0
    var i64: Int64 = 0
    var f64: Float64 = 0.0
    var flag: Bool = false
    var text: String = ""
}
```

| 用例编号 | 场景 | 基线（Jackson ops/ms） | json4cj 目标 | 说明 |
| ---------- | ------ | ---------------------- | ------------ | ---- |
| T9.1.1 | 基础类型序列化 | ~800 | ≥ 800 | 7 字段简单 POJO |
| T9.1.2 | 基础类型反序列化 | ~600 | ≥ 600 | 7 字段简单 POJO |
| T9.1.3 | 基础类型往返 | ~350 | ≥ 350 | serialize + deserialize |

#### T9.2 字符串密集型

```cangjie
@Codable
class StringBean {
    var s1: String = ""
    var s2: String = ""
    var s3: String = ""
    var s4: String = ""
    var s5: String = ""
    var s6: String = ""
    var s7: String = ""
    var s8: String = ""
}
```

| 用例编号 | 场景 | 基线 | json4cj 目标 | 说明 |
| ---------- | ------ | ---- | ------------ | ---- |
| T9.2.1 | 短字符串序列化 | ~700 | ≥ 700 | 8 个 10 字符以内字符串 |
| T9.2.2 | 长字符串序列化 | ~300 | ≥ 300 | 8 个 1000 字符字符串 |
| T9.2.3 | 含转义字符串 | ~400 | ≥ 400 | 含 \n\t\"\\ 等 |
| T9.2.4 | Unicode 字符串 | ~500 | ≥ 500 | 中文/Emoji |

#### T9.3 集合类型吞吐量

```cangjie
@Codable
class CollectionBean {
    var intArray: Array<Int64> = []
    var strArray: Array<String> = []
    var intMap: HashMap<String, Int64> = HashMap<String, Int64>()
    var strMap: HashMap<String, String> = HashMap<String, String>()
}
```

| 用例编号 | 场景 | 基线 | json4cj 目标 | 说明 |
| ---------- | ------ | ---- | ------------ | ---- |
| T9.3.1 | 小数组序列化（10 元素） | ~600 | ≥ 600 | Array<Int64> |
| T9.3.2 | 大数组序列化（1000 元素） | ~50 | ≥ 50 | Array<Int64> |
| T9.3.3 | 大数组反序列化（1000 元素） | ~35 | ≥ 35 | Array<Int64> |
| T9.3.4 | 小 Map 序列化（10 键值对） | ~500 | ≥ 500 | HashMap<String, Int64> |
| T9.3.5 | 大 Map 序列化（100 键值对） | ~80 | ≥ 80 | HashMap<String, Int64> |
| T9.3.6 | 大 Map 反序列化（100 键值对） | ~50 | ≥ 50 | HashMap<String, Int64> |
| T9.3.7 | 嵌套集合序列化 | ~200 | ≥ 200 | HashMap<String, Array<Int64>> |
| T9.3.8 | 嵌套集合反序列化 | ~150 | ≥ 150 | HashMap<String, Array<Int64>> |

#### T9.4 嵌套对象吞吐量

```cangjie
@Codable
class DeepNested {
    var level1: Level1 = Level1()
}

@Codable
class Level1 {
    var value: String = ""
    var level2: Level2 = Level2()
}

@Codable
class Level2 {
    var value: String = ""
    var level3: Level3 = Level3()
}

@Codable
class Level3 {
    var value: String = ""
    var count: Int64 = 0
}

@Codable
class WideNested {
    var f1: Int64 = 0
    var f2: String = ""
    var f3: Float64 = 0.0
    var f4: Bool = false
    var f5: String = ""
    var f6: Int64 = 0
    var f7: String = ""
    var f8: Float64 = 0.0
    var f9: Bool = false
    var f10: String = ""
    var f11: Int64 = 0
    var f12: String = ""
    var f13: Float64 = 0.0
    var f14: Bool = false
    var f15: String = ""
    var f16: Int64 = 0
    var f17: String = ""
    var f18: Float64 = 0.0
    var f19: Bool = false
    var f20: String = ""
}
```

| 用例编号 | 场景 | 基线 | json4cj 目标 | 说明 |
| ---------- | ------ | ---- | ------------ | ---- |
| T9.4.1 | 深层嵌套序列化（3 层） | ~400 | ≥ 400 | DeepNested |
| T9.4.2 | 深层嵌套反序列化（3 层） | ~300 | ≥ 300 | DeepNested |
| T9.4.3 | 宽对象序列化（20 字段） | ~500 | ≥ 500 | WideNested |
| T9.4.4 | 宽对象反序列化（20 字段） | ~350 | ≥ 350 | WideNested |
| T9.4.5 | 超宽对象序列化（50 字段） | ~200 | ≥ 200 | 50 个字段的 class |
| T9.4.6 | 超宽对象反序列化（50 字段） | ~130 | ≥ 130 | 50 个字段的 class |

#### T9.5 注解开销测试

> 验证各注解不影响核心序列化性能（注解的额外开销应 < 5%）

| 用例编号 | 场景 | 基线 | json4cj 目标 | 说明 |
| ---------- | ------ | ---- | ------------ | ---- |
| T9.5.1 | @CodableKey 字段名映射 | — | 与无注解差异 < 5% | 仅键名不同，不应有性能差异 |
| T9.5.2 | @CodableSkip 忽略字段 | — | 比全序列化更快 | 少写字段应更快 |
| T9.5.3 | @CodablePolicy[NON_NULL] | — | 与无注解差异 < 5% | Option 判断是内联的 |
| T9.5.4 | @CodableAlias 反序列化 | — | 与无别名差异 < 10% | 多分支 match 有少量开销 |
| T9.5.5 | @CodableFormat 格式化 | — | 允许慢于无格式（格式化本身有开销） | DateTime 格式化是主要开销 |
| T9.5.6 | @CodableUnwrap 扁平化 | — | 与嵌套序列化差异 < 5% | 展开不引入额外对象 |
| T9.5.7 | @CodableRaw 原始 JSON | — | 比普通字符串快 | 避免 JSON 转义 |

#### T9.6 流式 vs 树模型对比

> 验证流式 API 路径的性能优势

| 用例编号 | 场景 | 基线 | json4cj 目标 | 说明 |
| ---------- | ------ | ---- | ------------ | ---- |
| T9.6.1 | 流式写入 vs 树模型写入 | — | 流式 ≥ 树模型 1.5x | 流式无中间对象开销 |
| T9.6.2 | 流式读取 vs 树模型读取 | — | 流式 ≥ 树模型 1.5x | 流式无整棵树构建开销 |
| T9.6.3 | 大 JSON（1MB）流式写入 | ~10 | ≥ 10 | 1000 元素嵌套对象 |
| T9.6.4 | 大 JSON（1MB）流式读取 | ~5 | ≥ 5 | 1000 元素嵌套对象 |
| T9.6.5 | 大 JSON（1MB）树模型写入 | ~5 | ≥ 5 | 同上，但走树模型路径 |
| T9.6.6 | 大 JSON（1MB）树模型读取 | ~3 | ≥ 3 | 同上，但走树模型路径 |

#### T9.7 宏路径 vs 反射路径对比

> json4cj 的核心优势：宏生成代码零反射。此组测试验证该优势。

| 用例编号 | 场景 | 说明 |
| ---------- | ------ | ---- |
| T9.7.1 | @Codable 宏路径序列化 | 宏生成的 encode() 方法 |
| T9.7.2 | @Codable 宏路径反序列化 | 宏生成的 decode() 方法 |
| T9.7.3 | BeanEncoder 反射路径序列化 | 运行时反射读取 public 字段 |
| T9.7.4 | BeanDecoder 反射路径反序列化 | 运行时反射赋值 public 字段 |
| T9.7.5 | 宏路径 vs 反射路径倍率 | 目标：宏路径 ≥ 反射路径 3x（Jackson 反射路径 vs Afterburner 字节码生成的差距约 2-3x） |

#### T9.8 内存占用测试

> 验证序列化/反序列化过程中不引入不必要的堆分配

| 用例编号 | 场景 | 说明 |
| ---------- | ------ | ---- |
| T9.8.1 | 序列化 GC 压力 | 连续序列化 10000 次，GC 次数应在合理范围 |
| T9.8.2 | 反序列化 GC 压力 | 连续反序列化 10000 次，GC 次数应在合理范围 |
| T9.8.3 | 大对象内存峰值 | 序列化 1MB JSON 时的内存峰值不超过输入的 3x |
| T9.8.4 | ByteBuffer 复用 | 复用 ByteBuffer 后性能提升比例 |

#### T9.9 并发性能测试

> 验证多线程场景下的序列化/反序列化性能

| 用例编号 | 场景 | 说明 |
| ---------- | ------ | ---- |
| T9.9.1 | 单线程序列化吞吐 | 基线 |
| T9.9.2 | 4 线程序列化吞吐 | 目标：≥ 单线程 3x |
| T9.9.3 | 8 线程序列化吞吐 | 目标：≥ 单线程 5x |
| T9.9.4 | 并发反序列化无竞态 | 多线程同时 parse，结果正确无数据竞争 |
| T9.9.5 | CodecRegistry 并发注册 | 多线程同时注册 Encoder/Decoder 不死锁 |

#### T9.10 性能回归基线建立

| 用例编号 | 场景 | 说明 |
| ---------- | ------ | ---- |
| T9.10.1 | 记录 P0 完成后的性能基线 | 作为后续版本对比参照 |
| T9.10.2 | 记录 P1 完成后的性能基线 | 对比 P0，下降不超过 10% |
| T9.10.3 | 记录 P2 完成后的性能基线 | 对比 P1，下降不超过 10% |
| T9.10.4 | 记录 P3 完成后的性能基线 | 对比 P2，下降不超过 10% |

---

## 十一、验收标准

### 项目整体目录结构（基础验收项）

项目由三个独立组件构成，每个组件拥有独立的 `cjpm.toml`，可独立编译、测试、提交：

```text
json4cj/
├── README.md                        # 项目总说明
├── execution-plan.md                 # 执行计划
├── todolist.md                       # 任务清单
│
├── json4cj-core/                     # ① 流式读写引擎
│   ├── cjpm.toml                     #   独立构建配置（无外部依赖，仅 stdx）
│   ├── README.md
│   ├── src/
│   │   ├── stream/                   #   JsonWriter/JsonReader/JsonToken/JsonStreamFactory/JsonStreamContext
│   │   ├── tree/                     #   JsonTree/JsonTreeKind/JsonTreeBuilder/JsonTreeWalker
│   │   ├── codec/                    #   Encoder<T>/Decoder<T>/BuiltinEncoders/BuiltinDecoders
│   │   ├── extend/                   #   JsonValueExtend/JsonKindExtend
│   │   ├── exc/                      #   6 个异常类
│   │   ├── cfg/                      #   CodecConfig/ReadFeature/WriteFeature/PrettyPrinter
│   │   ├── util/                     #   Base64/JsonPointer/CharEscapes
│   │   └── package.cj
│   └── test/
│       ├── stream/
│       ├── tree/
│       ├── codec/
│       └── extend/
│
├── json4cj-annotations/              # ② 注解 + 宏引擎
│   ├── cjpm.toml                     #   独立构建配置（依赖 json4cj-core）
│   ├── README.md
│   ├── src/
│   │   ├── anno/                     #   @Codable/@CodableKey/@CodableSkip 等 20+ 注解
│   │   ├── enum/                     #   PolicyMode/AccessMode/VariantUse 等枚举
│   │   ├── macro/                    #   CodableMacro/MacroContext/FieldMeta/CodeEmitter 等
│   │   └── package.cj
│   └── test/
│       ├── anno/
│       ├── macro/
│       └── integration/
│
└── json4cj-databind/                 # ③ 高级数据绑定
    ├── cjpm.toml                     #   独立构建配置（依赖 core + annotations）
    ├── README.md
    ├── src/
    │   ├── bind/                     #   JsonCodec/CodecReader/CodecWriter/CodecRegistry
    │   ├── ser/                      #   BeanEncoder/StdEncoders/EncoderFactory
    │   ├── deser/                    #   BeanDecoder/StdDecoders/DecoderFactory
    │   ├── type/                     #   TypeSpec/TypeFactory/TypeReference
    │   ├── node/                     #   JsonNode/NodeFactory/NodeCursor/NodePatch
    │   ├── module/                   #   CodecModule/SimpleModule/ModuleRegistry
    │   ├── naming/                   #   NamingStrategy/SnakeCase/CamelCase/PascalCase/KebabCase
    │   ├── filter/                   #   CodecFilter/SimpleFilter
    │   ├── view/                     #   CodecView
    │   ├── exc/                      #   CodecException/BindException/InvalidFormat
    │   └── package.cj
    └── test/
        ├── bind/
        ├── ser/
        ├── deser/
        ├── node/
        ├── module/
        ├── naming/
        └── integration/
```

- [ ] 项目根目录包含 `json4cj-core/`、`json4cj-annotations/`、`json4cj-databind/` 三个独立组件目录
- [ ] 每个组件拥有独立的 `cjpm.toml`，可独立执行 `cjpm build` 和 `cjpm test`
- [ ] `json4cj-core` 无外部依赖（仅仓颉标准库 + stdx）
- [ ] `json4cj-annotations` 的 `cjpm.toml` 声明依赖 `json4cj-core`
- [ ] `json4cj-databind` 的 `cjpm.toml` 声明依赖 `json4cj-core` + `json4cj-annotations`
- [ ] 各组件 `src/` 下子目录与上述结构一致，`.cj` 文件名与设计文档匹配

### P0（阶段一~三完成后）
- [ ] `json4cj-core`：`JsonWriter`/`JsonReader` 流式读写正常工作
- [ ] `json4cj-core`：基础类型（Int/Float/String/Bool/Array/HashMap/Option）编解码正确
- [ ] `json4cj-annotations`：`@Codable` + `@CodableKey` + `@CodableSkip` + `@CodablePolicy` + `@CodableOrder` 5 个核心注解正常工作
- [ ] `json4cj-databind`：`JsonCodec.stringify/parse` 能正确序列化/反序列化标注了 `@Codable` 的 class/struct
- [ ] 无注解类能通过反射兜底序列化
- [ ] 继承（open class）场景正常工作
- [ ] 泛型 class 场景正常工作

### P1（阶段四完成后）
- [ ] 枚举序列化（`@CodableEnum`）正常工作
- [ ] 日期/数字格式化（`@CodableFormat`）正常工作
- [ ] 反序列化别名（`@CodableAlias`）正常工作
- [ ] 指定构造方法（`@CodableCreator`）正常工作
- [ ] 忽略类型/多个字段正常工作
- [ ] 树模型 `JsonTree` API 完整可用
- [ ] 命名策略可配置

### P2（阶段五完成后）
- [ ] 多态序列化（`@CodableVariant`）正常工作
- [ ] 扁平化内嵌（`@CodableUnwrap`）正常工作
- [ ] 原始 JSON 写入（`@CodableRaw`）正常工作
- [ ] 动态属性（`@CodableAnyKey/AnyValue`）正常工作
- [ ] 模块系统可扩展

### P3（阶段六完成后）
- [ ] 视图过滤（`@CodableView`）正常工作
- [ ] 循环引用（`@CodableRef`）正常工作
- [ ] 值注入（`@CodableInject`）正常工作
- [ ] 完整文档和示例

### 性能验收（各阶段持续）

- [ ] **宏路径 vs 反射路径**：`@Codable` 宏生成的 encode/decode 吞吐量 ≥ BeanEncoder/BeanDecoder 反射路径 3 倍
- [ ] **流式 vs 树模型**：流式 API（JsonWriter/JsonReader）吞吐量 ≥ 树模型 API（toJsonValue/fromJsonValue）1.5 倍
- [ ] **基础类型序列化**：7 字段简单 POJO 序列化吞吐量 ≥ 800 ops/ms（同环境对标 Jackson）
- [ ] **基础类型反序列化**：7 字段简单 POJO 反序列化吞吐量 ≥ 600 ops/ms
- [ ] **注解开销**：各注解（@CodableKey/@CodableSkip/@CodablePolicy）相比无注解性能差异 < 5%
- [ ] **性能无回归**：每个 P 阶段完成后基准测试对比前一版本，吞吐量下降不超过 10%
- [ ] **并发安全**：多线程序列化/反序列化无数据竞争，4 线程吞吐量 ≥ 单线程 3 倍
- [ ] **内存可控**：序列化 1MB JSON 内存峰值不超过输入 3x，连续 10000 次操作 GC 压力在合理范围

---

## 十二、代码提交规范

### 12.1 远程仓库

- **SSH**：`git@gitcode.com:mufengzi/json4cj.git`
- **HTTPS**：`https://gitcode.com/mufengzi/json4cj`

### 12.2 提交原则

1. **编译通过方可提交**：每次 `git commit` 前，必须确保代码通过 `cjpm build` 编译，严禁提交编译失败的代码
2. **UT 用例跑通方可提交**：包含单元测试的代码，必须确保 `cjpm test` 全部通过后才可提交，严禁提交测试用例未通过的代码
3. **渐进式提交**：每完成一部分功能即可提交，无需等待完整能力具备后再提交。例如：
   - 完成异常体系中 2 个异常类 → 编译通过 → 提交
   - 完成 `JsonToken` 枚举 + 对应测试 → 编译通过 + 测试通过 → 提交
   - 完成 `JsonWriter` 基础写入功能 → 编译通过 → 提交
4. **提交粒度建议**：以功能模块或单个任务为单位，避免单次提交包含过多变更

### 12.3 提交流程

```bash
# 1. 编译检查
cjpm build

# 2. 运行测试（如有测试代码）
cjpm test

# 3. 暂存变更
git add <相关文件>

# 4. 提交（提交信息遵循规范）
git commit -m "<type>: <描述>"

# 5. 推送到远程
git push origin main
```

### 12.4 提交信息规范

格式：`<type>: <描述>`

| type | 说明 | 示例 |
|------|------|------|
| feat | 新功能 | `feat: 实现 JsonWriter 流式写入` |
| fix | 修复缺陷 | `fix: 修复 JsonReader 空值读取异常` |
| test | 新增/修改测试 | `test: 添加 JsonToken 枚举单元测试` |
| refactor | 重构（不改变功能） | `refactor: 重构异常体系继承关系` |
| docs | 文档变更 | `docs: 更新 README 使用说明` |
| chore | 构建/工具变更 | `chore: 配置 cjpm.toml 依赖` |

### 12.5 各阶段提交检查点

以下为每个实施阶段建议的提交节点，每节点需满足编译通过 + 测试通过：

#### 阶段一（json4cj-core）

- [ ] 项目骨架 + `cjpm.toml` → 编译通过 → 提交
- [ ] 异常体系（`exc/`）→ 编译通过 → 提交
- [ ] `JsonToken` 枚举 + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `JsonWriter` 流式写入 + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `JsonReader` 流式读取 + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `JsonStreamFactory` + `JsonStreamContext` → 编译通过 → 提交
- [ ] `JsonValue`/`JsonKind` 扩展 + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `Encoder<T>`/`Decoder<T>` 接口 + 内置编解码器 + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `CodecConfig` + `Feature` + `PrettyPrinter` + 测试 → 编译通过 + 测试通过 → 提交

#### 阶段二（json4cj-annotations）

- [ ] 项目骨架 + 枚举类型 → 编译通过 → 提交
- [ ] P0 注解（`@Codable`, `@CodableKey`, `@CodableSkip`, `@CodablePolicy`, `@CodableOrder`）→ 编译通过 → 提交
- [ ] `MacroContext` + `FieldMeta`/`TypeMeta` → 编译通过 → 提交
- [ ] `FieldCollector` + `CodeEmitter` → 编译通过 → 提交
- [ ] `ClassProcessor` + `StructProcessor` → 编译通过 → 提交
- [ ] `SerializeEmitter` + `DeserializeEmitter` + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `RegistryEmitter` + `@Codable` 主宏入口 + 测试 → 编译通过 + 测试通过 → 提交

#### 阶段三（json4cj-databind）

- [ ] 项目骨架 + `CodecRegistry` → 编译通过 → 提交
- [ ] `JsonCodec` 主入口 + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `CodecConfig` + `CodecReader/CodecWriter` → 编译通过 → 提交
- [ ] `TypeSpec` + `TypeFactory` + `BeanEncoder/BeanDecoder` + 测试 → 编译通过 + 测试通过 → 提交
- [ ] `NamingStrategy` + `CodecModule` + 树模型 + 测试 → 编译通过 + 测试通过 → 提交

#### 阶段四~六（P1/P2/P3 功能）

- 每完成一个功能点（如 `@CodableEnum`、`@CodableFormat` 等），编译通过 + 测试通过后即可提交

---

## 十三、总结

json4cj 项目采用 **"宏为主、反射为辅、流式优先"** 的架构策略，将 Jackson 在运行时用反射做的事前移到编译期用宏完成，在获得零反射开销的同时实现了完整的 Jackson 功能对标。三组件分层的架构（core → annotations → databind）确保了关注点分离和渐进式使用。

相比已有的 cangjieJSON 实现，json4cj 在以下方面有本质提升：
1. **流式 API**（性能量级提升，支持大 JSON 场景）
2. **注解丰富度**（5 → 20+，覆盖 Jackson 几乎所有注解）
3. **扩展机制**（Encoder/Decoder 接口 + Module 系统）
4. **高级特性**（多态、视图、循环引用、命名策略等）
5. **独立身份**（全新的命名规范和代码架构，非 Jackson 翻译版）
