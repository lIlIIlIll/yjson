# json4cj 任务清单

> 基于 [execution-plan.md](execution-plan.md) 生成，任务完成后将 `[ ]` 改为 `[x]` 并刷新状态。

---

## 状态说明

| 标记 | 含义 |
|------|------|
| `[ ]` | 未开始 |
| `[~]` | 进行中 |
| `[x]` | 已完成 |

---

## 项目整体目录结构验收

- [x] D.1 项目根目录包含 `json4cj-core/`、`json4cj-annotations/`、`json4cj-databind/` 三个独立组件目录
- [x] D.2 每个组件拥有独立的 `cjpm.toml`，可独立执行 `cjpm build` 和 `cjpm test`
- [x] D.3 `json4cj-core` 无外部依赖（仅仓颉标准库 + stdx）
- [x] D.4 `json4cj-annotations` 的 `cjpm.toml` 声明依赖 `json4cj-core`
- [x] D.5 `json4cj-databind` 的 `cjpm.toml` 声明依赖 `json4cj-core` + `json4cj-annotations`
- [x] D.6 各组件 `src/` 下子目录与设计文档一致，`.cj` 文件名与设计文档匹配

---

## 阶段一：基础设施（json4cj-core 核心）— 已完成 ✅

### 1.1 创建项目骨架

- [x] 1.1.1 创建 `json4cj-core/` 目录及 `cjpm.toml`
- [x] 1.1.2 创建 `src/` 下子目录：`stream/`、`tree/`、`codec/`、`ext/`、`exc/`、`cfg/`、`util/`
- [x] 1.1.3 创建 `test/` 下子目录：`stream/`、`tree/`、`codec/`、`ext/`
- [x] 1.1.4 创建 `src/package.cj` 包声明与导出
- [x] 1.1.5 **提交检查点**：编译通过 → `git commit`

### 1.2 实现异常体系

- [x] 1.2.1 实现 `exc/JsonException.cj` — 基础异常
- [x] 1.2.2 实现 `exc/JsonReadException.cj` — 读取异常
- [x] 1.2.3 实现 `exc/JsonWriteException.cj` — 写入异常
- [x] 1.2.4 实现 `exc/JsonTypeException.cj` — 类型不匹配
- [x] 1.2.5 实现 `exc/JsonMissingField.cj` — 字段缺失
- [x] 1.2.6 实现 `exc/JsonOverflowException.cj` — 数值溢出
- [x] 1.2.7 **提交检查点**：编译通过 → `git commit`

### 1.3 实现 JsonToken 枚举

- [x] 1.3.1 实现 `stream/JsonToken.cj` — 令牌类型枚举
- [x] 1.3.2 编写 `test/stream/JsonToken_test.cj` 单元测试
- [x] 1.3.3 **提交检查点**：编译通过 + 测试通过 → `git commit`

### 1.4 实现 JsonWriter 流式写入

- [x] 1.4.1 实现 `stream/JsonWriter.cj` — 基于 `stdx.encoding.json.stream` 封装
- [x] 1.4.2 编写 `test/stream/JsonWriter_test.cj` 单元测试
- [x] 1.4.3 **提交检查点**：编译通过 + 测试通过 → `git commit`

### 1.5 实现 JsonReader 流式读取

- [x] 1.5.1 实现 `stream/JsonReader.cj` — 基于 `stdx.encoding.json.stream` 封装
- [x] 1.5.2 编写 `test/stream/JsonReader_test.cj` 单元测试
- [x] 1.5.3 **提交检查点**：编译通过 + 测试通过 → `git commit`

### 1.6 实现 JsonStreamFactory

- [x] 1.6.1 实现 `stream/JsonStreamFactory.cj` — 流式工厂方法
- [x] 1.6.2 编写 `test/stream/JsonStreamFactory_test.cj` 单元测试

### 1.7 实现 JsonStreamContext

- [x] 1.7.1 实现 `stream/JsonStreamContext.cj` — 读写位置追踪
- [x] 1.7.2 编写 `test/stream/JsonStreamContext_test.cj` 单元测试
- [x] 1.7.3 **提交检查点**：1.6 + 1.7 编译通过 → `git commit`

### 1.8 实现 JsonValue/JsonKind 扩展

- [x] 1.8.1 实现 `ext/JsonValueExtend.cj` — JsonValue 便捷扩展
- [x] 1.8.2 实现 `ext/JsonKindExtend.cj` — JsonKind 便捷扩展
- [x] 1.8.3 编写 `test/ext/JsonValueExtend_test.cj` 单元测试
- [x] 1.8.4 编写 `test/ext/JsonKindExtend_test.cj` 单元测试
- [x] 1.8.5 **提交检查点**：编译通过 + 测试通过 → `git commit`

### 1.9 实现 Encoder\<T\>/Decoder\<T\> 接口

- [x] 1.9.1 实现 `codec/Encoder.cj` — 编码器接口 `Encoder<T>`
- [x] 1.9.2 实现 `codec/Decoder.cj` — 解码器接口 `Decoder<T>`

### 1.10 实现内置编解码器

- [x] 1.10.1 实现 `codec/BuiltinEncoders.cj` — 内置编码器
- [x] 1.10.2 实现 `codec/BuiltinDecoders.cj` — 内置解码器
- [x] 1.10.3 编写 `test/codec/BuiltinEncoders_test.cj` 单元测试
- [x] 1.10.4 编写 `test/codec/BuiltinDecoders_test.cj` 单元测试
- [x] 1.10.5 **提交检查点**：1.9 + 1.10 编译通过 + 测试通过 → `git commit`

### 1.11 实现 CodecConfig + Feature 枚举

- [x] 1.11.1 实现 `cfg/CodecConfig.cj` — 全局编解码配置
- [x] 1.11.2 实现 `cfg/ReadFeature.cj` — 读取特性开关枚举
- [x] 1.11.3 实现 `cfg/WriteFeature.cj` — 写入特性开关枚举

### 1.12 实现 PrettyPrinter

- [x] 1.12.1 实现 `stream/PrettyPrinter.cj` — 格式化输出（由 `cfg/` 迁移至 `stream/` 包）
- [x] 1.12.2 编写 `test/cfg/PrettyPrinter_test.cj` 单元测试
- [x] 1.12.3 **提交检查点**：1.11 + 1.12 编译通过 + 测试通过 → `git commit`

### 1.13 实现 IJsonAdapter 扩展

- [x] 1.13.1 实现 `ext/IJsonAdapter.cj` — IJsonAdapter 接口 + Int64/Float64/String/Bool/Array/Option/HashMap 扩展

### 阶段一验收

- [x] `JsonWriter`/`JsonReader` 流式读写正常工作
- [x] 基础类型编解码正确
- [x] 异常体系完整，层次化报错
- [x] 所有 `cjpm test` 通过（已验证：core 118、databind 31 全部通过）

---

## 阶段二：注解与宏引擎（json4cj-annotations 核心）— 已完成 ✅

### 2.1 创建项目骨架

- [x] 2.1.1 创建 `json4cj-annotations/` 目录及 `cjpm.toml`（依赖 `json4cj-core`）
- [x] 2.1.2 创建 `src/` 下子目录：`anno/`、`enums/`、`macros/`
- [x] 2.1.3 创建 `test/` 下子目录：`anno/`、`macros/`、`integration/`
- [x] 2.1.4 创建 `src/package.cj` 包声明与导出

### 2.2 实现枚举类型

- [x] 2.2.1 实现 `enums/PolicyMode.cj` — ALWAYS / NON_NULL / NON_EMPTY / NON_DEFAULT
- [x] 2.2.2 实现 `enums/AccessMode.cj` — READ_WRITE / READ_ONLY / WRITE_ONLY
- [x] 2.2.3 实现 `enums/VariantUse.cj` — NAME / TYPE / NONE
- [x] 2.2.4 实现 `enums/VariantAs.cj` — PROPERTY / WRAPPER / ARRAY
- [x] 2.2.5 实现 `enums/EnumNaming.cj` — 枚举命名策略
- [x] 2.2.6 实现 `enums/NullHandling.cj` — null 处理策略
- [x] 2.2.7 实现 `enums/NumberFormat.cj` — 数字格式
- [x] 2.2.8 **提交检查点**：编译通过 → `git commit`

### 2.3 实现 P0+ 注解

- [x] 2.3.1 实现 `anno/Codable.cj` — `@Codable` 主注解
- [x] 2.3.2 实现 `anno/CodableKey.cj` — `@CodableKey` 字段名映射
- [x] 2.3.3 实现 `anno/CodableSkip.cj` — `@CodableSkip` 忽略字段
- [x] 2.3.4 实现 `anno/CodablePolicy.cj` — `@CodablePolicy` 包含策略
- [x] 2.3.5 实现 `anno/CodableOrder.cj` — `@CodableOrder` 字段排序
- [x] 2.3.6 实现 P1 注解：CodableFormat, CodableAlias, CodableCreator, CodableSkipType
- [x] 2.3.7 实现 P2 注解：CodableVariant, CodableUnwrap, CodableRaw, CodableAnyKey/AnyValue, CodableRoot
- [x] 2.3.8 实现 P3 注解：CodableView, CodableRef, CodableInject, CodableFilter, CodableMerge, CodableMeta, CodableEnum, CodableDefault
- [x] 2.3.9 **提交检查点**：编译通过 → `git commit`

### 2.4 实现宏引擎（参考 cangjieJSON 代码实现）

- [x] 2.4.1 实现 `macros/CodableMacro.cj` — @Codable 主宏入口（属性宏 + 无属性宏）
- [x] 2.4.2 实现 `macros/HandleClass.cj` — class 类型处理器（生成 toJsonValue/fromJsonValue/encode/decode）
- [x] 2.4.3 实现 `macros/HandleStruct.cj` — struct 类型处理器
- [x] 2.4.4 实现 `macros/HandleEnum.cj` — enum 类型处理器（名称/序号序列化）
- [x] 2.4.5 实现 `macros/MacroInfo.cj` — 基于 setItem/getChildMessages 的嵌套宏通信
- [x] 2.4.6 实现 `macros/utils.cj` — 类型判断辅助函数
- [x] 2.4.7 实现 `macros/Diagnostic.cj` — 编译期诊断（封装 diagReport）
- [x] 2.4.8 实现内层字段宏：@CodableKey, @CodableSkip, @CodableDefault, @CodablePolicy
- [x] 2.4.9 **提交检查点**：编译通过 → `git commit`

### 2.5 编写注解+宏测试

- [x] 2.5.1 编写 `test/anno/` 下各注解功能测试（Enums_test.cj 7/7）
- [~] 2.5.2 编写 `test/macros/` 下宏展开测试（由 databind macros_test 全量覆盖）
- [~] 2.5.3 编写 `test/integration/` 下集成测试（由 databind macros_test 全量覆盖）

### 阶段二验收

- [x] `@Codable` + 内层注解宏框架完成
- [x] 宏引擎基于 cangjieJSON 模式实现（macro package + std.ast + quote）
- [x] 支持 class/struct/enum 三种声明类型
- [x] 支持继承（withSuperClass）和泛型（withGenericType）
- [x] 所有 `cjpm test` 通过（已验证：core 118、databind 31 全部通过）

---

## 阶段三：数据绑定（json4cj-databind 核心）— 已完成 ✅

### 3.1 创建项目骨架

- [x] 3.1.1 创建 `json4cj-databind/` 目录及 `cjpm.toml`（依赖 `json4cj-core` + `json4cj-annotations`）
- [x] 3.1.2 创建 `src/` 下子目录：`bind/`、`ser/`、`deser/`、`types/`、`node/`、`module/`、`naming/`、`filter/`、`view/`、`exc/`
- [x] 3.1.3 创建 `src/package.cj` 包声明与导出

### 3.2 实现 bind 子包

- [x] 3.2.1 实现 `bind/JsonCodec.cj` — 主入口（stringify/parse/write/read/writeTree/readTree）
- [x] 3.2.2 实现 `bind/CodecRegistry.cj` — 编解码器注册与查找
- [x] 3.2.3 实现 `bind/CodecReader.cj` — 预配置的读取器
- [x] 3.2.4 实现 `bind/CodecWriter.cj` — 预配置的写入器
- [x] 3.2.5 实现 `bind/CodecConfig.cj` — 全局配置 + Feature 开关

### 3.3 实现 ser 子包

- [x] 3.3.1 实现 `ser/BeanEncoder.cj` — Bean 编码器（运行时反射兜底）
- [x] 3.3.2 实现 `ser/StdEncoders.cj` — 标准编码器集合
- [x] 3.3.3 实现 `ser/EncoderFactory.cj` — 编码器工厂
- [x] 3.3.4 实现 `ser/ContextualEncoder.cj` — 上下文感知编码器

### 3.4 实现 deser 子包

- [x] 3.4.1 实现 `deser/BeanDecoder.cj` — Bean 解码器（运行时反射兜底）
- [x] 3.4.2 实现 `deser/StdDecoders.cj` — 标准解码器集合
- [x] 3.4.3 实现 `deser/DecoderFactory.cj` — 解码器工厂
- [x] 3.4.4 实现 `deser/ContextualDecoder.cj` — 上下文感知解码器

### 3.5 实现 type 子包

- [x] 3.5.1 实现 `types/TypeSpec.cj` — 类型规格
- [x] 3.5.2 实现 `types/TypeFactory.cj` — 类型工厂
- [x] 3.5.3 实现 `types/TypeReference.cj` — 泛型类型引用

### 3.6 实现 node 子包

- [x] 3.6.1 实现 `node/JsonNode.cj` — 增强版树节点
- [x] 3.6.2 实现 `node/NodeFactory.cj` — 节点工厂
- [x] 3.6.3 实现 `node/NodeCursor.cj` — 节点遍历游标
- [x] 3.6.4 实现 `node/NodePatch.cj` — JSON Patch (RFC 6902)

### 3.7 实现 module 子包

- [x] 3.7.1 实现 `bind/CodecModule.cj` — 模块接口（由 `module/` 迁移至 `bind/` 包）
- [x] 3.7.2 实现 `module/SimpleModule.cj` — 简单模块实现
- [x] 3.7.3 实现 `module/ModuleRegistry.cj` — 模块注册表

### 3.8 实现 naming 子包

- [x] 3.8.1 实现 `naming/NamingStrategy.cj` — 命名策略接口
- [x] 3.8.2 实现 `naming/SnakeCase.cj` — snake_case
- [x] 3.8.3 实现 `naming/CamelCase.cj` — camelCase
- [x] 3.8.4 实现 `naming/PascalCase.cj` — PascalCase
- [x] 3.8.5 实现 `naming/KebabCase.cj` — kebab-case

### 3.9 实现 filter/view/exc 子包

- [x] 3.9.1 实现 `filter/CodecFilter.cj` — 过滤器接口
- [x] 3.9.2 实现 `filter/SimpleFilter.cj` — 简单过滤器
- [x] 3.9.3 实现 `view/CodecView.cj` — 视图定义与解析
- [x] 3.9.4 实现 `exc/CodecException.cj` — 编解码异常 + BindException + InvalidFormat

### 3.10 编写 databind 测试

- [x] 3.10.1 编写 `test/bind/` 下 JsonCodec 全流程测试（JsonCodec_test.cj 6/6）
- [x] 3.10.2 编写 `test/module/` 下模块系统测试（ModuleRegistry_test.cj）
- [x] 3.10.3 编写 `test/naming/` 下命名策略测试（NamingStrategy_test.cj）
- [x] 3.10.4 编写 `test/node/` 下树模型测试（NodeModel_test.cj 4/4）
- [~] 3.10.5 编写 `test/integration/` 下跨组件集成测试（由 databind macros_test 全量覆盖）

### 阶段三验收

- [x] JsonCodec、CodecRegistry、CodecReader/CodecWriter 框架完成
- [x] BeanEncoder/BeanDecoder 反射兜底框架完成
- [x] TypeSpec/TypeFactory/TypeReference 类型系统完成
- [x] JsonNode/NodeFactory 树模型完成
- [x] 模块系统、命名策略、过滤器、视图完成
- [x] bind 层 `CodecConfig` 与 core 层同名冲突已解决（selective import alias `CodecConfig as CoreCodecConfig`）；bind 流式 API 改用 `stdx.encoding.json.stream.*`（JsonSerializable/JsonDeserializable/JsonReader/JsonWriter/WriteConfig）
- [x] `SimpleFilter` 白名单/黑名单过滤已实现；`TypeSpec.optional()` 工厂已补齐；`ReadFeature.ALLOW_COMMENTS` 已新增
- [x] 所有 `cjpm test` 通过（已验证：core 118、databind 31 全部通过）

---

## 阶段四：P1 功能补齐 — 代码完成 ✅（测试待编写）

### 4.1 完善枚举序列化

- [x] 4.1.1 `anno/CodableEnum.cj` 注解已创建
- [x] 4.1.2 `macros/HandleEnum.cj` 枚举处理器已实现（名称/序号模式）
- [x] 4.1.3 编写枚举序列化测试 — 名称/序号/默认值/流式冒烟测试（5 项已通过）
- [x] 4.1.4 修复 HandleEnum 代码生成缺陷 — name()/ordinal() 不存在改用 match(this)；序号 case 整型插值；名称 case 引号；@CodableEnum 内层配置宏（assertParentContext + ord + 始终设置两键）

### 4.2 完善 @CodableFormat

- [x] 4.2.1 `anno/CodableFormat.cj` 注解已创建
- [x] 4.2.2 编写日期/数字格式化测试 — DateTime 格式化已实现（树+流双路径，直接字段 + Option<DateTime>，class + struct），由 T5.6 覆盖（6 项）。数字格式化受仓颉无 printf / Float64.toString 有损制约推迟

### 4.3 完善 @CodableAlias

- [x] 4.3.1 `anno/CodableAlias.cj` 注解已创建
- [x] 4.3.2 编写别名测试 — 已由 T5.5 覆盖（4 项：主键序列化 + 主键/第一/第二别名反序列化回退）

### 4.4 完善 @CodableCreator

- [x] 4.4.1 `anno/CodableCreator.cj` 注解已创建
- [x] 4.4.2 编写构造方法指定测试 — T5.12（9 用例：Point/Mixed/Key/PointStruct/Opt 树+流往返、缺失必需参数 JsonMissingField、@CodableKey 映射 ctor 参数、Option ctor 参数）。宏实现：`CodableMacro.CodableCreator` 内层宏 + HandleClass/HandleStruct 树 fromJsonValue creator codegen + fromJsonValueInherit 跳过 + 流 decode 委托 fromJsonValue(readJsonValue)

### 4.5 完善 ReadFeature/WriteFeature

- [x] 4.5.1 `cfg/ReadFeature.cj` 和 `cfg/WriteFeature.cj` 已创建
- [x] 4.5.2 实现各 Feature 开关的实际逻辑（JsonWriter/JsonReader 中已实现）

### 4.6 完善 JsonTree 树模型

- [x] 4.6.1 `tree/JsonTree.cj`、`tree/JsonTreeKind.cj`、`tree/JsonTreeBuilder.cj`、`tree/JsonTreeWalker.cj` 已创建
- [x] 4.6.2 完善 JsonTree 接口实现（DefaultJsonTree 完整实现）

### 4.7 编写 P1 功能测试

- [x] 4.7.1 编写忽略类型/多字段测试 — 已由 T5.13 覆盖（9 项）。补全两项源码：@CodableSkipType（对标 Jackson @JsonIgnoreType，经 IJsonAdapter 静态默认 jsonIgnoredType()=false 通用守卫，直对象字段树/流编解码均跳过，流式解码 else reader.skip() 消费值）；类级 @CodableSkip["a","b"] 多字段忽略（2 参属性宏 + collectFields 按 identifier 匹配，未匹配报编译错）。class+struct 双路径往返通过。
- [x] 4.7.2 编写 ReadFeature/WriteFeature 测试 — 已由 T7.4 覆盖（5 项：PRETTY_PRINT 端到端行为级 + 4 项开关存取；FAIL_ON_UNKNOWN_PROPERTIES 等行为级生效待宏集成）
- [x] 4.7.3 编写 JsonTree 树模型测试 — 已由 T7.3 覆盖（t7_3_1~t7_3_4：stringToTree/treeToString/pathQuery/modifyNode）
- [x] 4.7.4 编写 JsonPointer 测试 — 已由 T7.3 覆盖（t7_3_5：路径查询 + ~1/~0 转义）

### 4.8 完善 @CodableVariant（WRAPPER 模式）

- [x] 4.8.1 修复 WRAPPER_OBJECT/WRAPPER_ARRAY 代码生成缺陷 — 父类 toJsonValue/encode 的 WRAPPER 分支变量名 innerObj→jsonObj（与字段写入代码一致）；WRAPPER 分支补 openMod 使子类可重写；子类无 variantConfig 无法包装，新增父类 variantAsMode() 静态方法 + 子类 toJsonValue 运行期包装尾部（wrapJsonValueTail）
- [x] 4.8.2 编写 WRAPPER_OBJECT/WRAPPER_ARRAY 树模型往返冒烟测试（4 项已通过）
- [x] 4.8.3 流式路径多态/继承支持 — 流式 encode/decode 对 withSuperClass/variantConfig/caseData 桥接树路径 toJsonValue/fromJsonValue（真流式 decodeInherit 不可行：顺序读 match 循环无法跨继承层级共享 reader；同 @CodableCreator 桥接策略，热点类不走此分支）。PROPERTY/WRAPPER_OBJECT/WRAPPER_ARRAY 流式分发往返 + 非多态继承流式往返经 T5.14（8 项）验证

---

## 阶段五：P2 高级特性 — 代码完成 ✅（测试待编写）

- [x] 5.1 完善多态序列化（@CodableVariant + VariantEmitter + VariantRegistry）
- [x] 5.2 完善子类型声明（@CodableVariantCase 嵌套宏）
- [x] 5.3 完善 @CodableUnwrap 扁平化内嵌（Phase 4 已实现）
- [x] 5.4 完善 @CodableRaw 原始 JSON 写入（Phase 4 已实现）
- [x] 5.5 完善 @CodableAnyKey/AnyValue 动态属性
- [x] 5.6 完善 @CodableRoot 根名称包装
- [x] 5.7 完善 @CodableEnum.Default 枚举默认值
- [x] 5.8 编写 P2 功能测试（@CodableAnyKey/@CodableAnyValue/@CodableRoot + JsonValue 字段，T5.10/T5.11 共 10 项）

---

## 阶段六：P3 特性与完善 — 代码完成 ✅（测试待编写）

- [x] 6.1 完善 @CodableView 视图过滤（ViewContext + HandleClass/HandleStruct 宏代码生成）
- [x] 6.2 完善 @CodableRef 循环引用处理（RefContext + HandleClass/HandleStruct 宏代码生成）
- [x] 6.3 完善 @CodableInject 值注入（InjectContext + HandleClass/HandleStruct 宏代码生成 + decode post-endObject 注入）
- [x] 6.4 完善 @CodableFilter 动态过滤（FilterContext + HandleClass/HandleStruct 宏代码生成）
- [x] 6.5 完善 @CodableMerge 合并更新（fromJsonValue containsKey 语义 + HandleClass/HandleStruct 支持）
- [x] 6.6 完善文档与示例（README.md 已编写，含 P0-P3 全部注解用法及流式/databind/异常体系说明）
- [x] 6.7 全面集成测试（P3 上下文单元测试 + 宏集成测试均经 cjc 编译验证：annotations enums 7/7、databind macros_test 314/314）

---

## 序列化/反序列化测试用例

> 每项测试需覆盖序列化 + 反序列化双向，以及往返一致性（round-trip）

### T1 基础类型测试

- [x] T1.1 整数类型测试（7 项）
- [x] T1.2 浮点类型测试（7 项）
- [x] T1.3 布尔类型测试（3 项）
- [x] T1.4 字符串类型测试（6 项）
- [x] T1.5 Rune 类型测试（4 项）
- [x] T1.6 BigInt / Decimal 类型测试（3 项）
- [x] T1.7 DateTime 类型测试（4 项）— 共 30 项已通过；T1.3.3/T1.3.4/T1.2.4/T1.7.2/T1.7.3 依赖 CodecFeature/@CodableFormat，推迟至 T7

### T2 仓颉自定义类型测试

- [x] T2.1 Unit 类型测试（2 项）
- [x] T2.2 Option 类型测试（7 项）
- [x] T2.3 元组类型测试（7 项）— 仓颉禁止扩展元组类型（无 IJsonAdapter），宏层内联数组式编解码已实现。树路径 treeFieldValueExpr/treeFieldReadExpr + Option 变体（treeOptionFieldValueExpr/treeOptionFieldReadExpr）+ Array<Tuple> 集合分支；流路径 buildStreamElementWrite/buildStreamReadExpr 镜像（HandleClass+HandleStruct）。7 项：2/3 元组树往返、嵌套元组、Option<Tuple> 树+流、Array<Tuple> 树+流、元组流往返、具名元组、struct 元组树+流
- [x] T2.4 枚举类型测试（11 项）— 11 项已通过；T2.4.5~T2.4.7 带关联值/递归枚举、T2.4.10 枚举 Map key、T2.4.11 大小写不敏感推迟

### T3 用户自定义类型测试

- [x] T3.1 普通 class 测试（6 项）
- [x] T3.2 struct 类型测试（4 项）
- [x] T3.3 继承测试（5 项）
- [x] T3.4 泛型类型测试（10 项）— @Codable 泛型类/结构体支持已实现。utils.cj 新增 16 个泛型辅助（extractTypeParamNames/hasValueParam/isGenericTypeParam/typeParamsBracketed/nameWithTypeArgs/adapterWhereClause/mergedAdapterWhereClause/injectWhereClause/mergeWhereClause/splitWhereClauses/splitTopLevelAmp/findConstraintOp/sliceTokens/joinStr/indexOfString/listContains）。HandleClass/HandleStruct doExpend 自动检测类型参数（无需 withGenericType 属性），向类声明注入合并后的 `where T <: IJsonAdapter<T>`（合并既有 where 如 `T <: Hashable & Equatable<T>` 时追加 `& IJsonAdapter<T>` 不丢失原约束），生成 `extend<T> Foo<T> <: IJsonAdapter<Foo<T>> where ... {}` 声明一致性；方法返回类型/构造改用 selfType（Foo<T>，非泛型保留真实标识符 Token 零回归）。流式 buildStreamReadExpr/buildStreamElementWrite 顶部加泛型参数回退（IJsonAdapter 仅声明 toJsonValue/fromJsonValue 无 encode/decode，故 T 字段改用 readJsonValue/writeJsonValue 桥接）。10 项：box 树/流往返(Int64+String)、pair 双参、collections 树/流(Array+Option+HashMap)、嵌套泛型 T3Outer<T3Box<T>>、generic struct 树+流、merge where(HashSet<T> 验证 where 合并不丢约束)。值参数($N)回退跳过；泛型类需无参 init 故类型参数字段须可默认。266/266 通过
- [x] T3.5 混合类型测试（8 项）
- [x] T3.6 sealed class 测试（3 项）
- [x] T3.7 私有变量测试（14 项）— 共 39 项已通过；T3.7.13 反射兜底对比依赖 BeanEncoder（T7 范畴）推迟

### T4 集合类型测试

- [x] T4.1 Array 类型测试（6 项）— 树+流往返 6 项已通过
- [x] T4.2 ArrayList 类型测试（2 项）— 树+流往返 2 项已通过（新增 ArrayList IJsonAdapter 扩展）
- [x] T4.3 HashMap 类型测试（6 项）— 树+流往返 6 项已通过
- [x] T4.4 HashSet 类型测试（3 项）— 树+流往返 3 项已通过（新增 HashSet IJsonAdapter 扩展）
- [x] T4.5 嵌套集合测试（10 项）— `Array<Array>/Array<Map>/Map<Array>/Map<Map>/深层嵌套/Array<Option>/Option<Array>/ArrayList<Array>/Array<用户类型>` 10 项已通过
- [x] T4.6 VArray 类型测试（5 项）— 树+流往返 5 项已通过。`getCollectionElementType` 修复（深度感知 `findTopLevelComma`）；VArray 无 IJsonAdapter 且 `$N` 为编译期字面量无法泛型抽象，故宏内联 codegen：树 encode 内联 `JsonArray`、树/流 decode 索引 lambda 构造 `VArray<T,$N>`；`$N` 的 `$` 经 `\$$(sizeNum)`（双 `$`：`\$` 出字面 `$` + `$(sizeNum)` 出数字）注入；`$0` 因仓颉 VArray 构造器仍以索引 0 调用 lambda 致越界，改用 `repeat: zero`。继承树路径（toJsonValueInherit/fromJsonValueInherit）路由 `treeFieldValueExpr/treeFieldReadExpr`；流 encode 按索引遍历（VArray 不实现 Iterator）。已知限制：元素须值类型；不支持嵌套 VArray 解码 / Option<VArray>（受 `$N` 约束）。
- [x] T4.7 Range 类型测试（3 项）— Range 无自然 JSON 形态（无 IJsonAdapter），宏层内联对象式 {start,end,step,isClosed} 编解码已实现。树路径 treeFieldValueExpr/treeFieldReadExpr；流路径 encode 写对象、decode 委托 JsonStreamCodec.readRange（HandleClass+HandleStruct 镜像）。3 项：Int64 Range 树往返（半开/闭/step + 迭代求和校验）、流往返、struct Range 树+流

### T5 注解功能测试

- [x] T5.1 @CodableKey 测试（4 项）— 字段名映射树+流路径，全部通过
- [x] T5.2 @CodableSkip 测试（3 项）— 序列化省略/反序列化忽略键/往返，全部通过
- [x] T5.3 @CodablePolicy 测试（12 项）— NON_NULL（4 项）：None 省略/Some 写出/缺失反序列化/混合往返；NON_EMPTY（4 项）：空集合/空串/None 省略 + 非空写出 + 流路径 + 往返；NON_DEFAULT（4 项）：默认值(0/0.0/false/""/[])省略 + 非默认写出 + 流路径 + 往返。本轮同步修复写入门控缺陷：utils.cj 新增 policyOmitCondition/guardPolicyWrite，HandleClass/HandleStruct 树+流 encode 按策略对空集合/空串/默认值门控（Option 解包值 v 判定、非 Option 字段统一包裹），NON_DEFAULT 对自定义对象不门控（无可靠默认值比较），全部通过
- [x] T5.4 @CodableOrder 测试（2 项）— 同步修复静默空操作缺陷（utils.cj 新增 applyFieldOrder，HandleClass/HandleStruct collectFields 读取并重排），class+struct 字段顺序断言通过
- [x] T5.5 @CodableAlias 测试（4 项）— 主键序列化 + 主键/第一别名/第二别名反序列化回退，全部通过
- [x] T5.6 @CodableFormat 测试（6 项）— DateTime 格式化已实现：core/BasicTypeCodec 新增 formatDateTime/parseDateTimeStr/parseDateTimeFromJson/decodeDateTime(fmt)/parseOptionDateTimeFromJson；macros/utils 新增 treeFieldValueExpr/treeOptionFieldValueExpr/treeFieldReadExpr/treeOptionFieldReadExpr；HandleClass/HandleStruct 流三辅助加 format 参数透传 + 树 encode/decode 调用点注入。6 项：dateFormat/dateRoundTrip/optionFormat/streamSerialize/streamRoundTrip/structRoundTrip（249/249 通过）
- [x] T5.7 @CodableVariant 测试（6 项）— PROPERTY 往返+分发 2 项 + WRAPPER_OBJECT/WRAPPER_ARRAY 往返+分发 4 项，全部已通过
- [x] T5.8 @CodableUnwrap 测试（7 项）— 树路径序列化扁平化/反序列化/往返（3 项）+ 流路径序列化扁平展开（1 项）+ 流路径反序列化（收集未知键至 unwrapObj 后 fromJsonValue 解码，含字符串形似数字保留类型回归，2 项）+ 流路径往返（1 项），全部通过。本轮修复 unwrap 流式 decode bug：HandleClass/HandleStruct decode codegen 新增 hasUnwrap 分支，未知键经 reader.readJsonValue() 收集到 JsonObject，endObject 后交由 InnerType.fromJsonValue 解码（与树路径对称）；JsonReader 新增 readJsonValue() 基于 stdx JsonToken 完整分派（绕过 StdxTokenBridge 标量归并误判），并修复 readRawValue 对字符串产出无引号非法 JSON 缺陷
- [x] T5.9 @CodableRaw 测试（2 项）— 序列化内联解析/往返还原，全部通过
- [x] T5.10 @CodableAnyKey/@CodableAnyValue 动态属性测试（6 项）— AnyKey 序列化展开 Map→顶层键、AnyValue 反序列化收集未映射键→Map、树往返、流往返 + JsonValue 普通字段树/流往返。本轮同步修复源码缺陷：core/ext 新增 `extend JsonValue <: IJsonAdapter<JsonValue>` 恒等映射（使树路径 toJsonValue/fromJsonValue 与 `HashMap<String,JsonValue>` 可用）；宏 buildStreamElementWrite/buildStreamReadExpr 新增 JsonValue 特例（writeJsonValue/readJsonValue，与基础类型一致，不依赖跨包 direct extend）；AnyKey 流式展开 `v.encode(writer)`→`writer.writeJsonValue(v)`；AnyValue 树式收集 `for-in jsonObj`→`JsonObjectHelper.entries(jsonObj)`（JsonObject 不可直接迭代）；移除失效的 JsonValueCodec.cj。全部通过
- [x] T5.11 @CodableRoot 根名称包装测试（4 项）— 序列化包装 `{root:{...}}`、反序列化解包、树往返、流往返。本轮同步修复源码缺陷：AnyRoot 树式 decode 此前 jsonObjExpr 内联 `jsonObj.get(root).getOrThrow()` 得 JsonValue，后续 `.get(field)` 因 JsonValue 无 get 编译失败；改为解包后 match 转 JsonObject 赋 innerObj、字段读取源指向 innerObj。全部通过

### T6 边界与异常场景测试

- [x] T6.1 null 值处理测试（5 项）— None 序列化为 null、null/缺失反序列化为 None、Some 往返、嵌套 Option<@Codable> None 往返，全部通过
- [x] T6.2 空/缺失处理测试（5 项）— 空串往返、缺失 @CodableDefault 保留默认、缺失必需抛 JsonMissingField、null 给默认字段保留默认、空数组/空 Map 往返，全部通过
- [x] T6.3 循环引用测试（3 项）— @CodableRef 钻石 DAG 去重写 $ref、@CodableRefBack 跳过打破循环、未启用 RefContext 不去重，全部通过。本轮同步修复 @CodableRef 编译缺陷（见下）；$ref 反序列化还原仍推迟
- [x] T6.4 类型不匹配与异常测试（7 项）— String←Int/Int←String/Bool←String/Array←Object/Object←Array 抛 JsonTypeException、缺失必需抛 JsonMissingField、畸形 JSON 抛 Exception，全部通过
- [x] T6.5 特殊字符串测试（7 项）— 引号/反斜杠/换行制表/中文/emoji/空串/JSON 特殊字符 往返相等，全部通过

### T7 高级场景测试

- [x] T7.1 自定义 Encoder/Decoder 测试（3 项）— 自定义 TaggedStringEncoder/Decoder 直接调用 encode/decode 验证编码逻辑；模块注册 builder 链验证（注册生效待类型擦除解决）
- [x] T7.2 命名策略测试（4 项）— SnakeCase/PascalCase/KebabCase translate 正确，CamelCase 为 identity；同步修复 setNamingStrategy 静默丢弃策略缺陷（新增 getNamingStrategy 保留策略）；端到端字段名转换待宏集成
- [x] T7.3 树模型操作测试（5 项）— NodeFactory.fromStr 构建树、toString/toPrettyString 序列化、get(key)/get(index) 路径查询、JsonObject 增改、JsonPointer RFC 6901（含 ~1/~0 转义），全部通过
- [x] T7.4 CodecFeature 开关测试（5 项）— PRETTY_PRINT 端到端（树路径紧凑 vs 流式 encode+WriteConfig.pretty 格式化）通过；FAIL_ON_UNKNOWN_PROPERTIES/ACCEPT_SINGLE_VALUE_AS_ARRAY/WRITE_NULLS/FAIL_ON_NULL_FOR_PRIMITIVES 验证开关可存取，行为级生效待宏集成
- [x] T7.5 模块系统测试（2 项通过 + T7.5.2 推迟）— registerModule/builder/getModuleName/多模块共存通过；T7.5.2 模块覆盖默认编解码器推迟（registerEncoder/setupModule 空占位，类型擦除未解决）

### T8 往返一致性测试

- [x] T8 往返一致性测试（9 项通过）— T8.1 基础类型聚合往返（整数/浮点/布尔/字符串/Rune/BigInt/Decimal/DateTime，Float64 高精度用容差断言）、T8.2 自定义类型往返（Option/枚举/Unit/嵌套用户类型）、T8.3 集合往返（Array/ArrayList/HashMap/HashSet/嵌套集合/对象数组）、T8.4 注解往返（@CodableKey/@CodableSkip/@CodableDefault/@CodableAlias/@CodableUnwrap，skip 字段往返后重置默认值）、T8.5 null/空值往返（None/空串/空数组/空 Map + Some 往返）、T8.6 三层嵌套对象往返、T8.8 @CodableVariant 多态类型鉴别信息保留；附流路径 encode/decode 往返冒烟；T8.7 泛型往返（嵌套泛型 T3Box<T3Box<Int64>> 树往返 + Array<T3Box<String>> 流往返，T3.4 已支持）。仓颉 class 默认非 Equatable，采用字段逐项比对

### T9 性能基准测试

> 核心目标：json4cj 宏生成路径性能不得低于 Jackson 反射路径。使用 @Bench + cjpm bench 运行。

- [x] T9 冒烟与诊断（框架验证 + 关键发现）— @Bench + cjpm bench 框架可用，ops/ms = 1000/median(μs)。T9.1 PrimitiveBean(7 字段) 实测：序列化 967 ops/ms(≥800✓)、反序列化 650(≥600✓)、往返 389(≥350✓)，对标 Jackson 达标。关键诊断：BeanEncoder 反射路径对非 public 字段输出 `{}`（仓颉反射仅可见 public 成员，属设计行为非缺陷，execution-plan §4/§6.3 已载明），先前"宏慢于反射"为假象——反射仅写 `{}` 未做实质工作。改用 public var 字段后实测：宏 4 字段 0.908μs vs 反射 1.972μs(2.17x)、宏 20 字段 1.272μs vs 反射 5.107μs(4.01x✓ 达 ≥3x)；每字段宏 ~23ns vs 反射 ~196ns(8.6x)。宏生成代码与手写 field() 等价(1.272 vs 1.231μs)，codegen 已最优。T9.6 流式 vs 树式 1.33x(目标 1.5x，略低待优化)。BeanDecoder 反序列化仍为桩(Cangjie 反射无法调用构造器)，T9.7.4/反序列化倍率推迟
- [x] T9.1 基础类型吞吐量（3 项）— PrimitiveBean(7 字段)：序列化 1.34μs(744 ops/ms)、反序列化 2.20μs(456)、往返 3.85μs(260)
- [x] T9.2 字符串密集型（4 项）— 短串 1.31μs / 长串(1000×8) 13.95μs / 转义 1.44μs / Unicode 1.38μs
- [x] T9.3 集合类型吞吐量（8 项）— 小数组 2.57μs、大数组(1000) 序 94.7μs/反 131μs、小 Map 4.56μs、大 Map(100) 序 30.3μs/反 70.8μs、嵌套集合 序 13.9μs/反 20.8μs
- [x] T9.4 嵌套对象吞吐量（6 项）— 深嵌套(4 层) 序 1.19μs/反 2.26μs、宽(20 字段) 序 2.88μs/反 6.79μs、超宽(50 字段) 序 3.50μs/反 16.8μs
- [x] T9.5 注解开销测试（7 项）— 5/7 达标：@CodableKey −0.2%、@CodableSkip holder 快 28%、@CodablePolicy −2.6%、@CodableAlias +0.1%、@CodableFormat +0.1%（no-op stub，待 T5.3 重测），均 <5%/<10% 达标。T9.5.6 @CodableUnwrap（3.13×）/T9.5.7 @CodableRaw（6.64×）未达标：**T3 流式 encode bug 已修复**（JsonWriter 新增 writeJsonValue 公共方法、rawField 改解析+重序列化、unwrap codegen 镜像树路径扁平写入），改回流路径重测——证实开销为 unwrap/raw 的 DOM 构建+重序列化固有成本（非 bug）：unwrap 与树路径 2.93× 同量级（瓶颈 toJsonValue DOM 构建），raw 高于树路径 3.59×（writeJsonValue 逐字段走状态机 vs toString 直接序列化器）。unwrap 流式 decode bug 已修复（readJsonValue 完整分派 + decode codegen 收集未知键至 unwrapObj 后 fromJsonValue 解码，见 T5.8）
- [x] T9.6 流式 vs 树模型对比（6 项）— 序列化达标：stream 1.71× 快于 tree（窄对象 2.871 vs 4.912μs，大对象 1.74×）；反序列化未达标：stream 1.86× **慢于** tree（6.881 vs 3.704μs），根因在 stdx JsonReader 逐 token 开销高于 JsonValue.fromStr + 流式固有顺序字段名匹配 vs 树式 HashMap O(1)，decode codegen 已最优（规范模式无冗余），非 json4cj 可优化。大 JSON 绝对吞吐（1.08/0.61/0.62/0.86 ops/ms）远低于乐观目标（≥10/5/5/3），受 itoa 瓶颈制约
- [x] T9.7 宏路径 vs 反射路径对比（5 项）— 宏 ≥ 反射 3× **达标**（20 字段 4.01×：macro 1.898 vs reflect 7.603μs）；4 字段 2.33×（固定开销摊薄不足）；宏 codegen ≈ 手写（macroWide 1.898 ≈ handWide 1.903，−0.3%）；T9.7.4 反射反序列化推迟（BeanDecoder stub，仓颉反射无法调构造器）。详见 docs/T9-performance-baseline.md §7-§9
- [x] T9.8 内存占用测试（4 项）— 流式 vs 树式吞吐差代理 GC/峰值（仓颉 std 无堆统计 API）；标量 0.92/0.95 µs、1000 元素集合 66.9/172.6 µs（树式 2.58× 慢，DOM 节点即峰值/GC 源）
- [x] T9.9 并发性能测试（5 项）— 2 安全 @Test（8×200 并发编解码无损坏）+ 3 吞吐 @Bench（单线程 86.6 µs / 多线程 790 µs / 混合 476.8 µs）
- [x] T9.10 性能回归基线建立（4 项）— 基线已固化于 docs/T9-performance-baseline.md：含 T9.1-T9.4 全量实测、T9ArrayDiag 根因隔离、Jackson 同环境对照（JDK21+Jackson2.17.2，docs/jackson-bench/ 可复现）
- [ ] T9.11 乘法强度削减 itoa 快速路径（实验性，待用户决策）— 用 `n*倒数>>shift` 替代 `n/10`/`n%10`（JVM Hotspot 做法），理论将整数算术成本从 ~18ns/位降到 ~1-3ns/位；在 json4cj 侧实现后直写 ByteBuffer，绕过 stdx `Int64.toString()` 路径。风险/保留意见：① 需手写 64 位乘法高 64 位取值（Cangjie 无 `__int128`，需拆 32 位高低位 schoolbook 模拟，易错）；② 仅对整数序列化有效，Float64/Unicode String 瓶颈另在别处；③ 即便算术提速 ~10×，buffer 物化（`String.fromUtf8(readToEnd(buf))`）、反序列化分配仍存，整体未必追平 Jackson；④ 仓颉 1.0.5 的 `Int64.toString` 内部是否已有此优化未知（实测 60.7μs 表明没有或不如 JVM）；⑤ 可先做"两位查表（div-by-100）减半 idiv 次数"作为简易部分收益版。验收：实现后 `cjpm bench` 对照现路径，有实测加速则保留、否则回退。【三方基准 2026-08-10】序列化侧 json4cj stream 已是仓颉最快（LargeBean ser 16.76μs < cangjieJSON 27.13μs），T9.11 仍为唯一序列化杠杆；作用面仅对象/数组序列化（BigString tree ser 仅 3.0× Jackson，字符串拷贝主导非 itoa）。详见 docs/T9-e2e-three-way-bench.md §5
- [ ] T9.12 自写 JSON 解析器绕过 stdx JsonReader（重大架构变更，实验性，待用户决策）— 针对反序列化分配瓶颈（大数组 11.4×、大 Map 25.4× 慢，逐元素装箱 Long/String + 建 Map 桶，仓颉分配+GC 单对象成本高于 JVM 分代 GC 对短命对象近零成本），json4cj 侧自写解析器直填目标类型，避免中间 JsonValue 装箱。亦可改善流式反序列化 1.86× 慢于树式的回归（stdx JsonReader 逐 token 开销 + 顺序字段名匹配 vs 树式 HashMap O(1)）。风险/保留意见：① 工作量大，需完整复刻 token 状态机 + 错误处理 + 转义解析；② 须与既有树路径（`JsonValue.fromStr`）语义对齐；③ 架构级变更影响面广，破坏现有 decode 路径回归风险高。【三方基准新证据 2026-08-10】cangjieJSON（同 stdx `JsonValue.fromStr` 解析地板）在 LargeBean 反序列化快 json4cj 1.4-1.7×——解析步骤完全相同、差距在 json4cj `fromJsonValue` 的 DOM→对象映射 codegen，**证明反序列化有源码级头空间**（部分推翻基线"反序列化无源码优化空间"结论），T9.12 应升档。建议先做低成本子杠杆「优化 fromJsonValue codegen」（profile vs cangjieJSON，精简每字段 Option/missing/alias 分流与集合元素 unboxing，目标 tree deser 追平 cangjieJSON），触顶后再评估自写解析器。详见 docs/T9-e2e-three-way-bench.md §5 【2026-08-11 子杠杆1已完成】逐层对比 json4cj vs cangjieJSON tree 反序列化全链路，证实 fromJsonValue codegen 与 cangjieJSON 等价（原「codegen 冗余」前提证伪），唯一实质差异在 JsonObjectHelper.entries/keys 用 obj.toString()+手写状态机 skipValue 解析键名的「序列化→再解析」往返（cangjieJSON 直接 getFields 原生迭代）。已改用 stdx getFields 重写（签名不变，10+2 消费者含 @CodableAnyValue/@CodableUnwrap/@CodableVariant 宏生成代码零改动），删 skipValue。LargeList(200×40-entry HashMap) tree deser @Bench 中位 11.29ms 较修复前 -15.7%（同次 ser/stream 路径因机器负载全红 +5.9%~+66.3%，唯一变快的 tree deser 恰为修复作用路径，收益突破噪声确证）；LargeBean(1 HashMap 字段) 收益小被噪声淹没符合预期。core 124/124、databind 325/325 不回归。自写解析器（绕过 stdx JsonReader）仍为待决策重大架构变更。commit 124020f 【2026-08-13 v2 复测】entries 修复收益经三方复测确认：LargeBean tree deser 35.36→28.61μs（−19.1%）、cangjieJSON-vs-tree 差距 1.73×→1.48×、PerfLargeList(8000 HashMap entry)进一步收窄至 1.30×。新发现 stream 反序列化批量退化（PerfLargeList stream deser 16.19ms 慢于 tree 12.36ms 1.31×、慢于 cangjieJSON 9.477ms 1.71×）——逐字段 JsonReader 分派在批量宽对象上被 stdx 原生批量解析反超，与 T9.14 BigString stream ser 退化对称，列为 T9.12 子杠杆2（stream deser 批量快路径）。详见 docs/T9-e2e-bench-v2/T9-e2e-three-way-bench-v2.md §5/§7 【2026-08-13 子杠杆1续·HashMap/ArrayList 物化消除】逐字段 codegen 对比证实 json4cj vs cangjieJSON 宏字段映射逐字等价（try/catch+getOrThrow 闭包+Option 路径均 common-mode 非差距源；skipTypeGuardStmt 仅嵌套对象字段 PerfLargeList 零影响），1.30-1.48× 余量定位在 3 处核心适配器：① HashMap.fromJsonValue 经 JsonObjectHelper.entries() 物化 ArrayList→Array+N tuple（cangjieJSON 直接 getFields 迭代；2026-08-11 entries 修复仅把内部从 toString+parse 换成 getFields，未去外层物化包装）；② ArrayList.fromJsonValue 动态扩容（cangjieJSON 预分配 ArrayList(size,init)，json4cj 自身 Array<T> 已预分配但 ArrayList 未对齐）；③ Int32 range check（保留安全）。本轮修①②：HashMap 改 for((k,v) in obj.getFields())、ArrayList 改 ArrayList<T>(size,init)，均对齐 cangjieJSON 已验证写法。同会话 3×before/3×after 分布对比（控制组 ser/stream-deser 持平）：PerfLargeList tree deser 中位 12.07→10.90ms（-9.7%，after-max 11.21<baseline-min 11.61 完全分离）、LargeBean tree deser 中位 30.09→28.11us（-6.6%，after-max 28.48<baseline-min 29.93 完全分离）。core 124/124、databind 536/536 不回归。commit daf0b6e。子杠杆2（stream deser 批量退化）仍待推进
- [x] T9.13 三方端到端基准（json4cj vs cangjieJSON vs Jackson，较大类+较大字符串）— LargeBean(24 字段含集合,~1.3KB)+BigString(~41KB) 字符串端到端。结论：对象路径差距最大(7.6×~17.1×)、大字符串收窄(2.2×~6.1×)；序列化 json4cj stream 已是仓颉最快(16.76 vs cangjieJSON 27.13μs)，剩余对 Jackson 9.4×=itoa 地板；反序列化 cangjieJSON 在 LargeBean 快 json4cj 1.4-1.7×（见 T9.12 新证据），证明 stdx 地板之上仍有源码头空间。基准产物：docs/jackson-bench/JacksonBenchE2E.java、json4cj-databind/src/macros_test/T9BenchE2E_test.cj。完整对比表与分析见 docs/T9-e2e-three-way-bench.md
- [x] T9.14 BigString 流式序列化退化修复（源码级，低风险）— 三方基准发现 BigString stream 序列化 95.52μs，2× 慢于 tree 47.16μs 与 cangjieJSON 50.37μs。**根因经 A/B 实测修正原推测**：原推测"逐字符经 ByteBuffer 写入并逐字符查转义"**证伪**——stdx `String.toJson` 已批量 `copyTo`/`out.write`、转义走 C 函数；受控 A/B（消除 Cangjie 逐字节扫描的快路径经 diagFast==1 确认触发但零收益，stream/tree 比 1.85× 不变）排除扫描瓶颈。真实根因：`JsonWriter.toString()` 用 `String.fromUtf8(readToEnd(buf))` **双拷贝**（readToEnd 逐字节拷出 ByteBuffer 内容 + fromUtf8 再拷入 String + UTF-8 校验扫描），32KB 耗 ~23μs，即 stream-vs-tree 全部差距；encode+flush 本身已与 tree 平齐（~49μs vs ~43μs）。**修复**（仅改 JsonWriter.toString）：`buf.bytes()`（ByteBuffer 共享存储零拷贝视图）+ `unsafe { String.fromUtf8Unchecked(_) }`（单拷贝、跳过 UTF-8 校验；stdx 写出 JSON 恒为合法 UTF-8 故安全）。**结果**：bigString_streamSerialize 95.52μs（三方原始）/71.72μs（本会话隔离基线）→52.06μs（−45%/−27%），tree 对照 44.14μs 持平（+0.3%，未动该路径），达 ~50μs 目标、追平 cangjieJSON 50μs；largeBean_streamSerialize 16.58μs 现为 tree 0.54×（30.90μs），toString 优化惠及全部流式序列化。core 124/124、databind 325/325 不回归。【2026-08-13 v2 三方复测验证】BigString stream ser @Bench 中位 60.30μs（均值 55.82），较修复前 95.52 −36.9%，对 Jackson 6.1×→3.9×、对 tree 2.02×→1.30×，最差回归消除。未达单次 best-case 52（@Bench 稳态含批量分配压力高于单次）；中位对中位仍 1.30× tree，残余开销优先级降低。详见 docs/T9-e2e-bench-v2/T9-e2e-three-way-bench-v2.md §4.1
- [x] T9.15 移植第三方大列表基准用例（200×110 字段 ser/deser）— 移植 jackson_dataformat_yaml PerfBenchmark_test.cj：@GenerateBackingProps+@JsonProperty+ObjectMapper → @Codable 字段式（去 getter/setter，字段名==键名故省略 @CodableKey）+包装类 T9PerfLargeList；MonoTime→@Bench、去文件副作用。@TestCase 闸门校验树+流往返（首次验证 61×?String 流式编解码路径）。@Bench 4 项中位（ms）：tree 序 9.92/反 13.90、stream 序 5.51/反 15.92，与 T9 模型一致（stream 序 1.8× 快于 tree、tree 反快于 stream 反，复现 T9.6）。databind 325/325 通过。产物：json4cj-databind/src/macros_test/T9BenchLargeList_test.cj
- [x] T9.16 三方端到端基准 v2 复测（json4cj vs cangjieJSON vs Jackson，+PerfLargeList+数据落盘）— 按用户要求复跑三方基准并新增第 3 工作负载 PerfLargeList(200×110 字段,~665KB)，测试输入数据(类定义 .cj/.java + JSON 串 .json)单独落盘 docs/T9-e2e-bench-v2/data/（9 文件）；新增 T9DumpBenchData_test.cj @TestCase 物化 JSON 样本，Jackson/cangjieJSON 基准各扩展 2 bench。**T9.14 修复验证**：BigString stream ser 95.52→60.30μs（@Bench 中位,均值 55.82），−36.9%，对 Jackson 6.1×→3.9×，最差回归消除（未达单次 best-case 52，中位对中位仍 1.30× tree，残余开销优先级降低）。**entries/keys 修复验证**：LargeBean tree deser 35.36→28.61μs（−19.1%），cangjieJSON-vs-tree 差距 1.73×→1.48×；PerfLargeList(8000 HashMap entry)差距进一步收窄至 1.30×（修复收益 HashMap 密集处集中）。**新发现·头条**：PerfLargeList stream 反序列化批量退化——stream deser 16.19ms 比 tree(12.36)慢 1.31×、比 cangjieJSON(9.477)慢 1.71×，与 v1 BigString stream ser 退化对称（stream 逐字段 token 分派在单对象省 DOM 占优、批量宽对象被 stdx 原生批量解析反超）；tree deser 已反超 stream deser → stream token 地板不再是 json4cj 反序列化下限，列为 T9.12 子杠杆2。序列化侧 json4cj stream 仍最快（PerfLargeList ser 4.906ms < cangjieJSON 9.114 < tree 10.01）。JSON 三方逐字节一致（1326/41125/664816 B）。Jackson 2.16.1。完整对比表+差异分析见 docs/T9-e2e-bench-v2/T9-e2e-three-way-bench-v2.md

> **性能 GAP 已有结论（T9.10 基线，完整论证见 docs/T9-performance-baseline.md §1-§8）**：
>
> **达标状态**：宏-vs-反射 ≥3×（4.01×）✅、宏 codegen ≈手写（−0.3%）✅、流式序列化 ≥树式 1.5×（1.71×）✅、注解开销 5/7 达标 ✅。**未达标**：不慢于 Jackson ❌（慢 5×~26×，集合类差距最大）、流式反序列化 ≥树式 ❌（反方向 1.86× 慢）、大 JSON 绝对吞吐 ❌（1.08/0.61/0.62/0.86 vs 目标 ≥10/5/5/3 ops/ms，itoa 瓶颈）、反射反序列化 ⏸（BeanDecoder stub，仓颉反射无法调构造器）。
>
> **根因隔离（T9ArrayDiag 七路拆解，1000 个 Int64）实测**：`directBufferWrite`（预计算字节写 buffer）45.9μs；`pureArithmeticNoAlloc`（零分配、只 `n%10`/`n/10`）51.9μs；`int64ToStringOnly`（纯 `Int64.toString` 含 String 分配）60.7μs；`itoaToVArray`（零堆分配手写 itoa：div/mod + 写栈 VArray + 逆序）62.6μs；`rawStdxArray` ≈62μs。
>
> **关键定论**：① 成本在**整数除法算术**而非 String 分配——`pureArithmeticNoAlloc`(零分配) 占 `toString`(有分配) 的 86%，`itoaToVArray`(零分配) ≈ `int64ToStringOnly`(有分配)，**消除分配零收益**，"分配是元凶"假设证伪；② 根因是仓颉 1.0.5 编译器/JIT **不做除法强度削减**，`x/10` 原样编译为硬件 `idiv`（x64 ~20-40 周期，~18ns/次），而 JVM Hotspot 重写为 `x*0xCCCCCCCCCCCCCCCD>>3`（乘法 ~3 周期，~1ns）——Jackson 快是因 JVM 帮它消除了除法，非因绕开 `Long.toString` 分配；③ 底层 stdx 引擎已是性能地板，json4cj 封装仅 +5%~10%、宏 codegen +0%（与手写等价）、反射路径 by-design 仅 public 字段——**json4cj 源码层面常规优化已穷尽**；④ 反序列化分配确有影响（区别于序列化 itoa 路径）：大数组反序列化 11.4×、大 Map 25.4× 慢，逐元素装箱 Long/String + 建 Map 桶。
>
> **唯一待验证方向（文档已识别但未实现/未基准，待用户决策）**：T9.11（乘法替代除法的 itoa）针对序列化算术瓶颈、T9.12（自写解析器）针对反序列化分配瓶颈。"原则上不慢于 Jackson"受仓颉运行时数字格式化/分配/GC 成本制约，仅这两条源码级重大变更有可能缩小差距，且不保证追平。【2026-08-10 三方基准补充，docs/T9-e2e-three-way-bench.md】序列化侧 json4cj stream 已是仓颉最快、T9.11 仍为唯一杠杆且仅作用于对象/数组序列化；反序列化侧 cangjieJSON 同 stdx 地板下快 json4cj 1.4-1.7× → 证明有源码级头空间，T9.12 升档并新增低成本子杠杆「优化 fromJsonValue codegen」；另发现 BigString stream 序列化退化（T9.14，源码可修，**已修复 2026-08-11**）。【2026-08-13 v2 复测】T9.14 验证生效（BigString stream ser 95.52→60.30μs）；entries 修复验证生效（LargeBean tree deser 差距 1.73×→1.48×、PerfLargeList 1.30×）；新增 PerfLargeList 工作负载暴露 stream 反序列化批量退化（16.19ms，1.31× 慢于 tree），列为 T9.12 子杠杆2。详见 docs/T9-e2e-bench-v2/T9-e2e-three-way-bench-v2.md

### T10 大而全综合序列化/反序列化测试

- [x] T10 大而全综合测试（16 项）— 单继承层级端到端覆盖前序全部类型与注解场景。CompBase(open,24 字段:整数族/无符号/浮点/Bool/String/Rune/BigInt/Decimal/DateTime(@CodableFormat)/Option/私有变量/@CodableKey/@CodableSkip/@CodableDefault/@CodableAlias) + CompChild(非 open,<:CompBase,12 字段:集合/集合嵌套/自定义对象/私有变量/@CodableAlias) + CompGrand(非 open,<:CompBase,12 字段:元组/枚举/Unit/VArray/Range/JsonValue/@CodablePolicy/私有变量)；旁路 CompItem 嵌套对象、CompColor/CompPriority 枚举(名/序号模式)、CompAnimal→CompDog/CompCat @CodableVariant 多态。每类树反序列化/树往返/流反序列化/流往返 4 组(12 项) + @CodablePolicy[NON_EMPTY] 门控(1 项) + @CodableVariant 多态(3 项)。固件 testdata/T10_*.json 人工可读。**同步修复 3 处继承路径宏缺陷**：① fromJsonValueInherit 忽略 @CodableFormat(父类 DateTime 字段继承反序列化退化为无格式 parse,致 t10_5 hang)——传 field.format；② fromJsonValueInherit 忽略 @CodableAlias(父类别名字段 JSON 用别名时抛 JsonMissingField)——主键→别名回退；③ toJsonValueInherit 忽略 @CodableFormat(父类 DateTime 继承序列化退化为 ISO "T" 格式,致往返 TimeParseException)——传 field.format(与主 toJsonValue 路径对齐,非格式字段 field.format=None 零回归)。**cjc v1.0.5 编译器 bug 规避**:open class 继承另一类 + 自有字段 → 自有字段偏移错位(父类偏移正确),经 R29(non-open 12 字段继承通过)/R30(open 同结构字段值损坏)对照实验确认,method-modifier(override/open override)与字段数削减均无效,故 CompChild/CompGrand 均设为非 open 平级继承 CompBase(三层继承的宏递归机制由 T3 覆盖)。core 124/124、databind 341/341 全部通过,无回归。

### T11 第三方测试用例适配（yaml2 → json4cj）

- [x] T11 适配 yaml2 三方测试用例（16 文件 / 194 项）— 将 D:\code\wangdehaitest\yaml2（Jackson-databind 的 Cangjie 移植，非 cangjieJSON；路径含 yaml 但实为 JSON 数据绑定）下三方系统测试用例适配为 json4cj @Codable 风格，新增 16 个 Y\*_test.cj（json4cj-databind/src/macros_test/）。API 映射：ObjectMapper().writeValueAsString(obj) / CjJsonDeserializeUtils.deserialize\<T\>(jsonStr) → toJson() / fromJson()；@GenerateBackingProps + private var + getter/setter → @Codable + public var（字段式默认值）；@JsonProperty[value:"x"] → @CodableKey["x"]；@JsonIgnore → @CodableSkip。16 文件分组：① 共享模型 YamlContentModels_test.cj（YFeature/YArrayContent 等供多文件复用）；② 基础集合/Option YList/YNone/YOptionField；③ 嵌套对象/继承/Option 套集合 YFeatureContainer/YMmlResult/YMmlCmdReturn/YMultiConstruct/YPageNode/YInheritance/YQueryCondition；④ @CodableKey 改名+@CodableDefault 叠加 YJsonProperty（30 项，验证单字段多注解叠加编译且生效）；⑤ Option 套集合/嵌套对象 YOptionContainer（32 项）；⑥ 字节数组 YByteArray（Jackson base64 编码 Array\<Byte\> → json4cj 数字数组适配）；⑦ 集合元素为 Option YOptionCollection（22 项，HashMap\<String,?T\>/ArrayList\<?T\>，双层 Option deser map.get(k).getOrThrow() 解外层）；⑧ 嵌套集合对象带 Option 字段+深层 HashMap YNestedOptionField（25 项，3 层 HashMap 嵌套）。关键适配点：① Option 套集合（?ArrayList/?HashMap）None 判定用 .isNone()（集合非 Equatable，== None 编译报 "generic type should be used with type argument"，见 cangjie-option-collection-not-equatable）；② HashMap 不保序 → 序列化断言用 contains（order-independent），往返用 deser→ser→deser→字段断言；③ Jackson base64 编码 Array\<Byte\> → json4cj 数字数组（Array\<UInt8\>）；④ Map\<String,Any\> 不支持 → @Codable 容器类替代；⑤ @CodableKey+@CodableDefault 单字段叠加验证通过（batch-3a 最大未验证风险，30 项全绿）；⑥ 仓颉 raw string \##"..."\## 末尾 " 被 "\## 吞（空串值 "key":"" 片段断言失效），改用精确全串等值（见 cangjie-rawstring-trailing-quote，已存记忆）；⑦ Float32 取值用 2.5（二进制精确），不用 3.14（提升 Float64 后全精度展开非 "3.14"）。databind 342→536 全部通过（+194，0 失败 0 回归），cjpm build 通过。PerfBenchmark_test.cj 已由 T9.15（2026-08-10）适配，本轮不重复。

---

## 总进度统计

| 阶段 | 任务数 | 已完成 | 进度 |
|------|--------|--------|------|
| 目录结构验收 | 6 | 6 | 100% |
| 阶段一 | 46 | 46 | 100% |
| 阶段二 | 33 | 31 | 94% |
| 阶段三 | 40 | 39 | 98% |
| 阶段四 | 21 | 21 | 100% |
| 阶段五 | 8 | 8 | 100% |
| 阶段六 | 7 | 7 | 100% |
| T1~T8 功能测试 | 283 | 283 | 100% |
| T9 性能基准测试 | 58 | 56 | 97% |
| T10 综合测试 | 16 | 16 | 100% |
| T11 第三方用例适配 | 194 | 194 | 100% |
| **合计** | **712** | **707** | **99%** |

> 统计口径（2026-08-10 重计）：阶段一~六按实际勾选子项（X.Y.Z）计数，T1~T8 按测试用例数（括号内项数）计数，T9 按「项」计数（T9 冒烟计 0 项）。原表为规划期估算值（如阶段四标 23/15 实为 21/21 已全完成），现已对齐实际勾选状态。`[~]` 计为未完成：当前 [~] 项为 2.5.2/2.5.3/3.10.5（均由 databind macros_test 全量覆盖，非缺口）。剩余 5 项 = 包内测试 covered 3（2.5.2/2.5.3/3.10.5）+ 实验性 2（T9.11/T9.12；T9.14 已于 2026-08-11 修复）。本轮完成 T2.3 元组（7 项，含 struct）+ T4.7 Range（3 项，含 struct），原「语言限制推迟 8」已全部实现，T1~T8 达 100%。

> 最后更新：2026-08-09（本轮完成 T9.1-T9.4 共 21 项吞吐量基准 + T9.10 基线：T9BenchThroughput_test.cj 覆盖基础类型/字符串/集合/嵌套全场景；T9ArrayDiag_test.cj 四路诊断隔离大数组慢源；新增 docs/T9-performance-baseline.md 固化基线、docs/jackson-bench/ 提供 Jackson 同环境对照（JDK21+Jackson2.17.2 可复现）。关键结论：同环境实测 json4cj 比 Jackson 慢 5×~26×，根因是仓颉运行时 `Int64.toString()`（~62ns/数 vs Jackson 全流程 3.5ns/数，慢约 17×）占逐元素成本 ~96%，底层 stdx 已是性能地板、json4cj 封装仅 +5%~10%、宏 codegen +0% 已最优——属仓颉运行时限制非源码缺陷；宏-vs-反射 ≥3× 达标(4.01×)。T9.5/T9.6/T9.7 已完成（T9BenchAnnotation_test.cj 7 例注解开销、T9BenchStreamTree_test.cj 6 例流式vs树式、T9SmokeBench_test.cj 5 例宏vs反射）：T9.5 5/7 达标（unwrap/raw 为固有开销 3.13×/6.64×，T3 流式 bug 已修复）；T9.6 序列化流式 1.71× 达标、反序列化流式 1.86× 慢于树式（stdx JsonReader+流式固有，codegen 已最优非 json4cj 可优化）；T9.7 宏 ≥ 反射 3× 达标(4.01×)、codegen ≈手写。详见 docs/T9-performance-baseline.md §7-§9。T9.8/T9.9 已完成（见末条变更记录），T9.7.4 反射反序列化推迟（BeanDecoder stub）；databind 全量 232/232 通过；本轮修复 T3 流式 encode bug：JsonWriter 新增 writeJsonValue 公共方法、rawField 改解析+重序列化、unwrap codegen 镜像树路径扁平写入，新增 t5_8_4/t5_9_3 流式 encode 测试）
>
> 2026-08-09（unwrap 流式 decode 修复）：修复 @CodableUnwrap 流式反序列化缺陷——此前流式 decode 对 unwrap 字段静默丢失内嵌对象数据（未知键被 skip）。HandleClass/HandleStruct decode codegen 新增 hasUnwrap 分支：未知键经 reader.readJsonValue() 收集到 JsonObject，endObject 后交由 InnerType.fromJsonValue(unwrapObj) 解码，与树路径 fromJsonValue(parentJsonObj) 对称。同步修复 JsonReader：新增 readJsonValue() 直接基于 stdx JsonToken 完整分派（绕过 StdxTokenBridge 将所有标量归并为单一码的历史误判，正确区分 JsonString/JsonNumber/JsonBool/JsonNull），readRawValue 改为 readJsonValue().toString() 修复字符串产出无引号非法 JSON 缺陷。新增 t5_8_5/t5_8_6/t5_8_7 流式 decode 测试（含字符串形似数字保留类型回归）。core 118/118、databind 235/235 全部通过
>
> 2026-08-09（peek/OptionDecoder 缺陷簇修复）：根治 StdxTokenBridge 标量归并误判的连锁缺陷。JsonReader.peek() 改为直接映射 stdx JsonToken→CjJsonToken（区分 null/bool/number/string 与结构性令牌），移除 intToToken 与整个 stdx_bridge 包（基于"Null 构造器与 Cangjie 关键字冲突"的虚假前提，无实际冲突，唯一消费者为 peek）。连锁修复：① JsonStreamCodec.readOption 的 `case ValueNull` 死代码激活（此前 null 泄漏至 readElem）；② BuiltinDecoders.OptionDecoder 移除 readRawValue 消费陷阱——非 null 标量此前被 readRawValue 消费后无法重新解码、误返 None，现据 peek() 的 ValueNull 精确分流（null→skip+None，其余→valueDecoder.decode）；③ 清理两处误导注释。新增 testPeekScalarTags/testPeekStructuralTokens + 4 项 OptionDecoder 测试（null/Int/String/Bool 标量）。core 124/124、databind 235/235 全部通过，无回归
>
> 2026-08-09（@CodableFormat DateTime 格式化补全）：补齐此前"声明但不工作"的 @CodableFormat 注解——format 已收集但 getFormat() 全程无消费者，@CodableFormat["yyyy-MM-dd"] 完全空操作。本轮实现 DateTime 字段格式化（直接字段 + Option<DateTime>，树+流双路径，class + struct）。core/BasicTypeCodec 新增 5 个 format 感知静态方法（formatDateTime/parseDateTimeStr/parseDateTimeFromJson/decodeDateTime(reader,fmt)/parseOptionDateTimeFromJson），封装仓颉 deprecated 的 DateTimeFormat.of/toString(DateTimeFormat) API（自定义模式唯一途径），使宏生成代码无需在用户包导入 std.time；macros/utils 新增 4 个 codegen 辅助（treeFieldValueExpr/treeOptionFieldValueExpr/treeFieldReadExpr/treeOptionFieldReadExpr），按 simpleTypeName=="DateTime" + format 切换格式化/默认两条路径。HandleClass/HandleStruct 流三辅助（buildStreamReadExpr/buildStreamFieldWrite/buildStreamElementWrite）加 format 必填参数透传（Option 继承 format，Array/Map 传 None，v1 不支持嵌套集合）；树 encode/decode 调用点注入 format 感知表达式。同步修复源码缺陷：非 NON_NULL 的 Option<DateTime> 树 encode else 分支此前静默丢弃 format（treeFieldValueExpr 见 "Option" 非 "DateTime"），新增 treeOptionFieldValueExpr 解包 match（Some→格式化 JsonString/None→JsonNull()）并路由 else 分支。Cangjie 不支持位置默认参数（format: Option<String>=None 编译失败），故 format 设为必填、collection/Map 元素调用点显式传 None。新增 T5.6 共 6 项测试（dateFormat/dateRoundTrip/optionFormat/streamSerialize/streamRoundTrip/structRoundTrip）。core 124/124、databind 249/249 全部通过，无回归。数字格式化（Float64/Decimal 定格式化）受仓颉无 printf + Float64.toString 有损制约推迟，非 v1 范围
>
> 2026-08-09（性能 GAP 结论与实验性方案补录待办）：此前 T9 性能基准的 GAP（不慢于 Jackson ❌，慢 5×~26×）仅在 docs/T9-performance-baseline.md 与 T9.10 备注"待决策"中提及，未作为可跟踪任务。本轮将完整论证与待验证方案补入 todolist：① T9.10 关键结论备注扩写——补入 T9ArrayDiag 七路实测数据（pureArithmeticNoAlloc 51.9μs / directBufferWrite 45.9μs / int64ToStringOnly 60.7μs / itoaToVArray 62.6μs）、已证伪的"零分配 itoa"假设（itoaToVArray ≈ int64ToStringOnly，消除分配零收益）、idiv 根因（仓颉 1.0.5 不做除法强度削减，x/10→硬件 idiv ~18ns vs JVM 乘法 ~1ns）、达标/未达标清单、反序列化分配瓶颈（大数组 11.4×/大 Map 25.4×）；② 新增 T9.11 乘法强度削减 itoa 快速路径（用 n*倒数>>shift 替代 n/10，直写 ByteBuffer 绕过 stdx，含 5 条保留意见）、T9.12 自写 JSON 解析器绕过 stdx JsonReader（针对反序列化分配瓶颈，含 3 条保留意见），均标"实验性，待用户决策"。总进度统计 T9 行 52→54、合计 430→432。是否启动 T9.11/T9.12 由用户决策
>
> 2026-08-09（T4.6 VArray<T,$N> 集合支持）：补齐此前推迟的 VArray 编解码。核心障碍：VArray 的 `$N` 为编译期值参数，无法 `extend<T,$N>` 抽象为 IJsonAdapter 或泛型 helper（`extend<T,$N> VArray<T,$N>` / `func f<T,$N>` 均编译失败），故仅宏内联 codegen 可行。修复 `getCollectionElementType` 对 `VArray<T,N>` 顶层逗号的误解析（新增深度感知 `findTopLevelComma`）；新增 `isVArrayType`/`getVArraySize`/`getVArraySizeStr`/`varrayZeroExpr` 辅助。四路 codegen：树 encode 内联 `JsonArray(Array<JsonValue>(size, lambda))`；树 decode `match JsonArray → VArray<T,$N>({i=>T.fromJsonValue(arr[i])})`；流 encode 按索引遍历（VArray 不实现 Iterator/Iterable，`for-in` 失败，改 `0..size` 索引）；流 decode `readArray<T>` 后索引构造。`$N` 的 `$` 注入是关键难点：`\$(sizeNum)` 被 lex 为 `\$`+字面 `(sizeNum)`（`\$` 吞掉唯一 `$`），最终用 `\$$(sizeNum)`（双 `$`：`\$` 出字面 `$` + `$(sizeNum)` 出数字，相邻成 `$N`）。`$0` 特殊：仓颉 VArray<T,$0>(lambda) 仍以索引 0 调用一次 lambda 致访问空数组越界（实测确认），改用 `VArray<T,$0>(repeat: zero)`（zero 不存储，`varrayZeroExpr` 按类型给 `0`/`false`/`0.0`，整型/浮点字面量自适应目标类型）。同步修复继承树路径 `toJsonValueInheritFunc`/`fromJsonValueInheritFunc` 此前内联 `.toJsonValue()`/`.fromJsonValue()` 致 VArray 字段失败，改为路由 `treeFieldValueExpr`/`treeFieldReadExpr`。新增 T4.6 共 5 项测试（树序列化/树往返/流往返/struct 往返/$0 空数组）。core 124/124、databind 254/254 全部通过，无回归。已知限制：元素须值类型（仓颉 VArray 不可含引用类型）；不支持嵌套 VArray 解码 / Option<VArray> / Map 值为 VArray（受 `$N` 字面量约束，v1 推迟）
>
> 2026-08-09（T3.4 泛型类型支持）：补齐此前"宏跳过泛型类"的 T3.4 缺口——@Codable 应用于 `class Foo<T>` / `struct Foo<T>` 此前 doExpend 直接 `return cd.toTokens()` 不生成 IJsonAdapter 一致性，泛型类无法作为 Option<T>/Array<T> 等适配器的元素类型。本轮实现：utils.cj 新增 16 个泛型辅助（extractTypeParamNames 从声明 Token 自动检测类型参数含 out/in 变体、hasValueParam 探测 $N 值参数、isGenericTypeParam 判定字段类型是否为裸类型参数、typeParamsBracketed/nameWithTypeArgs 构造 `<T,U>` 与 `Foo<T,U>`、adapterWhereClause/mergedAdapterWhereClause/injectWhereClause/mergeWhereClause 合并既有 where 不丢失原约束如 `T <: Hashable & Equatable<T>` 时追加 `& IJsonAdapter<T>`、splitWhereClauses/splitTopLevelAmp/findConstraintOp/sliceTokens/joinStr/indexOfString/listContains 等切分辅助）；HandleClass/HandleStruct doExpend 自动检测类型参数（废弃 withGenericType 属性依赖），向类/结构体声明注入合并后的 where 子句，并生成 `extend<T> Foo<T> <: IJsonAdapter<Foo<T>> where ... {}` 空体声明一致性；类体方法返回类型/构造改用 selfType（Foo<T>，非泛型保留真实标识符 Token 零回归）。流式 buildStreamReadExpr/buildStreamElementWrite 顶部加泛型参数回退（IJsonAdapter 仅声明 toJsonValue/fromJsonValue 无 encode/decode，故 T 字段改用 readJsonValue/writeJsonValue 桥接，Option<T>/Array<T>/HashMap 经递归到达 T 后触发）。限制：泛型类需无参 init（decode 生成 `let obj = Foo<T>()`），故类型参数字段须可默认（Option<T>=None / Array<T> / HashMap）；直接 `var x: T` 无默认需 @CodableCreator（v1 未实现）；值参数（$N）无法抽象为 IJsonAdapter，回退跳过不改原声明；HandleStruct 流式无 HashMap 分支，泛型 struct 测试避免 HashMap<String,T> 字段。新增 T3.4 共 10 项测试（box 树/流往返 Int64+String、pair 双参、collections 树+流 Array+Option+HashMap、嵌套泛型 T3Outer<T3Box<T>>、generic struct 树+流、merge where HashSet<T> 验证 where 合并不丢约束）+ T8.7 共 2 项（嵌套泛型 T3Box<T3Box<Int64>> 树往返、Array<T3Box<String>> 流往返）；移除验证用探针 T3GenericProbe_test.cj。core 124/124、databind 266/266 全部通过，无回归
>
> 2026-08-09（5.8 P2 注解功能测试 + JsonValue 适配器修复）：补齐此前"已实现但无测试"的 3 个 P2 注解 @CodableAnyKey/@CodableAnyValue/@CodableRoot 及 JsonValue 字段类型。编写测试时发现并同步修复 3 处源码缺陷：① AnyValue 树式 decode 收集未映射键生成 `for ((key,v) in jsonObj)`，但 JsonObject 不可直接 for-in 迭代，改用 `JsonObjectHelper.entries(jsonObj)`（与 @CodableUnwrap 流式一致）；② AnyKey 流式展开生成 `v.encode(writer)`，但 JsonValue 的 encode 由 codec 包 direct extend 提供，仓颉 direct extend 跨包不激活（仅 interface extend 经 public import 生效），改在宏 buildStreamElementWrite/buildStreamReadExpr 新增 JsonValue 特例（`writer.writeJsonValue`/`reader.readJsonValue`，与基础类型处理一致），AnyKey 流式展开改 `writer.writeJsonValue(v)`，并移除失效的 JsonValueCodec.cj；③ @CodableRoot 树式 decode jsonObjExpr 内联 `jsonObj.get(root).getOrThrow()` 得 JsonValue，后续 `.get(field)` 因 JsonValue 无 get 编译失败，改为解包后 match 转 JsonObject 赋 innerObj、字段读取源指向 innerObj。保留 core/ext 的 `extend JsonValue <: IJsonAdapter<JsonValue>` 恒等映射（interface extend 跨包生效，使树路径 toJsonValue/fromJsonValue 与 `HashMap<String,JsonValue>` 可用）。新增 T5.10 共 6 项（AnyKey 序列化展开/AnyValue 反序列化收集/树往返/流往返 + JsonValue 普通字段树/流往返）+ T5.11 共 4 项（Root 序列化包装/反序列化解包/树往返/流往返）。HandleClass/HandleStruct 双镜像修复。core 124/124、databind 266→276 全部通过，无回归
>
> 2026-08-09（包内测试收尾 + T9.8/T9.9 基准）：补齐组织完备性缺口。新增三份包内单元测试：json4cj-annotations/enums/Enums_test.cj（2.5.1，7 枚举逐一 match 断言，7/7）、json4cj-databind/bind/JsonCodec_test.cj（3.10.1，手写 JcDemo <: JsonSerializable & JsonDeserializable<JcDemo> 验证 stringify/parse/write/read/writeTree/readTree + configure/naming/registry/readerFor/writerFor 全套 API，6/6）、json4cj-databind/node/NodeModel_test.cj（3.10.4，NodeFactory 类型化工厂 + JsonNode 树操作 + NodeCursor 导航 + NodePatch 构造，4/4）。2.5.2/2.5.3/3.10.5 标 [~]（由 databind macros_test 全量覆盖，非缺口）。6.7 宏集成测试经 cjc 编译验证（annotations enums 7/7 + databind macros_test 314/314）标 [x]。T9.8 内存占用基准（T9BenchMemory_test.cj，4 项 @Bench）：仓颉 std 无堆峰值/GC 统计 API，以流式（瞬态 buffer 不保留 DOM）vs 树式（构建 JsonValue DOM）吞吐差代理 GC/峰值压力——标量 0.92/0.95 µs（DOM 开销可忽略）、1000 元素集合 66.9/172.6 µs（树式 2.58× 慢，1000 个 JsonInt 节点即峰值/GC 源）。T9.9 并发性能（T9BenchConcurrency_test.cj，5 项）：2 安全 @Test（8 线程×200 次并发编/解码同一只读对象，输出一致性校验无损坏）+ 3 吞吐 @Bench（单线程 86.6 µs / 4 线程 790 µs / 编解码混合 476.8 µs，SyncCounter 屏障 + AtomicInt64 聚合）。cjpm bench 全 65 项 PASSED 0 失败，无死锁/panic。core 124/124、annotations enums 7/7、databind 314/314 全部通过，无回归。总进度 470→483/496（95%→97%）
>
> 2026-08-10（T2.3 元组 + T4.7 Range 类型支持）：补齐此前"语言限制推迟"的元组与区间编解码。仓颉禁止 `extend (T1,T2) <: IJsonAdapter`（元组无 IJsonAdapter）、Range 无自然 JSON 形态且无 IJsonAdapter 扩展，故均走宏内联 codegen。元组：树 encode 内联 `JsonArray` IIFE 按位置 `v[i].toJsonValue()`、decode `match JsonArray → (T1.fromJsonValue(arr[0]), ...)`（`t[i]` 索引须编译期字面量）；流 encode `startArray`+逐元素 `writeValue`、decode IIFE `startArray`+`readXxx()`+`endArray` 构造。Range：树 encode/decode 对象式 `{start,end,step,isClosed}`；流 encode 写对象、decode 委托 `JsonStreamCodec.readRange<T>`（core 新增，start/end 必需抛 JsonMissingField、step 缺省 1、isClosed 缺省 true，hasStart/hasEnd 固定 true）。Option<Tuple>/Option<Range> 经 treeOption* + readOption 桥接；Array<Tuple>/Array<Range> 树式内联 `Array<T>(arr.size(), {i=>readExpr})` 构造（集合 IJsonAdapter 要求 T<:IJsonAdapter，元组不满足；ArrayList/HashSet-of-tuple 树式为 v1 限制，流式已覆盖）。具名元组 `(name: T,...)` 仅类型层具名、构造按位置，getTupleElementTypes 剥离 `name:` 前缀。HandleClass+HandleStruct 双路径镜像。同步修复 3 处源码缺陷：① `findTopLevelComma`/`splitTopLevelCommas` 此前仅追踪 `<>` 深度，元组类型 `(Int64, String)` 的逗号被误判为顶层致 `getCollectionElementType` 截断为 `(Int64`，改为追踪 `()`/`[]`/`<>` 三类括号深度（亦修正嵌套元组与 `VArray<(Int64,String),$N>`）；② 继承树路径 `toJsonValueInheritFunc`/`fromJsonValueInheritFunc` 此前未路由 treeOption*，Option<Tuple/Range> 字段降级到 `.toJsonValue()`/`Option<T>.fromJsonValue()` 编译报错，改为与主 fromJsonValue/toJsonValue 一致走 `treeOptionFieldValueExpr`/`treeOptionFieldReadExpr`；③ `treeFieldReadExpr` 的 `jsonKindName($(jsonExpr).kind())` 因 `.` 优先级高于 `??`，当 jsonExpr 为 `jsonObj.get(name) ?? JsonNull()`（Option 路径传入）时 `.kind()` 误绑到 `JsonNull()` 致类型不匹配，改为 `jsonKindName(($(jsonExpr)).kind())` 加括号（4 处：VArray/Tuple/Range/Array 分支）。`isDirectObjectFieldType` 对 tuple/range 返回 false（无 IJsonAdapter，type token 不可作 `jsonIgnoredType()` 接收者）。新增 T2.3 共 7 项（2/3 元组树往返、嵌套、Option<Tuple> 树+流、Array<Tuple> 树+流、流往返、具名元组、struct 元组树+流）+ T4.7 共 3 项（Range 树往返半开/闭/step+迭代求和、流往返、struct Range 树+流）。core 124/124、annotations 7/7、databind 0 失败（281+322 两组全 PASSED）全部通过，无回归。T1~T8 达 100%（283/283）、合计 493/498（99%）
>
> 2026-08-10（三方端到端基准 + T9.11/T9.12 评估细化）：按用户要求新增「较大字符串与类端到端反/序列化」三方对比（json4cj / cangjieJSON / Jackson）。新增 docs/T9-e2e-three-way-bench.md（完整对比表 + 分析）、docs/jackson-bench/JacksonBenchE2E.java、json4cj-databind/src/macros_test/T9BenchE2E_test.cj（@Test T9E2EBench 8 @Bench：tree+stream × LargeBean+BigString）；cangjieJSON 基准用独立包 d:/tmp/cjjson-bench（依赖 cangjieJSON，显式 import stdx，临时 static 链接跑完即恢复 dynamic）。结论：对象路径 LargeBean 差距最大（7.6×~17.1×）、大字符串 BigString 收窄（2.2×~6.1×）；序列化 json4cj stream 已是仓颉最快（16.76 vs cangjieJSON 27.13μs），剩余 9.4× = itoa 地板；【头条新发现】反序列化 cangjieJSON（同 stdx JsonValue.fromStr 解析地板）在 LargeBean 快 json4cj 1.4-1.7×——解析步骤相同、差距在 fromJsonValue DOM→对象映射 codegen，证明反序列化有源码级头空间，部分推翻基线「反序列化无源码优化空间」结论 → T9.12 升档、新增低成本子杠杆「优化 fromJsonValue codegen」先于自写解析器；另发现 BigString stream 序列化退化（95.52μs，2× 慢于 tree）→ 新增 T9.14 源码级修复项。databind 全量 324/324 通过（新增 @Bench 类不影响 cjpm test）。总进度 493/498 → 494/500（99%）
>
> 2026-08-10（移植第三方大列表基准用例）：按用户要求将第三方 jackson_dataformat_yaml 性能用例 PerfBenchmark_test.cj（200×PerfLargeItem 110 字段大对象）移植入项目（json4cj-databind/src/macros_test/T9BenchLargeList_test.cj）。API 适配：@GenerateBackingProps+private var+getter/setter → @Codable 默认可见性 var（字段式）；@JsonProperty[value:"x"]（字段名==键名）→ 省略 @CodableKey；ObjectMapper.writeValueAsString(list)/deserialize → 包装类 T9PerfLargeList{items:Array<T9PerfLargeItem>} 的 toJson/fromJson(tree)+encode/decode(stream)，对齐 T9 双路径；MonoTime 单次计时+写文件 → @Bench（预热+多批中位）+@TestCase 往返断言，去文件副作用。@TestCase 闸门校验树+流双路径往返（含 61×?String，首次验证 ?String 流式编解码路径）。@Bench 4 项中位：tree 序 9.92/反 13.90、stream 序 5.51/反 15.92 ms（200×110），与 T9 模型一致（stream 序 1.8× 快于 tree 序；tree 反 13.90 快于 stream 反 15.92，复现 T9.6 stdx JsonReader 逐 token 开销致流式反序列化慢于树式）。databind 全量 325/325 通过（新增 1 @TestCase，@Bench 不计入 test）。总进度 494/500 → 495/501（99%）
>
> 2026-08-13（T10 大而全综合测试 + 继承路径 3 处宏缺陷修复）：新增 T10 大而全端到端测试（T10AllTypes_models_test.cj 模型 + T10AllTypes_test.cj 16 用例 + testdata/T10_*.json 5 固件），单继承层级覆盖前序全部类型与注解：CompBase(24 字段含 DateTime/@CodableFormat/BigInt/Decimal/Option/私有变量/4 类字段注解) + CompChild(12 字段:集合/嵌套集合/自定义对象/@CodableAlias) + CompGrand(12 字段:元组/枚举/Unit/VArray/Range/JsonValue/@CodablePolicy) + CompAnimal 多态。编写测试时发现并同步修复 HandleClass.cj 继承路径 3 处宏缺陷：① fromJsonValueInherit 忽略 @CodableFormat——父类 DateTime 字段在子类反序列化时退化为无格式 DateTime.parse,致 t10_5 hang,改为传 field.format(对齐主 fromJsonValue);② fromJsonValueInherit 忽略 @CodableAlias——父类带别名字段(如 nick)在 JSON 用别名(nick_name)时抛 JsonMissingField,改为先主键 containsKey 再逐别名回退(buildAliasFallbackExpr);③ toJsonValueInherit 忽略 @CodableFormat——父类 DateTime 字段在子类序列化时退化为 ISO "T" 格式,致带格式字段往返反序列化 TimeParseException,改为传 field.format(对齐主 toJsonValue,非格式字段 None 零回归)。三处修复均镜像主路径(own-field)已正确逻辑,继承路径(Inherit)此前漏传 format/alias。**cjc v1.0.5 编译器 bug 规避**:open class 继承另一类 + 自有字段 → 自有字段偏移错位(父类偏移正确),经 R29(non-open 12 字段继承通过)/R30(open 同结构字段值损坏如 mainItem.id=-8266262047940327384)对照实验确认,override/open override method 修饰符与字段数削减(12/10/8)均无效,触发条件为 open+继承+自有字段(与 method codegen/vtable 无关)。故 CompChild/CompGrand 均设为非 open 平级继承 CompBase(降三层为两层,字段类型覆盖不变;三层继承的宏递归机制由 T3.3.5 multiLevelInheritance 覆盖)。core 124/124、databind 325→341/341 全部通过,无回归。总进度 495/501 → 512/517（99%）
>
> 2026-08-13（三方端到端基准 v2 复测 + PerfLargeList + 数据落盘）：按用户要求复跑三方基准（json4cj/cangjieJSON/Jackson）并新增第 3 工作负载 PerfLargeList(200×110 字段,~665KB)，测试输入数据(类定义 .cj/.java + JSON 串 .json)单独落盘 docs/T9-e2e-bench-v2/data/(9 文件)。新增 T9DumpBenchData_test.cj @TestCase 物化 JSON 样本；Jackson JacksonBenchE2E.java + cangjieJSON Bench_test.cj 各扩展 2 bench（PerfLargeList ser/deser）。**T9.14 修复验证**：BigString stream ser 95.52→60.30μs（@Bench 中位,均值 55.82），−36.9%，对 Jackson 6.1×→3.9×，最差回归消除（未达单次 best-case 52，中位对中位仍 1.30× tree）。**entries/keys 修复验证**：LargeBean tree deser 35.36→28.61μs（−19.1%），cangjieJSON-vs-tree 差距 1.73×→1.48×；PerfLargeList(8000 HashMap entry)差距 1.30×（修复收益 HashMap 密集处集中）。**新发现·头条**：PerfLargeList stream 反序列化批量退化——stream deser 16.19ms 比 tree(12.36)慢 1.31×、比 cangjieJSON(9.477)慢 1.71×，与 v1 BigString stream ser 退化对称（stream 逐字段 token 分派在单对象省 DOM 占优、批量宽对象被 stdx 原生批量解析反超）；tree deser 已反超 stream deser → stream token 地板不再是 json4cj 反序列化下限，列为 T9.12 子杠杆2。序列化侧 json4cj stream 仍最快（PerfLargeList ser 4.906ms < cangjieJSON 9.114 < tree 10.01）。JSON 三方逐字节一致（1326/41125/664816 B）。Jackson 2.16.1。databind 341→342/342 通过（新增 T9DumpBenchData 1 @TestCase）。完整对比表+差异分析见 docs/T9-e2e-bench-v2/T9-e2e-three-way-bench-v2.md。总进度 512/517 → 513/518（99%）
>
> 2026-08-13（T11 适配 yaml2 三方测试用例）：按用户要求将 D:\code\wangdehaitest\yaml2（Jackson-databind 的 Cangjie 移植）下三方测试用例适配入 json4cj，新增 16 个 Y\*_test.cj（json4cj-databind/src/macros_test/）。API 映射：ObjectMapper.writeValueAsString / CjJsonDeserializeUtils.deserialize\<T\> → toJson/fromJson；@GenerateBackingProps+private var+getter/setter → @Codable+public var（字段式默认值）；@JsonProperty[value:"x"] → @CodableKey["x"]；@JsonIgnore → @CodableSkip。16 文件 194 用例：YamlContentModels(共享模型) + YList/YNone/YOptionField(基础集合/Option) + YFeatureContainer/YMmlResult/YMmlCmdReturn/YMultiConstruct/YPageNode/YInheritance/YQueryCondition(嵌套对象/继承/Option 套集合) + YJsonProperty(@CodableKey 改名+@CodableDefault 叠加,30 项) + YOptionContainer(Option 套集合/嵌套对象,32 项) + YByteArray(base64→数字数组) + YOptionCollection(集合元素为 Option:HashMap\<String,?T\>/ArrayList\<?T\>,22 项) + YNestedOptionField(嵌套集合对象带 Option 字段+3 层 HashMap,25 项)。关键适配点：Option 套集合 None 用 .isNone()(集合非 Equatable,== None 编译报 "generic type should be used with type argument")；HashMap 不保序→contains 断言+往返 deser→ser→deser→字段；Jackson base64 Array\<Byte\>→数字数组(Array\<UInt8\>)；@CodableKey+@CodableDefault 单字段叠加验证通过(batch-3a 最大未验证风险,30 项全绿)；仓颉 raw string 末尾 " 被 "## 吞(空串值 "key":"" 片段断言失效)→改精确全串等值(已存记忆 cangjie-rawstring-trailing-quote)；Float32 用 2.5(二进制精确)不用 3.14(提升 Float64 全精度展开)。databind 342→536 全部通过(+194,0 失败 0 回归),cjpm build 通过。PerfBenchmark_test.cj 已由 T9.15 适配不重复。总进度 513/518 → 707/712（99%）
>
> 2026-08-13（T9.12 子杠杆1续·HashMap/ArrayList 树式反序列化物化消除）：分析 v2 三方基准 json4cj tree vs cangjieJSON 反序列化差距——逐字段 codegen 对比证实宏字段映射逐字等价（try/catch+getOrThrow 闭包+Option 路径均 common-mode，差距不在宏），1.30-1.48× 余量定位在核心适配器 3 处：① HashMap.fromJsonValue 经 JsonObjectHelper.entries() 物化 ArrayList→Array+N tuple（cangjieJSON 直接 getFields 迭代；2026-08-11 entries 修复仅换 getFields 未去物化包装）；② ArrayList.fromJsonValue 动态扩容（cangjieJSON 预分配 ArrayList(size,init)，json4cj 自身 Array<T> 已预分配但 ArrayList 未对齐）；③ Int32 range check（保留安全）。本轮修①②（json4cj-core/src/ext/IJsonAdapter.cj：HashMap 改 for((k,v) in obj.getFields())、ArrayList 改 ArrayList<T>(arr.size(),{index=>T.fromJsonValue(arr[index])})，均对齐 cangjieJSON 已验证写法）。同会话 3×before/3×after 分布对比（控制组 ser/stream-deser 持平证非噪声）：PerfLargeList tree deser 中位 12.07→10.90ms（-9.7%，after-max 11.21<baseline-min 11.61 完全分离）、LargeBean tree deser 中位 30.09→28.11us（-6.6%，after-max 28.48<baseline-min 29.93 完全分离）。core 124/124、databind 536/536 不回归。commit daf0b6e。子杠杆2（stream deser 批量退化）仍待推进。详见 T9.12 条目
