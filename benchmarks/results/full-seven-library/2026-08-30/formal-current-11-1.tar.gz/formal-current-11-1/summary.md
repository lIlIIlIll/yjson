# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.539 us | 57.370 us | 3.449 us | 3.456 us | 2.458 us | 0.171 us | 0.066 us | 19.62% |
| address_decode | 0.814 us | 37.248 us | 3.306 us | 3.454 us | 2.015 us | 0.310 us | 0.069 us | 8.70% |
| person_encode | 3.879 us | 82.005 us | 17.402 us | 5.509 us | 10.738 us | 0.576 us | 0.257 us | 14.17% |
| person_decode | 10.064 us | 99.132 us | 28.129 us | 22.464 us | 15.552 us | 1.139 us | 0.427 us | 10.16% |
| large_array_encode | 47.104 us | 558.454 us | 248.704 us | 91.443 us | 75.776 us | 8.940 us | 3.722 us | 8.11% |
| large_array_decode | 47.663 us | 1073.004 us | 418.259 us | 175.275 us | 78.336 us | 18.886 us | 5.052 us | 10.03% |
| large_map_encode | 7.168 us | 284.001 us | 174.493 us | 126.797 us | 129.586 us | 1.851 us | 1.741 us | 15.74% |
| large_map_decode | 28.581 us | 589.577 us | 351.211 us | 223.232 us | 229.655 us | 5.428 us | 4.018 us | 11.25% |
| deep_nested_encode | 61.184 us | 363.048 us | 171.648 us | 85.606 us | 73.865 us | 4.506 us | 2.604 us | 6.53% |
| deep_nested_decode | 76.130 us | 606.595 us | 255.283 us | 142.713 us | 96.768 us | 10.534 us | 3.499 us | 9.16% |
