# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.564 us | 92.127 us | 2.836 us | 3.398 us | 2.946 us | 0.170 us | 0.064 us | 18.90% |
| address_decode | 0.944 us | 37.182 us | 3.098 us | 3.449 us | 2.042 us | 0.304 us | 0.067 us | 14.20% |
| person_encode | 3.836 us | 123.469 us | 16.211 us | 5.465 us | 10.058 us | 0.584 us | 0.264 us | 9.54% |
| person_decode | 10.356 us | 124.353 us | 24.933 us | 19.891 us | 15.228 us | 1.134 us | 0.427 us | 13.11% |
| large_array_encode | 72.185 us | 633.995 us | 265.352 us | 92.306 us | 76.370 us | 8.927 us | 3.961 us | 16.32% |
| large_array_decode | 66.086 us | 1100.139 us | 316.129 us | 211.037 us | 80.198 us | 18.932 us | 5.107 us | 9.26% |
| large_map_encode | 7.733 us | 370.841 us | 169.543 us | 121.402 us | 117.848 us | 1.781 us | 1.752 us | 16.52% |
| large_map_decode | 33.637 us | 716.636 us | 293.737 us | 222.504 us | 202.004 us | 5.277 us | 3.933 us | 20.68% |
| deep_nested_encode | 84.492 us | 426.165 us | 172.341 us | 84.366 us | 72.480 us | 4.520 us | 2.508 us | 10.02% |
| deep_nested_decode | 94.873 us | 784.964 us | 222.617 us | 144.320 us | 93.575 us | 10.533 us | 3.395 us | 9.46% |
