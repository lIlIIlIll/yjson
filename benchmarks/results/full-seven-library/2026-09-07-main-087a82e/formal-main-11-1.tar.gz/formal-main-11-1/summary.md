# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.305 us | 3.324 us | 2.837 us | 3.425 us | 2.991 us | 0.169 us | 0.067 us | 15.09% |
| address_decode | 1.502 us | 2.425 us | 3.078 us | 3.449 us | 2.052 us | 0.307 us | 0.067 us | 11.73% |
| person_encode | 2.773 us | 12.394 us | 15.982 us | 5.493 us | 10.581 us | 0.577 us | 0.269 us | 19.15% |
| person_decode | 9.205 us | 21.220 us | 25.825 us | 19.973 us | 14.925 us | 1.129 us | 0.425 us | 17.11% |
| large_array_encode | 28.464 us | 113.644 us | 261.336 us | 91.857 us | 76.064 us | 9.020 us | 3.937 us | 10.04% |
| large_array_decode | 132.692 us | 205.405 us | 317.075 us | 226.204 us | 79.915 us | 18.613 us | 5.051 us | 11.15% |
| large_map_encode | 6.856 us | 135.270 us | 162.038 us | 124.272 us | 125.398 us | 1.811 us | 1.778 us | 7.62% |
| large_map_decode | 49.550 us | 315.729 us | 295.572 us | 215.065 us | 217.086 us | 5.086 us | 3.919 us | 22.28% |
| deep_nested_encode | 55.721 us | 102.764 us | 172.213 us | 79.450 us | 74.197 us | 4.498 us | 2.491 us | 14.08% |
| deep_nested_decode | 387.172 us | 197.653 us | 230.720 us | 160.719 us | 94.381 us | 10.410 us | 3.428 us | 14.13% |
