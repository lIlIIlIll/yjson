# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.279 us | 3.052 us | 2.840 us | 3.471 us | 2.961 us | 0.169 us | 0.066 us | 17.04% |
| address_decode | 1.570 us | 2.420 us | 3.107 us | 3.441 us | 2.047 us | 0.304 us | 0.066 us | 8.89% |
| person_encode | 3.187 us | 12.550 us | 16.246 us | 5.462 us | 10.828 us | 0.576 us | 0.269 us | 30.89% |
| person_decode | 8.346 us | 19.188 us | 26.047 us | 19.916 us | 14.935 us | 1.136 us | 0.428 us | 10.09% |
| large_array_encode | 28.877 us | 115.411 us | 255.277 us | 92.486 us | 75.933 us | 8.878 us | 4.231 us | 12.57% |
| large_array_decode | 129.378 us | 200.035 us | 310.735 us | 223.328 us | 78.876 us | 18.540 us | 5.052 us | 8.51% |
| large_map_encode | 6.957 us | 138.527 us | 160.427 us | 123.440 us | 127.793 us | 1.789 us | 1.739 us | 10.76% |
| large_map_decode | 49.210 us | 316.508 us | 288.467 us | 203.392 us | 208.025 us | 5.102 us | 3.961 us | 14.12% |
| deep_nested_encode | 54.989 us | 96.611 us | 172.437 us | 85.193 us | 70.899 us | 4.488 us | 2.535 us | 14.87% |
| deep_nested_decode | 374.897 us | 195.640 us | 211.924 us | 162.089 us | 96.250 us | 10.468 us | 3.421 us | 8.24% |
