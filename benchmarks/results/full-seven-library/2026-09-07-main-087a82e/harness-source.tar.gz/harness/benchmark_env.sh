#!/usr/bin/env bash

BENCH_ROOT=/home/chenqian/yjson-seven-preflight-20260831.PHZEs1
BENCH_SDK=/home/chenqian/fastjson-bench-sdk-20260803
BENCH_RUNTIME_VIEW="$BENCH_ROOT/runtime-view"

mkdir -p "$BENCH_RUNTIME_VIEW"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}"
source "$BENCH_SDK/cangjie/envsetup.sh"
BENCH_SDK_LD_LIBRARY_PATH="$LD_LIBRARY_PATH"
unset LD_LIBRARY_PATH
BENCH_SANITIZED_PATHS=()
IFS=: read -r -a BENCH_SDK_PATHS <<< "$BENCH_SDK_LD_LIBRARY_PATH"
for BENCH_SDK_PATH in "${BENCH_SDK_PATHS[@]}"; do
  [[ -n "$BENCH_SDK_PATH" ]] || continue
  if [[ -f "$BENCH_SDK_PATH/libcangjie-runtime.so" ]]; then
    for BENCH_LIBRARY in "$BENCH_SDK_PATH"/*; do
      BENCH_NAME=${BENCH_LIBRARY##*/}
      case "$BENCH_NAME" in
        libpcre2*) ;;
        *) ln -sf -- "$BENCH_LIBRARY" "$BENCH_RUNTIME_VIEW/$BENCH_NAME" ;;
      esac
    done
  else
    BENCH_SANITIZED_PATHS+=("$BENCH_SDK_PATH")
  fi
done
BENCH_SANITIZED_PATHS=("$BENCH_RUNTIME_VIEW" "${BENCH_SANITIZED_PATHS[@]}")
printf -v BENCH_LD_LIBRARY_PATH '%s:' "${BENCH_SANITIZED_PATHS[@]}"
export LD_LIBRARY_PATH=${BENCH_LD_LIBRARY_PATH%:}
export CANGJIE_STDX_PATH="$BENCH_SDK/linux_x86_64_cjnative/dynamic/stdx"
export STDX_FFI_LIB="-L $BENCH_SDK/linux_x86_64_cjnative/static/stdx -lstdx.encoding.jsonFFI -lstdx.encoding.json.streamFFI"
export YJSON_CROSSLANG_CORPUS_DIR="$BENCH_ROOT/repo/benchmarks/results/stream-v1/2026-08-28/formal-cell-1/payloads"
export cjHeapSize=128MB
export LC_ALL=C
