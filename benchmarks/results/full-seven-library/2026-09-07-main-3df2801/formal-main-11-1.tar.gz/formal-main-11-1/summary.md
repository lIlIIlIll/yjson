# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.335 us | 3.327 us | 2.818 us | 3.403 us | 3.074 us | 0.169 us | 0.065 us | 8.71% |
| address_decode | 1.525 us | 2.396 us | 3.095 us | 3.479 us | 2.048 us | 0.306 us | 0.067 us | 8.72% |
| person_encode | 2.763 us | 12.594 us | 16.445 us | 5.512 us | 10.978 us | 0.580 us | 0.270 us | 14.93% |
| person_decode | 8.167 us | 21.310 us | 24.308 us | 19.802 us | 15.182 us | 1.121 us | 0.430 us | 28.24% |
| large_array_encode | 30.230 us | 112.132 us | 265.465 us | 101.188 us | 77.248 us | 8.920 us | 3.802 us | 15.83% |
| large_array_decode | 128.152 us | 211.058 us | 300.719 us | 211.251 us | 78.308 us | 18.481 us | 5.092 us | 12.26% |
| large_map_encode | 6.911 us | 135.700 us | 160.250 us | 126.506 us | 116.736 us | 1.817 us | 1.745 us | 16.39% |
| large_map_decode | 51.833 us | 316.007 us | 304.152 us | 224.736 us | 221.318 us | 5.110 us | 3.910 us | 19.53% |
| deep_nested_encode | 47.279 us | 101.470 us | 172.963 us | 84.190 us | 70.612 us | 4.515 us | 2.516 us | 18.61% |
| deep_nested_decode | 381.001 us | 199.987 us | 234.134 us | 146.717 us | 96.256 us | 10.349 us | 3.381 us | 10.03% |
