# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.352 us | 3.328 us | 3.012 us | 3.439 us | 2.993 us | 0.171 us | 0.064 us | 6.99% |
| address_decode | 1.441 us | 2.272 us | 3.141 us | 3.463 us | 2.041 us | 0.303 us | 0.068 us | 9.44% |
| person_encode | 2.790 us | 12.451 us | 16.228 us | 5.522 us | 10.807 us | 0.576 us | 0.268 us | 20.78% |
| person_decode | 8.787 us | 21.528 us | 23.434 us | 19.803 us | 15.000 us | 1.132 us | 0.428 us | 17.24% |
| large_array_encode | 29.947 us | 110.982 us | 266.532 us | 92.128 us | 75.797 us | 8.948 us | 4.195 us | 17.07% |
| large_array_decode | 128.124 us | 205.158 us | 311.836 us | 222.162 us | 84.072 us | 18.560 us | 5.028 us | 9.23% |
| large_map_encode | 6.865 us | 140.355 us | 159.085 us | 125.937 us | 105.971 us | 1.809 us | 1.732 us | 17.62% |
| large_map_decode | 50.537 us | 306.371 us | 297.182 us | 220.016 us | 211.071 us | 5.054 us | 4.013 us | 15.02% |
| deep_nested_encode | 48.196 us | 100.192 us | 173.245 us | 80.522 us | 68.255 us | 4.486 us | 2.654 us | 14.98% |
| deep_nested_decode | 371.596 us | 197.669 us | 242.864 us | 141.084 us | 96.716 us | 10.453 us | 3.377 us | 8.59% |
