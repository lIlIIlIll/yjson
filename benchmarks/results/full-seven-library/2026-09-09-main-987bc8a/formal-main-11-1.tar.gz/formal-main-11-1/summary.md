# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.059 us | 3.316 us | 3.423 us | 3.475 us | 2.464 us | 0.181 us | 0.066 us | 11.09% |
| address_decode | 1.490 us | 2.430 us | 3.246 us | 3.455 us | 2.040 us | 0.323 us | 0.072 us | 12.86% |
| person_encode | 1.731 us | 13.190 us | 16.767 us | 5.466 us | 10.920 us | 0.561 us | 0.271 us | 16.99% |
| person_decode | 7.948 us | 21.637 us | 28.208 us | 20.246 us | 15.333 us | 1.108 us | 0.420 us | 8.68% |
| large_array_encode | 28.704 us | 92.416 us | 250.470 us | 92.430 us | 76.544 us | 8.993 us | 4.172 us | 16.49% |
| large_array_decode | 108.641 us | 179.660 us | 418.300 us | 179.152 us | 77.982 us | 18.879 us | 5.076 us | 14.69% |
| large_map_encode | 6.819 us | 115.840 us | 182.885 us | 135.162 us | 131.453 us | 1.745 us | 1.745 us | 8.06% |
| large_map_decode | 32.572 us | 253.440 us | 347.059 us | 221.568 us | 228.782 us | 5.343 us | 4.000 us | 9.95% |
| deep_nested_encode | 44.055 us | 79.104 us | 171.008 us | 85.376 us | 74.624 us | 4.495 us | 2.496 us | 11.23% |
| deep_nested_decode | 324.476 us | 164.389 us | 238.824 us | 141.440 us | 96.853 us | 10.451 us | 3.454 us | 10.65% |
