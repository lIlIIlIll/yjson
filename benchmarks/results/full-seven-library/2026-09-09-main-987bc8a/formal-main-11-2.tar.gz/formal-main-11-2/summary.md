# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.066 us | 3.340 us | 3.179 us | 3.437 us | 2.480 us | 0.179 us | 0.067 us | 12.78% |
| address_decode | 1.505 us | 2.439 us | 3.512 us | 3.446 us | 2.032 us | 0.325 us | 0.073 us | 26.97% |
| person_encode | 1.748 us | 13.433 us | 17.337 us | 5.454 us | 10.080 us | 0.565 us | 0.269 us | 9.73% |
| person_decode | 8.201 us | 21.760 us | 26.771 us | 20.265 us | 15.443 us | 1.114 us | 0.421 us | 12.14% |
| large_array_encode | 28.677 us | 99.807 us | 250.376 us | 92.003 us | 76.346 us | 9.178 us | 4.168 us | 17.94% |
| large_array_decode | 105.334 us | 183.183 us | 413.851 us | 174.592 us | 77.874 us | 18.908 us | 5.134 us | 14.47% |
| large_map_encode | 6.773 us | 114.816 us | 178.072 us | 130.441 us | 131.483 us | 1.752 us | 1.744 us | 17.61% |
| large_map_decode | 33.024 us | 248.173 us | 320.931 us | 222.208 us | 231.520 us | 5.306 us | 3.930 us | 14.50% |
| deep_nested_encode | 47.616 us | 78.944 us | 171.808 us | 85.043 us | 74.381 us | 4.457 us | 2.501 us | 13.59% |
| deep_nested_decode | 316.554 us | 160.401 us | 274.398 us | 142.336 us | 96.469 us | 10.475 us | 3.455 us | 10.82% |
