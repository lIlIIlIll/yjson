# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.043 us | 3.145 us | 3.133 us | 3.457 us | 2.480 us | 0.178 us | 0.066 us | 10.77% |
| address_decode | 1.495 us | 2.443 us | 3.372 us | 3.442 us | 2.042 us | 0.324 us | 0.072 us | 9.12% |
| person_encode | 1.713 us | 13.228 us | 17.094 us | 5.451 us | 9.943 us | 0.568 us | 0.267 us | 14.57% |
| person_decode | 8.209 us | 21.457 us | 26.841 us | 20.213 us | 15.516 us | 1.108 us | 0.421 us | 20.59% |
| large_array_encode | 28.672 us | 88.993 us | 250.059 us | 91.822 us | 75.814 us | 9.186 us | 4.147 us | 19.21% |
| large_array_decode | 108.629 us | 178.466 us | 418.215 us | 173.888 us | 78.176 us | 18.734 us | 5.029 us | 16.31% |
| large_map_encode | 6.893 us | 130.176 us | 174.753 us | 132.022 us | 130.475 us | 1.774 us | 1.743 us | 6.18% |
| large_map_decode | 36.128 us | 249.687 us | 309.894 us | 221.890 us | 231.899 us | 5.376 us | 3.975 us | 13.41% |
| deep_nested_encode | 47.797 us | 80.448 us | 171.817 us | 85.248 us | 74.496 us | 4.521 us | 2.466 us | 8.34% |
| deep_nested_decode | 325.760 us | 156.603 us | 222.966 us | 141.814 us | 96.393 us | 10.408 us | 3.429 us | 10.78% |
