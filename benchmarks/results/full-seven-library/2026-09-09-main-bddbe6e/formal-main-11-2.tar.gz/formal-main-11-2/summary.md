# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 1.050 us | 3.002 us | 3.107 us | 3.426 us | 2.457 us | 0.180 us | 0.066 us | 9.36% |
| address_decode | 1.509 us | 2.439 us | 3.545 us | 3.437 us | 2.008 us | 0.322 us | 0.074 us | 9.33% |
| person_encode | 1.717 us | 12.660 us | 17.746 us | 5.463 us | 10.003 us | 0.562 us | 0.267 us | 11.20% |
| person_decode | 8.094 us | 21.504 us | 27.952 us | 20.632 us | 15.347 us | 1.114 us | 0.420 us | 8.45% |
| large_array_encode | 28.465 us | 93.706 us | 249.131 us | 92.416 us | 75.729 us | 9.060 us | 4.163 us | 6.81% |
| large_array_decode | 107.986 us | 182.805 us | 421.106 us | 174.720 us | 78.080 us | 19.057 us | 5.064 us | 13.88% |
| large_map_encode | 6.779 us | 129.396 us | 174.803 us | 127.590 us | 132.165 us | 1.727 us | 1.734 us | 6.71% |
| large_map_decode | 33.280 us | 248.149 us | 350.976 us | 222.605 us | 228.864 us | 5.297 us | 3.955 us | 16.32% |
| deep_nested_encode | 47.031 us | 80.576 us | 172.032 us | 85.376 us | 74.496 us | 4.486 us | 2.460 us | 14.04% |
| deep_nested_decode | 306.889 us | 164.182 us | 248.285 us | 141.824 us | 96.256 us | 10.413 us | 3.425 us | 16.32% |
