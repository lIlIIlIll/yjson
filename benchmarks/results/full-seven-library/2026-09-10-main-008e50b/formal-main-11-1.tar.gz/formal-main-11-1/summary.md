# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 0.255 us | 0.661 us | 0.669 us | 0.687 us | 0.567 us | 0.107 us | 0.047 us | 11.70% |
| address_decode | 0.137 us | 1.075 us | 0.360 us | 1.250 us | 0.478 us | 0.181 us | 0.040 us | 11.39% |
| person_encode | 0.666 us | 2.472 us | 3.953 us | 1.575 us | 2.288 us | 0.315 us | 0.137 us | 4.99% |
| person_decode | 0.964 us | 4.634 us | 3.119 us | 5.364 us | 3.090 us | 0.644 us | 0.226 us | 5.55% |
| large_array_encode | 10.725 us | 22.242 us | 58.059 us | 26.119 us | 19.274 us | 4.558 us | 2.821 us | 9.23% |
| large_array_decode | 21.027 us | 41.196 us | 27.399 us | 61.319 us | 28.159 us | 9.272 us | 3.161 us | 5.31% |
| large_map_encode | 2.120 us | 15.924 us | 32.529 us | 19.622 us | 16.915 us | 1.551 us | 1.074 us | 4.18% |
| large_map_decode | 6.510 us | 34.800 us | 35.894 us | 39.237 us | 33.753 us | 3.074 us | 2.402 us | 2.43% |
| deep_nested_encode | 11.780 us | 17.314 us | 36.504 us | 20.273 us | 15.149 us | 2.542 us | 1.478 us | 4.45% |
| deep_nested_decode | 30.529 us | 30.642 us | 22.875 us | 38.820 us | 21.209 us | 5.463 us | 1.896 us | 2.58% |
