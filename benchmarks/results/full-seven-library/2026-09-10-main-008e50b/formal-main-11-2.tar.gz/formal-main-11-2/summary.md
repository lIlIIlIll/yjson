# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 0.297 us | 0.724 us | 0.770 us | 0.777 us | 0.649 us | 0.119 us | 0.051 us | 13.49% |
| address_decode | 0.158 us | 1.243 us | 0.413 us | 1.439 us | 0.541 us | 0.203 us | 0.044 us | 13.93% |
| person_encode | 0.767 us | 2.870 us | 4.557 us | 1.813 us | 2.626 us | 0.362 us | 0.151 us | 8.66% |
| person_decode | 1.081 us | 5.258 us | 3.464 us | 5.995 us | 3.508 us | 0.721 us | 0.254 us | 9.30% |
| large_array_encode | 11.987 us | 24.691 us | 65.484 us | 29.276 us | 21.757 us | 5.063 us | 2.794 us | 9.26% |
| large_array_decode | 23.765 us | 46.327 us | 30.231 us | 69.087 us | 31.836 us | 10.077 us | 3.420 us | 8.56% |
| large_map_encode | 2.350 us | 17.590 us | 36.412 us | 21.804 us | 19.560 us | 1.650 us | 1.176 us | 8.08% |
| large_map_decode | 7.355 us | 39.397 us | 40.563 us | 44.449 us | 37.728 us | 3.350 us | 2.660 us | 8.53% |
| deep_nested_encode | 13.125 us | 19.467 us | 41.231 us | 22.654 us | 17.022 us | 2.809 us | 1.575 us | 9.43% |
| deep_nested_decode | 33.975 us | 34.780 us | 25.950 us | 44.101 us | 24.069 us | 6.121 us | 2.081 us | 8.07% |
