#!/usr/bin/env bash

BENCH_ROOT=/home/runner/work/_temp/yjson-seven
BENCH_SDK=/home/runner/work/_temp/setup-cangjie-cjv/toolchains
BENCH_RUNTIME_VIEW="$BENCH_ROOT/runtime-view"

mkdir -p "$BENCH_RUNTIME_VIEW"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}"
source "$BENCH_SDK/cangjie/envsetup.sh"
BENCH_SDK_LD_LIBRARY_PATH="$LD_LIBRARY_PATH"
unset LD_LIBRARY_PATH
BENCH_SANITIZED_PATHS=()
IFS=: read -r -a BENCH_SDK_PATHS <<< "$BENCH_SDK_LD_LIBRARY_PATH"
for BENCH_SDK_PATH in "${BENCH_SDK_PATHS[@]}"; do
  [[ -n "$BENCH_SDK_PATH" ]] || continue
  if [[ -f "$BENCH_SDK_PATH/libcangjie-runtime.so" ]]; then
    for BENCH_LIBRARY in "$BENCH_SDK_PATH"/*; do
      BENCH_NAME=${BENCH_LIBRARY##*/}
      case "$BENCH_NAME" in
        libpcre2*) ;;
        *) ln -sf -- "$BENCH_LIBRARY" "$BENCH_RUNTIME_VIEW/$BENCH_NAME" ;;
      esac
    done
  else
    BENCH_SANITIZED_PATHS+=("$BENCH_SDK_PATH")
  fi
done
BENCH_SANITIZED_PATHS=("$BENCH_RUNTIME_VIEW" "${BENCH_SANITIZED_PATHS[@]}")
printf -v BENCH_LD_LIBRARY_PATH '%s:' "${BENCH_SANITIZED_PATHS[@]}"
export LD_LIBRARY_PATH=${BENCH_LD_LIBRARY_PATH%:}
export CANGJIE_STDX_PATH="$BENCH_SDK/linux_x86_64_cjnative/dynamic/stdx"
export STDX_FFI_LIB="-L $BENCH_SDK/linux_x86_64_cjnative/static/stdx -lstdx.encoding.jsonFFI -lstdx.encoding.json.streamFFI"
export YJSON_CROSSLANG_CORPUS_DIR="$BENCH_ROOT/repo/benchmarks/results/stream-v1/2026-08-28/formal-cell-1/payloads"
export cjHeapSize=128MB
export LC_ALL=C
# (Re)build the sanitized runtime view from the SDK runtime directory.
# The bundled SDK envsetup derives its runtime directory from a shell
# variable that is only defined under zsh; under bash it resolves to a
# missing path, so the view is populated directly from the SDK. The view
# itself is excluded from the input to keep the symlinks idempotent.
_runtime_dir="${BENCH_SDK}/cangjie/runtime/lib/linux_x86_64_cjnative"
if [[ -f "${_runtime_dir}/libcangjie-runtime.so" ]]; then
    for _lib in "${_runtime_dir}"/*; do
        _name="${_lib##*/}"
        case "${_name}" in libpcre2*) ;; *) ln -sf -- "${_lib}" "${BENCH_RUNTIME_VIEW}/${_name}" ;; esac
    done
fi
export LD_LIBRARY_PATH="${BENCH_RUNTIME_VIEW}:${BENCH_SDK}/cangjie/third_party/llvm/lib:${BENCH_SDK}/cangjie/tools/lib${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}"
