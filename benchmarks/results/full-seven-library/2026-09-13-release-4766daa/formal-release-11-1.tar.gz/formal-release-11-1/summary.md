# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 0.916 us | 2.761 us | 3.066 us | 3.474 us | 2.477 us | 0.179 us | 0.067 us | 19.19% |
| address_decode | 1.481 us | 2.453 us | 3.606 us | 3.437 us | 2.038 us | 0.321 us | 0.071 us | 11.52% |
| person_encode | 1.650 us | 13.324 us | 18.179 us | 5.074 us | 10.536 us | 0.559 us | 0.266 us | 19.19% |
| person_decode | 7.893 us | 21.590 us | 27.944 us | 20.854 us | 15.420 us | 1.115 us | 0.420 us | 12.91% |
| large_array_encode | 28.814 us | 99.013 us | 250.368 us | 92.073 us | 75.776 us | 9.167 us | 4.137 us | 7.81% |
| large_array_decode | 106.161 us | 182.449 us | 421.871 us | 172.160 us | 77.952 us | 18.861 us | 5.076 us | 8.09% |
| large_map_encode | 6.292 us | 131.086 us | 180.075 us | 131.605 us | 129.490 us | 1.781 us | 1.733 us | 6.51% |
| large_map_decode | 29.624 us | 252.288 us | 351.808 us | 222.464 us | 227.365 us | 5.301 us | 3.888 us | 7.15% |
| deep_nested_encode | 43.557 us | 78.421 us | 171.805 us | 85.589 us | 74.069 us | 4.511 us | 2.506 us | 16.77% |
| deep_nested_decode | 316.985 us | 170.364 us | 241.074 us | 143.040 us | 96.320 us | 10.440 us | 3.411 us | 15.68% |
