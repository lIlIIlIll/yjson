# Full optimal-public-API JSON benchmark

Times are median ns/op across 11 independent process rounds. Lower is better.

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 | Max CV |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| address_encode | 0.900 us | 3.325 us | 3.185 us | 3.476 us | 2.489 us | 0.178 us | 0.066 us | 10.37% |
| address_decode | 1.490 us | 2.406 us | 3.395 us | 3.441 us | 2.054 us | 0.319 us | 0.072 us | 12.81% |
| person_encode | 1.700 us | 13.254 us | 16.956 us | 5.425 us | 10.415 us | 0.564 us | 0.267 us | 10.23% |
| person_decode | 6.446 us | 21.810 us | 26.928 us | 21.316 us | 15.621 us | 1.112 us | 0.419 us | 18.70% |
| large_array_encode | 28.847 us | 100.328 us | 251.520 us | 91.904 us | 75.840 us | 9.042 us | 4.162 us | 9.81% |
| large_array_decode | 107.767 us | 187.745 us | 397.481 us | 175.659 us | 77.376 us | 18.908 us | 5.154 us | 8.68% |
| large_map_encode | 6.075 us | 130.189 us | 179.092 us | 130.409 us | 129.510 us | 1.771 us | 1.861 us | 6.45% |
| large_map_decode | 29.717 us | 249.920 us | 350.483 us | 224.512 us | 227.156 us | 5.323 us | 3.943 us | 7.01% |
| deep_nested_encode | 45.090 us | 71.863 us | 171.648 us | 85.786 us | 73.728 us | 4.549 us | 2.475 us | 12.87% |
| deep_nested_decode | 325.770 us | 161.899 us | 263.682 us | 144.555 us | 96.069 us | 10.454 us | 3.400 us | 10.05% |
