#!/usr/bin/env bash
set -euo pipefail

BENCH_ROOT=/home/chenqian/yjson-pr30-af8693f
BENCH_SDK=/home/chenqian/cangjie_sdk/sts1.1.3
export CANGJIE_SDK_ROOT="$BENCH_SDK"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}"
source "$BENCH_SDK/envsetup.sh"
export CANGJIE_STDX_PATH="$BENCH_SDK/linux_x86_64_cjnative/dynamic/stdx"
export STDX_FFI_LIB="-L $BENCH_SDK/linux_x86_64_cjnative/static/stdx -lstdx.encoding.jsonFFI -lstdx.encoding.json.streamFFI"
export YJSON_CROSSLANG_CORPUS_DIR="$BENCH_ROOT/repo/benchmarks/results/stream-v1/2026-08-28/formal-cell-1/payloads"
export cjHeapSize=128MB
export LC_ALL=C
