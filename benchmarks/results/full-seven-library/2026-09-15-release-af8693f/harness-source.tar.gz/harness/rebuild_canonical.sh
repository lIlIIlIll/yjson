#!/usr/bin/env bash
set -euo pipefail

ROOT=/home/chenqian/yjson-pr30-af8693f
source "$ROOT/harness/benchmark_env.sh"
rm -rf "$ROOT/canonical-build-logs"
mkdir -p "$ROOT/canonical-build-logs"

(
  cd "$ROOT/repo/packages/benchmarks"
  cjpm clean
  cjpm bench --no-color --filter 'ComprehensiveJsonCompareBenchmarks.yjsonStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/yjson-stdx.log" 2>&1

(
  cd "$ROOT/harness/cjjson"
  cjpm clean
  cjpm bench --no-color --filter 'CangjieJsonOptimalBenchmarks.cjjsonStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/cangjiejson.log" 2>&1

(
  cd "$ROOT/harness/json4cj"
  cjpm clean
  cjpm bench --no-color --filter 'Json4CjOptimalBenchmarks.json4cjStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/json4cj.log" 2>&1

(
  cd "$ROOT/cjfast-json"
  cjpm clean
  cjpm bench --no-color --filter 'CjFastJsonComprehensiveBenchmarks.cjfastStringDecodeAddress*'
) >"$ROOT/canonical-build-logs/cjfast-json.log" 2>&1

(
  cd "$ROOT/harness/java"
  mvn -q package
) >"$ROOT/canonical-build-logs/java.log" 2>&1

printf 'canonical harnesses rebuilt and validated\n'
