#!/usr/bin/env bash
set -euo pipefail

# LLVM llc requires a large stack for optimization passes on complex IR.
ulimit -Ss 131072 2>/dev/null || true

repo=$(cd "$(dirname "$0")/.." && pwd)
job=${1:-}
mode=${2:-}
modules=$(mktemp -d "${TMPDIR:-/tmp}/yjson-ci-modules.XXXXXX")
trap 'rm -rf "$modules"' EXIT

require_cangjie() {
    command -v cjc >/dev/null || { echo 'cjc is required on the CI runner' >&2; exit 2; }
    command -v cjpm >/dev/null || { echo 'cjpm is required on the CI runner' >&2; exit 2; }
}

dependency_override_args() {
    if [[ -n "${YJSON_CI_DEPENDENCY_OVERRIDE:-}" ]]; then
        printf '%s\n' "--override-compile-option=${YJSON_CI_DEPENDENCY_OVERRIDE}"
    fi
}

run_with_dependency_override() {
    local project=$1
    shift
    local override=${YJSON_CI_DEPENDENCY_OVERRIDE:-}
    if [[ -z "$override" ]]; then
        (cd "$project" && "$@")
        return
    fi

    local manifest="$project/cjpm.toml"
    local backup
    backup=$(mktemp "${TMPDIR:-/tmp}/yjson-cjpm-manifest.XXXXXX")
    cp "$manifest" "$backup"
    python3 - "$manifest" "$override" <<'PY'
import pathlib
import sys

manifest = pathlib.Path(sys.argv[1])
override = sys.argv[2]
if override not in ("-O0", "-O1"):
    raise SystemExit(f"unsupported dependency override: {override}")
text = manifest.read_text(encoding="utf-8")
marker = 'override-compile-option = ""'
replacement = f'override-compile-option = "{override}"'
if text.count(marker) == 1:
    text = text.replace(marker, replacement)
elif marker not in text and text.count('compile-option = "-O2"') == 1:
    text = text.replace(
        'compile-option = "-O2"',
        f'compile-option = "-O2"\n{replacement}',
    )
else:
    raise SystemExit(f"unexpected cjpm manifest: {manifest}")
manifest.write_text(text, encoding="utf-8")
PY
    set +e
    (cd "$project" && "$@")
    local status=$?
    set -e
    cp "$backup" "$manifest"
    rm -f "$backup"
    return "$status"
}

stage_modules() {
    python3 "$repo/scripts/release_package_stage.py" "$modules" --development
}

prepare_cjdoc() {
    require_cangjie
    local -a args=()
    if [[ -n "${YJSON_CJDOC_ARCHIVE:-}" ]]; then
        args+=(--archive "$YJSON_CJDOC_ARCHIVE")
    fi
    python3 "$repo/scripts/prepare_cjdoc.py" "${args[@]}"
}

case "$job" in
    stream-docs)
        python3 "$repo/scripts/test_stage_source_tree.py"
        evidence="$repo/benchmarks/results/stream-v1/2026-08-28"
        extracted="$modules/stream-evidence"
        peer_extracted="$modules/stream-peer-evidence"
        regenerated="$modules/stream-regenerated"
        (cd "$evidence" && sha256sum -c checksums.txt)
        python3 "$repo/scripts/generate_json_stream_workloads.py" \
            "$evidence/formal-cell-1" --check
        python3 "$repo/scripts/check_local_markdown_links.py" \
            "$repo/README.md" \
            "$repo/benchmarks/README.md" \
            "$evidence/README.md" \
            "$repo/docs/README.md" \
            "$repo/docs/streams.md" \
            "$repo/docs/performance.md" \
            "$repo/docs/performance/README.md" \
            "$repo/docs/performance/methodology.md" \
            "$repo/docs/performance/stream.md" \
            "$repo/docs/performance/stream-workloads.md" \
            "$repo/docs/performance/results/2026-08-28-stream-protocol-v1.md"
        mkdir -p "$extracted" "$peer_extracted" "$regenerated"
        tar -xzf "$evidence/formal-cell-1.tar.gz" -C "$extracted"
        tar -xzf "$evidence/peer-cell-1.tar.gz" -C "$peer_extracted"
        python3 "$repo/scripts/json_stream_protocol_summary.py" \
            "$extracted/formal-cell-1" --variant baseline \
            --json "$regenerated/baseline-summary.json" \
            --markdown "$regenerated/baseline-summary.md" >/dev/null
        python3 "$repo/scripts/json_stream_protocol_summary.py" \
            "$extracted/formal-cell-1" --variant candidate \
            --json "$regenerated/candidate-summary.json" \
            --markdown "$regenerated/candidate-summary.md" >/dev/null
        python3 "$repo/scripts/json_stream_protocol_compare.py" \
            "$regenerated/baseline-summary.json" "$regenerated/candidate-summary.json" \
            --json "$regenerated/compare.json" \
            --markdown "$regenerated/compare.md" >/dev/null
        python3 "$repo/scripts/json_stream_protocol_compare.py" \
            "$regenerated/baseline-summary.json" "$regenerated/candidate-summary.json" \
            --candidate-lifecycle unpooled \
            --json "$regenerated/compare-unpooled.json" \
            --markdown "$regenerated/compare-unpooled.md" >/dev/null
        for name in baseline-summary.json candidate-summary.json compare.json \
                compare-unpooled.json; do
            python3 "$repo/scripts/check_json_numeric_equivalence.py" \
                "$evidence/formal-cell-1/$name" "$regenerated/$name"
        done
        for name in baseline-summary.md candidate-summary.md compare.md compare-unpooled.md; do
            cmp "$regenerated/$name" "$evidence/formal-cell-1/$name"
        done
        python3 "$repo/scripts/json_stream_peer_summary.py" \
            "$peer_extracted/yjson-stream-peer-v1-20260828-formal-v10" \
            --json "$regenerated/peer-summary.json" \
            --markdown "$regenerated/peer-summary.md" >/dev/null
        python3 "$repo/scripts/check_json_numeric_equivalence.py" \
            "$evidence/peer-cell-1/peer-summary.json" "$regenerated/peer-summary.json"
        cmp "$regenerated/peer-summary.md" "$evidence/peer-cell-1/peer-summary.md"
        ;;
    perf-evidence-drift)
        case "${mode:-strict}" in
            strict)
                evidence_args=()
                ;;
            integrity-only)
                evidence_args=(--integrity-only)
                ;;
            *)
                echo 'perf-evidence-drift mode must be strict or integrity-only' >&2
                exit 2
                ;;
        esac
        python3 "$repo/scripts/test_check_seven_library_evidence.py"
        python3 "$repo/scripts/check_seven_library_evidence.py" "${evidence_args[@]}"
        ;;
    api-inventory)
        python3 "$repo/scripts/check_api_inventory.py"
        ;;
    cjdoc-qualification)
        python3 "$repo/scripts/test_check_cjdoc_qualification.py"
        python3 "$repo/scripts/test_prepare_cjdoc.py"
        cjdoc_binary=$(prepare_cjdoc)
        python3 "$repo/scripts/check_cjdoc_qualification.py" \
            --binary "$cjdoc_binary"
        ;;
    api-docs)
        python3 "$repo/scripts/test_check_api_documentation.py"
        python3 "$repo/scripts/test_generate_api_docs.py"
        cjdoc_binary=$(prepare_cjdoc)
        docs_output=${YJSON_API_DOCS_OUTPUT:-"$modules/api-docs"}
        python3 "$repo/scripts/generate_api_docs.py" \
            --cjdoc "$cjdoc_binary" --output "$docs_output"
        test -f "$docs_output/index.html"
        test -f "$docs_output/api-docs.json"
        python3 "$repo/scripts/check_api_documentation.py" "$docs_output"
        ;;
    runtime-freeze)
        require_cangjie
        run_with_dependency_override "$repo/packages/runtime_freeze_contract" \
            "$repo/scripts/runtime_freeze_contract_checks.sh"
        ;;
    core)
        require_cangjie
        (cd "$repo" && cjpm test --no-color)
        ;;
    pure-platform)
        require_cangjie
        if [[ "$(uname -s)" == Darwin ]]; then
            # The deep JSONPath tests need a larger Cangjie thread stack on macOS.
            # Keep this scoped to the Pure test gate; optimization overrides stay
            # explicit in the caller environment.
            export cjStackSize=8MB
        fi
        # A failing test is not an infrastructure retry. Propagate the first
        # failure while honoring any explicit dependency optimization override.
        run_with_dependency_override "$repo" cjpm test --no-color
        run_with_dependency_override "$repo/packages/yjson_algorithms" \
            cjpm test --no-color
        ;;
    standards-conformance)
        require_cangjie
        run_with_dependency_override "$repo/packages/standards_conformance" \
            env YJSON_TEST_STANDARDS_ORACLE=1 python3 "$repo/scripts/test_ci_candidate_wiring.py" \
            StandardsOracleTests
        mapfile -t override_args < <(dependency_override_args)
        if [[ "${YJSON_STANDARDS_OFFLINE:-}" == "1" ]]; then
            override_args+=(--offline)
        fi
        python3 "$repo/scripts/run_standards_conformance.py" --quiet-failures \
            "${override_args[@]}"
        ;;
    schema-formats-conformance)
        require_cangjie
        run_with_dependency_override "$repo/packages/yjson_schema_formats" \
            cjpm test --no-color
        mapfile -t override_args < <(dependency_override_args)
        if [[ "${YJSON_STANDARDS_OFFLINE:-}" == "1" ]]; then
            override_args+=(--offline)
        fi
        python3 "$repo/scripts/run_standards_conformance.py" --quiet-failures \
            --include-schema-optional "${override_args[@]}"
        ;;
    performance-comparison)
        require_cangjie
        : "${YJSON_PERF_RESULT_DIR:?set YJSON_PERF_RESULT_DIR}"
        "$repo/scripts/release_performance_compare.sh" "$YJSON_PERF_RESULT_DIR" \
            "${YJSON_CJFAST_WORK_DIR:-}"
        ;;
    examples)
        require_cangjie
        run_with_dependency_override "$repo/packages/examples" \
            "$repo/scripts/run_cjpm_executable.sh" "$repo/packages/examples"
        ;;
    macro-consumer)
        require_cangjie
        run_with_dependency_override "$repo/packages/codec_integration" \
            cjpm test --no-color
        run_with_dependency_override "$repo/packages/codec_integration" \
            "$repo/scripts/run_cjpm_executable.sh" "$repo/packages/codec_integration"
        stage_modules
        mapfile -t override_args < <(dependency_override_args)
        python3 "$repo/scripts/release_consumer_checks.py" \
            --modules-root "$modules" --only macro "${override_args[@]}"
        ;;
    algorithms-consumer)
        require_cangjie
        run_with_dependency_override "$repo/packages/yjson_algorithms" \
            cjpm test --no-color
        stage_modules
        mapfile -t override_args < <(dependency_override_args)
        python3 "$repo/scripts/release_consumer_checks.py" \
            --modules-root "$modules" --only algorithms --only schema-formats \
            "${override_args[@]}"
        ;;
    registry-rehearsal)
        require_cangjie
        if [[ ! -e "$repo/.git" && \
                -f "$repo/release/candidate-provenance.json" ]]; then
            candidate="$repo"
        else
            candidate="$modules/release-candidate"
            python3 "$repo/scripts/release_temp_tree.py" "$candidate" --enforce-clean
        fi
        diagnostic="$modules/release-candidate-diagnostic"
        cp -a "$candidate" "$diagnostic"
        PYTHONDONTWRITEBYTECODE=1 \
            python3 "$diagnostic/scripts/check_api_inventory.py"
        run_with_dependency_override "$diagnostic" cjpm test --no-color
        rehearsal="$modules/registry-rehearsal"
        registry_args=()
        if [[ -n "${YJSON_CI_DEPENDENCY_OVERRIDE:-}" ]]; then
            registry_args+=(
                "--bundle-override-compile-option=${YJSON_CI_DEPENDENCY_OVERRIDE}"
                "--consumer-override-compile-option=${YJSON_CI_DEPENDENCY_OVERRIDE}")
        fi
        PYTHONDONTWRITEBYTECODE=1 \
            python3 "$repo/scripts/release_registry_rehearsal.py" "$rehearsal" \
            --candidate-root "$candidate" \
            --require-clean-candidate \
            "${registry_args[@]}"
        ;;
    custom-native)
        require_cangjie
        run_with_dependency_override "$repo/packages/yjson_native_primitives" cjpm test --no-color
        run_with_dependency_override "$repo/packages/yjson_native_accel" cjpm test --no-color
        run_with_dependency_override "$repo/packages/yjson_native" cjpm test --no-color
        stage_modules
        mapfile -t override_args < <(dependency_override_args)
        python3 "$repo/scripts/release_consumer_checks.py" \
            --modules-root "$modules" --only native "${override_args[@]}"
        # Keep nm outside a conditional pipeline: an inspection error must fail.
        nm -g --defined-only "$repo/packages/yjson_native_primitives/target/native/libyjson_scanner.a" \
            > "$modules/symbols.txt"
        python3 - "$modules/symbols.txt" <<'PY'
import pathlib
import sys

for line in pathlib.Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    fields = line.split()
    if len(fields) >= 2 and fields[-1].startswith(("yyjson_", "unsafe_yyjson_")):
        raise SystemExit("unexpected exported yyjson symbol: " + fields[-1])
PY
        ;;
    yyjson-native)
        require_cangjie
        run_with_dependency_override "$repo/packages/yjson_yyjson" cjpm test --no-color
        stage_modules
        mapfile -t override_args < <(dependency_override_args)
        python3 "$repo/scripts/release_consumer_checks.py" \
            --modules-root "$modules" --only yyjson "${override_args[@]}"
        ;;
    native-clang)
        CC=${CC:-clang} YJSON_NATIVE_CHECK_MODE=targeted \
            "$repo/scripts/release_native_checks.sh"
        ;;
    native-gcc)
        CC=${CC:-gcc} YJSON_NATIVE_CHECK_MODE=targeted \
            "$repo/scripts/release_native_checks.sh"
        ;;
    sanitizer)
        CC=${CC:-clang} YJSON_NATIVE_CHECK_MODE=sanitizer \
            "$repo/scripts/release_native_checks.sh"
        ;;
    fuzz-short)
        CC=${CC:-clang} YJSON_NATIVE_CHECK_MODE=fuzz YJSON_FUZZ_CASES=5000 \
            "$repo/scripts/release_native_checks.sh"
        ;;
    fuzz-extended)
        CC=${CC:-clang} YJSON_NATIVE_CHECK_MODE=fuzz YJSON_FUZZ_CASES=50000 \
            "$repo/scripts/release_native_checks.sh"
        ;;
    yyjson-colink)
        "$repo/scripts/release_yyjson_colink_check.sh"
        ;;
    *)
        echo 'usage: scripts/ci_job.sh {stream-docs|perf-evidence-drift [strict|integrity-only]|api-inventory|cjdoc-qualification|api-docs|runtime-freeze|core|pure-platform|standards-conformance|schema-formats-conformance|performance-comparison|examples|macro-consumer|algorithms-consumer|registry-rehearsal|custom-native|yyjson-native|native-clang|native-gcc|sanitizer|fuzz-short|fuzz-extended|yyjson-colink}' >&2
        exit 2
        ;;
esac
