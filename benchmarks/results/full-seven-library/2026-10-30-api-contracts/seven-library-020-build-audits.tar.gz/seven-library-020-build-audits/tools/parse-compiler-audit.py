import pathlib,re,json,sys,hashlib
label=sys.argv[1];paths=[pathlib.Path(value) for value in sys.argv[2:]];calls=[]
for path in paths:
 text=path.read_text();assert '--fno-chir-function-inlining' not in text,path
 for line in text.splitlines():
  match=re.search(r'execve\(("(?:\\.|[^"\\])*")\s*,\s*(\[.*?\])',line)
  if not match:continue
  try:exe=json.loads(match[1]);argv=json.loads(match[2])
  except json.JSONDecodeError:continue
  if pathlib.Path(exe).name not in ['cjc','cjc-frontend'] or '= -1 ' in line:continue
  if '--scan-dependency' in argv:role='dependency scan'
  elif any(x in argv for x in ['-v','--version','--help']):role='compiler introspection'
  elif '--compile-macro' in argv:role='compile-time macro'
  elif any(x.endswith('/build.cj') for x in argv):role='build helper'
  elif any(x.endswith('/testrunner.cj') for x in argv):role='unused test framework launcher'
  else:role='measured runtime or benchmark compilation'
  calls.append({'log':path.name,'executable':exe,'argv':argv,'optimizationFlags':[arg for arg in argv if re.fullmatch(r'-O[0-3sz]',arg)],'role':role})
assert calls,'no native compiler argv captured'
measured=[c for c in calls if c['role']=='measured runtime or benchmark compilation'];assert measured,'no measured compilation captured'
record={'label':label,'status':'PASS' if all('-O2' in c['argv'] for c in measured) else 'FAIL','nativeCjcSha256':hashlib.sha256(pathlib.Path('/mnt/sdk/cangjie/bin/cjc').read_bytes()).hexdigest(),'noNoinlineOption':True,'scope':'actual measured runtime and benchmark compiler argv must request O2; scans/version, build helpers, compile-time macros and unused std.testrunner are separately retained with actual flags','calls':calls}
pathlib.Path('/mnt/receipts/'+label+'-compiler-argv.json').write_text(json.dumps(record,indent=2)+'\n')
print(label,'all native cjc invocations',len(calls),'measured compilations',len(measured),'status',record['status'])
for c in measured:print(c['log'],c['optimizationFlags'],c['argv'][:5])
assert record['status']=='PASS','measured runtime or benchmark compiler invocation lacks explicit O2'
