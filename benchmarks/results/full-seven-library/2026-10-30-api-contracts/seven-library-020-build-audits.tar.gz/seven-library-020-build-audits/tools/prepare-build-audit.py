from pathlib import Path
import os,sys,json,hashlib,subprocess,tarfile,shutil,tomllib,re,importlib.util,fcntl,time
B=Path('/mnt/candidate');R=B/'receipts';L=B/'logs';SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
os.environ['GIT_OPTIONAL_LOCKS']='0'
def write(n,v): (R/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def capture(args,cwd=None):return subprocess.check_output(args,cwd=cwd,stderr=subprocess.STDOUT,text=True).strip()
def run(args,cwd,log):
 print('BUILD_STAGE',log,flush=True)
 with (L/log).open('wb')as f:
  p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError('first build failure '+log+' exit '+str(p.returncode))
def identity_module():
 s=importlib.util.spec_from_file_location('frozen_bii',B/'workspace/repo/scripts/benchmark_input_identity.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
I=identity_module();production=json.loads((R/'production-source-files.json').read_text());pure=json.loads((R/'pure-snapshot-receipt.json').read_text());fragment=json.loads((R/'current-candidate-fragment.json').read_text())
def sdk():
 root=Path('/mnt/sdk');entries={}
 for p in sorted(root.rglob('*')):
  n=str(p.relative_to(root))
  if p.is_symlink():entries[n]={'symlink':os.readlink(p)}
  elif p.is_file():entries[n]={'sha256':SHA(p)}
 digest=hashlib.sha256(json.dumps(entries,sort_keys=True,indent=2).encode()).hexdigest();assert len(entries)==1179 and digest=='ea7984dc5c37c02acf7f7119c24d7633a3b655f0c71350a8aa910c87abe00b5a',(len(entries),digest)
 assert SHA(Path(sys.executable).resolve())=='58fe899223901d346e9d3a0184bdd04d82a276ff1f99be0e68d5873ea71c1b68'
 return {'sdkEntries':len(entries),'sdkFileManifestSha256':digest,'pythonBinarySha256':SHA(Path(sys.executable).resolve()),'pythonVersion':sys.version}
def verify(label,full=False):
 repo=B/'workspace/repo'
 for n,v in production['files'].items():
  p=repo/n;raw=os.readlink(p).encode()if p.is_symlink()else p.read_bytes();assert hashlib.sha256(raw).hexdigest()==v['sha256'],n
 assert I.manifest_digest(I.product_manifest(repo))==fragment['product_source_sha256'];assert I.manifest_digest(I.harness_manifest(repo))==fragment['effective_harness_sha256'];assert I.product_manifest(B/'pure-candidate')==I.product_manifest(repo)
 for n,c in [('pure-baseline','d5cf460a6c5cdfb25a07bd45e97bd04d7336ea87'),('pure-candidate',pure['commit'])]:
  p=B/n;assert capture(['git','rev-parse','HEAD'],p)==c;assert not capture(['git','status','--porcelain=v1','--untracked-files=all'],p)
 assert I.harness_manifest(B/'pure-baseline')==I.harness_manifest(B/'pure-candidate');assert I.manifest_digest(I.harness_manifest(B/'pure-candidate'))=='dc28db7743c93f1550bad1f31e15455bc213c486a54c131e6b0f9a8cd16de9a6'
 paths=[]
 for root in [B/'pure-baseline',B/'pure-candidate',repo]:paths += [root/'cjpm.toml',root/'packages/benchmarks/cjpm.toml',root/'packages/yjson_algorithms/cjpm.toml',root/'packages/yjson_macros/cjpm.toml']
 ws=B/'workspace';paths += [ws/n for n in ['cangjieJSON-upstream/cjpm.toml','harness/cjjson/cjpm.toml','harness/json4cj/cjpm.toml','json4cj/json4cj-core/cjpm.toml','json4cj/json4cj-annotations/cjpm.toml','json4cj/json4cj-databind/cjpm.toml','cjfast-json/cjpm.toml']]
 manifests={}
 for p in paths:
  raw=p.read_bytes();text=raw.decode();pkg=tomllib.loads(text)['package'];flags=pkg.get('compile-option','');assert '--fno-chir-function-inlining'not in text and 'cjdoc'not in flags.lower(),str(p)
  if pkg['name']!='yjson_macros':assert '-O2'in flags,(str(p),flags)
  manifests[str(p.relative_to(B))]={'sha256':SHA(p),'package':pkg['name'],'compileOption':flags,'overrideCompileOption':pkg.get('override-compile-option',''),'linkOption':pkg.get('link-option','')}
 for n,v in os.environ.items():assert 'CJDOC'not in n.upper()and '--fno-chir-function-inlining'not in v and not any(t in v for t in ['/cjdoc/','/cjd/']),n
 for t,v in [('cjc','023be1bb2ded1078906fc91919b3c1175ad14436ad88d23d505f7b8dcd0d7118'),('cjpm','a565d86540656c62340aacf6ac89c175b50c1f4d9ba4f69cee6a0fdacdee412d')]:assert SHA(Path(shutil.which(t)).resolve())==v,t
 old=json.loads(Path('/mnt/receipts/frozen-measured-overlay.json').read_text());assert {n:SHA(ws/n)for n in old['files']}==old['files'];assert I.manifest_digest(old['files'])==old['measured_overlay_sha256']=='5f09b209c66d504a2533b261a922e63cc8312ea549aa88619d9c4160c058f4fc'
 record={'status':'PASS','productionCommit':fragment['measured_commit'],'productSourceSha256':fragment['product_source_sha256'],'productionHarnessSha256':fragment['effective_harness_sha256'],'pureHarnessSha256':'dc28db7743c93f1550bad1f31e15455bc213c486a54c131e6b0f9a8cd16de9a6','measuredOverlaySha256':old['measured_overlay_sha256'],'manifests':manifests,'environment':{n:os.environ.get(n)for n in ['PATH','CANGJIE_HOME','CANGJIE_SDK_ROOT','CANGJIE_STDX_PATH','STDX_FFI_LIB','LD_LIBRARY_PATH','CC','AR','cjHeapSize','cjProcessorNum','YJSON_BUILD_YYJSON','TMPDIR','HOME']},'noCjdocOrNoinline':True,'cjcVersion':capture(['cjc','-v']),'cjpmVersion':capture(['cjpm','--version']),'pythonVersion':sys.version,'formalSamplesCapturedByBuildAuditor':0}
 if full:record.update(sdk())
 write(label+'.json',record);print(label,'PASS',flush=True);return record

def prepare():
 for name in ['pure-baseline','pure-candidate']:
  subprocess.run(['git','fsck','--full'],cwd=B/name,check=True,capture_output=True)
 verify('build-env-before',True)

def build(seven_only=False):
 stages=[('pure-baseline',B/'pure-baseline/packages/benchmarks'),('pure-candidate',B/'pure-candidate/packages/benchmarks'),('seven-yjson',B/'workspace/repo/packages/benchmarks'),('seven-cjjson',B/'workspace/harness/cjjson'),('seven-json4cj',B/'workspace/harness/json4cj'),('seven-cjfast',B/'workspace/cjfast-json')]
 if seven_only:stages=stages[2:]
 for label,p in stages:
  clean=L/(label+'-clean.execve.log');bench=L/(label+'-bench.execve.log')
  run(['strace','-f','-s','65535','-e','trace=execve','-o',str(clean),'cjpm','clean'],p,label+'-clean.log')
  run(['strace','-f','-s','65535','-e','trace=execve','-o',str(bench),'cjpm','bench','--no-color','--no-run'],p,label+'-bench.log')
  run(['python3','/mnt/parse-compiler-audit.py','api-groups-'+(CYCLE+'-'if CYCLE else '')+label,str(clean),str(bench)],B,label+'-argv-parse.log')
  raw=Path('/mnt/receipts/api-groups-'+(CYCLE+'-'if CYCLE else '')+label+'-compiler-argv.json');shutil.copy2(raw,R/raw.name)
  verify('build-env-after-'+label)
 run(['mvn','-B','-DskipTests','-Dmaven.repo.local=/mnt/m2','clean','package'],B/'workspace/harness/java','java-package.log')
 verify('build-env-after-all',True)
 finalize()
def finalize():
 sys.path.insert(0,str(B/'workspace/repo/benchmarks/full-seven-library'));import run_full
 verify('build-env-before-link-finalization',True)
 artifactpaths={'pure-baseline':B/'pure-baseline/packages/benchmarks/target/release/unittest_bin/yjson_benchmarks','pure-candidate':B/'pure-candidate/packages/benchmarks/target/release/unittest_bin/yjson_benchmarks','seven-yjson':B/'workspace/repo/packages/benchmarks/target/release/unittest_bin/yjson_benchmarks','seven-cjjson':B/'workspace/harness/cjjson/target/release/unittest_bin/bench_cjjson','seven-json4cj':B/'workspace/harness/json4cj/target/release/unittest_bin/bench_json4cj','seven-cjfast':B/'workspace/cjfast-json/target/release/unittest_bin/fastjson.bench','java':B/'workspace/harness/java/target/json-optimal-bench-1.0.0-all.jar'}
 arts={};links={}
 for label,p in artifactpaths.items():
  assert p.is_file();d=(R.parent/'artifacts')/label/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);arts[label]={'path':str(p.relative_to(B)),'sha256':SHA(p),'sizeBytes':p.stat().st_size}
  if label=='java':continue
  runtime_env=run_full.cangjie_runtime_environment(dict(os.environ),Path('/mnt/sdk'),p.parents[3]);text=subprocess.check_output(['ldd',str(p)],env=runtime_env,text=True,stderr=subprocess.STDOUT).strip();(L/(label+'-ldd.log')).write_text(text+'\n');libs={}
  assert 'not found'not in text
  for line in text.splitlines():
   m=re.search(r'=>\s+(/\S+)|^\s*(/\S+)',line)
   if m:
    q=Path(m.group(1)or m.group(2)).resolve();libs[str(q)]=SHA(q)
  links[label]=libs
 assert links['pure-baseline']==links['pure-candidate']==links['seven-yjson']
 write('linked-runtime-libraries.json',{'status':'PASS','libraries':links})
 old=json.loads(Path('/mnt/receipts/frozen-measured-overlay.json').read_text());updated={**old,'rootCommit':fragment['measured_commit'],'productSourceSha256':fragment['product_source_sha256'],'productionHarnessSha256':fragment['effective_harness_sha256']}
 sys.path.insert(0,str(B/'workspace/repo/benchmarks/full-seven-library'));import run_full
 updated['actualSourceTreeDigests']={n:run_full.source_digest(B/'workspace'/n)for n in old['actualSourceTreeDigests']}
 for n,v in old['actualSourceTreeDigests'].items():
  if n!='repo':assert updated['actualSourceTreeDigests'][n]==v,n
 write('frozen-measured-overlay.json',updated)
 write('final-build-readiness.json',{'status':'PASS','productionCommit':fragment['measured_commit'],'productSourceSha256':fragment['product_source_sha256'],'productionHarnessSha256':fragment['effective_harness_sha256'],'pureCommonHarnessSha256':'dc28db7743c93f1550bad1f31e15455bc213c486a54c131e6b0f9a8cd16de9a6','pureCandidateCommit':pure['commit'],'pureBaselineCommit':'d5cf460a6c5cdfb25a07bd45e97bd04d7336ea87','measuredOverlaySha256':old['measured_overlay_sha256'],'actualSourceTreeDigests':updated['actualSourceTreeDigests'],'artifacts':arts,'fourCangjiePeersRebuilt':True,'mavenRebuilt':True,'allMeasuredCangjieActualArgvExplicitO2':True,'noNoinlineOrCjdocLeak':True,'traceScope':'build-only; trace finished before any formal benchmark','productionSourceMode':'byte-identical source-only export bound to clean real root receipt','formalSamplesCapturedByBuildAuditor':0,'cpuSelection':'fresh 30-second idle sample required immediately before every formal batch','sdk':sdk()})
 print('FINAL_BUILD_READINESS_PASS',flush=True)
CYCLE=''
if __name__=='__main__':
 lock=Path('/mnt/measurement.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  if sys.argv[1]=='prepare':prepare()
  elif sys.argv[1]=='build':build()
  elif sys.argv[1]=='finalize':finalize()
  elif sys.argv[1]=='seven-cycle':
   CYCLE=sys.argv[2];assert CYCLE in ['seven-batch-01','seven-batch-02'];R=B/'audits'/CYCLE/'receipts';L=B/'audits'/CYCLE/'logs';R.mkdir(parents=True);L.mkdir();verify('build-env-before',True);build(True)
  else:raise ValueError(sys.argv[1])
 except BaseException as exc:
  write('firstcause-'+sys.argv[1]+'.json',{'status':'STOPPED','exception':type(exc).__name__,'message':str(exc),'formalSamplesCapturedByBuildAuditor':0});raise
