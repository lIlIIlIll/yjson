from pathlib import Path
import os,sys,subprocess,json,datetime,fcntl,csv,collections,importlib.util,hashlib
B=Path('/mnt/candidate');number=int(sys.argv[1]);assert number in [1,2];cycle='seven-batch-01'if number==1 else'seven-batch-02';R=B/'audits'/cycle/'receipts';L=B/'audits'/cycle/'logs';out=B/('results/seven-library-release-020-b1'if number==1 else'results/seven-library-release-020-b2');assert not out.exists();assert json.loads((B/'results/pure-release-020/summary.json').read_text())['gates']['passed'];assert json.loads((R/'final-build-readiness.json').read_text())['status']=='PASS'
lock=Path('/mnt/measurement.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('task_auditor',B/'prepare-build-audit.py');auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor);auditor.R=R;auditor.L=L;auditor.verify('env-immediately-before-formal',True)
sys.path.insert(0,str(B/'pure-candidate/scripts'));import benchmark_pure_direct
print('SEVEN_BATCH',number,'FRESH_IDLE_SAMPLE_BEGIN',flush=True);sample=benchmark_pure_direct.select_idle_cpu_triple(30);core=sample['physical_cores'][0];cpu=core['cpu'];siblings=[int(v)for v in core['siblings']];assert len(siblings)==2 and cpu in siblings;sibling=next(v for v in siblings if v!=cpu)
selection={'sample_seconds':30,'selected_cpu':cpu,'selected_sibling':sibling,'utilization_percent':[core['utilization_percent'][str(cpu)],core['utilization_percent'][str(sibling)]],'acceptable_both_threads_below_1_percent':True,'actualFullCpuWindow':sample,'selectionMethod':'first physical core from canonical full idle topology sample; seven runner retains its original single-CPU binding'};assert all(v<1 for v in selection['utilization_percent']);(B/'workspace/cpu-selection.json').write_text(json.dumps(selection,indent=2)+'\n');(R/'cpu-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
cmd=['python3',str(B/'workspace/repo/benchmarks/full-seven-library/run_full.py'),'--workspace',str(B/'workspace'),'--stdx-sdk-root','/mnt/sdk','--runs','11','--cpu',str(cpu),str(out)];env=os.environ.copy();env.update(YJSON_RELEASE_COMMIT='ac4f8b987910a473ada7d77f10ce6cd3c12d2248',YJSON_PRODUCT_SOURCE_SHA256='4251be5ff98c50a91afdd162ae130d94f8bf2a70c85faf5da6a78304232771af',YJSON_EFFECTIVE_HARNESS_SHA256='9d457f09101cb4466a82b000d2494e9c12b2f495b5b16b4fef809811a60d8852',YJSON_MEASURED_OVERLAY_SHA256='5f09b209c66d504a2533b261a922e63cc8312ea549aa88619d9c4160c058f4fc',YJSON_CROSSLANG_CORPUS_DIR='/mnt/corpus')
corpus=json.loads((B/'results/pure-release-020/provenance.json').read_text())['corpus']['manifest'];assert len(corpus)==3
for n,v in corpus.items():assert hashlib.sha256((Path('/mnt/corpus')/n).read_bytes()).hexdigest()==v,n
(R/'required-corpus-environment.json').write_text(json.dumps({'status':'PASS','corpusFiles':corpus,'corpusPath':'/mnt/corpus','sameAsPure':True,'onlyPreparationEnvironmentDifference':{'YJSON_CROSSLANG_CORPUS_DIR':{'before':None,'after':'/mnt/corpus'}},'oldFailedPreflightPreserved':True,'canonicalHarnessSourceFlagsWorkThresholdChanged':False},indent=2)+'\n')
state={'status':'RUNNING','batch':number,'command':cmd,'metadataEnvironment':{k:v for k,v in env.items()if k in ['YJSON_RELEASE_COMMIT','YJSON_PRODUCT_SOURCE_SHA256','YJSON_EFFECTIVE_HARNESS_SHA256','YJSON_MEASURED_OVERLAY_SHA256','YJSON_CROSSLANG_CORPUS_DIR']},'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'traceOrDebugger':False,'retry':False,'fourCangjieAndMavenFreshRebuiltForThisBatch':True};statepath=R/'formal-state.json';statepath.write_text(json.dumps(state,indent=2)+'\n');print('SEVEN_BATCH',number,'BEGIN',state['startedAtUtc'],'CPU',cpu,'sibling',sibling,'idle',selection['utilization_percent'],flush=True)
try:
 with(L/'formal-run.log').open('w')as f:
  p=subprocess.Popen(cmd,cwd=B,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  for line in p.stdout:f.write(line);f.flush();print(line,end='',flush=True)
  rc=p.wait()
 state.update(exitCode=rc,finishedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='COMPLETE'if rc==0 else 'FAIL');statepath.write_text(json.dumps(state,indent=2)+'\n');assert rc==0,('formal runner first failure',rc)
 assert(out/'COMPLETE').is_file();rows=list(csv.DictReader((out/'manifest.csv').open()));assert len(rows)==770;counts=collections.Counter((r['library'],r['workload_id'])for r in rows);assert len(counts)==70 and set(counts.values())=={11};assert {int(r['round'])for r in rows}==set(range(1,12))
 summarize=['python3',str(B/'workspace/repo/benchmarks/full-seven-library/summarize_full.py'),str(out),'--min-runs','11']
 with(L/'summarize.log').open('w')as f:r=subprocess.run(summarize,cwd=B,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,('summary first failure',r.returncode)
 md=json.loads((out/'metadata.json').read_text());assert md['versions']['yjson_commit']==env['YJSON_RELEASE_COMMIT']
 for key,en in [('product_source_sha256','YJSON_PRODUCT_SOURCE_SHA256'),('effective_harness_sha256','YJSON_EFFECTIVE_HARNESS_SHA256'),('measured_overlay_sha256','YJSON_MEASURED_OVERLAY_SHA256')]:assert md[key]==env[en]
 assert md['cpu_selection']==selection
 auditor.verify('env-immediately-after-formal',True)
 readiness=json.loads((R/'final-build-readiness.json').read_text());actual={}
 for name,a in readiness['artifacts'].items():
  path=B/a['path'];value=hashlib.sha256(path.read_bytes()).hexdigest();assert value==a['sha256'],name;actual[name]=value
 summary=json.loads((out/'summary.json').read_text());assert len(summary)==10 and all(row['rounds']==11 for row in summary)
 receipt={'status':'PASS_COMPLETE_AND_SUMMARY','batch':number,'formalCells':770,'workloadLibraryPairs':70,'roundsPerPair':11,'correctnessPreflight':'canonical runner passed all seven fixtures before formal cells','productionCommit':env['YJSON_RELEASE_COMMIT'],'productSourceSha256':env['YJSON_PRODUCT_SOURCE_SHA256'],'harnessSha256':env['YJSON_EFFECTIVE_HARNESS_SHA256'],'measuredOverlaySha256':env['YJSON_MEASURED_OVERLAY_SHA256'],'prePostSdkSourceLocksStable':True,'actualArtifacts':actual,'summaryStableRows':sum(row['stable_cv_le_5_percent']for row in summary),'summaryNoisyRows':sum(not row['stable_cv_le_5_percent']for row in summary),'noSameCandidateRetry':True};(R/'independent-cell-count-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print('SEVEN_BATCH_COMPLETE',json.dumps(receipt),flush=True)
except BaseException as e:
 state.update(status='STOPPED',firstException=type(e).__name__,firstCause=str(e));statepath.write_text(json.dumps(state,indent=2)+'\n');raise
