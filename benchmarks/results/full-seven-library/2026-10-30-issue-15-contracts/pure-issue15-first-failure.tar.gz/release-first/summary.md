Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeLargeInt64Map` | 6.554 us | 6.684 us | 1.020x | -2.0% | 0/11 | 0.39% | 0.40% | 170284 | 170212 |
| `yjsonStringDecodeLargeInt64Map` | 14.649 us | 14.233 us | 0.972x | 2.8% | 11/11 | 0.51% | 0.39% | 161612 | 170552 |
| `yjsonBytesDecodeLargeInt64Map` | 17.342 us | 17.693 us | 1.020x | -2.0% | 0/11 | 0.50% | 0.49% | 166712 | 170492 |
| `yjsonStringEncodeDeepNestedProfiles` | 23.651 us | 23.567 us | 0.996x | 0.4% | 6/11 | 0.62% | 0.80% | 128116 | 128480 |
| `yjsonStringDecodeDeepNestedProfiles` | 114.229 us | 112.841 us | 0.988x | 1.2% | 9/11 | 1.44% | 0.82% | 169704 | 170136 |
| `yjsonBytesDecodeDeepNestedProfiles` | 118.391 us | 117.321 us | 0.991x | 0.9% | 8/11 | 0.51% | 0.49% | 169568 | 169900 |
| `yjsonStringEncodePerson` | 1.123 us | 2.193 us | 1.953x | -95.3% | 0/11 | 0.90% | 1.33% | 117700 | 117236 |
| `yjsonStringDecodePerson` | 3.551 us | 3.949 us | 1.112x | -11.2% | 0/11 | 1.29% | 1.84% | 169964 | 170532 |
| `yjsonStringEncodeLargeProfileArray` | 20.596 us | 21.028 us | 1.021x | -2.1% | 1/11 | 2.30% | 0.39% | 146412 | 144068 |
| `yjsonStringDecodeLargeProfileArray` | 42.817 us | 40.178 us | 0.938x | 6.2% | 11/11 | 0.35% | 0.22% | 117336 | 117168 |
| `parseStringRecords64k` | 1290.273 us | 1282.265 us | 0.994x | 0.6% | 7/11 | 0.76% | 1.15% | 170348 | 170560 |
| `parseBytesRecords64k` | 1406.123 us | 1390.670 us | 0.989x | 1.1% | 7/11 | 2.19% | 2.39% | 170180 | 170252 |
| `parseStringRecords1m` | 26235.739 us | 25875.929 us | 0.986x | 1.4% | 7/11 | 0.48% | 0.87% | 168660 | 168972 |
| `parseBytesRecords1m` | 26965.925 us | 27177.048 us | 1.008x | -0.8% | 3/11 | 1.14% | 0.70% | 168744 | 169176 |
| `yjsonStringEncodeProfileBundle` | 3.697 us | 5.529 us | 1.495x | -49.5% | 0/11 | 0.77% | 1.32% | 117508 | 117220 |
| `yjsonStringDecodeProfileBundle` | 6.217 us | 7.011 us | 1.128x | -12.8% | 0/11 | 1.48% | 1.11% | 170004 | 169272 |
| `yjsonBytesEncodeProfileBundle` | 4.082 us | 6.116 us | 1.498x | -49.8% | 0/11 | 0.74% | 0.54% | 139976 | 117740 |
| `yjsonBytesDecodeProfileBundle` | 7.051 us | 8.021 us | 1.138x | -13.8% | 0/11 | 0.70% | 0.91% | 156756 | 146084 |
| `yjsonStringEncodeEscapedUnicodeString` | 0.784 us | 0.802 us | 1.022x | -2.2% | 2/11 | 1.49% | 0.80% | 170344 | 170616 |
| `yjsonBytesEncodeEscapedUnicodeString` | 0.637 us | 0.652 us | 1.023x | -2.3% | 2/11 | 1.93% | 0.51% | 170316 | 170612 |
| `decodePersonChunk4k` | 23.835 us | 24.225 us | 1.016x | -1.6% | 1/11 | 2.04% | 0.49% | 144944 | 147112 |
| `decodeRecords64kChunk4k` | 6027.262 us | 6094.696 us | 1.011x | -1.1% | 0/11 | 0.46% | 5.15% | 117440 | 117360 |
| `encodePersonMemory` | 6.836 us | 7.742 us | 1.133x | -13.3% | 0/11 | 1.65% | 5.11% | 169904 | 170348 |
| `encodeRecords64kMemory` | 559.928 us | 566.567 us | 1.012x | -1.2% | 2/11 | 1.05% | 1.16% | 168424 | 170080 |
