Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeLargeInt64Map` | 6.555 us | 6.613 us | 1.009x | -0.9% | 0/11 | 0.33% | 0.62% | 170080 | 170212 |
| `yjsonStringDecodeLargeInt64Map` | 14.635 us | 14.282 us | 0.976x | 2.4% | 11/11 | 0.55% | 0.37% | 161656 | 170432 |
| `yjsonBytesDecodeLargeInt64Map` | 17.344 us | 17.824 us | 1.028x | -2.8% | 0/11 | 0.26% | 0.74% | 167052 | 170532 |
| `yjsonStringEncodeDeepNestedProfiles` | 23.642 us | 23.744 us | 1.004x | -0.4% | 2/11 | 0.81% | 0.33% | 127784 | 127916 |
| `yjsonStringDecodeDeepNestedProfiles` | 113.202 us | 111.913 us | 0.989x | 1.1% | 10/11 | 1.43% | 0.42% | 169732 | 170124 |
| `yjsonBytesDecodeDeepNestedProfiles` | 118.046 us | 116.993 us | 0.991x | 0.9% | 8/11 | 0.82% | 0.57% | 169660 | 170000 |
| `yjsonStringEncodePerson` | 1.120 us | 1.169 us | 1.043x | -4.3% | 0/11 | 1.15% | 1.42% | 117860 | 117648 |
| `yjsonStringDecodePerson` | 3.558 us | 3.658 us | 1.028x | -2.8% | 2/11 | 0.90% | 2.27% | 170056 | 170208 |
| `yjsonStringEncodeLargeProfileArray` | 20.583 us | 20.892 us | 1.015x | -1.5% | 2/11 | 1.37% | 1.77% | 146204 | 145720 |
| `yjsonStringDecodeLargeProfileArray` | 42.889 us | 40.133 us | 0.936x | 6.4% | 11/11 | 0.38% | 0.59% | 117408 | 117576 |
| `parseStringRecords64k` | 1298.679 us | 1289.161 us | 0.993x | 0.7% | 7/11 | 1.17% | 1.26% | 170348 | 170400 |
| `parseBytesRecords64k` | 1396.808 us | 1393.296 us | 0.997x | 0.3% | 6/11 | 2.16% | 2.09% | 170196 | 170316 |
| `parseStringRecords1m` | 26275.941 us | 25867.835 us | 0.984x | 1.6% | 10/11 | 0.58% | 1.05% | 168280 | 168996 |
| `parseBytesRecords1m` | 26918.459 us | 27336.118 us | 1.016x | -1.6% | 3/11 | 0.82% | 1.38% | 168812 | 169232 |
| `yjsonStringEncodeProfileBundle` | 3.706 us | 3.689 us | 0.995x | 0.5% | 7/11 | 0.51% | 0.78% | 117468 | 117320 |
| `yjsonStringDecodeProfileBundle` | 6.199 us | 6.183 us | 0.997x | 0.3% | 5/11 | 1.94% | 2.11% | 169980 | 170140 |
| `yjsonBytesEncodeProfileBundle` | 4.083 us | 4.253 us | 1.042x | -4.2% | 1/11 | 1.88% | 0.64% | 139496 | 137060 |
| `yjsonBytesDecodeProfileBundle` | 7.063 us | 6.838 us | 0.968x | 3.2% | 11/11 | 0.70% | 0.52% | 156864 | 160560 |
| `yjsonStringEncodeEscapedUnicodeString` | 0.781 us | 0.809 us | 1.036x | -3.6% | 0/11 | 0.87% | 1.32% | 170328 | 170388 |
| `yjsonBytesEncodeEscapedUnicodeString` | 0.642 us | 0.648 us | 1.010x | -1.0% | 2/11 | 1.77% | 0.79% | 170312 | 170448 |
| `decodePersonChunk4k` | 23.815 us | 23.917 us | 1.004x | -0.4% | 4/11 | 0.74% | 0.76% | 149344 | 146672 |
| `decodeRecords64kChunk4k` | 6007.042 us | 6085.550 us | 1.013x | -1.3% | 1/11 | 0.65% | 0.57% | 117452 | 117280 |
| `encodePersonMemory` | 6.847 us | 6.852 us | 1.001x | -0.1% | 4/11 | 1.92% | 1.03% | 169908 | 170120 |
| `encodeRecords64kMemory` | 556.139 us | 554.013 us | 0.996x | 0.4% | 6/11 | 1.10% | 1.01% | 168752 | 167424 |
