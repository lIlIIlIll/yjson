#!/usr/bin/env python3
"""Package completed task evidence; never run concurrently with measurement."""
import fcntl
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/mnt')
lock = (ROOT / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
OUTPUT = ROOT / 'public-seven-packets'
OUTPUT.mkdir()
expected = json.loads((ROOT / 'production-export-receipt-optimized.json').read_text())
ready = json.loads((ROOT / 'seven-build-audit-second/receipts/ready.json').read_text())
assert ready['status'] == 'PASS'
for field in ('productionMain', 'productionMacro', 'productSourceSha256', 'effectiveHarnessSha256'):
    assert ready[field] == expected[field], field
assert hashlib.sha256((ROOT / 'run-seven.py').read_bytes()).hexdigest() == '4743d8db9b1706a36a61e5ca9d2ac668f1a74f469e5cff9b7c6b3299c4e03d1e'


def package(name, sources):
    target = OUTPUT / (name + '.tar.gz')
    inventory = {}
    with tarfile.open(target, 'w:gz') as archive:
        for relative, source in sorted(sources.items()):
            assert source.is_file() and not source.is_symlink(), relative
            assert not relative.startswith('/') and '..' not in Path(relative).parts
            payload = source.read_bytes()
            assert not payload.startswith((b'\x7fELF', b'MZ', b'PK\x03\x04', b'!<arch>')), relative
            payload.decode('utf-8')
            member = tarfile.TarInfo(name + '/' + relative)
            member.mode = source.stat().st_mode & 0o777
            member.size = len(payload)
            archive.addfile(member, io.BytesIO(payload))
            inventory[relative] = {'sha256': hashlib.sha256(payload).hexdigest(), 'sizeBytes': len(payload)}
    with tarfile.open(target, 'r:gz') as verification:
        members = verification.getmembers()
        assert len(members) == len(inventory)
        for member in members:
            relative = member.name[len(name) + 1:]
            assert member.isfile() and (member.uid, member.gid, member.uname, member.gname) == (0, 0, '', '')
            assert hashlib.sha256(verification.extractfile(member).read()).hexdigest() == inventory[relative]['sha256']
    return {'archive': target.name, 'root': name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'sizeBytes': target.stat().st_size, 'regularFiles': len(inventory), 'memberPayloads': inventory, 'archiveOwnerFieldsAnonymous': True, 'allSourcePayloadsUnchanged': True}


receipts = []
for number in (1, 2):
    result = ROOT / f'results/seven-issue15-batch{number}'
    qualification = json.loads((result / 'qualification.json').read_text())
    state_path = ROOT / f'logs/seven-issue15-batch{number}.state.json'
    state = json.loads(state_path.read_text())
    assert qualification['status'] == 'PASS' and qualification['formalCells'] == 770
    assert qualification['sourceSdkArtifactIdentityUnchanged'] is True
    assert state['status'] == 'COMPLETE' and state['returnCode'] == 0
    assert (result / 'COMPLETE').is_file()
    for field in ('productionMain', 'productionMacro', 'productSourceSha256', 'effectiveHarnessSha256'):
        assert qualification[field] == expected[field], field
    sources = {path.relative_to(result).as_posix(): path for path in result.rglob('*') if path.is_file()}
    assert not any(name.startswith('task-control/') for name in sources)
    sources.update({'task-control/state.json': state_path, 'task-control/driver.py': ROOT / 'run-seven.py', 'task-control/driver.log': ROOT / f'logs/seven-issue15-batch{number}.log'})
    receipts.append(package(f'seven-library-issue15-batch{number}', sources))

sources = {}
for prefix, folder in [('first-preparation', ROOT / 'seven-build-audit'), ('completed-preparation', ROOT / 'seven-build-audit-second')]:
    assert folder.is_dir()
    for path in folder.rglob('*'):
        if path.is_file():
            sources[prefix + '/' + path.relative_to(folder).as_posix()] = path
for name in ['prepare-seven-first.py', 'prepare-seven.py', 'run-seven.py', 'run-pure.py', 'run-pure-optimized.py', 'with-sts120', 'pack-seven.py']:
    sources['tools/' + name] = ROOT / name
for name in ['production-export-receipt-optimized.json', 'seven-preparation-first-failure.json']:
    sources['receipts/' + name] = ROOT / name
receipts.append(package('seven-library-issue15-build-audits', sources))
record = {'status': 'PASS', 'productionMain': expected['productionMain'], 'productionMacro': expected['productionMacro'], 'scope': 'All formal result payloads, task controller records, completed and failed build preparation receipts. No binaries or Git metadata. Archive owner metadata is anonymous at creation.', 'archives': receipts}
(OUTPUT / 'server-packet-inventory.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({**record, 'archives': [{key: value for key, value in item.items() if key != 'memberPayloads'} for item in receipts]}, indent=2), flush=True)
