#!/usr/bin/env python3
"""Task-only preparation; never called during formal measurement."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path('/mnt')
WORKSPACE = ROOT / 'workspace'
REPO = WORKSPACE / 'repo'
ORIGIN = ROOT / 'peer-origin'
AUDIT = ROOT / 'seven-build-audit'
LOCK = (ROOT / 'measurement.lock').open('a')
fcntl.flock(LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)
AUDIT.mkdir()
(AUDIT / 'receipts').mkdir()
sys.path.insert(0, str(REPO / 'scripts'))
import benchmark_input_identity as identity
sys.path.insert(0, str(REPO / 'benchmarks/full-seven-library'))
spec = importlib.util.spec_from_file_location('seven_runner', REPO / 'benchmarks/full-seven-library/run_full.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
expected = json.loads((ROOT / 'production-export-receipt-optimized.json').read_text())

def capture(argv, cwd=REPO, env=None):
    return subprocess.check_output(argv, cwd=cwd, env=env, text=True, stderr=subprocess.STDOUT).strip()

def check_source():
    assert capture(['git', 'rev-parse', 'HEAD']) == expected['productionMain']
    assert capture(['git', 'rev-parse', 'HEAD'], REPO / 'packages/yjson_macros') == expected['productionMacro']
    assert not capture(['git', 'status', '--porcelain=v1', '--untracked-files=all'])
    assert identity.product_manifest(REPO) == expected['productManifest']
    assert identity.harness_manifest(REPO) == expected['harnessManifest']

check_source()
previous_dir = ORIGIN / 'candidate/audits/seven-batch-02/receipts'
previous = json.loads((previous_dir / 'final-build-readiness.json').read_text())
overlay = json.loads((previous_dir / 'frozen-measured-overlay.json').read_text())
assert previous['status'] == 'PASS'
assert previous['allMeasuredCangjieActualArgvExplicitO2'] is True
for relative in ['cangjieJSON-upstream', 'cjfast-json', 'json4cj', 'harness']:
    shutil.copytree(ORIGIN / 'candidate/workspace' / relative, WORKSPACE / relative, symlinks=True)
for relative, digest in previous['actualSourceTreeDigests'].items():
    if relative != 'repo':
        assert runner.source_digest(WORKSPACE / relative) == digest, relative
artifacts = {}
for key in ['seven-cjfast', 'seven-cjjson', 'seven-json4cj', 'java']:
    entry = previous['artifacts'][key]
    path = ROOT / entry['path']
    assert runner.file_digest(path) == entry['sha256'], key
    assert path.stat().st_size == entry['sizeBytes'], key
    artifacts[key] = {**entry, 'mode': 'reused original peer artifact, not rebuilt for this task'}
    if key != 'java':
        name = 'api-groups-seven-batch-02-' + key + '-compiler-argv.json'
        original = ORIGIN / 'receipts' / name
        argv_receipt = json.loads(original.read_text())
        assert argv_receipt['status'] == 'PASS'
        original_measured = [call for call in argv_receipt['calls'] if call['role'] == 'measured runtime or benchmark compilation']
        assert original_measured and all(
            '-O2' in call['argv'] and all(flag == '-O2' for flag in call['argv'] if flag.startswith('-O'))
            for call in original_measured
        ), key
        shutil.copy2(original, AUDIT / 'receipts' / name)
shutil.copy2(previous_dir / 'final-build-readiness.json', AUDIT / 'receipts/original-peer-build-readiness.json')
shutil.copy2(previous_dir / 'frozen-measured-overlay.json', AUDIT / 'receipts/original-peer-overlay.json')
actual_overlay = {relative: runner.file_digest(WORKSPACE / relative) for relative in overlay['files']}
assert actual_overlay == overlay['files']
overlay_digest = identity.manifest_digest(actual_overlay)
assert overlay_digest == previous['measuredOverlaySha256']
sdk_manifest = {p.relative_to(ROOT / 'sdk').as_posix(): runner.file_digest(p) for p in sorted((ROOT / 'sdk').rglob('*')) if p.is_file()}
assert len(sdk_manifest) == previous['sdk']['sdkEntries']
assert identity.manifest_digest(sdk_manifest) == previous['sdk']['sdkFileManifestSha256']
assert runner.file_digest(Path(sys.executable)) == previous['sdk']['pythonBinarySha256']
(AUDIT / 'receipts/sdk-manifest.json').write_text(json.dumps(sdk_manifest, indent=2) + '\n')
validation = capture(['python3', str(REPO / 'scripts/validate_cangjie_sts.py'), '--check-installed'])
env = os.environ.copy()
index = int(env.get('GIT_CONFIG_COUNT', '0'))
env[f'GIT_CONFIG_KEY_{index}'] = f'url.{(REPO / "packages/yjson_macros").as_uri()}.insteadOf'
env[f'GIT_CONFIG_VALUE_{index}'] = 'https://github.com/lIlIIlIll/yjson_macros.git'
env['GIT_CONFIG_COUNT'] = str(index + 1)
package = REPO / 'packages/benchmarks'
for label, argv in [('clean', ['cjpm', 'clean']), ('build', ['strace', '-f', '-s', '65535', '-e', 'trace=execve', '-o', str(AUDIT / 'yjson-build.execve.log'), 'cjpm', 'bench', '--no-color', '--no-run'])]:
    with (AUDIT / f'yjson-{label}.log').open('x') as output:
        completed = subprocess.run(argv, cwd=package, env=env, stdout=output, stderr=subprocess.STDOUT)
    assert completed.returncode == 0, (label, completed.returncode)
trace = (AUDIT / 'yjson-build.execve.log').read_text()
assert '--fno-chir-function-inlining' not in trace
calls = []
for line in trace.splitlines():
    match = re.search(r'execve\(("(?:\\.|[^"\\])*")\s*,\s*(\[.*?\])', line)
    if not match:
        continue
    try:
        executable, argv = json.loads(match[1]), json.loads(match[2])
    except json.JSONDecodeError:
        continue
    if Path(executable).name not in ['cjc', 'cjc-frontend'] or '= -1 ' in line:
        continue
    if '--scan-dependency' in argv:
        role = 'dependency scan'
    elif any(x in argv for x in ['-v', '--version', '--help']):
        role = 'compiler introspection'
    elif '--compile-macro' in argv:
        role = 'compile-time macro'
    elif any(x.endswith('/build.cj') for x in argv):
        role = 'build helper'
    elif any(x.endswith('/testrunner.cj') for x in argv):
        role = 'unused test framework launcher'
    else:
        role = 'measured runtime or benchmark compilation'
    calls.append({'executable': executable, 'argv': argv, 'role': role})
measured = [call for call in calls if call['role'] == 'measured runtime or benchmark compilation']
assert measured and all(
    '-O2' in call['argv'] and all(flag == '-O2' for flag in call['argv'] if flag.startswith('-O'))
    for call in measured
), measured
(AUDIT / 'receipts/yjson-compiler-argv.json').write_text(json.dumps({'status': 'PASS', 'calls': calls}, indent=2) + '\n')
main_binary = WORKSPACE / runner.CANGJIE_BINARIES['yjson']
artifacts['seven-yjson'] = {'path': main_binary.relative_to(ROOT).as_posix(), 'sha256': runner.file_digest(main_binary), 'sizeBytes': main_binary.stat().st_size, 'mode': 'rebuilt exact production Git-pinned source with explicit O2'}
check_source()
receipt = {'status': 'PASS', 'productionMain': expected['productionMain'], 'productionMacro': expected['productionMacro'], 'productSourceSha256': expected['productSourceSha256'], 'effectiveHarnessSha256': expected['effectiveHarnessSha256'], 'measuredOverlaySha256': overlay_digest, 'overlayFiles': actual_overlay, 'sourceTreeDigests': {relative: runner.source_digest(WORKSPACE / relative) for relative in previous['actualSourceTreeDigests']}, 'artifacts': artifacts, 'sdkManifestSha256': identity.manifest_digest(sdk_manifest), 'sdkValidation': validation, 'peerReusePolicy': 'Actual source trees, fixture bytes, artifacts and SDK verified against original build receipts. Peers are not claimed to be rebuilt.', 'formalMeasurementsStarted': False}
(AUDIT / 'receipts/ready.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
