#!/usr/bin/env python3
"""Qualify the optimized source pair without replacing first-failure evidence."""
from pathlib import Path
import fcntl
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/mnt')
mode, batch = sys.argv[1:]
assert mode in ('head-deep', 'release')
assert batch == 'second'
receipt = json.loads((ROOT / 'pure-snapshot-receipt-optimized.json').read_text())
candidate = 'pure-candidate-optimized'
source = ROOT / candidate
sys.path.insert(0, str(source / 'scripts'))
import benchmark_input_identity as identity

lock = (ROOT / 'measurement.lock').open('w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
(ROOT / 'logs').mkdir(exist_ok=True)
(ROOT / 'results').mkdir(exist_ok=True)
output = ROOT / 'results' / (mode + '-' + batch)
log_path = ROOT / 'logs' / (mode + '-' + batch + '.log')
assert not output.exists() and not log_path.exists()


def capture(command, cwd=None):
    return subprocess.check_output(command, cwd=cwd, text=True, stderr=subprocess.STDOUT).strip()


baseline = 'pure-head' if mode == 'head-deep' else 'pure-baseline'
for name in (baseline, candidate):
    folder = ROOT / name
    expected = receipt['snapshots'][name]
    assert capture(['git', 'rev-parse', 'HEAD'], folder) == expected['commit']
    assert capture(['git', 'rev-parse', 'HEAD^{tree}'], folder) == expected['tree']
    assert not capture(['git', 'status', '--porcelain=v1', '--untracked-files=all'], folder)
    assert identity.product_manifest(folder) == expected['productManifest']
    assert identity.harness_manifest(folder) == expected['harnessManifest']
assert identity.harness_manifest(ROOT / baseline) == identity.harness_manifest(source)

version = capture(['python3', str(ROOT / 'qualification/scripts/validate_cangjie_sts.py'), '--check-installed'])
assert version == '1.2.0', version
print(capture(['cjc', '-v']), flush=True)
print(capture(['cjpm', '--version']), flush=True)
command = ['python3', str(source / 'scripts/json_pure_perf_compare.py'),
           '--baseline', str(ROOT / baseline), '--candidate', str(source),
           '--corpus', '/mnt/corpus', '--output', str(output),
           '--rounds', '11', '--gate-mode', 'release', '--rebuild']
if mode == 'release':
    command += ['--enforce']
else:
    command += ['--case', 'yjsonStringDecodeDeepNestedProfiles',
                '--case', 'yjsonBytesDecodeDeepNestedProfiles']
record = {'command': command, 'mode': mode, 'batch': batch,
          'startUnixTime': time.time(), 'productionMain': receipt['productionMain'],
          'productionMacro': receipt['productionMacro'],
          'preFixMain': receipt['preFixMain'], 'preFixMacro': receipt['preFixMacro'],
          'commonHarnessSha256': receipt['commonHarnessSha256'],
          'orchestratorSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'status': 'RUNNING'}
record_path = ROOT / 'logs' / (mode + '-' + batch + '.json')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print('BEGIN', mode, batch, flush=True)
with log_path.open('x') as log:
    process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    result = process.wait()
record.update(returnCode=result, finishUnixTime=time.time(), status='PASS' if result == 0 else 'FAIL')
if result == 0:
    summary = json.loads((output / 'summary.json').read_text())
    record['gates'] = summary['gates']
    record['comparisons'] = summary['comparisons']
    if not summary['gates']['passed']:
        result = 1
        record['status'] = 'REGRESSION'
    record['comparisonExitCode'] = result
record_path.write_text(json.dumps(record, indent=2) + '\n')
print('COMPLETE', mode, batch, 'exit', result, flush=True)
raise SystemExit(result)
