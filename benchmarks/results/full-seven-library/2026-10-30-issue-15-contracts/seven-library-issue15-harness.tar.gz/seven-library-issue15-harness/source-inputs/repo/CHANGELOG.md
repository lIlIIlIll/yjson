# Changelog

本文件记录已发布版本和后续开发的用户可见变化。当前候选与历史发布说明见
[RELEASE_NOTES.md](RELEASE_NOTES.md)。历史 `1.0.0-rc.1` 的迁移步骤和验收记录分别保存在
[pre-1.0 → 1.0](docs/migration/pre-1.0-to-1.0.md) 与
`release/1.0.0-rc.1/evidence.md`。后者是历史仓库路径，不进入 `0.1.0` source archive。

## [Unreleased]

### 0.2.0 候选

- 产品、宏、示例、文档与 CI 统一到 Cangjie STS `1.2.0`；第一方包版本统一为 `0.2.0`。
- 整个 `0.x` 阶段不保证 patch 或 minor 的跨版本源码、API、ABI、生成代码或旧 SDK 兼容。
  升级时同步第一方依赖、重新展开宏并编译消费方；破坏性修改仍须逐项确认。
- 按已确认的迁移删除 `@JsonValue` 宏别名，改用 `@Json`。`JsonAlias` 字段读取别名、当前
  生成协议、ABI 错配校验、预算与资源生命周期语义保留。
- 修复 `@JsonCodec` 无参 struct 解码生成代码的字段赋值编译错误。
- 修复 JSON Pointer URI fragment 的百分号编码，空白、控制字符和 UTF-8 字节使用两位大写十六进制。
- 修复生成 Map、嵌套自定义 codec 和未知字段跳过路径的重复键策略；统一生成入口的读取预算，
  修复转义输出容量、混合写入深度、布尔 EOF、skip 空白、嵌套节点消费和 map 错误路径。
- 修复跨文件嵌套模型的 codec 查找与初始化，保留并发首次使用和递归模型的语义写入回退；
  延迟字段状态保留具体类型，仅缓存已证明恒定的 compact 肯定能力，动态自定义能力仍实时查询。
  仅实现接口的模型不再误当作继承 JSON 对象字段。
- 修复 Pure/Native/yyjson 标量类型错误及无定位 OOM 的异常分类；Schema 构造时校验未使用分支，
  URI template 检查保留 Unicode literal。逐项验收与边界见 [Issue #15 实施记录](docs/implementation/issue-15.md)。
- Custom Native 及 yyjson 的 Custom Native 回退路径在 backend metadata 中报告候选包版本 `0.2.0`。
- 文档候选要求九包统一站点、八个应用包的中文契约与逐入口可执行示例，交付 HTML、
  Markdown、Doc IR v16 和完整 Agent 离线包。不建设旧 URL、Doc IR 或产物布局兼容层。
- 文档工具固定为已发布并通过两次源码冷构建资格验证的 cjdoc `0.7.6`。本轮不创建 yjson tag 或发布九个包；
  实施、性能、托管 CI 和 Pages 的实际状态见[候选实施记录](docs/implementation/cjdoc-020.md)。
- 新性能证据使用 STS `1.2.0`；Pure 基线为 SDK 迁移后、旧包装清理前的源码。旧版测量和
  兼容结果保留为历史，不外推为新候选通过或跨 SDK 性能结论。

## [0.1.1] - 2026-09-21

- 已检入的 Cangjie public API、C ABI 和 generated-support v1 声明快照相对 `0.1.0` 不变；
  二进制兼容结论仍以冻结旧 consumer 的链接和调用矩阵为准。

- 修复字节输入的 UTF-8 字符串预算计费：非 ASCII 字符按实际消耗字节计数，避免长 ASCII
  前缀导致误报超限；转义后的 ASCII 后缀也纳入最终长度检查。
- 修复紧凑整数、字符串和数字数组的 `materialize(maxNodes)`，每个元素创建前扣减节点预算。
- provider 的 `primitives()` 回调失败后恢复可配置状态并唤醒等待者，保留原异常；Native
  底层回调抛异常时通过 `finally` 释放临时 raw-array handle。
- 第一方 Native provider 激活时校验实际链接库的 `YJ_JSON_ProbeV1()` 和基础能力位。
  不匹配时分别返回 `acceleration_abi_mismatch` 或 `acceleration_cpu_unsupported`，不冻结为 Native。
- 外部使用方门禁改为构建后直接执行二进制，不再把 `cjpm run` 的零退出码当作成功依据；
  runtime-freeze 门禁首次编译失败即终止，不重试 `llc` 崩溃。
- 性能候选身份统一处理独立宏的 Git 与本地 path 绑定，修复本地源码候选的发布图摘要不一致。
- 七库证据验收按正式运行器的规范 case 校验全部 workload/library 单元，拒绝彼此一致但误标
  workload 或库的日志与 sidecar；不改变测量协议、工作量或既有性能样本。
- 七库离线验收认证归档脚本并只执行可信检出中的汇总器，拒绝利用重算步骤执行归档代码；
  导入规范运行器时不生成字节码，避免校验自身破坏 clean-source 前提。
- Pure 发布验收使用冻结工作量的直接计时，七库 yjson 用例保留 SDKBench；两者分别校验
  实际调用数或 SDK 批次数、批大小及成功状态。仓颉进程固定 `cjProcessorNum=1`、128 MiB 堆，
  Pure 将业务与两组 GC 线程分核放置，七库仍为单核绑定。
- 候选 `c5ccfd6` 的 Pure 48 项预检和 528 个正式样本完整通过：24 项最大回退 2.06%，
  两侧 48 个 CV 均不超过 5%；七库两批各 770 个单元完整。保留此前 stream、Large Map
  encode 超限与旧协议失败记录，5% 门槛不变；不同协议不拼接样本，不声明 Native 性能或发布资格。

## [0.1.0] - 2026-09-16

- 当前成熟度版本线重置为 `0.1.0`；既有 1.x/2.0 tag 与 evidence 只作为不可变历史保留。
- 发布图固定为九个 lockstep package；`yjson_macros` 已拆为独立仓库
  `https://github.com/lIlIIlIll/yjson_macros`，但仍与 runtime 使用同一版本线。删除
  `yjson_all`，新增第一方 closed SPI `yjson_native_primitives`，并将宏展开产物固定为面向
  matching `yjson` runtime。
- `yjson_macros` 提供 `@Json({...})` expression macro，在编译期校验 JSON-like literal
  并生成可修改的 `JsonNode`；`@JsonValue` 为显式别名。支持 `$()` 插值，动态 key 使用后写覆盖。
- 全部同包测试改用 cjpm 的 `*_test.cj` 约定；release staging 复制 graph 声明的完整 source
  root，不再用 `lib_*`/`test_*` 文件名前缀决定产品源码。
- mutable `JsonNode` 的序列化、复制和等价比较现在检测祖先环，并允许共享 DAG 节点。
- direct writer 现在强制单一 root、统一 semantic/raw depth 预算，并在 stream sink 写出前检查
  `maxBytes`。
- Rune codec 只接受一个 Unicode scalar。legacy AST codec 对无法执行的非默认配置返回
  `unsupported_config`。
- JSONPath singularity 使用解析后的 selector 类型判定，不再根据表达式中的标点猜测。
- JSONPath cursor 改为惰性遍历，`first()` 在首个匹配后停止；Schema resolver graph 和 regex
  在构造阶段冻结，重复 validation 不再解析相同 schema。
- generated polymorphic codec 通过 concrete subtype 的 typed object provider 读写字段，不再
  复用从 open base 继承的 provider。
- generated codec lookup 改为全类型化
  `GeneratedCodecProviderV1<T> -> JsonCodec<T>`；删除 `GeneratedAnyCodecV1`、erase/reify
  adapter 和运行时类型转换。零状态 `GeneratedCodecTokenV1<T>` 支持父/子 provider 重载，
  concrete subtype codec 以类型化方式组合继承字段。
- 冻结后的普通 `YJson` 调用使用 atomic fast path，避免每次 encode/decode 获取全局 Mutex。
- Custom Native 与 yyjson 的 root serialization 和 document materialization 使用单次读锁
  bulk tape 路径；任意 retained 子 view 继续逐操作与 `close()` 线性化。
- formal performance runner 记录源码、工具链、语料与最终 binary 身份，并要求 clean、隔离的
  baseline 与 candidate rebuild。
- typed fast path 强制资源预算：`JsonFastReader` 构造携带 `JsonReadOptions`，扫描中执行
  `maxInputBytes` / `maxStringBytes` / `maxBufferedValueBytes`；default fast path 入口先执行
  与 DirectReader 相同的 limits 预检。
- HashMap 容器 codec 默认拒绝重复 key（`duplicateKeyPolicy: Reject` 抛 `duplicate_key`，
  按解码后 key 比较，`"a"` 与 `"\u0061"` 视为同一个）；`LastWins` 显式 opt-in。
- skip 未知字段路径在 `Reject` 策略下按层维护 seen key 并抛 `duplicate_key`，不再路由到
  native raw skip。
- compact parser 深度只计 array/object 容器，scalar 不计；specialized numeric/string 数组
  循环不增 depth（与资源限制文档一致）。
- native scanner 的 wrapper 错误统一为 `parse_error` 并携带 C 侧 offset 构造的
  `JsonLocation`；回退与 capacity 逻辑不变。
- 数值转换错误统一为 `number_out_of_range`（范围溢出）与 `invalid_value`（语法合法但转换
  失败且非范围问题，如 Rune 多 scalar）；stdlib parse 异常带上下文包装。
- `materialize` 单遍预算：`maxNodes` 传入递归构建，每节点创建前扣减，超限抛
  `work_limit_exceeded`；删除先 `materializeUnbounded` 再 deepCopy 校验的双阶段。
- managed document / root view / stream 保留 String owner，避免短生命周期输入在 view 读取前
  被回收；`YJsonByteArrayInputStream` 增加 `sourceText` 字段。
- yyjson 统计改用 C11 `_Atomic` relaxed 读取，root index 首次构建用 `once_flag`/`call_once`
  发布；SIMD 探测缓存（`cpu_has_avx2`/`numeric_avx2_enabled`）改原子 load + CAS 填充，
  getenv 只读一次。
- `CompactJsonDocument` 移除可变 `lookupCache` 与 `objectValueAt` 读路径写，宽对象查找回退
  线性扫描，文档保持 immutable。
- schema validator 运行态（baseUri/resource 栈、计数、depth、stopAtFirst、probeDepth、
  regex 预算）移入每次 validate/isValid 新建的 `ValidationContext`，validator 只保留
  immutable schema 引用。
- raw native activator `activateJsonNativePrimitivesV1` 降为 internal，槽位赋值只在 runtime
  初始化路径（校验后、Mutex 内）发生，删除公开无校验安装路径。
- 宏生成代码改用精确入口 `GeneratedSupportV1.enterGeneratedEntry()`（protocol 校验 +
  runtime freeze）；`toJson/fromJson` 精确重载直接调用该 helper，不再旁路 runtime freeze。
- C ABI 成本 probe（`YJ_Compact_Noop`/`ScalarProbe`/`CopyProbe`）移入 `YJ_TESTING` 条件，
  发布构建不导出。
- `yjson_native_primitives` 发布清单 `output-type` 统一为 `static`，并把
  `native/yjson_float_format.c` 及其 vendor/yyjson include 闭包纳入 native_files。
- standards conformance runner 支持 `--offline`（仅缓存）与 `--prefetch`（SHA-256 校验的
  预取）；CI standards job 使用 revision 作 cache key，运行 gate 显式 `--offline`。
- GitCode CI 每个 job 使用 run-id 唯一工作目录并在结束时清理，记录 cjc/cjpm 版本与
  runner identity；克隆前清理残留目录。
- Codecov 新增 algorithms/native/yyjson/schema-formats 独立 flag 与 patch gate；root core
  flag 与 macro 排除保持不变。
- 文档明确：生成代码引用的 `JsonFastReader`/`JsonDirectWriter`/`ReadCursor` 是 V1 协议表面；
  binary compatibility 以冻结旧 consumer artifact 的链接/调用矩阵实测为准，0.1.0 标注
  NOT PROVIDED；macro 每个 release 锁定单一 nightly；caller-owned stream 一次调用由单一
  任务独占；新增 `invalid_value` 稳定码说明。

## [2.0.0] - 2026-08-27

- 2.0 默认产品面收敛为单一 semantic engine；普通应用只使用 `YJson`，默认
  `JsonDocument` 为 GC 管理的只读 Compact representation，不再暴露 backend、资源生命周期
  或 `close()`。
- 新增真正增量的 `InputCursor`/`StreamInputCursor` 与共享 grammar；String、bytes 和 stream
  writer target 统一由一个结构状态机驱动。
- generated codec 改用版本化 generated-support v1 窄 SPI；宏生成源码不依赖具体
  reader/writer class，protocol 不变时允许跨 patch 版本。
- 新增 `yjson_native_accel`，应用只在首次 `YJson` 调用前执行一次
  `YJsonNativeAccel.initialize()`；进程冻结后不支持卸载、切换或故障静默回退。
- 将 resource-owning DOM/WholeDocument stream 移到 `yjson_backends` 高级 API，将 Schema、
  Pointer、Patch、Merge Patch 与 JSONPath 移到 `yjson_algorithms`；不提供 1.x 兼容 shim。
- 算法默认启用 visited/evaluation/match/copy/depth 等有限预算，耗尽统一抛出
  `JsonWorkLimitException(code: "work_limit_exceeded")`；Schema URI 只由注入的
  `UriResolver` 解析。
- release performance gate 固定输出 yjson、stdx.json、cjfast_json 的完整共同 workload 表；
  高 CV 行保留并标记为 noisy，不再被稳定性筛选隐藏。
- 新增 JSON Pointer（RFC 6901）、JSON Patch（RFC 6902）、JSON Merge Patch（RFC 7396）
  与 JSONPath（RFC 9535）API；Patch 的 copy 和 in-place 入口均为原子操作。
- JSON Schema 固定为 draft 2020-12，扩展 validation/applicator keyword，新增无网络
  `UriResolver` / `JsonSchemaRegistry`、format registry/provider，以及
  `Annotation` / `Assertion` / `StrictAssertion` 三种模式。
- 新增可选 `yjson_schema_formats` package，通过 libidn2 提供 IDNA2008/Punycode/Bidi/ContextJ，
  并提供 URI、IRI 与 RFC 6570 URI Template assertions；适用 optional suite 为 964/964。
- 新增固定 revision 的官方 standards conformance gate；JSON Schema required suite、
  JSONPath CTS 与 JSON Patch tests 当前分别为 1299/1299、703/703、108/108。
- 高级 `JsonStreamBackend` 仅保留显式 optional Custom Native / yyjson WholeDocument 实现；
  默认 `YJson.toStream/fromStream` 固定使用统一 incremental engine。
- typed codec contract 改为 backend-neutral `JsonCodecReader` / `JsonCodecWriter`；
  `JsonDirectCodec<T>` 直接更名为 `JsonCodec<T>`，不保留兼容 alias。
- `JsonWriteConfig` 新增 `maxBytes`，`0` 表示 unlimited，超限错误码为
  `output_too_large`。
- generated polymorphic decode 改为 capture/replay，不再 serialize/reparse。

## [1.0.0-rc.1] - 2026-08-22

- 首个 1.0 release candidate：compile-time generated codec、JSON literal、`JsonNode`、显式资源预算、
  Pure Compact DOM 与显式 opt-in Native packages。
