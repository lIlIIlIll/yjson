# yjson

**面向仓颉的类型安全 JSON 库**

*编译期编解码 · 可修改 JSON 树 · 只读文档 · 流式读写*

[![Tests](https://github.com/lIlIIlIll/yjson/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/lIlIIlIll/yjson/actions/workflows/ci.yml)
[![Core Coverage](https://codecov.io/gh/lIlIIlIll/yjson/branch/main/graph/badge.svg?flag=core)](https://codecov.io/gh/lIlIIlIll/yjson)
[![Latest historical GitHub release](https://img.shields.io/github/v/release/lIlIIlIll/yjson?display_name=tag&sort=semver&label=historical%20release)](https://github.com/lIlIIlIll/yjson/releases/latest)
![Current candidate 0.2.0](https://img.shields.io/badge/current%20candidate-0.2.0-F59E0B)
[![Apache License 2.0](https://img.shields.io/badge/License-Apache--2.0-yellow)](LICENSE)

yjson 是仓颉 JSON 库，支持类型与 JSON 互转、构造和修改 JSON 树、只读查询以及流式读写。
默认使用纯仓颉实现，由 GC 管理内存。

当前开发候选为 `0.2.0`，使用 Cangjie STS `1.2.0`。整个 `0.x` 阶段不保证 patch 或 minor
之间的源码、API、ABI、生成代码或旧 SDK 兼容。升级时同步第一方依赖，重新展开宏并编译应用。
历史版本的接口与验证结果不定义当前候选的保证。

[快速开始](#快速开始) · [API 选择](#按任务选择-api) · [可选包](#可选包) ·
[完整文档](docs/README.md)

## 适合什么场景

- class、struct、enum 与 JSON 之间的类型安全转换；
- 在源码中用 `@Json({...})` 构造可修改的 JSON 树；
- 不依赖运行时反射的编译期编解码；
- 修改 JSON 树、查询只读文档、读写调用方提供的流；
- 限制输入字节数、字符串大小、缓冲区大小和嵌套深度；
- JSON Schema draft 2020-12、JSON Pointer、JSON Patch、Merge Patch 和 JSONPath。

如果只需要 SDK 自带的基础 JSON 能力，先阅读[库能力对比](docs/library-comparison.md)。

## 安装

准备 Cangjie STS `1.2.0` 及匹配的 stdx。九个第一方包使用同一候选版本；分别从源码获取
宏与运行时时，也要选择已验证的配对提交。

仓库包含多个独立的 `cjpm` 模块。`yjson_macros` 是必须单独编译的宏模块，不能作为
runtime `yjson` 的子包。

从源码使用时，将两个仓库放在同级目录，并声明本地路径依赖。主仓库若要运行自身的宏测试，
请使用 `git clone --recurse-submodules`，或者单独下载 `yjson_macros` 仓库。

```toml
[dependencies]
yjson = { path = "../yjson" }
yjson_macros = { path = "../yjson_macros" }
```

也可以直接使用两个根模块的 Git 依赖：

```toml
[dependencies]
yjson = { git = "https://github.com/lIlIIlIll/yjson.git", branch = "main" }
yjson_macros = { git = "https://github.com/lIlIIlIll/yjson_macros.git", branch = "main" }
```

`cjpm` 当前不能从一个 monorepo 的 Git 依赖中选择子目录，因此不能使用 Git
`subdir` 选项。只允许一个 Git 依赖时，必须改用本地源码布局或不依赖宏包的
`JsonNode.object()`、`JsonNode.array()` 和 `put()` API。

只做 JSON 解析、节点操作、只读查询或使用手写编解码器时，添加 `yjson` 即可。
这份安装说明使用源码仓库，不依赖包仓库中的发布状态。`0.2.0` 候选尚不代表九包已发布；
当前变更与迁移要求见 [Release notes](RELEASE_NOTES.md)。

## 快速开始

```cangjie
package yjson_demo

import yjson.*
import yjson_macros.*

@JsonCodec
class User {
    public let id: Int64
    public let name: String

    public init(id: Int64, name: String) {
        this.id = id
        this.name = name
    }
}

main(): Unit {
    let text = YJson.toJson(User(7, "Alice"))
    let user = YJson.fromJson<User>(text)
    println(user.name)
}
```

输出：

```text
Alice
```

`@JsonCodec` 在编译应用时生成 `UserJson: JsonCodec<User>`，供 `YJson` 完成编解码，
不需要运行时反射。完整示例见
[`packages/examples`](packages/examples/README.md)。

## 按任务选择 API

| 任务 | 首选入口 | 结果或约束 |
| --- | --- | --- |
| 类型与 JSON 互转 | `YJson.toJson` / `YJson.fromJson<T>` | 类型使用 `@JsonCodec` |
| 使用内置或自定义编解码器 | 同一入口并传 `codec:` | 不要求类型使用宏 |
| 构造或修改 JSON 树 | `JsonNode.parse` / `JsonNode.object` / `JsonNode.array` | 返回可修改 `JsonNode` |
| 只读查询文档 | `YJson.parseDocument` | 返回 GC 管理的 `JsonDocument` |
| 读写调用方提供的流 | `YJson.fromJson(InputStream)` / `YJson.writeJson` | 不关闭调用方的流 |
| 校验 JSON | `yjson_algorithms.JsonSchema` | draft 2020-12；默认有限预算 |
| 定位、查询或更新节点 | `JsonPointer` / `JsonPath` / `JsonPatch` | 操作统一的 `JsonValueView` |

传入编解码器时，仍使用同一组 API：

```cangjie
let text = YJson.toJson("仓颉 JSON", codec: JsonCodecs.string)
let value = YJson.fromJson(text, codec: JsonCodecs.string)
```

完整选择说明见 [API 选择指南](docs/choosing-an-api.md)。

## 数据模型

```cangjie
let node = JsonNode.parse("{\"name\":\"Alice\"}").asObject()
node.put("active", JsonNode.boolean(true))
println(node.toJson(options: JsonWriteOptions.pretty()))

let document = YJson.parseDocument("{\"name\":\"Alice\"}")
let name = document.root().member("name").getOrThrow().asString()
```

`JsonValueView` 用同一套只读接口访问 `JsonNode`、`JsonDocument` 和可选后端的文档。
调用 `materialize()` 可以复制成可修改的树，默认最多复制 100,000 个节点，深度不超过 256 层。
需要调整节点数量上限时，传入 `maxNodes` 参数。

## 可选包

| 包 | 用途 |
| --- | --- |
| `yjson_macros` | `@JsonCodec`、`@Json`、`@JsonSubtype` 和 `@JsonUsing` 编译期宏 |
| `yjson_algorithms` | Pointer、Path、Patch、Merge Patch 和 Schema |
| `yjson_schema_formats` | Schema 国际化格式校验 |
| `yjson_native_accel` | 启动时为 `YJson` 启用原生加速 |
| `yjson_backends` + `yjson_native` | Custom Native 文档和整篇文档读写 |
| `yjson_backends` + `yjson_yyjson` | yyjson 文档和整篇文档读写 |

通过 `NativeBackends.customNative` 和 `YyjsonBackends.yyjson` 使用可选后端。
它们返回的 `BackendJsonDocument` 需要调用 `close()` 显式关闭，默认的 `JsonDocument` 由 GC 管理。详见 [Backend 使用指南](docs/backends.md)。

## 读写限制与并发

- `JsonReadOptions.defaults` 拒绝重复键，忽略类型解码时的未知字段，并设置 64 MiB
  输入、16 MiB 字符串、8 MiB 值缓冲区和 256 层深度上限；读取预算必须为正数。
- `JsonWriteOptions.defaults` 使用紧凑输出和 256 层深度；`maxOutputBytes = 0` 表示不设
  输出字节数上限。
- JSON 解析和校验错误使用 `JsonException`，处理时匹配 `error.code`。调用方的流或自定义
  编解码器抛出的异常也可能直接传出。
- 不可变的 `JsonDocument` 及其视图、编译后的 `JsonSchema` 支持并发读取。
  `JsonNode` 可以修改，仅通过 `JsonValueView` 访问它不会使底层数据不可变。
  `JsonPathCursor` 是有状态惰性迭代器，只能由一个线程消费。
- yjson 不关闭调用方提供的流。一次调用只处理一份 JSON 文档，文档后仍有非空白内容时会报错。
- 当前候选要求 Windows、macOS Pure 和 Linux Native 验证。未执行的平台不能记为通过；
  历史 `0.1.1` 结果见[发布记录](release/0.1.1/evidence.md)。

配置和预算见[配置与错误](docs/configuration-and-errors.md)及
[资源限制](docs/resource-limits.md)。

## 性能

生产源码 `ac4f8b9` 在 STS `1.2.0` 下通过 Pure 回退检查：24 项、528 个计时样本，
最大候选/基线比率为 1.017936，全部不超过原有 `1.05` 门槛。
七库两批各 770 个单元，第一批 9/10、第二批 7/10 workload 满足七库全部 `CV <= 5%`；
噪声行完整保留，没有第三批。干净检出 `d8859ee` 的完整 strict 检查与 40 项回归已通过。

下表只列第二批七库均稳定的七项，单位为微秒/操作、中位数。
仓颉测量构建使用显式 `-O2`，CHIR 函数内联保持启用；进程配置为
`cjProcessorNum=1`、`cjHeapSize=128MB`，七库单核绑定。

| Workload | yjson | stdx.json | cangjieJSON | json4cj | cjfast_json | Jackson | fastjson2 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Address decode | 0.249 | 1.868 | 0.562 | 1.783 | 0.691 | 0.323 | 0.071 |
| Person encode | 1.070 | 4.057 | 5.675 | 2.228 | 3.733 | 0.568 | 0.268 |
| Person decode | 1.536 | 7.115 | 4.929 | 6.195 | 4.695 | 1.129 | 0.419 |
| Large Array encode | 18.582 | 37.966 | 80.448 | 37.735 | 34.564 | 9.125 | 4.140 |
| Large Map decode | 11.876 | 53.624 | 58.784 | 50.266 | 49.766 | 5.393 | 3.991 |
| Deep Nested encode | 20.732 | 29.896 | 51.346 | 28.971 | 26.081 | 4.572 | 2.493 |
| Deep Nested decode | 46.830 | 48.643 | 36.399 | 44.246 | 32.868 | 10.362 | 3.424 |

完整波动、RSS、输入身份与历史记录见[七库报告](docs/performance/results/2026-10-30-api-contracts-seven-library.md)
和 [Pure 报告](docs/performance/results/2026-10-30-api-contracts-pure.md)。两种协议不拼接样本；本次不发布 yjson，
不外推到 Native、默认并发配置、其他平台或其他 SDK。方法见[性能文档](docs/performance/README.md)。

## 文档

- [文档导航](docs/README.md)
- [`@JsonCodec` 生成规则](docs/codec-generation.md)
- [自定义 Codec](docs/custom-codecs.md)
- [Stream I/O](docs/streams.md)
- [Backend 使用指南](docs/backends.md)
- [JSON Schema](docs/schema.md)
- [JSON Pointer、JSONPath 与 Patch](docs/path-and-patch.md)
- [公开 API 清单](docs/public-api-inventory.md)
- [Release notes](RELEASE_NOTES.md) · [Changelog](CHANGELOG.md)

`0.2.0` 文档候选采用九包统一站点，补齐八个应用包的中文契约与逐入口可执行示例。
站点入口为根目录 `index.html`；不提供旧 URL、旧 Doc IR 或旧产物布局的兼容层。
生成与验收要求见 [API 文档维护指南](docs/maintainers/api-documentation.md)。

维护者从[测试策略](docs/maintainers/testing.md)、
[发布流程](docs/maintainers/releasing.md)和
[仓库布局](docs/maintainers/repository-layout.md)开始。API 参考由固定版本的 cjdoc 从九个包生成；生成和已知限制见[文档导航](docs/README.md)。

## 参与项目

提交代码前阅读 [CONTRIBUTING.md](CONTRIBUTING.md)。安全问题按
[SECURITY.md](SECURITY.md) 报告，不要在公开 issue 中提交未修复漏洞的利用细节。

## 许可证

[Apache License 2.0](LICENSE)。可选 yyjson 后端的第三方许可见
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
