Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `encodePersonMemory` | 6.831 us | 6.922 us | 1.013x | -1.3% | 1/3 | 2.18% | 3.34% | 170076 | 170220 |
