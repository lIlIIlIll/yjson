Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeDeepNestedProfiles` | 23.478 us | 24.247 us | 1.033x | -3.3% | 0/3 | 1.78% | 0.74% | 128132 | 126264 |
| `yjsonStringEncodePerson` | 1.115 us | 1.117 us | 1.001x | -0.1% | 1/3 | 3.34% | 1.19% | 117096 | 116932 |
| `yjsonStringEncodeLargeProfileArray` | 20.408 us | 20.470 us | 1.003x | -0.3% | 1/3 | 0.79% | 3.11% | 145896 | 146848 |
| `yjsonBytesEncodeProfileBundle` | 4.121 us | 4.287 us | 1.040x | -4.0% | 0/3 | 1.30% | 1.44% | 138216 | 135892 |
| `yjsonBytesEncodeEscapedUnicodeString` | 0.639 us | 0.650 us | 1.017x | -1.7% | 0/3 | 1.75% | 5.09% | 170088 | 170452 |
| `encodePersonMemory` | 6.974 us | 7.001 us | 1.004x | -0.4% | 1/3 | 1.85% | 2.16% | 169604 | 170204 |
