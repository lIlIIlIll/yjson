Dump of assembler code for function _CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El:
   0x00000000004ed834 <+0>:	push   %rbp
   0x00000000004ed835 <+1>:	mov    %rsp,%rbp
   0x00000000004ed838 <+4>:	call   0x4ed83d <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+9>
   0x00000000004ed83d <+9>:	push   %r14
   0x00000000004ed83f <+11>:	push   %r13
   0x00000000004ed841 <+13>:	push   %r12
   0x00000000004ed843 <+15>:	push   %rbx
   0x00000000004ed844 <+16>:	sub    $0xe8,%rsp
   0x00000000004ed84b <+23>:	mov    0x28(%r15),%rax
   0x00000000004ed84f <+27>:	cmp    %rax,%rsp
   0x00000000004ed852 <+30>:	jbe    0x4edf79 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1861>
   0x00000000004ed858 <+36>:	mov    %rcx,%r12
   0x00000000004ed85b <+39>:	mov    %rdx,%rbx
   0x00000000004ed85e <+42>:	mov    %rsi,%r13
   0x00000000004ed861 <+45>:	mov    0xc(%rdx),%r14d
   0x00000000004ed865 <+49>:	mov    0x30(%r15),%rax
   0x00000000004ed869 <+53>:	cmp    $0x0,%rax
   0x00000000004ed870 <+60>:	jne    0x4edf9b <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1895>
   0x00000000004ed876 <+66>:	test   %r8,%r8
   0x00000000004ed879 <+69>:	js     0x4edc32 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1022>
   0x00000000004ed87f <+75>:	movabs $0x7fffffffffffffff,%rax
   0x00000000004ed889 <+85>:	mov    %r14,%rcx
   0x00000000004ed88c <+88>:	xor    %rax,%rcx
   0x00000000004ed88f <+91>:	cmp    %r8,%rcx
   0x00000000004ed892 <+94>:	jb     0x4edc77 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1091>
   0x00000000004ed898 <+100>:	add    %r14,%r8
   0x00000000004ed89b <+103>:	jo     0x4edc63 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1071>
   0x00000000004ed8a1 <+109>:	mov    0x20(%r12),%rcx
   0x00000000004ed8a6 <+114>:	test   %rcx,%rcx
   0x00000000004ed8a9 <+117>:	js     0x4edc32 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1022>
   0x00000000004ed8af <+123>:	movabs $0x2aaaaaaaaaaaaaab,%rdx
   0x00000000004ed8b9 <+133>:	cmp    %rdx,%rcx
   0x00000000004ed8bc <+136>:	jae    0x4edcf0 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1212>
   0x00000000004ed8c2 <+142>:	lea    (%rcx,%rcx,2),%rcx
   0x00000000004ed8c6 <+146>:	lea    -0x2(%rax),%rdx
   0x00000000004ed8ca <+150>:	cmp    %rdx,%rcx
   0x00000000004ed8cd <+153>:	ja     0x4edd69 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1333>
   0x00000000004ed8d3 <+159>:	test   %r8,%r8
   0x00000000004ed8d6 <+162>:	js     0x4edc32 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1022>
   0x00000000004ed8dc <+168>:	add    $0x2,%rcx
   0x00000000004ed8e0 <+172>:	sub    %r8,%rax
   0x00000000004ed8e3 <+175>:	cmp    %rcx,%rax
   0x00000000004ed8e6 <+178>:	jb     0x4edde2 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1454>
   0x00000000004ed8ec <+184>:	add    %rcx,%r8
   0x00000000004ed8ef <+187>:	jo     0x4edc63 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1071>
   0x00000000004ed8f5 <+193>:	test   %r8,%r8
   0x00000000004ed8f8 <+196>:	mov    %rdi,-0x38(%rbp)
   0x00000000004ed8fc <+200>:	jle    0x4ed91e <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+234>
   0x00000000004ed8fe <+202>:	mov    0x20(%r13),%rax
   0x00000000004ed902 <+206>:	cmp    %r8,%rax
   0x00000000004ed905 <+209>:	jle    0x4ed91e <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+234>
   0x00000000004ed907 <+211>:	add    0x30(%r13),%r8
   0x00000000004ed90b <+215>:	jo     0x4edc63 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1071>
   0x00000000004ed911 <+221>:	cmp    %rax,%r8
   0x00000000004ed914 <+224>:	jle    0x4ed91e <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+234>
   0x00000000004ed916 <+226>:	mov    %r13,%rdi
   0x00000000004ed919 <+229>:	call   0x4e9e14 <_CN5yjson24DirectStreamWriterTarget11flushBufferHv>
   0x00000000004ed91e <+234>:	mov    %r13,%rsi
   0x00000000004ed921 <+237>:	mov    %rbx,%rdx
   0x00000000004ed924 <+240>:	xor    %ecx,%ecx
   0x00000000004ed926 <+242>:	mov    %r14,%r8
   0x00000000004ed929 <+245>:	call   0x4ea4f4 <_CN5yjson24DirectStreamWriterTarget14writeTextRangeHRNat6StringEll>
   0x00000000004ed92e <+250>:	mov    %r13,%rdi
   0x00000000004ed931 <+253>:	mov    $0x5b,%esi
   0x00000000004ed936 <+258>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004ed93b <+263>:	cmpq   $0x0,0x20(%r12)
   0x00000000004ed941 <+269>:	je     0x4edaee <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+698>
   0x00000000004ed947 <+275>:	jle    0x4ede5b <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1575>
   0x00000000004ed94d <+281>:	cmpq   $0x0,0x18(%r12)
   0x00000000004ed953 <+287>:	je     0x4edf29 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1781>
   0x00000000004ed959 <+293>:	mov    0x8(%r12),%rax
   0x00000000004ed95e <+298>:	mov    0x10(%r12),%rbx
   0x00000000004ed963 <+303>:	mov    %rax,%rcx
   0x00000000004ed966 <+306>:	shr    $0x30,%rcx
   0x00000000004ed96a <+310>:	je     0x4ed979 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+325>
   0x00000000004ed96c <+312>:	lea    0x8(%r12),%rsi
   0x00000000004ed971 <+317>:	mov    %r12,%rdi
   0x00000000004ed974 <+320>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004ed979 <+325>:	lea    0x8(%rax),%r14
   0x00000000004ed97d <+329>:	shl    $0x4,%rbx
   0x00000000004ed981 <+333>:	mov    0x10(%rax,%rbx,1),%rcx
   0x00000000004ed986 <+338>:	mov    %rcx,%rdx
   0x00000000004ed989 <+341>:	shr    $0x30,%rdx
   0x00000000004ed98d <+345>:	je     0x4ed9a2 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+366>
   0x00000000004ed98f <+347>:	lea    (%rax,%rbx,1),%rsi
   0x00000000004ed993 <+351>:	add    $0x10,%rsi
   0x00000000004ed997 <+355>:	mov    %rax,%rdi
   0x00000000004ed99a <+358>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004ed99f <+363>:	mov    %rax,%rcx
   0x00000000004ed9a2 <+366>:	mov    %rcx,-0x100(%rbp)
   0x00000000004ed9a9 <+373>:	mov    0x10(%r14,%rbx,1),%r14
   0x00000000004ed9ae <+378>:	mov    %r14,-0xf8(%rbp)
   0x00000000004ed9b5 <+385>:	mov    %r13,%rdi
   0x00000000004ed9b8 <+388>:	mov    $0x22,%esi
   0x00000000004ed9bd <+393>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004ed9c2 <+398>:	shr    $0x20,%r14
   0x00000000004ed9c6 <+402>:	lea    -0x100(%rbp),%rdx
   0x00000000004ed9cd <+409>:	mov    %r13,%rsi
   0x00000000004ed9d0 <+412>:	xor    %ecx,%ecx
   0x00000000004ed9d2 <+414>:	mov    %r14,%r8
   0x00000000004ed9d5 <+417>:	call   0x4ea4f4 <_CN5yjson24DirectStreamWriterTarget14writeTextRangeHRNat6StringEll>
   0x00000000004ed9da <+422>:	mov    %r13,%rdi
   0x00000000004ed9dd <+425>:	mov    $0x22,%esi
   0x00000000004ed9e2 <+430>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004ed9e7 <+435>:	mov    0x20(%r12),%rax
   0x00000000004ed9ec <+440>:	mov    %rax,-0x108(%rbp)
   0x00000000004ed9f3 <+447>:	cmp    $0x2,%rax
   0x00000000004ed9f7 <+451>:	jl     0x4edaee <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+698>
   0x00000000004ed9fd <+457>:	mov    $0x1,%ebx
   0x00000000004eda02 <+462>:	jmp    0x4eda6c <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+568>
   0x00000000004eda04 <+464>:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   0x00000000004eda10 <+476>:	mov    %rcx,-0xf0(%rbp)
   0x00000000004eda17 <+483>:	mov    0x10(%rbx,%r14,1),%r14
   0x00000000004eda1c <+488>:	mov    %r14,-0xe8(%rbp)
   0x00000000004eda23 <+495>:	mov    %r13,%rdi
   0x00000000004eda26 <+498>:	mov    $0x22,%esi
   0x00000000004eda2b <+503>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004eda30 <+508>:	shr    $0x20,%r14
   0x00000000004eda34 <+512>:	mov    %r13,%rsi
   0x00000000004eda37 <+515>:	lea    -0xf0(%rbp),%rdx
   0x00000000004eda3e <+522>:	xor    %ecx,%ecx
   0x00000000004eda40 <+524>:	mov    %r14,%r8
   0x00000000004eda43 <+527>:	call   0x4ea4f4 <_CN5yjson24DirectStreamWriterTarget14writeTextRangeHRNat6StringEll>
   0x00000000004eda48 <+532>:	mov    %r13,%rdi
   0x00000000004eda4b <+535>:	mov    $0x22,%esi
   0x00000000004eda50 <+540>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004eda55 <+545>:	mov    -0x98(%rbp),%rbx
   0x00000000004eda5c <+552>:	inc    %rbx
   0x00000000004eda5f <+555>:	cmp    %rbx,-0x108(%rbp)
   0x00000000004eda66 <+562>:	je     0x4edaee <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+698>
   0x00000000004eda6c <+568>:	mov    %r13,%rdi
   0x00000000004eda6f <+571>:	mov    $0x2c,%esi
   0x00000000004eda74 <+576>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004eda79 <+581>:	cmp    0x20(%r12),%rbx
   0x00000000004eda7e <+586>:	mov    %rbx,-0x98(%rbp)
   0x00000000004eda85 <+593>:	jge    0x4edb10 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+732>
   0x00000000004eda8b <+599>:	mov    0x18(%r12),%rsi
   0x00000000004eda90 <+604>:	cmp    %rsi,%rbx
   0x00000000004eda93 <+607>:	jae    0x4edbe3 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+943>
   0x00000000004eda99 <+613>:	mov    0x8(%r12),%rax
   0x00000000004eda9e <+618>:	mov    0x10(%r12),%r14
   0x00000000004edaa3 <+623>:	mov    %rax,%rcx
   0x00000000004edaa6 <+626>:	shr    $0x30,%rcx
   0x00000000004edaaa <+630>:	je     0x4edab9 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+645>
   0x00000000004edaac <+632>:	lea    0x8(%r12),%rsi
   0x00000000004edab1 <+637>:	mov    %r12,%rdi
   0x00000000004edab4 <+640>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004edab9 <+645>:	add    %rbx,%r14
   0x00000000004edabc <+648>:	lea    0x8(%rax),%rbx
   0x00000000004edac0 <+652>:	shl    $0x4,%r14
   0x00000000004edac4 <+656>:	mov    0x10(%rax,%r14,1),%rcx
   0x00000000004edac9 <+661>:	mov    %rcx,%rdx
   0x00000000004edacc <+664>:	shr    $0x30,%rdx
   0x00000000004edad0 <+668>:	je     0x4eda10 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+476>
   0x00000000004edad6 <+674>:	lea    (%rax,%r14,1),%rsi
   0x00000000004edada <+678>:	add    $0x10,%rsi
   0x00000000004edade <+682>:	mov    %rax,%rdi
   0x00000000004edae1 <+685>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004edae6 <+690>:	mov    %rax,%rcx
   0x00000000004edae9 <+693>:	jmp    0x4eda10 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+476>
   0x00000000004edaee <+698>:	mov    %r13,%rdi
   0x00000000004edaf1 <+701>:	mov    $0x5d,%esi
   0x00000000004edaf6 <+706>:	call   0x4ea094 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004edafb <+711>:	mov    -0x38(%rbp),%rax
   0x00000000004edaff <+715>:	add    $0xe8,%rsp
   0x00000000004edb06 <+722>:	pop    %rbx
   0x00000000004edb07 <+723>:	pop    %r12
   0x00000000004edb09 <+725>:	pop    %r13
   0x00000000004edb0b <+727>:	pop    %r14
   0x00000000004edb0d <+729>:	pop    %rcx
   0x00000000004edb0e <+730>:	pop    %rbp
   0x00000000004edb0f <+731>:	ret    
   0x00000000004edb10 <+732>:	mov    0x59a4b9(%rip),%r14        # 0xa87fd0
   0x00000000004edb17 <+739>:	mov    0xc(%r14),%esi
   0x00000000004edb1b <+743>:	add    $0xf,%esi
   0x00000000004edb1e <+746>:	and    $0xfffffff8,%esi
   0x00000000004edb21 <+749>:	mov    %r14,%rdi
   0x00000000004edb24 <+752>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edb29 <+757>:	mov    %rax,%rbx
   0x00000000004edb2c <+760>:	mov    $0x23,%esi
   0x00000000004edb31 <+765>:	mov    %rax,%rdi
   0x00000000004edb34 <+768>:	mov    %r14,%rdx
   0x00000000004edb37 <+771>:	call   0x20f210 <_CNat13StringBuilder6<init>Hl@plt>
   0x00000000004edb3c <+776>:	lea    0x57cf9d(%rip),%rdx        # 0xa6aae0
   0x00000000004edb43 <+783>:	lea    -0x30(%rbp),%r13
   0x00000000004edb47 <+787>:	mov    %r13,%rdi
   0x00000000004edb4a <+790>:	mov    %rbx,%rsi
   0x00000000004edb4d <+793>:	mov    %r14,%rcx
   0x00000000004edb50 <+796>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004edb55 <+801>:	mov    %r13,%rdi
   0x00000000004edb58 <+804>:	mov    %rbx,%rsi
   0x00000000004edb5b <+807>:	mov    -0x98(%rbp),%rdx
   0x00000000004edb62 <+814>:	mov    %r14,%rcx
   0x00000000004edb65 <+817>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004edb6a <+822>:	lea    0x57cf7f(%rip),%rdx        # 0xa6aaf0
   0x00000000004edb71 <+829>:	mov    %r13,%rdi
   0x00000000004edb74 <+832>:	mov    %rbx,%rsi
   0x00000000004edb77 <+835>:	mov    %r14,%rcx
   0x00000000004edb7a <+838>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004edb7f <+843>:	mov    0x20(%r12),%rdx
   0x00000000004edb84 <+848>:	mov    %r13,%rdi
   0x00000000004edb87 <+851>:	mov    %rbx,%rsi
   0x00000000004edb8a <+854>:	mov    %r14,%rcx
   0x00000000004edb8d <+857>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004edb92 <+862>:	xorps  %xmm0,%xmm0
   0x00000000004edb95 <+865>:	movaps %xmm0,-0xc0(%rbp)
   0x00000000004edb9c <+872>:	lea    -0xc0(%rbp),%r12
   0x00000000004edba3 <+879>:	mov    %r12,%rdi
   0x00000000004edba6 <+882>:	mov    %rbx,%rsi
   0x00000000004edba9 <+885>:	mov    %r14,%rdx
   0x00000000004edbac <+888>:	call   0x210f00 <_CNat13StringBuilder8toStringHv@plt>
   0x00000000004edbb1 <+893>:	mov    0x59a370(%rip),%r14        # 0xa87f28
   0x00000000004edbb8 <+900>:	mov    0xc(%r14),%esi
   0x00000000004edbbc <+904>:	add    $0xf,%esi
   0x00000000004edbbf <+907>:	and    $0xfffffff8,%esi
   0x00000000004edbc2 <+910>:	mov    %r14,%rdi
   0x00000000004edbc5 <+913>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edbca <+918>:	mov    %rax,%rbx
   0x00000000004edbcd <+921>:	mov    %rax,%rdi
   0x00000000004edbd0 <+924>:	mov    %r12,%rsi
   0x00000000004edbd3 <+927>:	mov    %r14,%rdx
   0x00000000004edbd6 <+930>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004edbdb <+935>:	mov    %rbx,%rdi
   0x00000000004edbde <+938>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edbe3 <+943>:	xorps  %xmm0,%xmm0
   0x00000000004edbe6 <+946>:	movaps %xmm0,-0xb0(%rbp)
   0x00000000004edbed <+953>:	mov    %rbx,%rdx
   0x00000000004edbf0 <+956>:	lea    -0xb0(%rbp),%r14
   0x00000000004edbf7 <+963>:	mov    %r14,%rdi
   0x00000000004edbfa <+966>:	call   0x20ed80 <_CNatUarray$37arrayIndexOutOfBoundsExceptionMessageHll@plt>
   0x00000000004edbff <+971>:	mov    0x59a322(%rip),%r12        # 0xa87f28
   0x00000000004edc06 <+978>:	mov    0xc(%r12),%esi
   0x00000000004edc0b <+983>:	add    $0xf,%esi
   0x00000000004edc0e <+986>:	and    $0xfffffff8,%esi
   0x00000000004edc11 <+989>:	mov    %r12,%rdi
   0x00000000004edc14 <+992>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edc19 <+997>:	mov    %rax,%rbx
   0x00000000004edc1c <+1000>:	mov    %rax,%rdi
   0x00000000004edc1f <+1003>:	mov    %r14,%rsi
   0x00000000004edc22 <+1006>:	mov    %r12,%rdx
   0x00000000004edc25 <+1009>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004edc2a <+1014>:	mov    %rbx,%rdi
   0x00000000004edc2d <+1017>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edc32 <+1022>:	mov    0x59a35f(%rip),%r14        # 0xa87f98
   0x00000000004edc39 <+1029>:	mov    %r14,%rdi
   0x00000000004edc3c <+1032>:	mov    $0x40,%esi
   0x00000000004edc41 <+1037>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edc46 <+1042>:	mov    %rax,%rbx
   0x00000000004edc49 <+1045>:	lea    0x57ddd0(%rip),%rsi        # 0xa6ba20
   0x00000000004edc50 <+1052>:	mov    %rax,%rdi
   0x00000000004edc53 <+1055>:	mov    %r14,%rdx
   0x00000000004edc56 <+1058>:	call   0x20ed70 <_CNat24IllegalArgumentException6<init>HRNat6StringE@plt>
   0x00000000004edc5b <+1063>:	mov    %rbx,%rdi
   0x00000000004edc5e <+1066>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edc63 <+1071>:	lea    0x57ce96(%rip),%rdi        # 0xa6ab00
   0x00000000004edc6a <+1078>:	call   0x20f9c0 <rt$CreateOverflowException_msg@plt>
   0x00000000004edc6f <+1083>:	mov    %rax,%rdi
   0x00000000004edc72 <+1086>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edc77 <+1091>:	movups 0x57ce12(%rip),%xmm0        # 0xa6aa90
   0x00000000004edc7e <+1098>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004edc82 <+1102>:	xorps  %xmm0,%xmm0
   0x00000000004edc85 <+1105>:	movups %xmm0,-0x69(%rbp)
   0x00000000004edc89 <+1109>:	movq   $0x0,-0x59(%rbp)
   0x00000000004edc91 <+1117>:	movb   $0x1,-0x90(%rbp)
   0x00000000004edc98 <+1124>:	movups -0x70(%rbp),%xmm0
   0x00000000004edc9c <+1128>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004edca3 <+1135>:	mov    -0x61(%rbp),%rax
   0x00000000004edca7 <+1139>:	mov    %rax,-0x80(%rbp)
   0x00000000004edcab <+1143>:	mov    -0x59(%rbp),%rax
   0x00000000004edcaf <+1147>:	mov    %rax,-0x78(%rbp)
   0x00000000004edcb3 <+1151>:	lea    0x816356(%rip),%rdi        # 0xd04010 <yjson:JsonException.ti>
   0x00000000004edcba <+1158>:	mov    $0x80,%esi
   0x00000000004edcbf <+1163>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edcc4 <+1168>:	mov    %rax,%rbx
   0x00000000004edcc7 <+1171>:	lea    0x57dd62(%rip),%rsi        # 0xa6ba30
   0x00000000004edcce <+1178>:	lea    0x57d5bb(%rip),%rdx        # 0xa6b290
   0x00000000004edcd5 <+1185>:	lea    -0x50(%rbp),%rcx
   0x00000000004edcd9 <+1189>:	lea    -0x90(%rbp),%r8
   0x00000000004edce0 <+1196>:	mov    %rax,%rdi
   0x00000000004edce3 <+1199>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004edce8 <+1204>:	mov    %rbx,%rdi
   0x00000000004edceb <+1207>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edcf0 <+1212>:	movups 0x57cd99(%rip),%xmm0        # 0xa6aa90
   0x00000000004edcf7 <+1219>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004edcfb <+1223>:	xorps  %xmm0,%xmm0
   0x00000000004edcfe <+1226>:	movups %xmm0,-0x69(%rbp)
   0x00000000004edd02 <+1230>:	movq   $0x0,-0x59(%rbp)
   0x00000000004edd0a <+1238>:	movb   $0x1,-0x90(%rbp)
   0x00000000004edd11 <+1245>:	movups -0x70(%rbp),%xmm0
   0x00000000004edd15 <+1249>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004edd1c <+1256>:	mov    -0x61(%rbp),%rax
   0x00000000004edd20 <+1260>:	mov    %rax,-0x80(%rbp)
   0x00000000004edd24 <+1264>:	mov    -0x59(%rbp),%rax
   0x00000000004edd28 <+1268>:	mov    %rax,-0x78(%rbp)
   0x00000000004edd2c <+1272>:	lea    0x8162dd(%rip),%rdi        # 0xd04010 <yjson:JsonException.ti>
   0x00000000004edd33 <+1279>:	mov    $0x80,%esi
   0x00000000004edd38 <+1284>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edd3d <+1289>:	mov    %rax,%rbx
   0x00000000004edd40 <+1292>:	lea    0x57dce9(%rip),%rsi        # 0xa6ba30
   0x00000000004edd47 <+1299>:	lea    0x57d542(%rip),%rdx        # 0xa6b290
   0x00000000004edd4e <+1306>:	lea    -0x50(%rbp),%rcx
   0x00000000004edd52 <+1310>:	lea    -0x90(%rbp),%r8
   0x00000000004edd59 <+1317>:	mov    %rax,%rdi
   0x00000000004edd5c <+1320>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004edd61 <+1325>:	mov    %rbx,%rdi
   0x00000000004edd64 <+1328>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edd69 <+1333>:	movups 0x57cd20(%rip),%xmm0        # 0xa6aa90
   0x00000000004edd70 <+1340>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004edd74 <+1344>:	xorps  %xmm0,%xmm0
   0x00000000004edd77 <+1347>:	movups %xmm0,-0x69(%rbp)
   0x00000000004edd7b <+1351>:	movq   $0x0,-0x59(%rbp)
   0x00000000004edd83 <+1359>:	movb   $0x1,-0x90(%rbp)
   0x00000000004edd8a <+1366>:	movups -0x70(%rbp),%xmm0
   0x00000000004edd8e <+1370>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004edd95 <+1377>:	mov    -0x61(%rbp),%rax
   0x00000000004edd99 <+1381>:	mov    %rax,-0x80(%rbp)
   0x00000000004edd9d <+1385>:	mov    -0x59(%rbp),%rax
   0x00000000004edda1 <+1389>:	mov    %rax,-0x78(%rbp)
   0x00000000004edda5 <+1393>:	lea    0x816264(%rip),%rdi        # 0xd04010 <yjson:JsonException.ti>
   0x00000000004eddac <+1400>:	mov    $0x80,%esi
   0x00000000004eddb1 <+1405>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004eddb6 <+1410>:	mov    %rax,%rbx
   0x00000000004eddb9 <+1413>:	lea    0x57dc70(%rip),%rsi        # 0xa6ba30
   0x00000000004eddc0 <+1420>:	lea    0x57d4c9(%rip),%rdx        # 0xa6b290
   0x00000000004eddc7 <+1427>:	lea    -0x50(%rbp),%rcx
   0x00000000004eddcb <+1431>:	lea    -0x90(%rbp),%r8
   0x00000000004eddd2 <+1438>:	mov    %rax,%rdi
   0x00000000004eddd5 <+1441>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004eddda <+1446>:	mov    %rbx,%rdi
   0x00000000004edddd <+1449>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edde2 <+1454>:	movups 0x57cca7(%rip),%xmm0        # 0xa6aa90
   0x00000000004edde9 <+1461>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004edded <+1465>:	xorps  %xmm0,%xmm0
   0x00000000004eddf0 <+1468>:	movups %xmm0,-0x69(%rbp)
   0x00000000004eddf4 <+1472>:	movq   $0x0,-0x59(%rbp)
   0x00000000004eddfc <+1480>:	movb   $0x1,-0x90(%rbp)
   0x00000000004ede03 <+1487>:	movups -0x70(%rbp),%xmm0
   0x00000000004ede07 <+1491>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004ede0e <+1498>:	mov    -0x61(%rbp),%rax
   0x00000000004ede12 <+1502>:	mov    %rax,-0x80(%rbp)
   0x00000000004ede16 <+1506>:	mov    -0x59(%rbp),%rax
   0x00000000004ede1a <+1510>:	mov    %rax,-0x78(%rbp)
   0x00000000004ede1e <+1514>:	lea    0x8161eb(%rip),%rdi        # 0xd04010 <yjson:JsonException.ti>
   0x00000000004ede25 <+1521>:	mov    $0x80,%esi
   0x00000000004ede2a <+1526>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004ede2f <+1531>:	mov    %rax,%rbx
   0x00000000004ede32 <+1534>:	lea    0x57dbf7(%rip),%rsi        # 0xa6ba30
   0x00000000004ede39 <+1541>:	lea    0x57d450(%rip),%rdx        # 0xa6b290
   0x00000000004ede40 <+1548>:	lea    -0x50(%rbp),%rcx
   0x00000000004ede44 <+1552>:	lea    -0x90(%rbp),%r8
   0x00000000004ede4b <+1559>:	mov    %rax,%rdi
   0x00000000004ede4e <+1562>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004ede53 <+1567>:	mov    %rbx,%rdi
   0x00000000004ede56 <+1570>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004ede5b <+1575>:	mov    0x59a16e(%rip),%r14        # 0xa87fd0
   0x00000000004ede62 <+1582>:	mov    0xc(%r14),%esi
   0x00000000004ede66 <+1586>:	add    $0xf,%esi
   0x00000000004ede69 <+1589>:	and    $0xfffffff8,%esi
   0x00000000004ede6c <+1592>:	mov    %r14,%rdi
   0x00000000004ede6f <+1595>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004ede74 <+1600>:	mov    %rax,%rbx
   0x00000000004ede77 <+1603>:	mov    $0x23,%esi
   0x00000000004ede7c <+1608>:	mov    %rax,%rdi
   0x00000000004ede7f <+1611>:	mov    %r14,%rdx
   0x00000000004ede82 <+1614>:	call   0x20f210 <_CNat13StringBuilder6<init>Hl@plt>
   0x00000000004ede87 <+1619>:	lea    0x57cc52(%rip),%rdx        # 0xa6aae0
   0x00000000004ede8e <+1626>:	lea    -0x30(%rbp),%r13
   0x00000000004ede92 <+1630>:	mov    %r13,%rdi
   0x00000000004ede95 <+1633>:	mov    %rbx,%rsi
   0x00000000004ede98 <+1636>:	mov    %r14,%rcx
   0x00000000004ede9b <+1639>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004edea0 <+1644>:	mov    %r13,%rdi
   0x00000000004edea3 <+1647>:	mov    %rbx,%rsi
   0x00000000004edea6 <+1650>:	xor    %edx,%edx
   0x00000000004edea8 <+1652>:	mov    %r14,%rcx
   0x00000000004edeab <+1655>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004edeb0 <+1660>:	lea    0x57cc39(%rip),%rdx        # 0xa6aaf0
   0x00000000004edeb7 <+1667>:	mov    %r13,%rdi
   0x00000000004edeba <+1670>:	mov    %rbx,%rsi
   0x00000000004edebd <+1673>:	mov    %r14,%rcx
   0x00000000004edec0 <+1676>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004edec5 <+1681>:	mov    0x20(%r12),%rdx
   0x00000000004edeca <+1686>:	mov    %r13,%rdi
   0x00000000004edecd <+1689>:	mov    %rbx,%rsi
   0x00000000004eded0 <+1692>:	mov    %r14,%rcx
   0x00000000004eded3 <+1695>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004eded8 <+1700>:	xorps  %xmm0,%xmm0
   0x00000000004ededb <+1703>:	movaps %xmm0,-0xe0(%rbp)
   0x00000000004edee2 <+1710>:	lea    -0xe0(%rbp),%r12
   0x00000000004edee9 <+1717>:	mov    %r12,%rdi
   0x00000000004edeec <+1720>:	mov    %rbx,%rsi
   0x00000000004edeef <+1723>:	mov    %r14,%rdx
   0x00000000004edef2 <+1726>:	call   0x210f00 <_CNat13StringBuilder8toStringHv@plt>
   0x00000000004edef7 <+1731>:	mov    0x59a02a(%rip),%r14        # 0xa87f28
   0x00000000004edefe <+1738>:	mov    0xc(%r14),%esi
   0x00000000004edf02 <+1742>:	add    $0xf,%esi
   0x00000000004edf05 <+1745>:	and    $0xfffffff8,%esi
   0x00000000004edf08 <+1748>:	mov    %r14,%rdi
   0x00000000004edf0b <+1751>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edf10 <+1756>:	mov    %rax,%rbx
   0x00000000004edf13 <+1759>:	mov    %rax,%rdi
   0x00000000004edf16 <+1762>:	mov    %r12,%rsi
   0x00000000004edf19 <+1765>:	mov    %r14,%rdx
   0x00000000004edf1c <+1768>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004edf21 <+1773>:	mov    %rbx,%rdi
   0x00000000004edf24 <+1776>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edf29 <+1781>:	xorps  %xmm0,%xmm0
   0x00000000004edf2c <+1784>:	movaps %xmm0,-0xd0(%rbp)
   0x00000000004edf33 <+1791>:	lea    -0xd0(%rbp),%r14
   0x00000000004edf3a <+1798>:	mov    %r14,%rdi
   0x00000000004edf3d <+1801>:	xor    %esi,%esi
   0x00000000004edf3f <+1803>:	xor    %edx,%edx
   0x00000000004edf41 <+1805>:	call   0x20ed80 <_CNatUarray$37arrayIndexOutOfBoundsExceptionMessageHll@plt>
   0x00000000004edf46 <+1810>:	mov    0x599fdb(%rip),%r12        # 0xa87f28
   0x00000000004edf4d <+1817>:	mov    0xc(%r12),%esi
   0x00000000004edf52 <+1822>:	add    $0xf,%esi
   0x00000000004edf55 <+1825>:	and    $0xfffffff8,%esi
   0x00000000004edf58 <+1828>:	mov    %r12,%rdi
   0x00000000004edf5b <+1831>:	call   0x55ea40 <CJ_MCC_NewObjectFast>
   0x00000000004edf60 <+1836>:	mov    %rax,%rbx
   0x00000000004edf63 <+1839>:	mov    %rax,%rdi
   0x00000000004edf66 <+1842>:	mov    %r14,%rsi
   0x00000000004edf69 <+1845>:	mov    %r12,%rdx
   0x00000000004edf6c <+1848>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004edf71 <+1853>:	mov    %rbx,%rdi
   0x00000000004edf74 <+1856>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004edf79 <+1861>:	add    $0xe0,%rsp
   0x00000000004edf80 <+1868>:	movabs $0x40,%rax
   0x00000000004edf8a <+1878>:	call   0x210e40 <CJ_MCC_StackGrowStub@plt>
   0x00000000004edf8f <+1883>:	sub    $0xe0,%rsp
   0x00000000004edf96 <+1890>:	jmp    0x4ed858 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+36>
   0x00000000004edf9b <+1895>:	mov    0x59b61e(%rip),%rax        # 0xa895c0 <CJ_MCC_HandleSafepoint.CJStubGV>
   0x00000000004edfa2 <+1902>:	call   *%rax
   0x00000000004edfa4 <+1904>:	jmp    0x4ed876 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+66>
End of assembler dump.
