Dump of assembler code for function _CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El:
   0x00000000004ef814 <+0>:	push   %rbp
   0x00000000004ef815 <+1>:	mov    %rsp,%rbp
   0x00000000004ef818 <+4>:	call   0x4ef81d <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+9>
   0x00000000004ef81d <+9>:	push   %r14
   0x00000000004ef81f <+11>:	push   %r13
   0x00000000004ef821 <+13>:	push   %r12
   0x00000000004ef823 <+15>:	push   %rbx
   0x00000000004ef824 <+16>:	sub    $0xd8,%rsp
   0x00000000004ef82b <+23>:	mov    0x28(%r15),%rax
   0x00000000004ef82f <+27>:	cmp    %rax,%rsp
   0x00000000004ef832 <+30>:	jbe    0x4effc4 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1968>
   0x00000000004ef838 <+36>:	mov    %r8,%r13
   0x00000000004ef83b <+39>:	mov    %rcx,%r12
   0x00000000004ef83e <+42>:	mov    %rsi,%r14
   0x00000000004ef841 <+45>:	mov    %rdi,-0x30(%rbp)
   0x00000000004ef845 <+49>:	mov    %rdx,-0x40(%rbp)
   0x00000000004ef849 <+53>:	mov    0xc(%rdx),%ebx
   0x00000000004ef84c <+56>:	mov    0x30(%r15),%rax
   0x00000000004ef850 <+60>:	cmp    $0x0,%rax
   0x00000000004ef857 <+67>:	jne    0x4effe6 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+2002>
   0x00000000004ef85d <+73>:	test   %r8,%r8
   0x00000000004ef860 <+76>:	js     0x4efc71 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1117>
   0x00000000004ef866 <+82>:	mov    0x59a5c3(%rip),%rdi        # 0xa89e30
   0x00000000004ef86d <+89>:	mov    %rdi,%rsi
   0x00000000004ef870 <+92>:	call   0x210ac0 <_CNatXl3MaxpgHv@plt>
   0x00000000004ef875 <+97>:	sub    %rbx,%rax
   0x00000000004ef878 <+100>:	jo     0x4efca2 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1166>
   0x00000000004ef87e <+106>:	cmp    %r13,%rax
   0x00000000004ef881 <+109>:	jl     0x4efcae <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1178>
   0x00000000004ef887 <+115>:	add    %rbx,%r13
   0x00000000004ef88a <+118>:	jo     0x4efc65 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1105>
   0x00000000004ef890 <+124>:	mov    %rbx,-0x98(%rbp)
   0x00000000004ef897 <+131>:	mov    0x20(%r12),%rbx
   0x00000000004ef89c <+136>:	test   %rbx,%rbx
   0x00000000004ef89f <+139>:	js     0x4efc71 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1117>
   0x00000000004ef8a5 <+145>:	mov    0x59a584(%rip),%rdi        # 0xa89e30
   0x00000000004ef8ac <+152>:	mov    %rdi,%rsi
   0x00000000004ef8af <+155>:	call   0x210ac0 <_CNatXl3MaxpgHv@plt>
   0x00000000004ef8b4 <+160>:	movabs $0x5555555555555556,%rcx
   0x00000000004ef8be <+170>:	imul   %rcx
   0x00000000004ef8c1 <+173>:	mov    %rdx,%rax
   0x00000000004ef8c4 <+176>:	shr    $0x3f,%rax
   0x00000000004ef8c8 <+180>:	add    %rdx,%rax
   0x00000000004ef8cb <+183>:	cmp    %rbx,%rax
   0x00000000004ef8ce <+186>:	jl     0x4efd27 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1299>
   0x00000000004ef8d4 <+192>:	imul   $0x3,%rbx,%rbx
   0x00000000004ef8d8 <+196>:	jo     0x4efda0 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1420>
   0x00000000004ef8de <+202>:	mov    0x59a54b(%rip),%rdi        # 0xa89e30
   0x00000000004ef8e5 <+209>:	mov    %rdi,%rsi
   0x00000000004ef8e8 <+212>:	call   0x210ac0 <_CNatXl3MaxpgHv@plt>
   0x00000000004ef8ed <+217>:	sub    %rbx,%rax
   0x00000000004ef8f0 <+220>:	jo     0x4efca2 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1166>
   0x00000000004ef8f6 <+226>:	cmp    $0x2,%rax
   0x00000000004ef8fa <+230>:	jl     0x4efdb4 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1440>
   0x00000000004ef900 <+236>:	add    $0x2,%rbx
   0x00000000004ef904 <+240>:	jo     0x4efc65 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1105>
   0x00000000004ef90a <+246>:	test   %r13,%r13
   0x00000000004ef90d <+249>:	js     0x4efc71 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1117>
   0x00000000004ef913 <+255>:	mov    0x59a516(%rip),%rdi        # 0xa89e30
   0x00000000004ef91a <+262>:	mov    %rdi,%rsi
   0x00000000004ef91d <+265>:	call   0x210ac0 <_CNatXl3MaxpgHv@plt>
   0x00000000004ef922 <+270>:	sub    %r13,%rax
   0x00000000004ef925 <+273>:	jo     0x4efca2 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1166>
   0x00000000004ef92b <+279>:	cmp    %rbx,%rax
   0x00000000004ef92e <+282>:	jl     0x4efe2d <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1561>
   0x00000000004ef934 <+288>:	add    %rbx,%r13
   0x00000000004ef937 <+291>:	jo     0x4efc65 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1105>
   0x00000000004ef93d <+297>:	test   %r13,%r13
   0x00000000004ef940 <+300>:	mov    -0x40(%rbp),%rbx
   0x00000000004ef944 <+304>:	jle    0x4ef966 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+338>
   0x00000000004ef946 <+306>:	mov    0x20(%r14),%rax
   0x00000000004ef94a <+310>:	cmp    %r13,%rax
   0x00000000004ef94d <+313>:	jle    0x4ef966 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+338>
   0x00000000004ef94f <+315>:	add    0x30(%r14),%r13
   0x00000000004ef953 <+319>:	jo     0x4efc65 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1105>
   0x00000000004ef959 <+325>:	cmp    %rax,%r13
   0x00000000004ef95c <+328>:	jle    0x4ef966 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+338>
   0x00000000004ef95e <+330>:	mov    %r14,%rdi
   0x00000000004ef961 <+333>:	call   0x4ebc34 <_CN5yjson24DirectStreamWriterTarget11flushBufferHv>
   0x00000000004ef966 <+338>:	mov    %r14,%rsi
   0x00000000004ef969 <+341>:	mov    %rbx,%rdx
   0x00000000004ef96c <+344>:	xor    %ecx,%ecx
   0x00000000004ef96e <+346>:	mov    -0x98(%rbp),%r8
   0x00000000004ef975 <+353>:	call   0x4ec314 <_CN5yjson24DirectStreamWriterTarget14writeTextRangeHRNat6StringEll>
   0x00000000004ef97a <+358>:	mov    %r14,%rdi
   0x00000000004ef97d <+361>:	mov    $0x5b,%esi
   0x00000000004ef982 <+366>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004ef987 <+371>:	cmpq   $0x0,0x20(%r12)
   0x00000000004ef98d <+377>:	je     0x4efb24 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+784>
   0x00000000004ef993 <+383>:	jle    0x4efea6 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1682>
   0x00000000004ef999 <+389>:	cmpq   $0x0,0x18(%r12)
   0x00000000004ef99f <+395>:	je     0x4eff74 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1888>
   0x00000000004ef9a5 <+401>:	mov    0x8(%r12),%rax
   0x00000000004ef9aa <+406>:	mov    0x10(%r12),%rbx
   0x00000000004ef9af <+411>:	mov    %rax,%rcx
   0x00000000004ef9b2 <+414>:	shr    $0x30,%rcx
   0x00000000004ef9b6 <+418>:	je     0x4ef9c5 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+433>
   0x00000000004ef9b8 <+420>:	lea    0x8(%r12),%rsi
   0x00000000004ef9bd <+425>:	mov    %r12,%rdi
   0x00000000004ef9c0 <+428>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004ef9c5 <+433>:	lea    0x8(%rax),%r13
   0x00000000004ef9c9 <+437>:	shl    $0x4,%rbx
   0x00000000004ef9cd <+441>:	mov    0x10(%rax,%rbx,1),%rcx
   0x00000000004ef9d2 <+446>:	mov    %rcx,%rdx
   0x00000000004ef9d5 <+449>:	shr    $0x30,%rdx
   0x00000000004ef9d9 <+453>:	je     0x4ef9ee <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+474>
   0x00000000004ef9db <+455>:	lea    (%rax,%rbx,1),%rsi
   0x00000000004ef9df <+459>:	add    $0x10,%rsi
   0x00000000004ef9e3 <+463>:	mov    %rax,%rdi
   0x00000000004ef9e6 <+466>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004ef9eb <+471>:	mov    %rax,%rcx
   0x00000000004ef9ee <+474>:	mov    %rcx,-0x100(%rbp)
   0x00000000004ef9f5 <+481>:	mov    0x10(%r13,%rbx,1),%rbx
   0x00000000004ef9fa <+486>:	mov    %rbx,-0xf8(%rbp)
   0x00000000004efa01 <+493>:	mov    %r14,%rdi
   0x00000000004efa04 <+496>:	mov    $0x22,%esi
   0x00000000004efa09 <+501>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004efa0e <+506>:	shr    $0x20,%rbx
   0x00000000004efa12 <+510>:	lea    -0x100(%rbp),%rdx
   0x00000000004efa19 <+517>:	mov    %r14,%rsi
   0x00000000004efa1c <+520>:	xor    %ecx,%ecx
   0x00000000004efa1e <+522>:	mov    %rbx,%r8
   0x00000000004efa21 <+525>:	call   0x4ec314 <_CN5yjson24DirectStreamWriterTarget14writeTextRangeHRNat6StringEll>
   0x00000000004efa26 <+530>:	mov    %r14,%rdi
   0x00000000004efa29 <+533>:	mov    $0x22,%esi
   0x00000000004efa2e <+538>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004efa33 <+543>:	mov    0x20(%r12),%rax
   0x00000000004efa38 <+548>:	mov    %rax,-0x98(%rbp)
   0x00000000004efa3f <+555>:	cmp    $0x2,%rax
   0x00000000004efa43 <+559>:	jl     0x4efb24 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+784>
   0x00000000004efa49 <+565>:	mov    $0x1,%ebx
   0x00000000004efa4e <+570>:	jmp    0x4efaa5 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+657>
   0x00000000004efa50 <+572>:	mov    %rcx,-0xf0(%rbp)
   0x00000000004efa57 <+579>:	mov    0x10(%rbx,%r13,1),%r13
   0x00000000004efa5c <+584>:	mov    %r13,-0xe8(%rbp)
   0x00000000004efa63 <+591>:	mov    %r14,%rdi
   0x00000000004efa66 <+594>:	mov    $0x22,%esi
   0x00000000004efa6b <+599>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004efa70 <+604>:	shr    $0x20,%r13
   0x00000000004efa74 <+608>:	mov    %r14,%rsi
   0x00000000004efa77 <+611>:	lea    -0xf0(%rbp),%rdx
   0x00000000004efa7e <+618>:	xor    %ecx,%ecx
   0x00000000004efa80 <+620>:	mov    %r13,%r8
   0x00000000004efa83 <+623>:	call   0x4ec314 <_CN5yjson24DirectStreamWriterTarget14writeTextRangeHRNat6StringEll>
   0x00000000004efa88 <+628>:	mov    %r14,%rdi
   0x00000000004efa8b <+631>:	mov    $0x22,%esi
   0x00000000004efa90 <+636>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004efa95 <+641>:	mov    -0x40(%rbp),%rbx
   0x00000000004efa99 <+645>:	inc    %rbx
   0x00000000004efa9c <+648>:	cmp    %rbx,-0x98(%rbp)
   0x00000000004efaa3 <+655>:	je     0x4efb24 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+784>
   0x00000000004efaa5 <+657>:	mov    %r14,%rdi
   0x00000000004efaa8 <+660>:	mov    $0x2c,%esi
   0x00000000004efaad <+665>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004efab2 <+670>:	cmp    0x20(%r12),%rbx
   0x00000000004efab7 <+675>:	mov    %rbx,-0x40(%rbp)
   0x00000000004efabb <+679>:	jge    0x4efb46 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+818>
   0x00000000004efac1 <+685>:	mov    0x18(%r12),%rsi
   0x00000000004efac6 <+690>:	cmp    %rsi,%rbx
   0x00000000004efac9 <+693>:	jae    0x4efc17 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1027>
   0x00000000004efacf <+699>:	mov    0x8(%r12),%rax
   0x00000000004efad4 <+704>:	mov    0x10(%r12),%r13
   0x00000000004efad9 <+709>:	mov    %rax,%rcx
   0x00000000004efadc <+712>:	shr    $0x30,%rcx
   0x00000000004efae0 <+716>:	je     0x4efaef <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+731>
   0x00000000004efae2 <+718>:	lea    0x8(%r12),%rsi
   0x00000000004efae7 <+723>:	mov    %r12,%rdi
   0x00000000004efaea <+726>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004efaef <+731>:	add    %rbx,%r13
   0x00000000004efaf2 <+734>:	lea    0x8(%rax),%rbx
   0x00000000004efaf6 <+738>:	shl    $0x4,%r13
   0x00000000004efafa <+742>:	mov    0x10(%rax,%r13,1),%rcx
   0x00000000004efaff <+747>:	mov    %rcx,%rdx
   0x00000000004efb02 <+750>:	shr    $0x30,%rdx
   0x00000000004efb06 <+754>:	je     0x4efa50 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+572>
   0x00000000004efb0c <+760>:	lea    (%rax,%r13,1),%rsi
   0x00000000004efb10 <+764>:	add    $0x10,%rsi
   0x00000000004efb14 <+768>:	mov    %rax,%rdi
   0x00000000004efb17 <+771>:	call   0x20e9e0 <CJ_MCC_ReadRefField@plt>
   0x00000000004efb1c <+776>:	mov    %rax,%rcx
   0x00000000004efb1f <+779>:	jmp    0x4efa50 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+572>
   0x00000000004efb24 <+784>:	mov    %r14,%rdi
   0x00000000004efb27 <+787>:	mov    $0x5d,%esi
   0x00000000004efb2c <+792>:	call   0x4ebeb4 <_CN5yjson24DirectStreamWriterTarget12writeRawByteHh>
   0x00000000004efb31 <+797>:	mov    -0x30(%rbp),%rax
   0x00000000004efb35 <+801>:	add    $0xd8,%rsp
   0x00000000004efb3c <+808>:	pop    %rbx
   0x00000000004efb3d <+809>:	pop    %r12
   0x00000000004efb3f <+811>:	pop    %r13
   0x00000000004efb41 <+813>:	pop    %r14
   0x00000000004efb43 <+815>:	pop    %rcx
   0x00000000004efb44 <+816>:	pop    %rbp
   0x00000000004efb45 <+817>:	ret    
   0x00000000004efb46 <+818>:	mov    0x59a483(%rip),%r13        # 0xa89fd0
   0x00000000004efb4d <+825>:	mov    0xc(%r13),%esi
   0x00000000004efb51 <+829>:	add    $0xf,%esi
   0x00000000004efb54 <+832>:	and    $0xfffffff8,%esi
   0x00000000004efb57 <+835>:	mov    %r13,%rdi
   0x00000000004efb5a <+838>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efb5f <+843>:	mov    %rax,%rbx
   0x00000000004efb62 <+846>:	mov    $0x23,%esi
   0x00000000004efb67 <+851>:	mov    %rax,%rdi
   0x00000000004efb6a <+854>:	mov    %r13,%rdx
   0x00000000004efb6d <+857>:	call   0x20f210 <_CNat13StringBuilder6<init>Hl@plt>
   0x00000000004efb72 <+862>:	lea    0x57cf67(%rip),%rdx        # 0xa6cae0
   0x00000000004efb79 <+869>:	lea    -0x38(%rbp),%r14
   0x00000000004efb7d <+873>:	mov    %r14,%rdi
   0x00000000004efb80 <+876>:	mov    %rbx,%rsi
   0x00000000004efb83 <+879>:	mov    %r13,%rcx
   0x00000000004efb86 <+882>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004efb8b <+887>:	mov    %r14,%rdi
   0x00000000004efb8e <+890>:	mov    %rbx,%rsi
   0x00000000004efb91 <+893>:	mov    -0x40(%rbp),%rdx
   0x00000000004efb95 <+897>:	mov    %r13,%rcx
   0x00000000004efb98 <+900>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004efb9d <+905>:	lea    0x57cf4c(%rip),%rdx        # 0xa6caf0
   0x00000000004efba4 <+912>:	mov    %r14,%rdi
   0x00000000004efba7 <+915>:	mov    %rbx,%rsi
   0x00000000004efbaa <+918>:	mov    %r13,%rcx
   0x00000000004efbad <+921>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004efbb2 <+926>:	mov    0x20(%r12),%rdx
   0x00000000004efbb7 <+931>:	mov    %r14,%rdi
   0x00000000004efbba <+934>:	mov    %rbx,%rsi
   0x00000000004efbbd <+937>:	mov    %r13,%rcx
   0x00000000004efbc0 <+940>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004efbc5 <+945>:	xorps  %xmm0,%xmm0
   0x00000000004efbc8 <+948>:	movaps %xmm0,-0xc0(%rbp)
   0x00000000004efbcf <+955>:	lea    -0xc0(%rbp),%r14
   0x00000000004efbd6 <+962>:	mov    %r14,%rdi
   0x00000000004efbd9 <+965>:	mov    %rbx,%rsi
   0x00000000004efbdc <+968>:	mov    %r13,%rdx
   0x00000000004efbdf <+971>:	call   0x210f00 <_CNat13StringBuilder8toStringHv@plt>
   0x00000000004efbe4 <+976>:	mov    0x59a33d(%rip),%r12        # 0xa89f28
   0x00000000004efbeb <+983>:	mov    0xc(%r12),%esi
   0x00000000004efbf0 <+988>:	add    $0xf,%esi
   0x00000000004efbf3 <+991>:	and    $0xfffffff8,%esi
   0x00000000004efbf6 <+994>:	mov    %r12,%rdi
   0x00000000004efbf9 <+997>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efbfe <+1002>:	mov    %rax,%rbx
   0x00000000004efc01 <+1005>:	mov    %rax,%rdi
   0x00000000004efc04 <+1008>:	mov    %r14,%rsi
   0x00000000004efc07 <+1011>:	mov    %r12,%rdx
   0x00000000004efc0a <+1014>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004efc0f <+1019>:	mov    %rbx,%rdi
   0x00000000004efc12 <+1022>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efc17 <+1027>:	xorps  %xmm0,%xmm0
   0x00000000004efc1a <+1030>:	movaps %xmm0,-0xb0(%rbp)
   0x00000000004efc21 <+1037>:	lea    -0xb0(%rbp),%r12
   0x00000000004efc28 <+1044>:	mov    %r12,%rdi
   0x00000000004efc2b <+1047>:	mov    %rbx,%rdx
   0x00000000004efc2e <+1050>:	call   0x20ed80 <_CNatUarray$37arrayIndexOutOfBoundsExceptionMessageHll@plt>
   0x00000000004efc33 <+1055>:	mov    0x59a2ee(%rip),%r14        # 0xa89f28
   0x00000000004efc3a <+1062>:	mov    0xc(%r14),%esi
   0x00000000004efc3e <+1066>:	add    $0xf,%esi
   0x00000000004efc41 <+1069>:	and    $0xfffffff8,%esi
   0x00000000004efc44 <+1072>:	mov    %r14,%rdi
   0x00000000004efc47 <+1075>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efc4c <+1080>:	mov    %rax,%rbx
   0x00000000004efc4f <+1083>:	mov    %rax,%rdi
   0x00000000004efc52 <+1086>:	mov    %r12,%rsi
   0x00000000004efc55 <+1089>:	mov    %r14,%rdx
   0x00000000004efc58 <+1092>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004efc5d <+1097>:	mov    %rbx,%rdi
   0x00000000004efc60 <+1100>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efc65 <+1105>:	lea    0x57ce94(%rip),%rdi        # 0xa6cb00
   0x00000000004efc6c <+1112>:	jmp    0x4efda7 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1427>
   0x00000000004efc71 <+1117>:	mov    0x59a320(%rip),%r14        # 0xa89f98
   0x00000000004efc78 <+1124>:	mov    %r14,%rdi
   0x00000000004efc7b <+1127>:	mov    $0x40,%esi
   0x00000000004efc80 <+1132>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efc85 <+1137>:	mov    %rax,%rbx
   0x00000000004efc88 <+1140>:	lea    0x57dd91(%rip),%rsi        # 0xa6da20
   0x00000000004efc8f <+1147>:	mov    %rax,%rdi
   0x00000000004efc92 <+1150>:	mov    %r14,%rdx
   0x00000000004efc95 <+1153>:	call   0x20ed70 <_CNat24IllegalArgumentException6<init>HRNat6StringE@plt>
   0x00000000004efc9a <+1158>:	mov    %rbx,%rdi
   0x00000000004efc9d <+1161>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efca2 <+1166>:	lea    0x57cdf7(%rip),%rdi        # 0xa6caa0
   0x00000000004efca9 <+1173>:	jmp    0x4efda7 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+1427>
   0x00000000004efcae <+1178>:	movups 0x57cddb(%rip),%xmm0        # 0xa6ca90
   0x00000000004efcb5 <+1185>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004efcb9 <+1189>:	xorps  %xmm0,%xmm0
   0x00000000004efcbc <+1192>:	movups %xmm0,-0x69(%rbp)
   0x00000000004efcc0 <+1196>:	movq   $0x0,-0x59(%rbp)
   0x00000000004efcc8 <+1204>:	movb   $0x1,-0x90(%rbp)
   0x00000000004efccf <+1211>:	movups -0x70(%rbp),%xmm0
   0x00000000004efcd3 <+1215>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004efcda <+1222>:	mov    -0x61(%rbp),%rax
   0x00000000004efcde <+1226>:	mov    %rax,-0x80(%rbp)
   0x00000000004efce2 <+1230>:	mov    -0x59(%rbp),%rax
   0x00000000004efce6 <+1234>:	mov    %rax,-0x78(%rbp)
   0x00000000004efcea <+1238>:	lea    0x81686f(%rip),%rdi        # 0xd06560 <yjson:JsonException.ti>
   0x00000000004efcf1 <+1245>:	mov    $0x80,%esi
   0x00000000004efcf6 <+1250>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efcfb <+1255>:	mov    %rax,%rbx
   0x00000000004efcfe <+1258>:	lea    0x57dd2b(%rip),%rsi        # 0xa6da30
   0x00000000004efd05 <+1265>:	lea    0x57d584(%rip),%rdx        # 0xa6d290
   0x00000000004efd0c <+1272>:	lea    -0x50(%rbp),%rcx
   0x00000000004efd10 <+1276>:	lea    -0x90(%rbp),%r8
   0x00000000004efd17 <+1283>:	mov    %rax,%rdi
   0x00000000004efd1a <+1286>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004efd1f <+1291>:	mov    %rbx,%rdi
   0x00000000004efd22 <+1294>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efd27 <+1299>:	movups 0x57cd62(%rip),%xmm0        # 0xa6ca90
   0x00000000004efd2e <+1306>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004efd32 <+1310>:	xorps  %xmm0,%xmm0
   0x00000000004efd35 <+1313>:	movups %xmm0,-0x69(%rbp)
   0x00000000004efd39 <+1317>:	movq   $0x0,-0x59(%rbp)
   0x00000000004efd41 <+1325>:	movb   $0x1,-0x90(%rbp)
   0x00000000004efd48 <+1332>:	movups -0x70(%rbp),%xmm0
   0x00000000004efd4c <+1336>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004efd53 <+1343>:	mov    -0x61(%rbp),%rax
   0x00000000004efd57 <+1347>:	mov    %rax,-0x80(%rbp)
   0x00000000004efd5b <+1351>:	mov    -0x59(%rbp),%rax
   0x00000000004efd5f <+1355>:	mov    %rax,-0x78(%rbp)
   0x00000000004efd63 <+1359>:	lea    0x8167f6(%rip),%rdi        # 0xd06560 <yjson:JsonException.ti>
   0x00000000004efd6a <+1366>:	mov    $0x80,%esi
   0x00000000004efd6f <+1371>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efd74 <+1376>:	mov    %rax,%rbx
   0x00000000004efd77 <+1379>:	lea    0x57dcb2(%rip),%rsi        # 0xa6da30
   0x00000000004efd7e <+1386>:	lea    0x57d50b(%rip),%rdx        # 0xa6d290
   0x00000000004efd85 <+1393>:	lea    -0x50(%rbp),%rcx
   0x00000000004efd89 <+1397>:	lea    -0x90(%rbp),%r8
   0x00000000004efd90 <+1404>:	mov    %rax,%rdi
   0x00000000004efd93 <+1407>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004efd98 <+1412>:	mov    %rbx,%rdi
   0x00000000004efd9b <+1415>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efda0 <+1420>:	lea    0x57ceb9(%rip),%rdi        # 0xa6cc60
   0x00000000004efda7 <+1427>:	call   0x20f9c0 <rt$CreateOverflowException_msg@plt>
   0x00000000004efdac <+1432>:	mov    %rax,%rdi
   0x00000000004efdaf <+1435>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efdb4 <+1440>:	movups 0x57ccd5(%rip),%xmm0        # 0xa6ca90
   0x00000000004efdbb <+1447>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004efdbf <+1451>:	xorps  %xmm0,%xmm0
   0x00000000004efdc2 <+1454>:	movups %xmm0,-0x69(%rbp)
   0x00000000004efdc6 <+1458>:	movq   $0x0,-0x59(%rbp)
   0x00000000004efdce <+1466>:	movb   $0x1,-0x90(%rbp)
   0x00000000004efdd5 <+1473>:	movups -0x70(%rbp),%xmm0
   0x00000000004efdd9 <+1477>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004efde0 <+1484>:	mov    -0x61(%rbp),%rax
   0x00000000004efde4 <+1488>:	mov    %rax,-0x80(%rbp)
   0x00000000004efde8 <+1492>:	mov    -0x59(%rbp),%rax
   0x00000000004efdec <+1496>:	mov    %rax,-0x78(%rbp)
   0x00000000004efdf0 <+1500>:	lea    0x816769(%rip),%rdi        # 0xd06560 <yjson:JsonException.ti>
   0x00000000004efdf7 <+1507>:	mov    $0x80,%esi
   0x00000000004efdfc <+1512>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efe01 <+1517>:	mov    %rax,%rbx
   0x00000000004efe04 <+1520>:	lea    0x57dc25(%rip),%rsi        # 0xa6da30
   0x00000000004efe0b <+1527>:	lea    0x57d47e(%rip),%rdx        # 0xa6d290
   0x00000000004efe12 <+1534>:	lea    -0x50(%rbp),%rcx
   0x00000000004efe16 <+1538>:	lea    -0x90(%rbp),%r8
   0x00000000004efe1d <+1545>:	mov    %rax,%rdi
   0x00000000004efe20 <+1548>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004efe25 <+1553>:	mov    %rbx,%rdi
   0x00000000004efe28 <+1556>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efe2d <+1561>:	movups 0x57cc5c(%rip),%xmm0        # 0xa6ca90
   0x00000000004efe34 <+1568>:	movaps %xmm0,-0x50(%rbp)
   0x00000000004efe38 <+1572>:	xorps  %xmm0,%xmm0
   0x00000000004efe3b <+1575>:	movups %xmm0,-0x69(%rbp)
   0x00000000004efe3f <+1579>:	movq   $0x0,-0x59(%rbp)
   0x00000000004efe47 <+1587>:	movb   $0x1,-0x90(%rbp)
   0x00000000004efe4e <+1594>:	movups -0x70(%rbp),%xmm0
   0x00000000004efe52 <+1598>:	movups %xmm0,-0x8f(%rbp)
   0x00000000004efe59 <+1605>:	mov    -0x61(%rbp),%rax
   0x00000000004efe5d <+1609>:	mov    %rax,-0x80(%rbp)
   0x00000000004efe61 <+1613>:	mov    -0x59(%rbp),%rax
   0x00000000004efe65 <+1617>:	mov    %rax,-0x78(%rbp)
   0x00000000004efe69 <+1621>:	lea    0x8166f0(%rip),%rdi        # 0xd06560 <yjson:JsonException.ti>
   0x00000000004efe70 <+1628>:	mov    $0x80,%esi
   0x00000000004efe75 <+1633>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efe7a <+1638>:	mov    %rax,%rbx
   0x00000000004efe7d <+1641>:	lea    0x57dbac(%rip),%rsi        # 0xa6da30
   0x00000000004efe84 <+1648>:	lea    0x57d405(%rip),%rdx        # 0xa6d290
   0x00000000004efe8b <+1655>:	lea    -0x50(%rbp),%rcx
   0x00000000004efe8f <+1659>:	lea    -0x90(%rbp),%r8
   0x00000000004efe96 <+1666>:	mov    %rax,%rdi
   0x00000000004efe99 <+1669>:	call   0x44c784 <_CN5yjson13JsonException6<init>HRNat6StringEY3_Y3_NNat6OptionIRNY_12JsonLocationEE>
   0x00000000004efe9e <+1674>:	mov    %rbx,%rdi
   0x00000000004efea1 <+1677>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004efea6 <+1682>:	mov    0x59a123(%rip),%r14        # 0xa89fd0
   0x00000000004efead <+1689>:	mov    0xc(%r14),%esi
   0x00000000004efeb1 <+1693>:	add    $0xf,%esi
   0x00000000004efeb4 <+1696>:	and    $0xfffffff8,%esi
   0x00000000004efeb7 <+1699>:	mov    %r14,%rdi
   0x00000000004efeba <+1702>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004efebf <+1707>:	mov    %rax,%rbx
   0x00000000004efec2 <+1710>:	mov    $0x23,%esi
   0x00000000004efec7 <+1715>:	mov    %rax,%rdi
   0x00000000004efeca <+1718>:	mov    %r14,%rdx
   0x00000000004efecd <+1721>:	call   0x20f210 <_CNat13StringBuilder6<init>Hl@plt>
   0x00000000004efed2 <+1726>:	lea    0x57cc07(%rip),%rdx        # 0xa6cae0
   0x00000000004efed9 <+1733>:	lea    -0x38(%rbp),%r13
   0x00000000004efedd <+1737>:	mov    %r13,%rdi
   0x00000000004efee0 <+1740>:	mov    %rbx,%rsi
   0x00000000004efee3 <+1743>:	mov    %r14,%rcx
   0x00000000004efee6 <+1746>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004efeeb <+1751>:	mov    %r13,%rdi
   0x00000000004efeee <+1754>:	mov    %rbx,%rsi
   0x00000000004efef1 <+1757>:	xor    %edx,%edx
   0x00000000004efef3 <+1759>:	mov    %r14,%rcx
   0x00000000004efef6 <+1762>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004efefb <+1767>:	lea    0x57cbee(%rip),%rdx        # 0xa6caf0
   0x00000000004eff02 <+1774>:	mov    %r13,%rdi
   0x00000000004eff05 <+1777>:	mov    %rbx,%rsi
   0x00000000004eff08 <+1780>:	mov    %r14,%rcx
   0x00000000004eff0b <+1783>:	call   0x20fc70 <_CNat13StringBuilder6appendHRNat6StringE@plt>
   0x00000000004eff10 <+1788>:	mov    0x20(%r12),%rdx
   0x00000000004eff15 <+1793>:	mov    %r13,%rdi
   0x00000000004eff18 <+1796>:	mov    %rbx,%rsi
   0x00000000004eff1b <+1799>:	mov    %r14,%rcx
   0x00000000004eff1e <+1802>:	call   0x20f360 <_CNat13StringBuilder6appendHl@plt>
   0x00000000004eff23 <+1807>:	xorps  %xmm0,%xmm0
   0x00000000004eff26 <+1810>:	movaps %xmm0,-0xe0(%rbp)
   0x00000000004eff2d <+1817>:	lea    -0xe0(%rbp),%r12
   0x00000000004eff34 <+1824>:	mov    %r12,%rdi
   0x00000000004eff37 <+1827>:	mov    %rbx,%rsi
   0x00000000004eff3a <+1830>:	mov    %r14,%rdx
   0x00000000004eff3d <+1833>:	call   0x210f00 <_CNat13StringBuilder8toStringHv@plt>
   0x00000000004eff42 <+1838>:	mov    0x599fdf(%rip),%r14        # 0xa89f28
   0x00000000004eff49 <+1845>:	mov    0xc(%r14),%esi
   0x00000000004eff4d <+1849>:	add    $0xf,%esi
   0x00000000004eff50 <+1852>:	and    $0xfffffff8,%esi
   0x00000000004eff53 <+1855>:	mov    %r14,%rdi
   0x00000000004eff56 <+1858>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004eff5b <+1863>:	mov    %rax,%rbx
   0x00000000004eff5e <+1866>:	mov    %rax,%rdi
   0x00000000004eff61 <+1869>:	mov    %r12,%rsi
   0x00000000004eff64 <+1872>:	mov    %r14,%rdx
   0x00000000004eff67 <+1875>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004eff6c <+1880>:	mov    %rbx,%rdi
   0x00000000004eff6f <+1883>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004eff74 <+1888>:	xorps  %xmm0,%xmm0
   0x00000000004eff77 <+1891>:	movaps %xmm0,-0xd0(%rbp)
   0x00000000004eff7e <+1898>:	lea    -0xd0(%rbp),%r14
   0x00000000004eff85 <+1905>:	mov    %r14,%rdi
   0x00000000004eff88 <+1908>:	xor    %esi,%esi
   0x00000000004eff8a <+1910>:	xor    %edx,%edx
   0x00000000004eff8c <+1912>:	call   0x20ed80 <_CNatUarray$37arrayIndexOutOfBoundsExceptionMessageHll@plt>
   0x00000000004eff91 <+1917>:	mov    0x599f90(%rip),%r12        # 0xa89f28
   0x00000000004eff98 <+1924>:	mov    0xc(%r12),%esi
   0x00000000004eff9d <+1929>:	add    $0xf,%esi
   0x00000000004effa0 <+1932>:	and    $0xfffffff8,%esi
   0x00000000004effa3 <+1935>:	mov    %r12,%rdi
   0x00000000004effa6 <+1938>:	call   0x560a90 <CJ_MCC_NewObjectFast>
   0x00000000004effab <+1943>:	mov    %rax,%rbx
   0x00000000004effae <+1946>:	mov    %rax,%rdi
   0x00000000004effb1 <+1949>:	mov    %r14,%rsi
   0x00000000004effb4 <+1952>:	mov    %r12,%rdx
   0x00000000004effb7 <+1955>:	call   0x20fb90 <_CNat25IndexOutOfBoundsException6<init>HRNat6StringE@plt>
   0x00000000004effbc <+1960>:	mov    %rbx,%rdi
   0x00000000004effbf <+1963>:	call   0x210a00 <CJ_MCC_ThrowException@plt>
   0x00000000004effc4 <+1968>:	add    $0xd0,%rsp
   0x00000000004effcb <+1975>:	movabs $0x40,%rax
   0x00000000004effd5 <+1985>:	call   0x210e40 <CJ_MCC_StackGrowStub@plt>
   0x00000000004effda <+1990>:	sub    $0xd0,%rsp
   0x00000000004effe1 <+1997>:	jmp    0x4ef838 <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+36>
   0x00000000004effe6 <+2002>:	mov    0x59b5d3(%rip),%rax        # 0xa8b5c0 <CJ_MCC_HandleSafepoint.CJStubGV>
   0x00000000004effed <+2009>:	call   *%rax
   0x00000000004effef <+2011>:	jmp    0x4ef85d <_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El+73>
End of assembler dump.
