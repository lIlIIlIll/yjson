Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodePerson` | 1.315 us | 1.241 us | 0.943x | 5.7% | 3/3 | 0.57% | 0.20% | 116876 | 117088 |
| `yjsonStringEncodeLargeProfileArray` | 23.229 us | 22.191 us | 0.955x | 4.5% | 3/3 | 0.33% | 0.54% | 135152 | 139424 |
| `yjsonBytesEncodeEscapedUnicodeString` | 0.719 us | 0.706 us | 0.981x | 1.9% | 3/3 | 0.57% | 0.42% | 163356 | 165704 |
