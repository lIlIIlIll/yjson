Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeDeepNestedProfiles` | 23.570 us | 24.089 us | 1.022x | -2.2% | 0/3 | 0.37% | 2.22% | 127504 | 127488 |
| `yjsonStringEncodePerson` | 1.107 us | 1.147 us | 1.036x | -3.6% | 0/3 | 1.21% | 0.59% | 117596 | 117216 |
| `yjsonStringEncodeLargeProfileArray` | 20.444 us | 20.734 us | 1.014x | -1.4% | 0/3 | 0.06% | 0.36% | 145852 | 145680 |
| `yjsonBytesEncodeProfileBundle` | 4.189 us | 4.283 us | 1.023x | -2.3% | 0/3 | 0.90% | 0.40% | 137040 | 136768 |
| `yjsonBytesEncodeEscapedUnicodeString` | 0.622 us | 0.650 us | 1.045x | -4.5% | 0/3 | 2.42% | 0.54% | 170316 | 170096 |
| `encodePersonMemory` | 6.695 us | 7.042 us | 1.052x | -5.2% | 0/3 | 1.09% | 2.08% | 169736 | 169816 |
