Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodePerson` | 1.247 us | 1.160 us | 0.931x | 6.9% | 3/3 | 1.02% | 2.58% | 117360 | 117188 |
| `yjsonStringEncodeLargeProfileArray` | 21.901 us | 20.655 us | 0.943x | 5.7% | 3/3 | 0.09% | 0.33% | 139152 | 145628 |
| `yjsonBytesEncodeEscapedUnicodeString` | 0.687 us | 0.652 us | 0.949x | 5.1% | 3/3 | 1.09% | 0.47% | 166924 | 170508 |
