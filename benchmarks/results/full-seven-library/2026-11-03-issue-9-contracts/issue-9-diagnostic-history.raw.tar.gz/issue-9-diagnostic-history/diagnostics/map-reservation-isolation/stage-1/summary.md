Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeLargeInt64Map` | 6.773 us | 6.680 us | 0.986x | 1.4% | 3/3 | 0.54% | 0.60% | 170132 | 170232 |
| `yjsonStringEncodePerson` | 1.321 us | 1.263 us | 0.956x | 4.4% | 3/3 | 0.87% | 1.28% | 117280 | 117160 |
