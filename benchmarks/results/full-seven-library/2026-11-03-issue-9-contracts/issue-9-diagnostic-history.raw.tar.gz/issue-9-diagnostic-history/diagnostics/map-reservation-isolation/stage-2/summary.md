Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeLargeInt64Map` | 6.734 us | 6.564 us | 0.975x | 2.5% | 3/3 | 0.18% | 0.31% | 170196 | 170188 |
| `yjsonStringEncodePerson` | 1.250 us | 1.143 us | 0.914x | 8.6% | 3/3 | 2.11% | 0.16% | 117260 | 117008 |
