Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeLargeInt64Map` | 6.555 us | 7.223 us | 1.102x | -10.2% | 0/3 | 0.32% | 0.32% | 170372 | 170344 |
| `yjsonStringEncodePerson` | 1.140 us | 1.137 us | 0.997x | 0.3% | 2/3 | 0.34% | 0.50% | 117200 | 117220 |
