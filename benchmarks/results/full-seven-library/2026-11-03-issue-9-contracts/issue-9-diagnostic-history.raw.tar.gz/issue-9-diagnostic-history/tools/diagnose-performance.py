#!/usr/bin/env python3
"""Seal the failed full batch, then take diagnostic-only parent GDB samples."""
import fcntl
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

root = Path('/mnt')
lock = (root / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
result = root / 'results/pure-release-issue9-batch1'
summary = json.loads((result / 'summary.json').read_text())
assert len(summary['cases']) == 24 and len(summary['direct_cells']) == 528
assert len(summary['preflight_cells']) == 48 and summary['rounds'] == 11
assert summary['gates']['passed'] is False
assert summary['gates']['both_cv_at_most_5_percent'] is True
subprocess.run(['python3', '/mnt/audit-pure-build.py', str(result), 'pure-baseline', 'pure-candidate'], check=True)
receipt = json.loads((root / 'pure-snapshot-receipt.json').read_text())
production = json.loads((root / 'production-export-receipt.json').read_text())
sys.path.insert(0, str(root / 'workspace/repo/scripts'))
import benchmark_input_identity as identity
sources = {'results/' + result.name + '/' + path.relative_to(result).as_posix(): path for path in result.rglob('*') if path.is_file()}
for name in ('pure-snapshot-receipt.json', 'production-export-receipt.json', 'run-pure.py', 'audit-pure-build.py', 'cjpm'):
    sources['task-control/' + name] = root / name
for suffix in ('.json', '.log'):
    sources['task-control/pure-release-issue9-batch1' + suffix] = root / 'logs' / ('pure-release-issue9-batch1' + suffix)
for name, entry in receipt['snapshots'].items():
    folder = root / name
    assert identity.product_manifest(folder) == entry['productManifest']
    assert identity.harness_manifest(folder) == entry['harnessManifest']
    for relative in set(entry['productManifest']) | set(entry['harnessManifest']):
        sources['source-inputs/' + name + '/' + relative] = folder / relative
    for relative in ('LICENSE', 'packages/yjson_macros/LICENSE', 'native/vendor/yyjson/LICENSE'):
        if (folder / relative).is_file(): sources['source-inputs/' + name + '/' + relative] = folder / relative
name = 'pure-issue9-first-failure-C'
output = root / 'failed-pure-C'
output.mkdir()
archive_path = output / (name + '.tar.gz')
inventory = {}
with tarfile.open(archive_path, 'w:gz') as archive:
    for relative, source in sorted(sources.items()):
        assert source.is_file() and not source.is_symlink()
        payload = source.read_bytes()
        payload.decode('utf-8')
        assert not payload.startswith((b'\x7fELF', b'MZ', b'PK\x03\x04', b'!<arch>'))
        member = archive.gettarinfo(str(source), arcname=name + '/' + relative)
        with source.open('rb') as stream: archive.addfile(member, stream)
        inventory[relative] = {'sha256': hashlib.sha256(payload).hexdigest(), 'sizeBytes': len(payload)}
record = {'status': 'FAIL', 'productionMain': production['productionMain'], 'productionMacro': production['productionMacro'], 'cases': 24, 'rounds': 11, 'directCells': 528, 'preflightCells': 48, 'allRowsStable': True, 'overruns': [{'case': case, 'ratio': value['ratio']} for case, value in summary['comparisons'].items() if value['ratio'] > 1.05], 'archives': [{'archive': archive_path.name, 'root': name, 'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'sizeBytes': archive_path.stat().st_size, 'regularFiles': len(inventory), 'memberPayloads': inventory}]}
(output / 'failed-packet-inventory.json').write_text(json.dumps(record, indent=2) + '\n')
print('FAILED_BATCH_SEALED', json.dumps({key: value for key, value in record.items() if key != 'archives'}), flush=True)
subprocess.run(['python3', '/mnt/sample-case.py', 'yjsonStringEncodePerson', 'issue9-person-encode-C'], check=True)
print('DIAGNOSTIC_STACK_SAMPLING_FINISHED', flush=True)
