#!/usr/bin/env python3
from pathlib import Path
import json
import subprocess
import sys
root = Path('/mnt')
sys.path.insert(0, str(root / 'pure-candidate/scripts'))
import benchmark_input_identity as identity
receipt = json.loads((root / 'pure-snapshot-receipt.json').read_text())
for name, expected in receipt['snapshots'].items():
    folder = root / name
    print(name, flush=True)
    print(subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=folder, text=True), flush=True)
    for label, actual in [('productManifest', identity.product_manifest(folder)), ('harnessManifest', identity.harness_manifest(folder))]:
        differences = [path for path in sorted(set(actual) | set(expected[label])) if actual.get(path) != expected[label].get(path)]
        print(label, 'differences', differences, flush=True)
