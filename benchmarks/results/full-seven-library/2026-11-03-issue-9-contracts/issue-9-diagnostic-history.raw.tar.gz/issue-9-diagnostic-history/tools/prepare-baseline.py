#!/usr/bin/env python3
"""Check the restored immutable baseline pairing before formal measurements."""
from pathlib import Path
import subprocess
import sys

root = Path('/mnt/pure-baseline')
package = root / 'packages/benchmarks'
sys.path.insert(0, str(root / 'scripts'))
import benchmark_input_identity as identity
before = identity.product_manifest(root)
assert identity.manifest_digest(before) == 'ee7b04b11c99ef76e0bb4ff07266466b702895ea35eff01aaa44362d94e8c4b6'
log = Path('/mnt/logs/baseline-restored-pair-build.log')
assert not log.exists()
with log.open('x') as output:
    for command in (['cjpm', 'clean'], ['cjpm', 'bench', '--no-color', '--no-run']):
        result = subprocess.run(command, cwd=package, stdout=output, stderr=subprocess.STDOUT)
        print('BASELINE_RESTORED_PAIR', command, 'exit', result.returncode, flush=True)
        assert result.returncode == 0, (command, result.returncode)
assert identity.product_manifest(root) == before
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root, text=True).strip()
print('BASELINE_RESTORED_PAIR_BUILD_PASS', flush=True)
