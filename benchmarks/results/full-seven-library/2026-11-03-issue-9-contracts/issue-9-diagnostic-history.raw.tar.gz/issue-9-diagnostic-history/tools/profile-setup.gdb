set confirm off
set pagination off
set debuginfod enabled off
set disable-randomization off
set print frame-arguments none
set follow-fork-mode child
set detach-on-fork on
handle SIGUSR1 nostop noprint pass
handle SIGUSR2 nostop noprint pass
catch exec
commands
silent
set follow-fork-mode parent
printf "SAMPLE_CASE_EXEC\n"
continue
end
