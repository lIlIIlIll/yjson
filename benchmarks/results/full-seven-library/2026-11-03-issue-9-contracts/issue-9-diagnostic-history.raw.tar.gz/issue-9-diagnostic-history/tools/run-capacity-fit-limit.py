#!/usr/bin/env python3
"""Audit getter elimination and run diagnostic-only paired checks."""
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/mnt')
lock = (root / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
source = root / 'capacity-fit-limit'
previous = root / 'capacity-fit-pair'
release_baseline = root / 'pure-baseline'
sys.path.insert(0, str(source / 'scripts'))
import benchmark_input_identity as identity
before = {folder.name: identity.product_manifest(folder) for folder in (source, previous, release_baseline)}
assert [path for path in sorted(set(before[source.name]) | set(before[previous.name])) if before[source.name].get(path) != before[previous.name].get(path)] == ['src/lib_json_direct_writer.cj']
for folder in (source, previous, release_baseline):
    assert identity.harness_manifest(folder) == identity.harness_manifest(source)
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=folder, text=True).strip()
output = root / 'diagnostics/capacity-fit-constant-limit'
output.mkdir(parents=True)
binary_relative = 'packages/benchmarks/target/release/unittest_bin/yjson_benchmarks'
with (output / 'build.log').open('x') as log:
    subprocess.run(['cjpm', 'clean'], cwd=source / 'packages/benchmarks', stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run(['strace', '-f', '-s', '65535', '-e', 'trace=execve', '-o', str(output / 'compiler-capacity-fit-limit.execve'), 'cjpm', 'bench', '--no-color', '--no-run'], cwd=source / 'packages/benchmarks', stdout=log, stderr=subprocess.STDOUT, check=True)
shutil.copyfile(root / 'diagnostics/capacity-fit-pair/compiler-capacity-fit-pair.execve', output / 'compiler-capacity-fit-pair.execve')
subprocess.run(['python3', '/mnt/audit-pure-build.py', str(output), 'capacity-fit-pair', 'capacity-fit-limit'], check=True)
symbol = '_CN5yjson24DirectStreamWriterTarget32writeTextStringArrayListNoEscapeHRNat6StringECNac9ArrayListIY3_El'
codegen = {}
for label, folder in [('before', previous), ('after', source)]:
    result = subprocess.run(['gdb', '--batch', '--nx', '-ex', 'set debuginfod enabled off', '-ex', 'disassemble ' + symbol, str(folder / binary_relative)], text=True, capture_output=True, check=True)
    text = result.stdout + result.stderr
    (output / ('stream-reservation-' + label + '.asm')).write_text(text)
    codegen[label] = {'int64MaxGetterCalls': text.count('<_CNatXl3MaxpgHv@plt>'), 'disassemblySha256': hashlib.sha256(text.encode()).hexdigest()}
assert codegen['before']['int64MaxGetterCalls'] > 0 and codegen['after']['int64MaxGetterCalls'] == 0
comparisons = {}
for label, baseline, cases in [
    ('causal-memory', previous, ['encodePersonMemory']),
    ('release-six', release_baseline, ['yjsonStringEncodeDeepNestedProfiles', 'yjsonStringEncodePerson', 'yjsonStringEncodeLargeProfileArray', 'yjsonBytesEncodeProfileBundle', 'yjsonBytesEncodeEscapedUnicodeString', 'encodePersonMemory'])
]:
    command = ['python3', str(previous / 'scripts/json_pure_perf_compare.py'), '--baseline', str(baseline), '--candidate', str(source), '--corpus', '/mnt/corpus', '--output', str(output / label), '--rounds', '3', '--idle-sample-seconds', '30', '--cell-timeout-seconds', '180', '--gate-mode', 'release']
    for case in cases: command += ['--case', case]
    with (output / (label + '.log')).open('x') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (label, result.returncode)
    summary = json.loads((output / label / 'summary.json').read_text())
    comparisons[label] = summary['comparisons']
    print(label, flush=True)
    print((output / label / 'summary.md').read_text(), flush=True)
for folder in (source, previous, release_baseline):
    assert identity.product_manifest(folder) == before[folder.name]
record = {'diagnosticOnly': True, 'formalQualification': False, 'productionOrigin': '57cfddb61834fb1d3c5c2e573ff6d986124045e2', 'singleChangedProductFile': 'src/lib_json_direct_writer.cj', 'guardSemantics': 'Same nonnegative, addition, multiplication and growth bounds; fixed Int64 maximum is now a private compile-time constant. No overflow mode or checks disabled.', 'codegen': codegen, 'candidateProductSha256': identity.manifest_digest(before[source.name]), 'commonHarnessSha256': identity.manifest_digest(identity.harness_manifest(source)), 'rounds': 3, 'comparisons': comparisons}
(output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
