#!/usr/bin/env python3
"""Three-case, three-round causal diagnostic; not formal qualification."""
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/mnt')
lock = (root / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
source = root / 'capacity-fit'
baseline = root / 'pure-candidate'
sys.path.insert(0, str(source / 'scripts'))
import benchmark_input_identity as identity
before_baseline = identity.product_manifest(baseline)
before_candidate = identity.product_manifest(source)
differences = [path for path in sorted(set(before_baseline) | set(before_candidate)) if before_baseline.get(path) != before_candidate.get(path)]
assert differences == ['src/lib_json_direct_writer.cj']
assert identity.harness_manifest(baseline) == identity.harness_manifest(source)
for folder in (baseline, source):
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=folder, text=True).strip()
output = root / 'diagnostics/capacity-fit-one-change'
output.mkdir(parents=True)
binary_relative = 'packages/benchmarks/target/release/unittest_bin/yjson_benchmarks'
baseline_binary_sha = hashlib.sha256((baseline / binary_relative).read_bytes()).hexdigest()
with (output / 'build.log').open('x') as log:
    subprocess.run(['cjpm', 'clean'], cwd=source / 'packages/benchmarks', stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run(['strace', '-f', '-s', '65535', '-e', 'trace=execve', '-o', str(output / 'compiler-capacity-fit.execve'), 'cjpm', 'bench', '--no-color', '--no-run'], cwd=source / 'packages/benchmarks', stdout=log, stderr=subprocess.STDOUT, check=True)
shutil.copyfile(root / 'results/pure-release-issue9-batch1/compiler-pure-candidate.execve', output / 'compiler-pure-candidate.execve')
subprocess.run(['python3', '/mnt/audit-pure-build.py', str(output), 'pure-candidate', 'capacity-fit'], check=True)
command = ['python3', str(baseline / 'scripts/json_pure_perf_compare.py'), '--baseline', str(baseline), '--candidate', str(source), '--corpus', '/mnt/corpus', '--output', str(output / 'paired'), '--rounds', '3', '--idle-sample-seconds', '30', '--cell-timeout-seconds', '180', '--gate-mode', 'release', '--case', 'yjsonStringEncodePerson', '--case', 'yjsonStringEncodeLargeProfileArray', '--case', 'yjsonBytesEncodeEscapedUnicodeString']
with (output / 'diagnostic.log').open('x') as log:
    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0, result.returncode
assert identity.product_manifest(baseline) == before_baseline
assert identity.product_manifest(source) == before_candidate
assert hashlib.sha256((baseline / binary_relative).read_bytes()).hexdigest() == baseline_binary_sha
summary = json.loads((output / 'paired/summary.json').read_text())
record = {'diagnosticOnly': True, 'formalQualification': False, 'productionBaseline': '57cfddb61834fb1d3c5c2e573ff6d986124045e2', 'singleChangedProductFile': differences[0], 'baselineBinarySha256': baseline_binary_sha, 'candidateBinarySha256': hashlib.sha256((source / binary_relative).read_bytes()).hexdigest(), 'baselineProductSha256': identity.manifest_digest(before_baseline), 'candidateProductSha256': identity.manifest_digest(before_candidate), 'commonHarnessSha256': identity.manifest_digest(identity.harness_manifest(source)), 'rounds': 3, 'command': command, 'comparisons': summary['comparisons']}
(output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print((output / 'paired/summary.md').read_text(), flush=True)
print(json.dumps(record, indent=2), flush=True)
