#!/usr/bin/env python3
"""Diagnostic only: isolate each already-built checked-reservation delta."""
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys
root=Path('/mnt')
lock=(root/'measurement.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,str(root/'pure-candidate/scripts'))
import benchmark_input_identity as identity
names=['pure-candidate','capacity-fit','capacity-fit-pair','capacity-fit-limit']
products={name:identity.product_manifest(root/name) for name in names}
harness=identity.harness_manifest(root/'pure-candidate')
artifacts={}
for name in names:
    assert identity.harness_manifest(root/name)==harness
    assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root/name,text=True).strip()
    binary=root/name/'packages/benchmarks/target/release/unittest_bin/yjson_benchmarks'
    artifacts[name]={'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sizeBytes':binary.stat().st_size}
output=root/'diagnostics/map-reservation-isolation'
output.mkdir()
rows={}
for number,(baseline,candidate) in enumerate(zip(names,names[1:]),1):
    changed=[path for path in sorted(set(products[baseline])|set(products[candidate])) if products[baseline].get(path)!=products[candidate].get(path)]
    assert changed==['src/lib_json_direct_writer.cj']
    folder=output/f'stage-{number}'
    command=['python3',str(root/'pure-candidate/scripts/json_pure_perf_compare.py'),'--baseline',str(root/baseline),'--candidate',str(root/candidate),'--corpus','/mnt/corpus','--output',str(folder),'--rounds','3','--idle-sample-seconds','30','--cell-timeout-seconds','180','--gate-mode','release','--case','yjsonStringEncodeLargeInt64Map','--case','yjsonStringEncodePerson']
    with (output/f'stage-{number}.log').open('x') as log:
        subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    summary=json.loads((folder/'summary.json').read_text())
    rows[str(number)]={'baseline':baseline,'candidate':candidate,'comparisons':summary['comparisons']}
    print(baseline,'->',candidate,flush=True)
    print((folder/'summary.md').read_text(),flush=True)
for name in names:
    assert identity.product_manifest(root/name)==products[name]
    binary=root/name/'packages/benchmarks/target/release/unittest_bin/yjson_benchmarks'
    assert hashlib.sha256(binary.read_bytes()).hexdigest()==artifacts[name]['sha256']
receipt={'diagnosticOnly':True,'formalQualification':False,'rounds':3,'cases':['yjsonStringEncodeLargeInt64Map','yjsonStringEncodePerson'],'sourceIsolation':'Each adjacent variant differs only in the previously frozen writer reservation change. Existing O2 artifacts reused without rebuild; no original measured snapshot changed.','harnessSha256':identity.manifest_digest(harness),'productSha256':{name:identity.manifest_digest(value) for name,value in products.items()},'artifacts':artifacts,'comparisons':rows}
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('MAP_RESERVATION_ISOLATION_COMPLETE',flush=True)
