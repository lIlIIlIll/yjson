#!/usr/bin/env python3
"""Intrusive stack sampling only; never a timing or acceptance run."""
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time

root=Path('/mnt')
case=sys.argv[1]
label=sys.argv[2]
output=root/'diagnostics'/label
output.mkdir(parents=True)
binary=root/'pure-candidate/packages/benchmarks/target/release/unittest_bin/yjson_benchmarks'
sys.path.insert(0,str(root/'pure-candidate/scripts'))
from benchmark_pure_direct import direct_entry_point, terminate_process_tree
before=hashlib.sha256(binary.read_bytes()).hexdigest()
allowed = ('PATH', 'LD_LIBRARY_PATH', 'CANGJIE_HOME', 'CANGJIE_SDK_ROOT',
           'CANGJIE_STDX_PATH', 'STDX_FFI_LIB', 'TMPDIR', 'TMP', 'TEMP',
           'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'XDG_CACHE_HOME',
           'GIT_CONFIG_GLOBAL', 'GIT_CONFIG_NOSYSTEM', 'GIT_OPTIONAL_LOCKS')
env = {name: os.environ[name] for name in allowed if name in os.environ}
control = output / 'control'
control.mkdir()
(control / 'continue').write_text(case + '\n')
env.update(cjProcessorNum='1', cjHeapSize='128MB',
           YJSON_CROSSLANG_CORPUS_DIR='/mnt/corpus',
           YJSON_PURE_DIRECT_CASE=case, YJSON_PURE_DIRECT_CONTROL=str(control))
entry = direct_entry_point(case)
command=['gdb','--nx','--quiet','--interpreter=mi2','-x','/mnt/profile-setup.gdb','--args',str(binary),'--no-color','--no-progress',f'--filter=*.{entry}']
process=subprocess.Popen(command,cwd=binary.parents[3],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
log=(output/'gdb-mi.log').open('xb')
pending=b''
serial=0
samples=[]
deadline=time.monotonic()+180

def send(command):
    global serial
    serial+=1
    process.stdin.write((str(serial)+command+'\n').encode())
    process.stdin.flush()
    return str(serial)

def receive(until,seconds=15):
    global pending
    end=min(deadline,time.monotonic()+seconds)
    lines=[]
    while time.monotonic()<end:
        while b'\n' in pending:
            raw,pending=pending.split(b'\n',1)
            text=raw.decode(errors='replace')
            lines.append(text)
            if until(text):
                return lines
        ready,_,_=select.select([process.stdout],[],[],min(.1,max(0,end-time.monotonic())))
        if ready:
            chunk=os.read(process.stdout.fileno(),65536)
            if not chunk:
                return lines
            log.write(chunk);log.flush();pending+=chunk
        if process.poll() is not None:
            return lines
    return lines

try:
    receive(lambda line:line=='(gdb) ',2)
    token=send('-gdb-set mi-async on')
    receive(lambda line:line.startswith(token+'^'))
    symbol = '_CN5yjson5YJson12encodeStreamIG_HG_CN5yjson9JsonCodecIG_ECNah12OutputStreamECN5yjson16JsonWriteOptionsE'
    token=send('-break-insert -t ' + symbol)
    inserted=receive(lambda line:line.startswith(token+'^'))
    assert any(line.startswith(token+'^done') for line in inserted), inserted
    send('-exec-run')
    entered=receive(lambda line:'breakpoint-hit' in line or 'exited-normally' in line,60)
    assert any('breakpoint-hit' in line and symbol in line for line in entered), entered
    send('-exec-continue --all')
    for index in range(24):
        events=receive(lambda line:'exited-normally' in line,.02)
        if any('exited-normally' in line for line in events) or process.poll() is not None:
            break
        send('-exec-interrupt --all')
        stopped=receive(lambda line:line.startswith('*stopped'),5)
        if not any(line.startswith('*stopped') for line in stopped):
            break
        if any('exited-normally' in line for line in stopped):
            break
        token=send('-interpreter-exec console "thread apply all bt 30"')
        receive(lambda line:line.startswith(token+'^'),10)
        samples.append({'index':index,'monotonicTime':time.monotonic()})
        send('-exec-continue --all')
    events=receive(lambda line:'exited-normally' in line,60)
    token=send('-gdb-exit')
    receive(lambda line:line.startswith(token+'^'),5)
    process.wait(timeout=5)
finally:
    terminate_process_tree(process)
    log.close()
after=hashlib.sha256(binary.read_bytes()).hexdigest()
assert before==after
receipt={'case':case,'entryPoint':entry,'sampledAfterPublicEncodeStreamEntry':True,'binarySha256':before,'samples':samples,'gdbReturnCode':process.returncode,'diagnosticOnly':True,'timingOrTestAcceptance':False,'originalCaseWorkAndAssertionsUnchanged':True,'scope':'Original direct protocol input and work; intrusive debugger and pre-created continuation used solely to locate actual encode callers, not to measure time.'}
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
