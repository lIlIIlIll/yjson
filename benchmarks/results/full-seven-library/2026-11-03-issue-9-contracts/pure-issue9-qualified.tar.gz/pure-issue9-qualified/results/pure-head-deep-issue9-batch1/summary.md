Pure direct timing protocol: `1`

| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV | Baseline max RSS KB | Candidate max RSS KB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringDecodeDeepNestedProfiles` | 113.597 us | 113.249 us | 0.997x | 0.3% | 8/11 | 0.60% | 0.43% | 170044 | 169948 |
| `yjsonBytesDecodeDeepNestedProfiles` | 118.207 us | 118.417 us | 1.002x | -0.2% | 4/11 | 0.54% | 0.57% | 169908 | 169684 |
