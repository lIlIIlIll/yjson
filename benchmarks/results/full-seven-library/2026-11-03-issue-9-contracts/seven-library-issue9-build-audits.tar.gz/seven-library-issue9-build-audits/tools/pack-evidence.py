#!/usr/bin/env python3
"""Package completed source-bound measurements, preserving raw owner metadata."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/mnt')
REPO = ROOT / 'workspace/repo'
lock = (ROOT / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
sys.path.insert(0, str(REPO / 'scripts'))
sys.path.insert(0, str(REPO / 'benchmarks/full-seven-library'))
import benchmark_input_identity as identity
import run_full as runner
expected = json.loads((ROOT / 'production-export-receipt.json').read_text())
ready = json.loads((ROOT / 'seven-build-audit/receipts/ready.json').read_text())
pure = json.loads((ROOT / 'pure-snapshot-receipt.json').read_text())
qualified = json.loads((ROOT / 'pure-qualified.json').read_text())
assert ready['status'] == qualified['status'] == 'PASS'
assert identity.product_manifest(REPO) == expected['productManifest']
assert identity.harness_manifest(REPO) == expected['harnessManifest']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected['productionMain']
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=REPO, text=True).strip()
OUTPUT = ROOT / 'raw-packets'
OUTPUT.mkdir()
AUX = ROOT / 'packet-provenance'
AUX.mkdir()

def receipt(name, value):
    path = AUX / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return path

def tree(folder):
    return {path.relative_to(folder).as_posix(): path for path in folder.rglob('*') if path.is_file()}

def package(name, sources):
    target = OUTPUT / (name + '.tar.gz')
    inventory = {}
    with tarfile.open(target, 'w:gz') as archive:
        for relative, source in sorted(sources.items()):
            assert source.is_file() and not source.is_symlink(), relative
            assert not relative.startswith('/') and '..' not in Path(relative).parts
            payload = source.read_bytes()
            assert not payload.startswith((b'\x7fELF', b'MZ', b'PK\x03\x04', b'!<arch>')), relative
            payload.decode('utf-8')
            member = archive.gettarinfo(str(source), arcname=name + '/' + relative)
            assert member.isfile()
            with source.open('rb') as stream:
                archive.addfile(member, stream)
            inventory[relative] = {'sha256': hashlib.sha256(payload).hexdigest(), 'sizeBytes': len(payload)}
    with tarfile.open(target, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(inventory)
        for member in members:
            relative = member.name[len(name) + 1:]
            assert member.isfile()
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == inventory[relative]['sha256']
    return {'archive': target.name, 'root': name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'sizeBytes': target.stat().st_size, 'regularFiles': len(inventory), 'memberPayloads': inventory, 'allSourcePayloadsUnchanged': True, 'publication': 'Private raw packet; owner and compression metadata must be audited before publication.'}

archives = []
for number in (1, 2):
    result = ROOT / f'results/seven-issue9-batch{number}'
    result_qualification = json.loads((result / 'qualification.json').read_text())
    state_path = ROOT / f'logs/seven-issue9-batch{number}.state.json'
    state = json.loads(state_path.read_text())
    assert result_qualification['status'] == 'PASS' and result_qualification['formalCells'] == 770
    assert result_qualification['sourceSdkArtifactIdentityUnchanged'] is True
    assert state['status'] == 'COMPLETE' and state['returnCode'] == 0
    assert state['driverSha256'] == hashlib.sha256((ROOT / 'run-seven.py').read_bytes()).hexdigest()
    assert (result / 'COMPLETE').is_file()
    for field in ('productionMain', 'productionMacro', 'productSourceSha256', 'effectiveHarnessSha256'):
        assert result_qualification[field] == expected[field], field
    sources = tree(result)
    assert not any(name.startswith('task-control/') for name in sources)
    sources.update({'task-control/state.json': state_path, 'task-control/driver.py': ROOT / 'run-seven.py', 'task-control/driver.log': ROOT / f'logs/seven-issue9-batch{number}.log'})
    archives.append(package(f'seven-library-issue9-batch{number}', sources))

sources = {}
for folder in sorted(ROOT.glob('seven-build-audit*')):
    if folder.is_dir():
        sources.update({folder.name + '/' + relative: path for relative, path in tree(folder).items()})
for name in ['prepare-seven.py', 'run-seven.py', 'run-pure.py', 'qualify-pure.py', 'audit-pure-build.py', 'cjpm', 'with-sts120', 'pack-evidence.py', 'verify-pure.py', 'verify-failed-pure.py', 'offline_compiler_audit.py']:
    sources['tools/' + name] = ROOT / name
for name in ['production-export-receipt.json', 'pure-snapshot-receipt.json', 'pure-qualified.json']:
    sources['receipts/' + name] = ROOT / name
archives.append(package('seven-library-issue9-build-audits', sources))

sources = {}
result_directories = sorted((ROOT / 'results').glob('pure-*-issue9-batch*'))
assert len(result_directories) in (2, 3, 4)
for result in result_directories:
    state_path = ROOT / 'logs' / (result.name + '.json')
    state = json.loads(state_path.read_text())
    assert state['status'] == 'PASS' and state['returnCode'] == 0
    assert state['driverSha256'] == hashlib.sha256((ROOT / 'run-pure.py').read_bytes()).hexdigest()
    sources.update({'results/' + result.name + '/' + relative: path for relative, path in tree(result).items()})
    sources['logs/' + state_path.name] = state_path
    sources['logs/' + result.name + '.log'] = ROOT / 'logs' / (result.name + '.log')
for name in ['pure-qualified.json', 'pure-snapshot-receipt.json', 'production-export-receipt.json', 'run-pure.py', 'qualify-pure.py', 'audit-pure-build.py', 'cjpm']:
    sources['task-control/' + name] = ROOT / name
archives.append(package('pure-issue9-qualified', sources))

sources = {}
for name, entry in pure['snapshots'].items():
    snapshot = ROOT / name
    assert identity.product_manifest(snapshot) == entry['productManifest']
    assert identity.harness_manifest(snapshot) == entry['harnessManifest']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=snapshot, text=True).strip() == entry['commit']
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=snapshot, text=True).strip()
    for relative in set(entry['productManifest']) | set(entry['harnessManifest']):
        sources['snapshots/' + name + '/' + relative] = snapshot / relative
    for relative, value in entry['macroSourceManifest'].items():
        path = snapshot / 'packages/yjson_macros' / relative
        assert runner.file_digest(path) == value, (name, relative)
        sources['snapshots/' + name + '/packages/yjson_macros/' + relative] = path
    for relative in ['LICENSE', 'native/vendor/yyjson/LICENSE', 'packages/yjson_macros/LICENSE']:
        if (snapshot / relative).is_file(): sources['snapshots/' + name + '/' + relative] = snapshot / relative
for pin in sorted({entry['macroSourceCommit'] for entry in pure['snapshots'].values()}):
    origins = [entry['macroOriginManifest'] for entry in pure['snapshots'].values() if entry['macroSourceCommit'] == pin]
    assert all(origin == origins[0] for origin in origins)
    for relative, value in origins[0].items():
        path = ROOT / 'macro-origins' / pin / relative
        assert runner.file_digest(path) == value, (pin, relative)
        sources['macro-origins/' + pin + '/' + relative] = path
sources['provenance/pure-snapshot-receipt.json'] = ROOT / 'pure-snapshot-receipt.json'
corpus = json.loads((ROOT / qualified['releaseOutput'] / 'provenance.json').read_text())['corpus']
assert len(corpus['manifest']) == 3
assert identity.manifest_digest(corpus['manifest']) == corpus['sha256'] == 'db9b0242e01fb4cfa2468245f8be5329a0967052412b7340f12c468c6202a70f'
for relative, value in corpus['manifest'].items():
    path = ROOT / 'corpus' / relative
    assert runner.file_digest(path) == value, relative
    sources['corpus/' + relative] = path
sources['provenance/corpus-manifest.json'] = receipt('corpus-manifest.json', corpus)
archives.append(package('pure-issue9-source-inputs', sources))

sources = {
    'run_full.py': REPO / 'benchmarks/full-seven-library/run_full.py',
    'summarize_full.py': REPO / 'benchmarks/full-seven-library/summarize_full.py',
    'benchmark_fixed_work.py': REPO / 'scripts/benchmark_fixed_work.py',
    'fixture-preflight-overlay.patch': REPO / 'benchmarks/full-seven-library/fixture-preflight-overlay.patch',
    'provenance/production-export-receipt.json': ROOT / 'production-export-receipt.json',
    'provenance/complete-product-manifest.json': receipt('complete-product-manifest.json', expected['productManifest']),
    'provenance/complete-effective-harness-manifest.json': receipt('complete-effective-harness-manifest.json', expected['harnessManifest']),
    'provenance/peer-source-verification.json': receipt('peer-source-verification.json', {'status': 'PASS', 'sourceTreeDigests': ready['sourceTreeDigests'], 'overlayFiles': ready['overlayFiles'], 'peerArtifacts': {name: value for name, value in ready['artifacts'].items() if name != 'seven-yjson'}, 'peerReusePolicy': ready['peerReusePolicy']}),
}
for relative in ['json4cj-license-source-receipt.json', 'json4cj-manifest-adaptations-from-a185.patch', 'json4cj-upstream-README.md']:
    sources['provenance/' + relative] = ROOT / 'peer-provenance' / relative
for relative in set(expected['productManifest']) | set(expected['harnessManifest']):
    sources['source-inputs/repo/' + relative] = REPO / relative
for name, expected_digest in ready['sourceTreeDigests'].items():
    folder = ROOT / 'workspace' / name
    assert runner.source_digest(folder) == expected_digest, name
    for current, dirs, files in os.walk(folder):
        dirs[:] = [directory for directory in dirs if directory not in {'.git', 'target', 'build-script-cache', '__pycache__'}]
        for filename in files:
            path = Path(current) / filename
            if path.suffix in {'.cj', '.toml', '.java', '.xml'} or filename.upper().startswith(('LICENSE', 'COPYING', 'NOTICE')):
                relative = path.relative_to(folder).as_posix()
                sources['source-inputs/' + name + '/' + relative] = path
archives.append(package('seven-library-issue9-harness', sources))
record = {'status': 'PASS', 'productionMain': expected['productionMain'], 'productionMacro': expected['productionMacro'], 'scope': 'Complete formal results, source inputs, tools, failed preparation logs and build audits. No Git metadata or executable artifacts. Raw packet metadata has not been projected for publication.', 'archives': archives}
(OUTPUT / 'server-packet-inventory.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({**record, 'archives': [{key: value for key, value in item.items() if key != 'memberPayloads'} for item in archives]}, indent=2), flush=True)
