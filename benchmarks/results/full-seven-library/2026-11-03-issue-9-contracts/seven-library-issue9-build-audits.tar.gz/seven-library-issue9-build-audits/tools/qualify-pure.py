#!/usr/bin/env python3
"""Accept complete, stable release and extra HEAD matrices without retrying cells."""
import fcntl
import hashlib
import json
from pathlib import Path
import sys

root=Path('/mnt')
lock=(root/'measurement.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,str(root/'workspace/repo/scripts'))
import json_pure_perf_compare as compare
production=json.loads((root/'production-export-receipt.json').read_text())
snapshots=json.loads((root/'pure-snapshot-receipt.json').read_text())
records={}
for mode,cases in [('release',list(compare.CASES)),('head-deep',['yjsonStringDecodeDeepNestedProfiles','yjsonBytesDecodeDeepNestedProfiles'])]:
    folder=root/f'results/pure-{mode}-issue9-batch1'
    summary=json.loads((folder/'summary.json').read_text())
    state=json.loads((root/f'logs/pure-{mode}-issue9-batch1.json').read_text())
    assert state['status']=='PASS' and state['returnCode']==0
    assert state['productionMain']==snapshots['productionMain']==production['productionMain']
    assert state['driverSha256']==hashlib.sha256((root/'run-pure.py').read_bytes()).hexdigest()
    assert summary['cases']==cases and summary['rounds']==11
    assert len(summary['direct_cells'])==len(cases)*22 and len(summary['preflight_cells'])==len(cases)*2
    assert summary['gates']['passed'] and summary['gates']['both_cv_at_most_5_percent']
    assert all(value['ratio']<=1.05 for value in summary['comparisons'].values())
    assert json.loads((folder/'compiler-audit.json').read_text())['status']=='PASS'
    records[mode]={'output':folder.relative_to(root).as_posix(),'cases':len(cases),'rounds':11,'directCells':len(summary['direct_cells']),'preflightCells':len(summary['preflight_cells']),'maximumRatio':max(value['ratio'] for value in summary['comparisons'].values()),'maximumSingleSideCvPercent':max(summary[variant][case]['cv_percent'] for variant in ('baseline','candidate') for case in cases),'summarySha256':hashlib.sha256((folder/'summary.json').read_bytes()).hexdigest(),'stateSha256':hashlib.sha256((root/f'logs/pure-{mode}-issue9-batch1.json').read_bytes()).hexdigest()}
record={'status':'PASS','productionMain':production['productionMain'],'productionMacro':production['productionMacro'],'productSourceSha256':production['productSourceSha256'],'effectiveHarnessSha256':production['effectiveHarnessSha256'],'releaseOutput':records['release']['output'],'headDeepOutput':records['head-deep']['output'],'batches':records,'noiseRetryRequired':False,'formalMatrixNarrowed':False,'thresholdChanged':False,'cellRetries':False,'qualificationScope':'Complete Pure release and extra HEAD Deep Nested only. Seven-library and final CI remain separate.'}
path=root/'pure-qualified.json'
assert not path.exists()
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
