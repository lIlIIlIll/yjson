#!/usr/bin/env python3
"""Run one immutable, complete Pure batch; never retry individual cells."""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path('/mnt')
mode, batch_text = sys.argv[1:]
assert mode in ('release', 'head-deep')
batch = int(batch_text)
assert batch in (1, 2)
lock = (ROOT / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
receipt = json.loads((ROOT / 'pure-snapshot-receipt.json').read_text())
source = ROOT / 'pure-candidate'
sys.path.insert(0, str(source / 'scripts'))
import benchmark_input_identity as identity
baseline = 'pure-head' if mode == 'head-deep' else 'pure-baseline'
ready = json.loads((ROOT / 'seven-build-audit/receipts/ready.json').read_text())
sdk_expected = json.loads((ROOT / 'seven-build-audit/receipts/sdk-manifest.json').read_text())
assert ready['status'] == 'PASS'
assert ready['productionMain'] == receipt['productionMain']
assert hashlib.sha256(json.dumps(sdk_expected, sort_keys=True, indent=2).encode()).hexdigest() == ready['sdkManifestSha256']

def file_digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def capture(command, cwd=None):
    return subprocess.check_output(command, cwd=cwd, text=True, stderr=subprocess.STDOUT).strip()

def verify():
    for name in (baseline, 'pure-candidate'):
        folder = ROOT / name
        expected = receipt['snapshots'][name]
        assert capture(['git', 'rev-parse', 'HEAD'], folder) == expected['commit']
        assert capture(['git', 'rev-parse', 'HEAD^{tree}'], folder) == expected['tree']
        status = capture(['git', 'status', '--porcelain=v1', '--untracked-files=all'], folder)
        assert not status, (name, status)
        assert identity.product_manifest(folder) == expected['productManifest']
        assert identity.harness_manifest(folder) == expected['harnessManifest']
        macro = folder / 'packages/yjson_macros'
        for relative, value in expected['macroSourceManifest'].items():
            assert file_digest(macro / relative) == value, (name, relative)
        actual_sources = {path.relative_to(macro).as_posix() for path in (macro / 'src').rglob('*.cj')}
        expected_sources = {relative for relative in expected['macroSourceManifest'] if relative.startswith('src/') and relative.endswith('.cj')}
        assert actual_sources == expected_sources, name
    assert identity.harness_manifest(ROOT / baseline) == identity.harness_manifest(source)
    sdk_current = {}
    for path in sorted((ROOT / 'sdk').rglob('*')):
        relative = path.relative_to(ROOT / 'sdk').as_posix()
        if path.is_symlink():
            sdk_current[relative] = {'symlink': os.readlink(path)}
        elif path.is_file():
            sdk_current[relative] = {'sha256': file_digest(path)}
    assert sdk_current == sdk_expected

verify()
assert capture(['python3', '/mnt/workspace/repo/scripts/validate_cangjie_sts.py', '--check-installed']) == '1.2.0'
output = ROOT / 'results' / f'pure-{mode}-issue9-batch{batch}'
log_path = ROOT / 'logs' / f'pure-{mode}-issue9-batch{batch}.log'
state_path = log_path.with_suffix('.json')
assert not output.exists() and not log_path.exists() and not state_path.exists()
os.environ['YJSON_REAL_CJPM'] = shutil.which('cjpm')
os.environ['YJSON_PURE_BUILD_AUDIT_ROOT'] = str(output)
os.environ['PATH'] = '/mnt/build-audit-bin:' + os.environ['PATH']
command = ['python3', str(source / 'scripts/json_pure_perf_compare.py'),
           '--baseline', str(ROOT / baseline), '--candidate', str(source),
           '--corpus', '/mnt/corpus', '--output', str(output), '--rounds', '11',
           '--idle-sample-seconds', '30', '--cell-timeout-seconds', '180',
           '--gate-mode', 'release', '--rebuild']
if mode == 'release':
    command += ['--enforce']
else:
    command += ['--case', 'yjsonStringDecodeDeepNestedProfiles',
                '--case', 'yjsonBytesDecodeDeepNestedProfiles']
state = {'command': command, 'mode': mode, 'batch': batch,
         'productionMain': receipt['productionMain'], 'productionMacro': receipt['productionMacro'],
         'sdkManifestSha256': ready['sdkManifestSha256'],
         'commonHarnessSha256': receipt['commonHarnessSha256'], 'startedUnixTime': time.time(),
         'driverSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'status': 'RUNNING'}
state_path.write_text(json.dumps(state, indent=2) + '\n')
try:
    with log_path.open('x') as log:
        process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            log.write(line)
            log.flush()
            print(line, end='', flush=True)
        result = process.wait()
    state['returnCode'] = result
    assert result == 0, ('first batch failure', result)
    subprocess.run(['python3', '/mnt/audit-pure-build.py', str(output),
                    baseline, 'pure-candidate'], check=True)
    summary = json.loads((output / 'summary.json').read_text())
    state['gates'] = summary['gates']
    state['comparisons'] = summary['comparisons']
    verify()
    assert summary['gates']['passed'] is True, 'paired regression gate failed'
    state['status'] = 'PASS'
except BaseException as error:
    state.update(status='FAIL', firstException=type(error).__name__, firstCause=str(error))
    raise
finally:
    state['finishedUnixTime'] = time.time()
    state_path.write_text(json.dumps(state, indent=2) + '\n')
print('PURE_COMPLETE', mode, batch, flush=True)
