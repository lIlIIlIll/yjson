#!/usr/bin/env python3
"""Task-only exact-source formal run; preserves first failure and never retries."""
import collections
import csv
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/mnt')
WORKSPACE = ROOT / 'workspace'
REPO = WORKSPACE / 'repo'
number = int(sys.argv[1])
assert number in (1, 2)
output = ROOT / f'results/seven-issue9-batch{number}'
assert not output.exists()
log = ROOT / f'logs/seven-issue9-batch{number}.log'
assert not log.exists()
lock = (ROOT / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
ready = json.loads((ROOT / 'seven-build-audit/receipts/ready.json').read_text())
assert ready['status'] == 'PASS'
pure_qualified = json.loads((ROOT / 'pure-qualified.json').read_text())
assert pure_qualified['status'] == 'PASS'
for name in ('releaseOutput', 'headDeepOutput'):
    assert json.loads((ROOT / pure_qualified[name] / 'summary.json').read_text())['gates']['passed']
if number == 2:
    assert json.loads((ROOT / 'results/seven-issue9-batch1/qualification.json').read_text())['status'] == 'PASS'
sys.path.insert(0, str(REPO / 'scripts'))
import benchmark_input_identity as identity
import benchmark_pure_direct
import check_seven_library_evidence as evidence
expected = json.loads((ROOT / 'production-export-receipt.json').read_text())
sys.path.insert(0, str(REPO / 'benchmarks/full-seven-library'))
spec = importlib.util.spec_from_file_location('seven_runner', REPO / 'benchmarks/full-seven-library/run_full.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
for field in ('productionMain', 'productionMacro', 'productSourceSha256', 'effectiveHarnessSha256'):
    assert ready[field] == expected[field], field
pure_receipt = json.loads((ROOT / 'pure-snapshot-receipt.json').read_text())
for field in ('productionMain', 'productionMacro'):
    assert pure_receipt[field] == expected[field], field

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def verify():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected['productionMain']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO / 'packages/yjson_macros', text=True).strip() == expected['productionMacro']
    assert identity.product_manifest(REPO) == expected['productManifest']
    assert identity.harness_manifest(REPO) == expected['harnessManifest']
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=REPO, text=True).strip()
    for name, artifact in ready['artifacts'].items():
        assert digest(ROOT / artifact['path']) == artifact['sha256'], name
    sdk = json.loads((ROOT / 'seven-build-audit/receipts/sdk-manifest.json').read_text())
    assert hashlib.sha256(json.dumps(sdk, sort_keys=True, indent=2).encode()).hexdigest() == ready['sdkManifestSha256']
    current_sdk = {}
    for path in sorted((ROOT / 'sdk').rglob('*')):
        relative = path.relative_to(ROOT / 'sdk').as_posix()
        if path.is_symlink():
            current_sdk[relative] = {'symlink': os.readlink(path)}
        elif path.is_file():
            current_sdk[relative] = {'sha256': digest(path)}
    assert current_sdk == sdk
    for relative, value in ready['overlayFiles'].items():
        assert digest(WORKSPACE / relative) == value, relative
    for relative, value in ready['sourceTreeDigests'].items():
        assert runner.source_digest(WORKSPACE / relative) == value, relative

verify()
corpus = json.loads((ROOT / pure_qualified['releaseOutput'] / 'provenance.json').read_text())['corpus']['manifest']
assert len(corpus) == 3
for relative, value in corpus.items():
    assert digest(ROOT / 'corpus' / relative) == value, relative
print('FRESH_IDLE_SAMPLE', number, flush=True)
sample = benchmark_pure_direct.select_idle_cpu_triple(30)
core = sample['physical_cores'][0]
cpu = core['cpu']
siblings = [int(value) for value in core['siblings']]
assert len(siblings) == 2 and cpu in siblings
sibling = next(value for value in siblings if value != cpu)
selection = {'sample_seconds': 30, 'selected_cpu': cpu, 'selected_sibling': sibling, 'utilization_percent': [core['utilization_percent'][str(cpu)], core['utilization_percent'][str(sibling)]], 'acceptable_both_threads_below_1_percent': True, 'actualFullCpuWindow': sample, 'selectionMethod': 'first physical core from canonical full idle topology sample; original seven-library single-CPU binding'}
assert all(value < 1 for value in selection['utilization_percent'])
(WORKSPACE / 'cpu-selection.json').write_text(json.dumps(selection, indent=2) + '\n')
env = os.environ.copy()
env.update(YJSON_RELEASE_COMMIT=ready['productionMain'], YJSON_PRODUCT_SOURCE_SHA256=ready['productSourceSha256'], YJSON_EFFECTIVE_HARNESS_SHA256=ready['effectiveHarnessSha256'], YJSON_MEASURED_OVERLAY_SHA256=ready['measuredOverlaySha256'], YJSON_CROSSLANG_CORPUS_DIR='/mnt/corpus')
command = ['python3', str(REPO / 'benchmarks/full-seven-library/run_full.py'), '--workspace', str(WORKSPACE), '--stdx-sdk-root', '/mnt/sdk', '--runs', '11', '--cpu', str(cpu), str(output)]
state = {'status': 'RUNNING', 'batch': number, 'command': command, 'driverSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'startedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'retry': False, 'buildDuringTiming': False, 'peerArtifacts': 'verified reuse, not fresh rebuild', 'productionArtifact': 'fresh exact-source O2 build before timing'}
state_path = ROOT / f'logs/seven-issue9-batch{number}.state.json'
state_path.write_text(json.dumps(state, indent=2) + '\n')
try:
    with log.open('x') as stream:
        process = subprocess.Popen(command, env=env, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in process.stdout:
            stream.write(line)
            stream.flush()
            print(line, end='', flush=True)
        code = process.wait()
    state['returnCode'] = code
    assert code == 0, ('formal runner first failure', code)
    assert (output / 'COMPLETE').is_file()
    with (output / 'manifest.csv').open() as stream:
        cells = list(csv.DictReader(stream))
    assert len(cells) == 770
    counts = collections.Counter((row['library'], row['workload_id']) for row in cells)
    assert len(counts) == 70 and set(counts.values()) == {11}
    assert {int(row['round']) for row in cells} == set(range(1, 12))
    subprocess.run(['python3', str(REPO / 'benchmarks/full-seven-library/summarize_full.py'), str(output), '--min-runs', '11'], cwd=ROOT, env=env, check=True)
    metadata = json.loads((output / 'metadata.json').read_text())
    validated_metadata, fixed_work = evidence.read_metadata_and_validate(output, expected['candidateBinding'])
    assert validated_metadata == metadata
    assert len(fixed_work) == 10
    assert sum(row['library'] == 'yjson' for row in cells) == 110
    assert metadata['versions']['yjson_commit'] == ready['productionMain']
    for actual, expected_key in [('product_source_sha256', 'productSourceSha256'), ('effective_harness_sha256', 'effectiveHarnessSha256'), ('measured_overlay_sha256', 'measuredOverlaySha256')]:
        assert metadata[actual] == ready[expected_key]
    assert metadata['cpu_selection'] == selection
    verify()
    summary = json.loads((output / 'summary.json').read_text())
    assert len(summary) == 10 and all(row['rounds'] == 11 for row in summary)
    qualification = {'status': 'PASS', 'batch': number, 'formalCells': 770, 'workloadLibraryPairs': 70, 'roundsPerPair': 11, 'correctnessPreflight': 'all seven canonical fixtures passed', 'productionMain': ready['productionMain'], 'productionMacro': ready['productionMacro'], 'productSourceSha256': ready['productSourceSha256'], 'effectiveHarnessSha256': ready['effectiveHarnessSha256'], 'measuredOverlaySha256': ready['measuredOverlaySha256'], 'sourceSdkArtifactIdentityUnchanged': True, 'stableRows': sum(row['stable_cv_le_5_percent'] for row in summary), 'noisyRows': sum(not row['stable_cv_le_5_percent'] for row in summary), 'corpusManifest': corpus}
    qualification.update(canonicalRawCellValidation=True, positiveRssSidecars=770, yjsonFixedWorkProofs=110)
    (output / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
    state['status'] = 'COMPLETE'
    print('SEVEN_COMPLETE', json.dumps(qualification), flush=True)
except BaseException as error:
    state.update(status='FAILED', firstException=type(error).__name__, firstCause=str(error))
    raise
finally:
    state['finishedAtUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')
