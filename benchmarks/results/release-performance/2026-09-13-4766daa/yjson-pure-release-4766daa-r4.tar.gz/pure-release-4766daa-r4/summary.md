| Case | Baseline median | Candidate median | C/B | Improvement | Wins | Baseline CV | Candidate CV |
|---|---:|---:|---:|---:|---:|---:|---:|
| `yjsonStringEncodeLargeInt64Map` | 5.402 us | 5.491 us | 1.016x | -1.6% | 3/11 | 3.78% | 2.08% |
| `yjsonStringDecodeLargeInt64Map` | 31.744 us | 25.364 us | 0.799x | 20.1% | 11/11 | 1.74% | 3.02% |
| `yjsonBytesDecodeLargeInt64Map` | 35.091 us | 26.577 us | 0.757x | 24.3% | 11/11 | 5.19% | 3.92% |
| `yjsonStringEncodeDeepNestedProfiles` | 41.872 us | 41.523 us | 0.992x | 0.8% | 7/11 | 2.15% | 0.94% |
| `yjsonStringDecodeDeepNestedProfiles` | 301.747 us | 302.336 us | 1.002x | -0.2% | 4/11 | 5.02% | 5.42% |
| `yjsonBytesDecodeDeepNestedProfiles` | 307.610 us | 303.911 us | 0.988x | 1.2% | 8/11 | 3.78% | 6.70% |
| `yjsonStringEncodePerson` | 1.436 us | 1.490 us | 1.038x | -3.8% | 4/11 | 2.39% | 3.32% |
| `yjsonStringDecodePerson` | 7.622 us | 7.524 us | 0.987x | 1.3% | 8/11 | 4.08% | 7.33% |
| `yjsonStringEncodeLargeProfileArray` | 25.549 us | 25.670 us | 1.005x | -0.5% | 5/11 | 1.41% | 0.95% |
| `yjsonStringDecodeLargeProfileArray` | 73.347 us | 74.186 us | 1.011x | -1.1% | 1/11 | 1.01% | 1.06% |
| `parseStringRecords64k` | 2251.155 us | 2311.236 us | 1.027x | -2.7% | 4/11 | 5.40% | 4.53% |
| `parseBytesRecords64k` | 2335.904 us | 2288.350 us | 0.980x | 2.0% | 6/11 | 4.01% | 3.63% |
| `parseStringRecords1m` | 30801.024 us | 31180.032 us | 1.012x | -1.2% | 4/11 | 7.71% | 12.95% |
| `parseBytesRecords1m` | 31833.728 us | 32027.947 us | 1.006x | -0.6% | 6/11 | 10.25% | 5.53% |
| `yjsonStringEncodeProfileBundle` | 7.001 us | 6.940 us | 0.991x | 0.9% | 10/11 | 0.87% | 0.73% |
| `yjsonStringDecodeProfileBundle` | 15.595 us | 15.361 us | 0.985x | 1.5% | 7/11 | 2.07% | 3.21% |
| `yjsonBytesEncodeProfileBundle` | 9.007 us | 9.040 us | 1.004x | -0.4% | 5/11 | 2.58% | 2.17% |
| `yjsonBytesDecodeProfileBundle` | 17.920 us | 17.749 us | 0.990x | 1.0% | 8/11 | 1.77% | 4.51% |
| `yjsonStringEncodeEscapedUnicodeString` | 1.389 us | 1.385 us | 0.997x | 0.3% | 6/11 | 3.57% | 6.88% |
| `yjsonBytesEncodeEscapedUnicodeString` | 1.295 us | 1.310 us | 1.012x | -1.2% | 1/11 | 3.04% | 1.91% |
| `decodePersonChunk4k` | 62.953 us | 61.857 us | 0.983x | 1.7% | 7/11 | 5.25% | 5.49% |
| `decodeRecords64kChunk4k` | 11325.252 us | 11226.163 us | 0.991x | 0.9% | 8/11 | 2.92% | 16.56% |
| `encodePersonMemory` | 9.516 us | 9.293 us | 0.977x | 2.3% | 9/11 | 4.16% | 5.77% |
| `encodeRecords64kMemory` | 1302.578 us | 1306.314 us | 1.003x | -0.3% | 3/11 | 2.79% | 2.69% |
